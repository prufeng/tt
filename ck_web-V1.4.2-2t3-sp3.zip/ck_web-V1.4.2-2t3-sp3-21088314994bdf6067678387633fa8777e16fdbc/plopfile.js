const notEmpty = (name) => {
  return (v) => {
    if (!v || v.trim === '') {
      return `${name} is required`
    } else {
      return true
    }
  }
}

const viewGenerator = {
  description: 'generate a view',
  prompts: [
    {
      type: 'input',
      name: 'module',
      message: 'view module please:',
      validate: notEmpty('module'),
    },
    {
      type: 'input',
      name: 'name',
      message: 'view name please:',
      validate: notEmpty('name'),
    },
    {
      type: 'input',
      name: 'prop',
      message: 'view a prop example, eg:name.',
      validate: notEmpty('prop'),
    },
    {
      type: 'input',
      name: 'label',
      message: 'view a label example, eg:名称.',
      validate: notEmpty('label'),
    },
    {
      type: 'checkbox',
      name: 'blocks',
      message: 'Blocks:',
      choices: [
        {
          name: '<template>',
          value: 'template',
          checked: true,
        },
        {
          name: '<script>',
          value: 'script',
          checked: true,
        },
        {
          name: 'style',
          value: 'style',
          checked: true,
        },
      ],
      validate(value) {
        if (value.indexOf('script') === -1 && value.indexOf('template') === -1) {
          return 'View require at least a <script> or <template> tag.'
        }
        return true
      },
    },
  ],
  actions: (data) => {
    const module = '{{module}}'
    const name = '{{name}}'
    const prop = '{{prop}}'
    const label = '{{label}}'
    const actions = [
      {
        type: 'add',
        path: `src/views/${module}/${name}/index.vue`,
        templateFile: 'plop-templates/index.hbs',
        data: {
          module: module,
          name: name,
          prop: prop,
          label: label,
          template: data.blocks.includes('template'),
          script: data.blocks.includes('script'),
          style: data.blocks.includes('style'),
        },
      },
      {
        type: 'add',
        path: `src/views/${module}/${name}/edit.vue`,
        templateFile: 'plop-templates/edit.hbs',
        data: {
          name: name,
          prop: prop,
          label: label,
          template: data.blocks.includes('template'),
          script: data.blocks.includes('script'),
          style: data.blocks.includes('style'),
        },
      },
      {
        type: 'add',
        path: `src/views/${module}/${name}/columns.ts`,
        templateFile: 'plop-templates/columns.hbs',
        data: {
          name: name,
          prop: prop,
          label: label,
          template: data.blocks.includes('template'),
          script: data.blocks.includes('script'),
          style: data.blocks.includes('style'),
        },
      },
      {
        type: 'add',
        path: `src/apis/${module}/${name}.ts`,
        templateFile: 'plop-templates/api.hbs',
        abortOnFail: false,
        data: {
          module: module,
          name: name,
        },
      },
      // {
      //   type: 'modify',
      //   path: `src/router/async-component.js`,
      //   pattern: /}/g,
      //   template: `,'{{name}}/index': () => import('@/views/{{name}}/index')}`
      // }
    ]

    return actions
  },
}

export default function (plop) {
  // create your generators here
  plop.setGenerator('view', viewGenerator)
}
