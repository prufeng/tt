window.g = {
  // axiosBaseUrl: '/' + 'rk-scaffolding',
  // axiosBaseUrl: 'http://47.100.252.211:9999', // 服务接口 公司内部测试环境发送不
  axiosBaseUrl: 'http://localhost:9999',      // 本地接口
  // axiosBaseUrl: '/',    // 从当前浏览器地址和端口号作为根目录，发起请求。 放在jar包里用 /, 用户不用再改配置

  /*第三方登录地址 二代系统登录地址或者星展MFA登录地址或其他第三方登录地址*/
  // thirdPartyLoginUrl:'http://localhost:8080/oauth/login.html',
  // thirdPartyLoginUrl:'http://47.100.252.211:10004/oauth/login.html',
  thirdPartyLoginUrl:'http://47.100.252.211:10005/oauth/login.html',
  // thirdPartyLoginUrl:'http://localhost:10012/view/index.html#/login',
}
