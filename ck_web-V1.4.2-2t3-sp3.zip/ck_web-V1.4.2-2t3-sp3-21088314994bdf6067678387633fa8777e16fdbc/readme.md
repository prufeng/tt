
## 打war包注意事项
.en.production  todo的描述内容

打包时都要加/view/ , 访问时不加，yml中的配置会自动加

## 08-20 打包记录 东方汇 
    env.production  VITE_CONFIG_BASE=/view/

配置说明：本地jar包测试webUrl 
    添加/view/, 可以访问
    不加/view/, 控制台报index.html找不到，但会自动寻找正确的文件路径

## 08-20 打包记录 tomcat
    env.production  VITE_CONFIG_BASE=/view/

配置说明：本地tomcat测试webUrl
    添加/view/, 可以访问
    不加/view/, 不能访问  


### 公司内部测试环境发布 47.100.252.211
1. 参考打包配置，进行打包
2. 发布目录 home/wwwwroot/ck
3. 

## 打包配置修改
tomcat:
1. request.ts base路径配置 
2. vite.config.ts base路径配置
3. public/config.js  axiosBaseUrl 连接接口的地址， thirdPartyLoginUrl：权限登录地址
4. TEditor.vue 引用路径前加/view/
5. 启动时由权限系统登录，跳转地址在子系统管理里设置

## 环境
1. tomcat2 测试环节权限系统，2代的  10002
2. tomcat3 开发环境权限系统，2代的  10003, 本地开发使用
3. ngix 发布的测试环境web  9998
4. 10003 / 10002 -> 9998

# vite 配置 公共基础路径， 以及 vue-router 的路由前缀 ， war 包时， 需要 rk-fra（war包名，webapps 下的 app名），
# jar包时，没有 app名，直接去掉 rk-fra 就可以了
VITE_CONFIG_BASE=/rk-fra/view/
# vite 配置 打包后的 输出路径（相对于 项目根目录)
VITE_CONFIG_BUILD_OUT_DIR=view

# api配置 yml
rk:
global:
web:
resource-locations:
- file:view/   对应的是  静态资源的 路径，    file 表示 在系统中的路径，  classpath 表示在 jar 包里的 路径
resource-handler:
- /view/**   对应的就是  VITE_CONFIG_BASE=/rk-fra/view/


## 初始化

```sh
# npm
npm install
# yarn
yarn
```

## 配置后端代理

配置 `.env` 中 后端代理

```sh
vim src/.env

# 被代理的 后端服务地址
VITE_CONFIG_SERVER_PROXY_TARGET=http://localhost:9999/
```

## apis

`oauth.ts` 具体接口 `url` 修改

```ts
// src/apis/oauth.ts

export function login(data: any): Promise<RS<TokenInfo>> {
  return service({
    url: '/auth/login',
    method: 'POST',
    data,
    headers: {
      'Content-Type': 'application/json',
    },
  })
}

export function logout(headers: AxiosRequestHeaders) {
  return service({
    url: '/auth/logout',
    method: 'POST',
    headers,
  })
}

export function getUserResources(headers: AxiosRequestHeaders) {
  return service({
    url: '/auth/getUserResources',
    method: 'POST',
    headers,
  })
}

export function findAllTenantList(data = {}) {
  return service({
    url: '/auth/tenant/selectList',
    method: 'post',
    data,
  })
}

export function getCurrentBizData(headers: AxiosRequestHeaders): Promise<RS<any>> {
  return service({
    url: '/auth/rkSysBizData/getCurrentBizData',
    method: 'POST',
    headers,
  })
}
```

`user.ts` 具体接口 `url` 修改

```ts
// src/apis/user.ts
```

## 启动

```sh
# npm
npm run dev
# yarn
yarn dev
```

## 后台菜单配置 和 前端菜单配置切换

```ts
// src/store/user.ts  loadUserResources()
// phase 1:----------------------------------
// 未打包前，使用前端 asyncRoutes 配置
let accessedRoutes = asyncRoutes
if (import.meta.env.PROD) {
  accessedRoutes = buildAsyncRoutes(treeData(res.data.menuList))
}
// phase 2:----------------------------------
// 只使用 后端菜单 配置
let accessedRoutes = asyncRoutes
// if (import.meta.env.PROD) {
accessedRoutes = buildAsyncRoutes(treeData(res.data.menuList))
// }
```

## 打包

```sh
# npm
npm run build
# yarn
yarn build
```

## 新建模块

1. 快速生成新模块的标准页面

```sh
# npm
npm run new
# yarn
yarn new
```

2. 补充 `columns.ts` 字段信息 和 `apis/`下 接口信息

3. 在标准页面上 其它 自定义开发

## riking-layout 标准页面

RedirectView, 刷新页面
LayoutView, 页面布局
BlankView, 空白页面
NotFoundView, 404 页面
BatchOptMessage, 批量处理提示
DialogFormView, 弹出层表单
UserExportFilePage 我的下载
UserInfoView, 个人中心
DictView, 字典管理
OperateLogView, 操作日志
CacheView, 缓存管理
ParamView, 参数配置

## 打包报错

package.json 版本改为  "vite-plugin-top-level-await": "^1.4.4",


