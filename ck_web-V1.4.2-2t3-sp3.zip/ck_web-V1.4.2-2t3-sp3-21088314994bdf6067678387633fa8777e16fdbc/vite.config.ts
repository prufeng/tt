import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import * as path from 'path'

// vite插件：自动导入, 自动生成 auto-import.d.ts
import AutoImport from 'unplugin-auto-import/vite'
// vite插件：组件自动注册，自动生成 components.d.ts
import Components from 'unplugin-vue-components/vite'
// vite插件：自动加载样式 ，ElementPlus样式自动加载 解决
// import {
//   createStyleImportPlugin,
//   ElementPlusResolve,
// } from 'vite-plugin-style-import'

// ElementPlus 自动导入, 自动注册组件  解决器
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
// ElementPlus Icon
// yarn add  unplugin-icons  @iconify-json/ep
// import Icons from 'unplugin-icons/vite'
// import IconsResolver from 'unplugin-icons/resolver'

// 国际化插件： 模板中自定义 标签 <i18n></i18n>
import VueI18nPlugin from '@intlify/unplugin-vue-i18n/vite'

import topLevelAwait from 'vite-plugin-top-level-await'

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd())
  console.log(mode, env)
  return {
    base: env.VITE_CONFIG_BASE,
    // base: '/'+env.VITE_CONFIG_BUILD_OUT_DIR+'/', // todo tomcat发布需要配置
    build: {
      outDir: env.VITE_CONFIG_BUILD_OUT_DIR,
      chunkSizeWarningLimit: 4096,
      // assetsInlineLimit: 0,
      // target: 'ES2015',
      minify: true,
    },
    resolve: {
      //设置别名
      alias: { '@': path.resolve(__dirname, 'src') },
    },
    server: {
      host: true,
      port: 10012,
      open: true,
      proxy: {
        [env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX]: {
          target: env.VITE_CONFIG_SERVER_PROXY_TARGET,
          changeOrigin: true,
          // rewrite: (path) => path.replace(/^\/api/, ''), // 不可以省略rewrite
          rewrite: (path) => path.replace(env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX, ''), // 不可以省略rewrite
        },
      },
    },
    plugins: [
      vue({
        template: {
          compilerOptions: {
            isCustomElement: (tag) => /^micro-app/.test(tag) || /^gc-/.test(tag),
          },
        },
      }),
      // https://github.com/intlify/vite-plugin-vue-i18n
      VueI18nPlugin({
        /* options */
        // locale messages resource pre-compile option
        include: [path.resolve(__dirname, 'src/locales/**')],
      }),

      AutoImport({
        include: [
          /\.[tj]sx?$/, // .ts, .tsx, .js, .jsx
          /\.vue$/,
          /\.vue\?vue/, // .vue
        ],
        imports: [
          'vue',
          'pinia',
          'vue-router',
          'vue-i18n',
          // '@vueuse/head',
          '@vueuse/core',
          // custom
          {
            'vue3-cookies': ['useCookies'],
            echarts: [['*', 'echarts']],
            axios: [
              // default imports
              ['default', 'axios'], // import { default as axios } from 'axios',
            ],
            'riking-ui': ['useState', 'useDialogForm', 'useDialogFormArray', 'useDictState'],
            'riking-layout': ['useDict', 'useSettingsStore', 'openDialogForm', 'openBatchOptMessage'],
            '@/store/user': [['default', 'useUserStore']],
            '@/utils/request': [
              ['default', 'service'],
              ['transCancelable', 'transCancelable'],
            ],
            // '[package-name]': [
            //   '[import-names]',
            //   // alias
            //   ['[from]', '[alias]'],
            // ],
          },
        ],
        resolvers: [
          // 自动导入 ElementPlus 组件
          ElementPlusResolver(),
          // 自动导入图标组件
          // IconsResolver({ prefix: 'Icon' }),
        ],
        eslintrc: {
          enabled: false, // Default `false`
          filepath: './.eslintrc-auto-import.json', // Default `./.eslintrc-auto-import.json`
          globalsPropValue: true, // Default `true`, (true | false | 'readonly' | 'readable' | 'writable' | 'writeable')
        },
        // 可以选择auto-import.d.ts生成的位置，使用ts建议设置为'src/auto-import.d.ts'
        dts: './src/auto-import.d.ts',
      }),

      Components({
        extensions: ['vue'],
        // allow auto import and register components used in markdown
        include: [/\.vue$/, /\.vue\?vue/],
        exclude: [/[\/]node_modules[\/]/, /[\/].git[\/]/, /[\/].nuxt[\/]/],
        // ui库解析器，也可以自定义
        resolvers: [
          // 自动注册 ElementPlus 组件
          ElementPlusResolver(),
          // 自动注册图标组件
          // IconsResolver({ enabledCollections: ['ep'] }),
        ],
        dts: './src/components.d.ts',
      }),

      topLevelAwait({
        promiseExportName: '__tla',
        promiseImportName: i => `__tla_${i}`
      }),

      // createStyleImportPlugin({
      //   resolves: [ElementPlusResolve()],
      //   libs: [
      //     {
      //       libraryName: 'element-plus',
      //       esModule: true,
      //       resolveStyle: (name: string) => {
      //         name = name.substring(3, name.length)
      //         return `element-plus/es/components/${name}/style/index`
      //       },
      //     },
      //   ],
      // }),

      // Icons({
      //   autoInstall: true,
      // }),
    ],
  }
})
