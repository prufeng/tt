<template>

</template>

<script>
export default {
  name: "SubSystemList",
  props: {
    subSystemList:[]
  },

  data() {
    return {
      fileList: []
    };
  },
  methods: {
    onClick() {
      console.log('click zzzzz');
    },
  }
}
</script>

<style scoped>

</style>'<html></html>>'