<template>
  <el-form>
    <el-form-item>
      <el-radio v-model="radioValue" :label="1">
        秒，允许的通配符[, - * /]
      </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="2">
        周期从
        <el-input-number v-model="cycle01" :min="0" :max="58"/>
        -
        <el-input-number
            v-model="cycle02"
            :min="cycle01 ? cycle01 + 1 : 1"
            :max="59"
        />
        秒
      </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="3">
        从
        <el-input-number v-model="average01" :min="0" :max="58"/>
        秒开始，每
        <el-input-number
            v-model="average02"
            :min="1"
            :max="59 - average01 || 0"
        />
        秒执行一次
      </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="4">
        指定
        <el-select
            clearable
            v-model="checkboxList"
            placeholder="可多选"
            multiple
            style="width: 100%"
        >
          <el-option v-for="item in 60" :key="item" :value="item - 1">{{
              item - 1
            }}
          </el-option>
        </el-select>
      </el-radio>
    </el-form-item>
  </el-form>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import {ElForm, ElFormItem, ElInputNumber, ElRadio, ElSelect, ElOption,} from 'element-plus'

const props = defineProps(["check", "radioParent"])
const emits = defineEmits(['update']);

const radioValue = ref(1)
const cycle01 = ref(1)
const cycle02 = ref(2)
const average01 = ref(0)
const average02 = ref(1)
const checkboxList =  ref([])

defineExpose({checkboxList})

const checkNum = props.check

// 单选按钮值变化时
function radioChange() {
  switch (radioValue.value) {
    case 1:
      emits("update", "second", "*", "second");
      break;
    case 2:
      emits("update", "second", cycleTotal.value);
      break;
    case 3:
      emits("update", "second", averageTotal.value);
      break;
    case 4:
      emits("update", "second", checkboxString.value);
      break;
  }
}

// 周期两个值变化时
function cycleChange() {
  if (radioValue.value == "2") {
    emits("update", "second", cycleTotal.value);
  }
}

// 平均两个值变化时
function averageChange() {
  if (radioValue.value == "3") {
    emits("update", "second", averageTotal.value);
  }
}

// checkbox值变化时
function checkboxChange() {
  if (radioValue.value == "4") {
    emits("update", "second", checkboxString.value);
  }
}

// 计算两个周期值
const cycleTotal = computed(() => {
  const c1 = checkNum(cycle01.value, 0, 58);
  const c2 = checkNum(
      cycle02.value,
      c1 ? c1 + 1 : 1,
      59
  );
  return c1 + "-" + c2;
})

// 计算平均用到的值
const averageTotal = computed(() => {
  const a1 = checkNum(average01.value, 0, 58);
  const a2 = checkNum(average02.value, 1, 59 - a1 || 0);
  return a1 + "/" + a2;
})
// 计算勾选的checkbox值合集
const checkboxString = computed(() => {
  let str = checkboxList.value.join();
  return str == "" ? "*" : str;
})

watch(radioValue, () => {radioChange();})
watch(cycleTotal, () => {cycleChange();})
watch(averageTotal, () => {averageChange();})
watch(checkboxString, () => {checkboxChange();})
// watch(radioParent, () => {radioValue.value = radioParent})

</script>
