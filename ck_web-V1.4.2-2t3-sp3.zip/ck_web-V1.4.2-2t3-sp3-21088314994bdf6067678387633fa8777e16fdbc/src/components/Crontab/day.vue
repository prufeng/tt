<template>
  <el-form>
    <el-form-item>
      <el-radio v-model="radioValue" :label="1">
        日，允许的通配符[, - * ? / L W]
      </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="2"> 不指定 </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="3">
        周期从
        <el-input-number v-model="cycle01" :min="1" :max="30" /> -
        <el-input-number
          v-model="cycle02"
          :min="cycle01 ? cycle01 + 1 : 2"
          :max="31"
        />
        日
      </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="4">
        从
        <el-input-number v-model="average01" :min="1" :max="30" /> 号开始，每
        <el-input-number
          v-model="average02"
          :min="1"
          :max="31 - average01 || 1"
        />
        日执行一次
      </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="5">
        每月
        <el-input-number v-model="workday" :min="1" :max="31" />
        号最近的那个工作日
      </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="6"> 本月最后一天 </el-radio>
    </el-form-item>

    <el-form-item>
      <el-radio v-model="radioValue" :label="7">
        指定
        <el-select
          clearable
          v-model="checkboxList"
          placeholder="可多选"
          multiple
          style="width: 100%"
        >
          <el-option v-for="item in 31" :key="item" :value="item">{{
            item
          }}</el-option>
        </el-select>
      </el-radio>
    </el-form-item>
  </el-form>
</template>

<script setup lang="ts">
import {ref} from "vue";
import { ElInputNumber, ElForm, ElRadio, ElSelect, ElOption, ElFormItem } from 'element-plus'

const props = defineProps(["check", "cron"])
const emits = defineEmits(['update']);

const radioValue = ref(1)
const workday = ref(1);
const cycle01 = ref(1)
const cycle02 = ref(2)
const average01 = ref(1)
const average02 = ref(1)
const checkboxList = ref([])
const checkNum = props.check

defineExpose({checkboxList})

function radioChange() {
  ("day rachange");
  if (radioValue.value !== 2 && props.cron.week !== "?") {
    emits("update", "week", "?", "day");
  }

  switch (radioValue.value) {
    case 1:
      emits("update", "day", "*");
      break;
    case 2:
      emits("update", "day", "?");
      break;
    case 3:
      emits("update", "day", cycleTotal.value);
      break;
    case 4:
      emits("update", "day", averageTotal.value);
      break;
    case 5:
      emits("update", "day", workday.value + "W");
      break;
    case 6:
      emits("update", "day", "L");
      break;
    case 7:
      emits("update", "day", checkboxString.value);
      break;
  }
  ("day rachange end");
}
// 周期两个值变化时
function cycleChange() {
  if (radioValue.value == "3") {
    emits("update", "day", cycleTotal.value);
  }
}
// 平均两个值变化时
function averageChange() {
  if (radioValue.value == "4") {
    emits("update", "day", averageTotal.value);
  }
}
// 最近工作日值变化时
function workdayChange() {
  if (radioValue.value == "5") {
    emits("update", "day", workdayCheck.value + "W");
  }
}
// checkbox值变化时
function checkboxChange() {
  if (radioValue.value == "7") {
    emits("update", "day", checkboxString.value);
  }
}


// 计算两个周期值
const cycleTotal = computed(() => {
  const c1 = checkNum(cycle01.value, 1, 30);
  const c2 = checkNum(
      cycle02.value,
      c1 ? c1 + 1 : 2,
      31,
      31
  );
  return c1 + "-" + c2;
})
// 计算平均用到的值
const averageTotal = computed(() => {
  const a1 = checkNum(average01.value, 1, 30);
  const a2 = checkNum(average02.value, 1, 31 - a1 || 0);
  return a1 + "/" + a2;
})
// 计算工作日格式
const workdayCheck = computed(() => {
  const w = checkNum(workday.value, 1, 31);
  return w;
})
// 计算勾选的checkbox值合集
const checkboxString = computed(() => {
  let str = checkboxList.value.join();
  return str == "" ? "*" : str;
})

watch(radioValue, () => {
  radioChange();
})
watch(cycleTotal, () => {
  cycleChange();
})
watch(averageTotal, () => {
  averageChange();
})
watch(workdayCheck, () => {
  workdayChange();
})
watch(checkboxString, () => {
  checkboxChange();
})
</script>
