<template>
  <el-dialog
      v-model="value"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      v-bind="$attrs"
  >

    <el-form :inline="true" :model="data" class="demo-form-inline">
      <el-form-item v-for="item in formItems" :label="item.label" :prop="item.prop">
        <el-input v-model=""/>
      </el-form-item>
    </el-form>


    <slot/>
    <template #footer>
      <slot name="footer">
        <span v-if="showCancel || showConfirm">
          <el-button v-if="showCancel" @click="handlCancel">
            {{cancelText}}
          </el-button>
          <el-button v-if="showConfirm" @click="handleConfirm">
            {{confirmText}}
          </el-button>
        </span>
      </slot>
    </template>
  </el-dialog>
</template>

<script setup lang="ts" name="ComDialog">
interface IProps {
  modelValue: boolean
  loading?: boolean
  showCancel?: boolean
  showConfirm?: boolean
  cancelText?: string
  confirmText?: string
  formItems? : [],
  data?: {}
}

const props = withDefaults(defineProps<IProps>(), {
  modelValue: false,
  loading: false,
  showCancel: true,
  showConfirm: true,
  cancelText: '取消',
  confirmText: '保存'
})

const emits = defineEmits(['update:modelValue', 'cancel', 'confirm'])

const value = computed({
  get() {
    return props.modelValue
  },
  set(value) {
    emits('update:modelValue', value)
  }
})

const handleCancel = () => {
  emits('cancel')
}

const handleConfirm = () => {
  emits('confirm')
}

</script>

<style scoped>

</style>