import useUserStore from '@/store/user'
import {
  removeRequestClassificationCode,
  removeSubSystem,
  removeSubSystemList,
  removeSubSystemName
} from "@/utils/subSystem";



export default () => {
  const userStore = useUserStore()
  const router = useRouter()
  const route = useRoute()
  const handleLogout = async () => {
    //const mfaLoginUrlArr = JSON.parse(sessionStorage.getItem('mfaLoginUrlArr'));
    clearCookie();
    await userStore.logout()
    const thirdPartyLoginUrl = sessionStorage.getItem('thirdPartyLoginUrl');
    if (!!thirdPartyLoginUrl) {
      window.location.href = `${thirdPartyLoginUrl}`
    } else {
      router.push(`/login`)
    }
    ElMessage.success('退出成功')
  }

  return { handleLogout }
}

// 退出时清理cookie设置
function clearCookie() {
  removeSubSystem();
  removeSubSystemList();
  removeSubSystemName()
  removeRequestClassificationCode();
}
