import useUserStore from '@/store/user'
import { useTabsStore } from 'riking-layout'
import moment from "moment/moment";
// @ts-ignore
import Watermark from "@/utils/warterMarkVue"
import service from '@/utils/request'
import { getSubSystemName, setSubSystem, setSubSystemName } from '@/utils/subSystem'
import { RS } from "riking-ui";
import { nextTick, ref } from "vue";

export default () => {
  const router = useRouter();
  const route = useRoute()
  const userStore = useUserStore()
  const userTabs = useTabsStore()

  const handleTabClick = async (index: any, isLayout = true) => {
    setSubSystem(index.value);
    setSubSystemName(index.label)
    userStore.resetSubSystem();
    const result = await userStore.changeSubSystem(index.value)
    if (isLayout) {
      await router.replace({ path: `/${index.value}/waitToDo`})
      userTabs.clear()
      userTabs.removeOthers(route.path)
    }
    userStore.updateShowLayout(false);
    await nextTick()
    userStore.updateShowLayout(true);
    setWatermark()
  }

  // const handleTabClick = async (subSystem: string, subSystemName: string, isLayout = true) => {
  //   setSubSystem(subSystem);
  //   setSubSystemName(subSystemName)
  //   userStore.resetSubSystem();
  //   await userStore.changeSubSystem(subSystem)
  //   if (isLayout) {
  //     await router.replace({ path: '/waitToDo/waitToDo' })
  //     userTabs.clear()
  //     userTabs.removeOthers(route.path)
  //   }
  //   show.value = false
  //   await nextTick()
  //   show.value = true
  //   setWatermark()
  // }

  const getDictByTypeCode = (data: any): Promise<RS> => {
    return service({
      url: '/dict/getDictByTypeCode',
      method: 'post',
      params: data
    })
  };

  const setWatermark = () => {
    getDictByTypeCode({ typeCode: 'watermark' }).then(res => {
      let watermark = '';
      const internalInstance = getCurrentInstance()
      const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
      res.data.forEach((element: any) => {
        if (element.dictKey == 'systemName' && element.enableStatus == 'Y') {
          watermark += getSubSystemName() + '/'
        } else if (element.dictKey == 'loginTime' && element.enableStatus == 'Y') {
          watermark += currentTime + '/'
        } else if (element.dictKey == 'userName' && element.enableStatus == 'Y') {
          watermark += userStore.username + '/'
        }
      });
      watermark = watermark.substring(0, watermark.lastIndexOf('/'));
      Watermark.set(
        '1',
        watermark,
        document.getElementsByClassName('el-main')[0]
      )
    })
  }

  return { handleTabClick, setWatermark }

}
