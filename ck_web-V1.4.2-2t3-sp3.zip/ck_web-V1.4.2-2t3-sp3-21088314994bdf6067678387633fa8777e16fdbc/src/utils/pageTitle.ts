export default function (pageTitle: string, title: string) {
    /*const settingStore = useSettingsStore()
    let title = settingStore.systemName*/
    if (pageTitle) {
        if (title == null) {
            return `${pageTitle}`
        }
        return `${pageTitle} - ${title}`
    }
    if (title == null) {
        title = 'Login'
    }
    return `${title}`
}
