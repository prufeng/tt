import {ref} from "vue";
import {ButtonInfo, Pagination, RkFormInstance, RS, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";
import service from "@/utils/request";
import {ElMessage} from "element-plus";
import {getCommonParams} from "@/utils/subSystem";


export const assignmentDialog = ref(false);
export const assignmentLoading = ref(false);
export const assignmentQqdbs = ref('');
export const assignmentRwlsh = ref("");
export const assignmentData = ref<any []>([]);
export const assignmentFormDialog = ref(false);
export const assignmentFormRef = ref<RkFormInstance>()
export const assignmentForm =ref({})
export let assignmentIds: string;
export const assignmentIdsHandleSelectionChange = async (val: any) => {
    assignmentIds = val.map((item: any) => item.id).join(",");
}
export const assignmentColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    { prop: 'branchCode', label: '所属机构', minWidth: 200, dictFormatKey: 'branchTree'   ,sortable: true},
    { prop: 'assignTime', label: '指派时间', minWidth: 200,  formatter: dateFormatter   ,sortable: true},
    { prop: 'assignBy', label: '指派人', minWidth: 200,    sortable: true},
    { prop: 'assignType', label: '指派类型', minWidth: 200, dictFormatKey: 'assignType',   sortable: true},
]
// const assignmentPagination: Pagination = {
//     currentPage: 1,
//     pageSize: 10,
//     pageSizes: [10, 30, 50, 100],
//     total: 0,
//     layout: 'total, sizes, prev, pager, next, jumper',
//     pagerCount: 5,
// }
// export const assignmentPage = ref<Pagination>(assignmentPagination)

// export const assignmentPageChange = (p: Pagination) => {
//     assignmentPage.value = p
//     assignmentSearch()
// }

export const assignmentSearch = async () => {
    assignmentLoading.value = true;
    try{
        const result = await list(assignmentQqdbs.value,assignmentRwlsh.value);
        assignmentData.value = result.data;
        // assignmentPage.value.currentPage = current;
        // assignmentPage.value.total = total;
    }finally {
        assignmentLoading.value = false;
    }
}

export const assignmentButtons: ButtonInfo[] = [
    {
        key: 'assignment',
        label: '新增指派',
        tag: 'button',
        type: 'primary',
        icon: 'icon_add',
        handler: async () => {
            assignmentFormDialog.value = true;
        }
    },
    {
        key: 'delAssignment',
        label: '删除指派',
        tag: 'button',
        type: 'danger',
        icon: 'icon_delete',
        handler: async () => {
            if (assignmentIds == undefined || assignmentIds.length == 0) {
                ElMessage.warning('请先选择数据')
                return
            }
            await delAssignment();
            assignmentSearch()
            ElMessage.success("删除成功");
        }
    }
]

export const assignmentSave = async () => {
    const valid = await assignmentFormRef.value?.asyncValidate();
    if (!valid) {
        return;
    }
    const data = toRaw(assignmentForm.value);
    await assignment(data);
    await assignmentSearch();
    assignmentFormDialog.value = false;
    ElMessage.success("保存成功");
}

function list(qqdbs:string,rwlsh:string): Promise<RS> {
    return service({
        url: '/sysBranchDataRs/list',
        method: 'POST',
        data:{qqdbs,rwlsh},
        params: {}
    })
}

function assignment(data:any): Promise<RS> {
    return service({
        url: '/sysBranchDataRs/save',
        method: 'POST',
        data,
        params: {...getCommonParams()}
    })
}

function delAssignment(): Promise<RS> {
    const {subSystem, requestClassificationCode: reportCode} = {...getCommonParams()};
    return service({
        url: '/sysBranchDataRs/del',
        method: 'POST',
        params: {ids: assignmentIds, subSystem, reportCode}
    })
}