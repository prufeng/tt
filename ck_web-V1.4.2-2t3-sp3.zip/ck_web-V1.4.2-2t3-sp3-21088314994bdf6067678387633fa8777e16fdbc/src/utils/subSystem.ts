const {cookies} = useCookies()

export function getCommonParams() {
    const subSystem: string = getSubSystem();
    const requestClassificationCode: string | string[] = getRequestClassificationCode();
    // const pageIndicator = getPageIndicator();

    let cxnr = '';
    if (requestClassificationCode === 'account')
        cxnr = '01';
    if (requestClassificationCode === 'transaction')
        cxnr = '02';
    if (requestClassificationCode === 'accountAndTransaction')
        cxnr = '03';
    if (requestClassificationCode === 'certificate')
        cxnr = '04';
    if (requestClassificationCode === 'financial')
        cxnr = '05';

    if("ga" === subSystem) {
        if (requestClassificationCode === 'ps101')
            cxnr = '01';
        if (requestClassificationCode === 'ps103')
            cxnr = '03';
    }

    const commonParams = {subSystem, requestClassificationCode, cxnr};
    return commonParams;
}

const subSystemKey = 'subSystemKey'
const subSystemNameKey = 'subSystemNameKey'
const subSystemListKey = 'subSystemListKey'
const modIdKey = 'modIdKey'
const requestClassificationCodeKey = 'requestClassificationCodeKey'
// const pageIndicatorKey = 'pageIndicatorKey';
//
// export function getPageIndicator() {
//     return cookies.get(pageIndicatorKey)
// }
//
// export function setPageIndicator(pageIndicator: string) {
//     return cookies.set(pageIndicatorKey, pageIndicator)
// }
//
// export function removePageIndicator() {
//     return cookies.remove(pageIndicatorKey)
// }


// export function getSubSystem() {
//     return cookies.get(subSystemKey)
// }
//
// export function setSubSystem(subSystem: string) {
//     return cookies.set(subSystemKey, subSystem)
// }
//
// export function removeSubSystem() {
//     return cookies.remove(subSystemKey)
// }
//
//
// export function getSubSystemList() {
//     return cookies.get(subSystemListKey)
// }
//
// export function setSubSystemList(subSystemList: string) {
//     return cookies.set(subSystemListKey, subSystemList)
// }
//
// export function removeSubSystemList() {
//     return cookies.remove(subSystemListKey)
// }
//
// export function getSubSystemName() {
//     return cookies.get(subSystemNameKey)
// }
//
// export function setSubSystemName(subSystemName: string) {
//     return cookies.set(subSystemNameKey, subSystemName)
// }
//
// export function removeSubSystemName() {
//     return cookies.remove(subSystemNameKey)
// }
//
// // 请求分类
// export function getRequestClassificationCode() {
//     return cookies.get(requestClassificationCodeKey)
// }
//
// export function setRequestClassificationCode(requestClassificationCode: string) {
//     return cookies.set(requestClassificationCodeKey, requestClassificationCode)
// }
//
// export function removeRequestClassificationCode() {
//     return cookies.remove(requestClassificationCodeKey)
// }

export function getSubSystem() {
    return sessionStorage.getItem(subSystemKey)
}
export function getCookieSubSystem() {
    return cookies.get(subSystemKey)
}
export function setSubSystem(subSystem: string) {
    sessionStorage.setItem(subSystemKey, subSystem);
    return cookies.set(subSystemKey, subSystem)
}

export function removeSubSystem() {
    sessionStorage.removeItem(subSystemKey);
    return cookies.remove(subSystemKey)
}


export function getSubSystemList() {
    return sessionStorage.getItem(subSystemListKey)
}

export function setSubSystemList(subSystemList: string) {
    sessionStorage.setItem(subSystemListKey, subSystemList);
    return cookies.set(subSystemListKey, subSystemList)
}

export function getModId() {
    return sessionStorage.getItem(modIdKey)
}

export function setModId(modId: any) {
    sessionStorage.setItem(modIdKey, modId);
    return cookies.set(modIdKey, modId)
}

export function removeSubSystemList() {
    sessionStorage.removeItem(subSystemListKey);
    return cookies.remove(subSystemListKey)
}

export function getSubSystemName() {
    return sessionStorage.getItem(subSystemNameKey)
}
 export function getCookieSubSystemName() {
     return cookies.get(subSystemNameKey)
 }
export function setSubSystemName(subSystemName: string) {
    sessionStorage.setItem(subSystemNameKey, subSystemName);
    return cookies.set(subSystemNameKey, subSystemName)
}

export function removeSubSystemName() {
    sessionStorage.removeItem(subSystemNameKey);
    return cookies.remove(subSystemNameKey)
}

// 请求分类
export function getRequestClassificationCode() {
    return sessionStorage.getItem(requestClassificationCodeKey)
}

export function setRequestClassificationCode(requestClassificationCode: string) {
    sessionStorage.setItem(requestClassificationCodeKey, requestClassificationCode);
    return cookies.set(requestClassificationCodeKey, requestClassificationCode)
}

export function removeRequestClassificationCode() {
    sessionStorage.removeItem(requestClassificationCodeKey);
    return cookies.remove(requestClassificationCodeKey)
}
