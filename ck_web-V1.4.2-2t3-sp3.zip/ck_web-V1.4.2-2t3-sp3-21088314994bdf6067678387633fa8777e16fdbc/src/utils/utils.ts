import {Pagination} from "riking-ui";
import {ElMessage} from "element-plus";
import {setSubSystem} from "@/utils/subSystem";

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 50,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}
export const subPagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}

export const getRouteName = (route) => {
    const path = route.path;
    const lastIndex = path.lastIndexOf('/');
    const name = path.substring(lastIndex + 1);
    return name;
}

export function checkData(data: any = {}) {
    let newObject = {...data};
    for (const key in newObject) {
        if (newObject[key] === '') {
            newObject[key] = null;
        }
    }
    if (data.createTime != undefined) {
        newObject.endTime = formatDate(new Date(data.createTime[1]));
        newObject.createTime = formatDate(new Date(data.createTime[0]));
    }
    return newObject;
}

function formatDate(date: Date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}


export function dateFormatter(row: any, column: any, cellValue: any, index: any) {
    if (cellValue == null || cellValue.isEmpty) {
        return ''
    }
    let date = new Date(cellValue);
    if (cellValue.length == 8) {
        const year1 = parseInt(cellValue.slice(0, 4));
        const month1 = parseInt(cellValue.slice(4, 6)) - 1;
        const day1 = parseInt(cellValue.slice(6, 8));
        date = new Date(year1, month1, day1);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    } else if (cellValue.length == 14) {
        const year1 = parseInt(cellValue.slice(0, 4));
        const month1 = parseInt(cellValue.slice(4, 6)) - 1;
        const day1 = parseInt(cellValue.slice(6, 8));
        const hour = parseInt(cellValue.slice(8, 10));
        const minute = parseInt(cellValue.slice(10, 12));
        const second = parseInt(cellValue.slice(12, 14));

        const date = new Date(year1, month1, day1, hour, minute, second);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');

        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    } else {
        return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}:${date.getSeconds().toString().padStart(2, '0')}`;
    }

}

export function copyProperties(data: any, subRow: any, reportCode: string) {
    console.log(data, subRow, reportCode);
    
    //判断哪些字段需要被复制  请求页面字段
    let keys = [];
    //有些字段名并不是完全一致 , 需要mapping    请求页面字段:反馈页面字段  请求页面字段必须在keys中存在的
    let keysMap = {};
    switch (reportCode) {
        // 公安
        case 'ps101':
            keys = ['zzlx','zzlxdm','zzhm','ztmc'];
            keysMap = {'ztmc':'khmc','je':'sqdjxe'};
            break;
        case 'ps103':
            keys = ['zzlx','zzlxdm','zzhm','ztmc'];
            keysMap = {'ztmc':'khmc','je':'sqdjxe'};
            break;
        case 'ps104':
            keys = ['zh'];
            break;
        case 'ps105':
            keys = ['zh','je','djzhhz','zzlxdm','zzhm'];
            keysMap = {'ztmc':'khmc','je':'sqdjxe'};
            break;
        case 'ps106':
            keys = ['zh'];
            break;


        //五合一部分
        case 'account':
            keys = ['zzlx','zzlxdm','zzhm','ztmc'];
            keysMap = {'ztmc':'khmc','je':'sqdjxe'};
            break;
        case 'transaction':
            keys = ['cxzh'];
            break;
        case 'accountAndTransaction':
            keys = ['zzlx','zzlxdm','zzhm','ztmc'];
            keysMap = {'ztmc':'khmc','je':'sqdjxe'};
            break;
        case 'dynamic':
            keys = ['zh'];
            break;
        case 'freeze':
            keys = ['zh','je'];
            keysMap = {'ztmc':'khmc','je':'sqdjxe'};
            break;
        case 'payment':
            keys = ['zh'];
            break;
        case 'certificate':
            keys = ['cxzh','jylsh','pztxlx'];
            break;
        case 'financial':
            keys = ['cxzh'];
            keysMap = {'cxzh':'cxkh'};
            break;
        //最高法院部分
        case '1001':
            keys = ['xm'];
            keysMap = {'xm':'khmc'};
            break;
        case '1003':
            keys = ['ccxh','khzh','ksrq','jsrq','je','kznr'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        //taf部分
        case '100101':
            keys = ['accountType','accountNumber'];
            keysMap = {};
            break;
        case '100103':
            keys = ['accountType','accountNumber'];
            keysMap = {};
            break;
        case '100105':
            keys = ['accountType','accountNumber'];
            keysMap = {};
            break;
        case '100201':
            keys = ['accountType','accountNumber'];
            keysMap = {};
            break;
        case '100203':
            keys = ['accountType','accountNumber'];
            keysMap = {};
            break;
        case '100205':
            keys = ['accountType','accountNumber'];
            keysMap = {};
            break;
        case '100301':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        case '100303':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        case '100305':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        case '100307':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        case '100309':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        case '100601':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        case '100603':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        case '100701':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;
        case '100703':
            keys = ['ccxh','khzh','ksrq','jsrq','je'];
            keysMap = {'ksrq':'csksrq','jsrq':'csjsrq','je':'djxe'};
            break;

    }
    for (const key of keys) {
        if (subRow.hasOwnProperty(key)&&subRow[key]!=undefined&&subRow[key]!=null&&subRow[key]!='') {
            const keysMapElement = keysMap[key];
            if (keysMapElement == undefined) {
                data[key] = subRow[key];
            } else {
                data[keysMapElement] = subRow[key];
            }
        }
    }
    return data
}

export function specialChecks(data: any, systemCode: any, reportCode: string) {
    if (systemCode == 'zgfy') {  //最高法院部分
        let khzh = data.khzh
        if (data.fksj == null || data.fksj == '') {
            return {result: true, msg: "", clear: false,continueToVerify:true};
        } else {
            if (khzh == '查无开户信息') {
                return {result: true, msg: "", clear: true,continueToVerify:false};
            } else {
                return {result: true, msg: "", clear: false,continueToVerify:true};
            }
        }
    } else if (systemCode == 'taf') {
        let CaseType;
        switch (reportCode) {
            case '100604':
                CaseType = data.CaseType;
        }
        return {result: true, msg: "", clear: false,continueToVerify:true};
    } else {
        let zxjg;
        let cxfkjg;
        let cxfkjgyy;
        let sbyy;
        let wndjyy;
        let sqdjxe;
        let sdje;
        let wdjje;
        switch (reportCode) {
            case 'fkCustomer':
            case 'fkTransaction':
            case 'fkCertificateImage':
            case 'fkFinancialAccount':
            case 'fkAccountAndTransaction':
                cxfkjg = data.cxfkjg;
                cxfkjgyy = data.cxfkjgyy;
                if (cxfkjg == '02' && (cxfkjgyy == undefined || cxfkjgyy == '')) {
                    return {result: false, msg: "若查询反馈结果为失败,查询反馈结果原因必填", clear: true};
                }else if (cxfkjg == '02' && cxfkjgyy != undefined && cxfkjgyy != '') {
                    return {result: true, msg: "", clear: true,continueToVerify:false};
                } else {
                    return {result: true, msg: "", clear: true,continueToVerify:true};
                }
            case 'fkDynamic':
            case 'fkDynamicReceipt':
            case 'fkPayment':
                zxjg = data.zxjg;
                sbyy = data.sbyy;
                //查询反馈结果 01为成功  执行结果 0 为成功
                if (zxjg == '1' && (sbyy == undefined || sbyy == '')) {
                    return {result: false, msg: "若执行结果为失败,失败原因必填", clear: true};
                }else if (zxjg == '1' &&sbyy != undefined && sbyy != '') {
                    return {result: true, msg: "", clear: true,continueToVerify:false};
                } else {
                    return {result: true, msg: "", clear: true,continueToVerify:true};
                }
            case 'fkFreeze':
                sqdjxe = data.sqdjxe;
                sdje = data.sdje;
                wdjje = data.wdjje;
                zxjg = data.zxjg;
                wndjyy = data.wndjyy
                let djfs = data.djfs;
                if (zxjg == '1' && (wndjyy == undefined || wndjyy == '')) {
                    return {result: false, msg: "若执行结果为失败,未能冻结原因必填", clear: true};
                }else if (zxjg == '1' &&wndjyy != undefined && wndjyy != '') {
                    return {result: true, msg: "", clear: true,continueToVerify:false};
                } else {
                    let result = {result: true, msg: "", clear: true,continueToVerify:true};
                    if ((sqdjxe != undefined && sdje != undefined)||(sqdjxe == undefined && sdje == undefined)) {
                        result = {result: true, msg: "", clear: true,continueToVerify:true};
                    } else if (djfs == '02' && sdje != undefined) {
                        return {result: false, msg: "只收不付时，执行冻结金额需要为空", clear: true};
                    } else if (djfs == '01' && sdje == undefined) {
                        return {result: false, msg: "限额内冻结时，执行冻结金额不能为空", clear: true};
                    }
                    /*if ((sqdjxe != undefined && sdje != undefined)||(sqdjxe == undefined && sdje == undefined)) {
                        result = {result: true, msg: "", clear: true,continueToVerify:true};
                    } else if (sqdjxe == undefined && sdje != undefined) {
                        return {result: false, msg: "只收不付时，执行冻结金额需为空", clear: true};
                    } else {
                        return {result: false, msg: "限额内冻结时，执行冻结金额需不为空", clear: true};
                    }*/

                    if ((sqdjxe != undefined && wdjje != undefined)||(sqdjxe == undefined && wdjje == undefined)) {
                        result = {result: true, msg: "", clear: true,continueToVerify:true};
                    } else if (djfs == '02' && wdjje != undefined) {
                        return {result: false, msg: "只收不付时，未冻结金额需要为空", clear: true};
                    } else if (djfs == '01' && wdjje == undefined) {
                        return {result: false, msg: "限额内冻结时，未冻结金额不能为空", clear: true};
                    }
                    /*else if (sqdjxe == undefined && wdjje != undefined) {
                        return {result: false, msg: "只收不付时，未冻结金额需为空", clear: true};
                    } else {
                        return {result: false, msg: "限额内冻结时，未冻结金额需不为空", clear: true};
                    }*/
                    return result;
                }
        }
    }
    return {result: true, msg: "", clear: false,continueToVerify:true};
}

export function checkSpecialCharacters(data: any) {
    for (const key in data) {
        if(key === 'beiz')
            continue;

        const value = data[key];
        if (!/^[^<>&]*$/.test(value)) {
            return true;
        }
    }
    return false;
}

export function getJumpUrl(subSystem: string) {
    if (subSystem==undefined){
        return null
    }
    // 正则表达式，用括号创建两个捕获组来分别匹配ybjh和查控系统交互
    const regex = /'([^']*)\|([^']*)'/;
    const matches = subSystem.match(regex);


    const modIdMatch = subSystem.match(/modId=(\d+)/);
    let modId=null;
    if (modIdMatch) {
        modId = parseInt(modIdMatch[1], 10); // modIdMatch[1] 是正则表达式中第一个括号匹配的内容
        console.log('modId'+modId); // 输出: 58
    } else {
        console.log("未找到modId");
    }

    let sectok=null;
    let isThreeToken=false;
    if (modId==null){
        let sectokValue=null;
        if (subSystem.match(/sectok=(.*?)(?=&|$)/)==null){
            sectokValue=subSystem.match(/sectok3=(.*?)(?=&|$)/)[1]
            isThreeToken=true
        }else {
            sectokValue=subSystem.match(/sectok=(.*?)(?=&|$)/)[1]
        }
        if (sectokValue ) {
            sectok = sectokValue ;
            console.log('sectok'+sectokValue);
        } else {
            console.log("未找到sectok");
        }
    }



    if (matches) {
        const part1 = matches[1]; // ybjh
        const part2 = matches[2]; // 查控系统交互

        console.log("第一部分: " + part1); // 输出: ybjh
        console.log("第二部分: " + part2); // 输出: 查控系统交互
        return [part1,part2,modId,sectok,isThreeToken]
    } else {
        return null
        console.log("未找到匹配项");
    }
}

/**
 * 校验参数是否有值 有值返回true
 * @param arr
 */
export function checkNotNull(arr: any[]) {
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] != undefined && arr[i] != ''){
            return true
        }
    }
    return false
}


