import { Dict } from 'riking-ui'

const dictConfig: { [key: string]: Dict[] } = {
  // languageList : [
  //     ['zh_CN','简体中文'],
  //     ['en_US','English']
  // ],
  // pageSizeList: [10, 15, 20, 30, 50],
  // defaultPageSize: 15,
  // authRelatedList:{
  //     'etlDesign':'etlManage.html',
  //     'jobDesign':'jobManage.html',
  //     'calendarDesign':'calendarManage.html',
  // },
}

export default dictConfig
