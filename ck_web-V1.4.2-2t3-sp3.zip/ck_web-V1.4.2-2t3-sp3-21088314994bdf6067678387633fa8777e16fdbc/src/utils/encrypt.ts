import { Md5 } from 'ts-md5/dist/md5'

export function encrypt(context: string) {
  return Md5.hashStr(context)
}
