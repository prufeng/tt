const { cookies } = useCookies()

const TokenKey = 'access_token'

const RefreshTokenKey = 'refresh_token'

export function getToken() {
  return cookies.get(TokenKey)
}

export function setToken(token: string) {
  return cookies.set(TokenKey, token)
}

export function removeToken() {
  return cookies.remove(TokenKey)
}

export function getRefreshToken() {
  return cookies.get(RefreshTokenKey)
}

export function setRefreshToken(token: string) {
  return cookies.set(RefreshTokenKey, token)
}

export function removeRefreshToken() {
  return cookies.remove(RefreshTokenKey)
}


// 保存权限系统的token参数，在切换系统时取出，用来调用access_token方法。 星展分包发布添加 2025/02/19
const SectokKey = 'sectok'

export function getSectok() {
  return cookies.get(SectokKey)
}

export function setSectok(sectok: string) {
  return cookies.set(SectokKey, sectok)
}