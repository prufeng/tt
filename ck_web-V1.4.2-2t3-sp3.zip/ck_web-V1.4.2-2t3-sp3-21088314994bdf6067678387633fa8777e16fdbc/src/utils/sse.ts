import { ElNotification } from 'element-plus'

const BASE_PREFIX = import.meta.env.DEV
  ? import.meta.env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX
  : window.g.axiosBaseUrl

const SSE_CONN_URL = '/sse/sub/'
// const SSE_BREAK_URL = '/sse/breakConnect'

export const conn = (id: string): EventSource | undefined => {
  let source: EventSource
  if (window.EventSource) {
    // 建立连接

    source = new EventSource(BASE_PREFIX + SSE_CONN_URL + id, {
      withCredentials: true,
    })
    source.onopen = (e): any => {
      // ElMessage.info('建立连接。。。')
      console.log('建立连接。。。')
    }
    source.onmessage = (e) => {
      let data: any
      try {
        data = JSON.parse(e.data)
      } catch (error) {
        data = e.data
      }
      data &&
        ElNotification({
          title: data.title || '',
          message: data.message || data,
          type: data.type || 'info',
        })
    }

    return source
  } else {
    ElMessage.warning('你的浏览器不支持SSE')
  }
}
export const close = async (id: string, source?: EventSource) => {
  if (!id || !source) {
    return
  }
  // const res = await service({
  //   url: SSE_BREAK_URL,
  //   method: 'get',
  //   params: { id },
  // })
  console.log('sse close, id: ' + id)
  source?.close()
}
