import { RS } from 'riking-ui'
import axios, {
  AxiosInstance,
  AxiosRequestConfig,
  AxiosResponse,
  AxiosError,
  AxiosRequestHeaders,
  CancelToken,
  CancelTokenSource,
} from 'axios'
import { setToken, getToken, removeToken, getRefreshToken, removeRefreshToken } from './token'

// todo 打包发布到tomcat需要使用配置
export const BASE_PREFIX = import.meta.env.DEV ? import.meta.env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX : window.g.axiosBaseUrl

// todo 本地和nigix执行需要使用配置
// export const BASE_PREFIX = import.meta.env.DEV ? import.meta.env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX : import.meta.env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX

const REFRESH_TOKEN_URL = '/oauth/refreshToken'
export const isDEV=import.meta.env.DEV
// 创建实例
const service: AxiosInstance = axios.create({
  // 前缀
  baseURL: BASE_PREFIX,
  // 超时
  timeout: 1000 * 300,
})

// 请求拦截器
service.interceptors.request.use(
    // @ts-ignore
  (config: AxiosRequestConfig) => {
    if (config.headers) {
      config.headers['Authorization'] = getToken() || config.headers['Authorization']
      //todo登录后移除
      config.headers['tenant_code'] = 'tc1'
      //config.headers['Authorization'] = 'Bearer 123456'
    }
    return config
  },
  (error: AxiosError) => {
    return Promise.reject(error)
  },
)

// 是否正在刷新的标记
let isRefreshing = false
// 重试队列，每一项将是一个待执行的函数形式
let requests: ((token: string) => void)[] = []

let logoutConfirmVisible = false
const logoutConfirm = async (disableLogoutConfirm: any) => {
  if (!!disableLogoutConfirm) {
    return
  }


  if (!logoutConfirmVisible) {
    logoutConfirmVisible = true
    const actions = await ElMessageBox.confirm('登录状态已过期，您可以继续留在该页面，或者重新登录', '系统提示', {
      confirmButtonText: '重新登录',
      cancelButtonText: '取消',
      type: 'warning',
      beforeClose: (action, instance, done) => {
        logoutConfirmVisible = false
        done()
      },
    }).catch((e) => e)
    if (actions == 'confirm') {
     // const mfaLoginUrlArr = JSON.parse(sessionStorage.getItem('mfaLoginUrlArr'));
      removeToken()
      const thirdPartyLoginUrl = sessionStorage.getItem('thirdPartyLoginUrl');
      if (!!thirdPartyLoginUrl) {
         window.location.href = `${thirdPartyLoginUrl}`
       } else {
         window.location.reload()
      }
    }
  }
}

const doRefreshTokenAndRetry = async (response: AxiosResponse<RS<any>, any>) => {
  const { config, data: res } = response
  const refreshToken = getRefreshToken()
  if (!refreshToken) {
    // to re-login
    logoutConfirm(config.headers?.disableLogoutConfirm)
    return Promise.reject(new Error(`${response.config.url} ${res.msg || ' Error'}`))
  }
  isRefreshing = true
  // removeToken()
  try {
    const { data } = await service({
      url: REFRESH_TOKEN_URL,
      method: 'post',
      data: { refreshToken },
    })
    const { accessToken } = data.data
    setToken(accessToken)
    requests.forEach((cb) => cb(accessToken))
      // 保险操作，有时候 会不走 request interceptor
      ; (config.headers as AxiosRequestHeaders)['Authorization'] = accessToken
    return service(config)
  } catch (error) {
    removeRefreshToken()
    // to re-login
    logoutConfirm(config.headers?.disableLogoutConfirm)
    return Promise.reject(new Error(`${response.config.url} ${res.msg || ' Error'}`))
  } finally {
    new Promise(() => {
      isRefreshing = false
      requests = []
      console.log('clear...')
    })
  }
}

// 响应拦截器
service.interceptors.response.use(
  (response: AxiosResponse) => {
    if (response.status != 200) {
      const message = JSON.stringify(response.status)
      ElMessage.info(message)
      return Promise.reject(new Error(message))
    }
    if (response.config.responseType == 'blob') {
      return response
    }
    const res = response.data
    if (res.code != 200) {
      // 刷新token 接口 失败，直接返回
      if (response.config.url == REFRESH_TOKEN_URL) {
        return Promise.reject(new Error(`${response.config.url} ${res.msg || ' Error'}`))
      }
      // 普通接口 非401错误
      if (res.code != 401) {
        ElMessage.error({ message: res.msg, grouping: true, duration: 0, showClose: true })
        return Promise.reject(new Error(`${response.config.url} ${res.msg || ' Error'}`))
      }
      // 普通接口 401错误 res.code == 401
      const config = response.config
      if (isRefreshing) {
        // 正在刷新token，将返回一个未执行resolve的promise
        // 保存函数 等待执行
        // 吧请求都保存起来 等刷新完成后再一个一个调用
        return new Promise((resolve) => {
          // 将resolve放进队列，用一个函数形式来保存，等token刷新后直接执行
          requests.push((token) => {
            ; (config.headers as AxiosRequestHeaders)['Authorization'] = token
            resolve(service(config))
          })
        })
      }
      return doRefreshTokenAndRetry(response)
    }
    return response
  },
  (error: AxiosError) => {
    if (axios.isCancel(error)) {
      return Promise.reject(error)
    }
    const { response } = error
    if (response) {
      // @ts-ignore
      ElMessage.error({ message: error.message, grouping: true, showClose: true, duration: 0})
      // @ts-ignore
      return Promise.reject(response.data)
    }
    ElMessage.warning({ message: '网络连接异常,请稍后再试!', grouping: true, showClose: true, duration: 0})
    return Promise.reject(error)
  },
)

const convertAxiosResponseService = (config: AxiosRequestConfig): Promise<RS> => {
  return new Promise<RS>(async (resolve, reject) => {
    try {
      if (config['url'] == '/dictData/listLvByTypeCode') {
        config['url'] = '/dict/listEffectiveLvByTypeCode'
      }
      if (config['url'] == '/dictType/listTree') {
        config['url'] = '/dictType/rpc/listTree'
      }
      if (config['url'] == '/dictData/buildDictTreeSelect') {
        config['url'] = '/dictData/rpc/buildDictTreeSelect'
      }
      if (config['url'] == '/dictData/create') {
        config['data'].alterDataVersion = '0001'
      }
      if (config['url'] == '/dictType/create') {
        config['url'] = '/dict/createType'
        config['data'].dataVersion = '0'
        config['data'].alterStatus = '0'
        config['data'].invalid = '0'
      }
      if (config['url'] == '/dictData/updateById') {
        config['url'] = '/dict/updateDataById'
        config['data'].alterDataVersion = '0001'
        config['data'].dataVersion = '0'
        config['data'].invalid = '0'
      }
      if (config['url'] == '/dictType/updateById') {
        config['url'] = '/dict/updateTypeById'
        config['data'].invalid = '0'
        config['data'].alterStatus = '0'
      }
      if (config['url'] == '/dictType/removeById') {
        config['url'] = '/dict/removeTypeById'
      }
      if (config['url'] == '/dictType/disableBatch') {
        config['url'] = '/dict/disableTypeBatch'
      }
      if (config['url'] == '/dictType/enableBatch') {
        config['url'] = '/dict/enableTypeBatch'
      }
      if (config['url'] == '/dictData/enableBatch') {
        config['url'] = '/dict/enableDataBatch'
      }
      if (config['url'] == '/dictData/disableBatch') {
        config['url'] = '/dict/disableDataBatch'
      }
      if (config['url'] == '/dict/deleteDicCode' || config['url'] == '/dict/addOrUpdateDic') {
        return
      }

      const response = await service(config)
      if (config.responseType == 'blob') {
        if (response.data.type == 'application/json') {
          const text = await (response.data as Blob).text()
          const res: RS = JSON.parse(text)
          ElMessage.error({message: res.msg, grouping: true, duration: 0, showClose: true})
          reject(res.msg)
          return
        }
        downloadFile(response)
        resolve({} as RS)
        return
      }

      // if(response.data.code === '200') {
      //   // console.log('ffff');
      //   ElMessage.success(response.data.msg);
      // }

      resolve(response.data)
    } catch (error) {
      reject(error)
    }
  })
}
export default convertAxiosResponseService

export const downloadFile = (res: AxiosResponse<any>) => {
  const fileName =
    decodeURIComponent(res.headers['content-disposition'])
      .split(';')
      .find((s) => s.startsWith('filename='))
      ?.replace('filename=', '')
      ?.replace(/^['|"](.*)['|"]$/, '$1') || 'downloadFile'
  const blob = res.data as Blob
  const reader = new FileReader()
  reader.readAsText(blob)
  console.log(decodeURIComponent(res.headers['content-disposition']));
  console.log(res.headers['content-disposition']);
  console.log("下载文件:" + fileName);
  const downloadElement = document.createElement('a')
  //创建下载的链接
  const href = window.URL.createObjectURL(blob)
  downloadElement.href = href
  //下载后文件名
  downloadElement.download = fileName
  document.body.appendChild(downloadElement)
  //点击下载
  downloadElement.click()
  //下载完成移除元素
  document.body.removeChild(downloadElement)
  //释放掉blob对象
  window.URL.revokeObjectURL(href)
}

export const transCancelable = (service: (data: any, cancelToken?: CancelToken) => Promise<any>) => {
  const CancelToken = axios.CancelToken
  let source: CancelTokenSource | undefined = undefined
  return async (data: any) => {
    await source?.cancel()
    source = CancelToken.source()
    return await service(data, source?.token)
  }
}
