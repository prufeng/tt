<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup
// import zhCn from 'element-plus/lib/locale/lang/en'
// import en from 'element-plus/lib/locale/lang/zh-cn'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import enUs from 'element-plus/dist/locale/en.mjs'
import dictConfig from '@/utils/dictConfig'

const settingStore = useSettingsStore()
// settingStore.systemName = 'rk-web'

const { dictState } = useDict([], [], dictConfig)
const { locale } = useI18n()




</script>

<template>
  <ElConfigProvider :locale="locale === 'zh_CN' ? zhCn : enUs" :size="settingStore.size" :z-index="settingStore.zIndex">
    <RouterView>
    </RouterView>
  </ElConfigProvider>
</template>

<style scoped></style>
