/* eslint-disable @typescript-eslint/no-unused-vars */
import {RouteLocationNormalized, NavigationGuardNext} from 'vue-router'
import router from './router'
import useUserStore from './store/user'
import useDictStore from './store/dictStore'
import {useTabsStore} from 'riking-layout'
import getPageTitle from '@/utils/pageTitle'
import {getToken, removeToken, removeRefreshToken} from '@/utils/token'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import {
    getSubSystem, getSubSystemList,
    getSubSystemName,
    setRequestClassificationCode,
} from "@/utils/subSystem";
import {expLoading} from "@/components/UpAndDown.vue";
import {isExpPathArray, isExpSubSystemArray} from "@/views/query/feedback/page";
import {RS} from "riking-ui";
import {getJumpUrl} from "@/utils/utils";
// import useBranchChange from '@/hooks/useChangeBranch'
// import useBusinessLine from '@/hooks/useChangeBusinessLine'

const {cookies} = useCookies()

NProgress.configure({showSpinner: false}) // 进度环显示/隐藏

const whiteList = ['/login', '/accessToken'] // no redirect whitelist

const checkRepoBranchCode = async () => {
    const userStore = useUserStore()
    // const data: any = await userStore.loadCurrentBizData()
    // if (!data || !data?.branchCode) {
    //   await useBranchChange()
    // }
    // const userStore = useUserStore()
    // if (!userStore.repoBranchCode) {
    //   try {
    //     const repoBranchCode = await userStore.loadRepoBranchCode()
    //     if (!repoBranchCode) {
    //       await useBranchChange()
    //     }
    //   } catch (error) {
    //     await userStore.logout()
    //     return Promise.reject(error)
    //   }
    // }
    // if (!userStore.lineCode) {
    //   try {
    //     const lineCode = await userStore.loadBusinessLineCode()
    //     if (!lineCode) {
    //       await useBusinessLine()
    //     }
    //   } catch (error) {
    //     await userStore.logout()
    //     return Promise.reject(error)
    //   }
    // }
}

router.beforeEach(
    async (
        to: RouteLocationNormalized,
        _: RouteLocationNormalized,
        next: NavigationGuardNext
    ) => {
        NProgress.start()
        if (to.path === '/accessToken') {
            removeToken()
            removeRefreshToken()
            const userStore = useUserStore()
            userStore.resetSubSystem()
        }
        const settingStore = useSettingsStore()
        settingStore.systemName = getSubSystemName();

        if(getSubSystem()){
             document.title = getPageTitle(getSubSystem(),getSubSystemName())
        }
        // let arr = getJumpUrl(to.query['subSystem'] as string)
        // if (arr != null) {
        //     document.title = getPageTitle(arr[0], arr[1])
        // }
        const dictsStore = useDictStore()

        const hasToken = !!getToken()
        if (hasToken) {
            const userStore = useUserStore()

            if (getSubSystemList() == null) {
                await userStore.loadUserSystems();
                await dictsStore.loadDict();
            }
            const getDictByTypeCode = (data: any): Promise<RS> => {
                return service({
                    url: '/dict/getDictByTypeCode',
                    method: 'post',
                    params: data
                })
            };

            // 第三方登录地址，并保存在sessionStorage用来在token失效时使用
            const result = await getDictByTypeCode({typeCode: 'thirdPartyLoginUrl'});
            let thirdPartyLoginUrl;
            if(result && result.data.length) {
                thirdPartyLoginUrl = result.data[0].dictValue;
            } else {
                thirdPartyLoginUrl = window.g.thirdPartyLoginUrl;
            }
            sessionStorage.setItem('thirdPartyLoginUrl', thirdPartyLoginUrl);

            //const result = await getDictByTypeCode({typeCode: 'mfaLoginUrl'})
            //sessionStorage.setItem("mfaLoginUrlArr", JSON.stringify(result.data));
            if (whiteList.includes(to.path)) {
                next({path: '/'})
                NProgress.done()
            } else {

                /*if (to.query['mfa']) {
                    try {
                        await userStore.loadUserSystems();
                        await dictsStore.loadDict();
                        cookies.set('loginFrom', 'mfa');
                    } finally {
                    }
                }*/
                // 未加载 用户资源
                if (!userStore.routes || userStore.routes?.length <= 0) {
                    try {
                        console.log('permission.ts: 3', userStore.routes);
                        await checkRepoBranchCode()
                        await userStore.loadUserResources()
                        // await userStore.loadUserInfo()
                        console.log('to.path', to.path);
                        next({path: to.path, replace: true})
                        // 触发重定向
                    } catch (error) {
                        console.error(error)
                        removeToken()
                        removeRefreshToken()
                        if (!!thirdPartyLoginUrl) {
                            window.location.href = `${thirdPartyLoginUrl}?redirect=${to.path}`
                        } else {
                            next(`/login?redirect=${to.path}`)
                        }
                        NProgress.done()
                    }
                } else {
                    try {
                        // await checkRepoBranchCode()
                        console.log('to.path', to.path);
                        next()
                    } catch (error) {
                        removeToken()
                        removeRefreshToken()
                        if (!!thirdPartyLoginUrl) {
                            window.location.href = `${thirdPartyLoginUrl}?redirect=${to.path}`
                        } else {
                            next(`/login?redirect=${to.path}`)
                        }
                        NProgress.done()
                    }
                }
            }
        } else {
            // 未登录
            if (whiteList.includes(to.path)) {
                next()
            } else {
                // token失效下的跳转
                const thirdPartyLoginUrl = sessionStorage.getItem('thirdPartyLoginUrl');
                if (!!thirdPartyLoginUrl) {
                    window.location.href = `${thirdPartyLoginUrl}?redirect=${to.path}`
                    sessionStorage.removeItem('thirdPartyLoginUrl')
                    useTabsStore().clear()
                    next()
                } else {
                    console.log('permission.ts: 41');
                    // next(`/login?redirect=${to.path}`)
                    next(`/login`)
                    // const loginFrom = cookies.get('loginFrom');
                    // const logoutPath = loginFrom ? mfaUrl : `/login`;
                    // next(logoutPath);
                    NProgress.done()
                }
            }
        }
    }
)

router.afterEach(() => {
    let path = router.currentRoute.value.path;
    let parts = path.split('/');
    let requestClassificationCode = parts[parts.length - 1];
    // let pageIndicator = parts[parts.length -2];
    if (requestClassificationCode != 'login') {
        setRequestClassificationCode(requestClassificationCode);
    }
    console.log(router);
//以下逻辑修复导出加载状态问题
    if (isExpPathArray.value.indexOf(path) !== -1 && isExpSubSystemArray.value.indexOf(getSubSystem()) !== -1) {
        expLoading.value = true
    } else {
        expLoading.value = false
    }
    // todo
    // if(router.currentRoute.value.name === '404') {
    //   const subSystemList = JSON.parse(getSubSystemList());
    //   setSubSystem(subSystemList[0].value)
    //   setSubSystemName(subSystemList[0].label);
    // }
    NProgress.done()
})
