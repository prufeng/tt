import { App, Directive } from 'vue'
// import { vLoading } from 'element-plus'
import { permission } from './permission'
const directives: { [key: string]: Directive } = {
  // 指令对象
  // loading: vLoading,
  permission: permission,
}

export default {
  install(app: App<Element>) {
    Object.keys(directives).forEach((key) => {
      app.directive(key, directives[key])
    })
  },
}
