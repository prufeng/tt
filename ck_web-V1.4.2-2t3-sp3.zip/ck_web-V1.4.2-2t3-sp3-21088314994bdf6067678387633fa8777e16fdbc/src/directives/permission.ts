/* eslint-disable @typescript-eslint/no-unused-vars */
import type { Directive, VNode } from 'vue'

export const permission: Directive<HTMLElement, { permSigns: string[] }> = {
  mounted(el, binding, vnode: VNode<any, HTMLElement>) {
    // const value = vnode.context.$route?.meta.permCodes
    // const value = binding.instance?.$route?.meta?.permSigns
    const { arg = '', value: { permSigns = [] } = {} } = binding
    const hasPermission = permSigns.length > 0 && permSigns.includes(arg)
    if (!hasPermission) {
      el.parentNode && el.parentNode.removeChild(el)
    }
  },
}
