import { RouteRecordRaw, _RouteRecordBase } from 'vue-router'
import { BlankView, DictView, OperateLogView, ParamView, CacheView } from 'riking-layout'
import Layout from '@/layout/index.vue'

declare module 'vue-router' {
  interface RouteMeta {
    title?: string
    icon?: string
    affix?: boolean
    hidden?: boolean
    permSigns?: string[]
  }
}

export const asyncRoutes: Array<RouteRecordRaw> = [
  {
    path: '/dashboard',
    meta: {
      title: '首页',
      icon: 'icon_home',
    },
    redirect: '/dashboard/home',
    children: [
      {
        path: '/dashboard/home',
        meta: {
          title: '仪表盘',
          affix: true,
        },
        component: () => import('@/views/dashboard/index.vue'),
      },
    ],
  },
  {
    path: '/sys',
    meta: {
      title: '系统配置',
      icon: 'icon_System_Configuration',
    },
    redirect: '/sys/dictType',
    children: [
      {
        path: '/sys/dictType',
        meta: {
          title: '字典类型管理',
        },
        component: async () => DictView,
      },
    ],
  },
  {
    path: '/operateLog',
    meta: {
      icon: 'icon_LogManagement',
      title: '操作日志',
    },
    component: async () => OperateLogView,
  },
]

// /src/layout/index.vue: () => import('/src/layout/index.vue?t=1665301289686')
// /src/views/branch/index.vue :  () => import('/src/views/branch/index.vue')

const dynamicComponents = import.meta.glob(['@/views/**/*.vue'])
// dynamicComponents['BlankView'] = async () => BlankView // 导致缓存失效，原因不明。 多了一层组件
// dynamicComponents['CacheView'] = async () => CacheView
dynamicComponents['ParamView'] = async () => ParamView
dynamicComponents['DictView'] = async () => DictView
dynamicComponents['OperateLogView'] = async () => OperateLogView
dynamicComponents['Layout'] = async () => Layout

/**
 * route 解析构造
 * @param {*} routes
 * @returns
 */
export const buildAsyncRoutes = (routes: any[], parentPath = ''): RouteRecordRaw[] => {
  const res: RouteRecordRaw[] = []
  routes.forEach((route) => {
    // let component = dynamicComponents['Layout']
    // if (parentPath !== '' && parentPath !== '/') {
    //   if (!route['componentPath']) {
    //     component = dynamicComponents['BlankView']
    //   } else {
    //     component = dynamicComponents[route['componentPath']] || dynamicComponents[`/src/${route['componentPath']}`]
    //   }
    // }

    let component = dynamicComponents['BlankView']
    if (!!route['componentPath']) {
      component = dynamicComponents[route['componentPath']] || dynamicComponents[`/src/${route['componentPath']}`]
    }

    // TODO 根据配置， requestClassificationCode 和route url关系映射，动态设置 props中的指
    // TODO methods implements

    const tmpRoute: RouteRecordRaw = {
      path: parentPath + route['routeUrl'],
      component,
      name: parentPath + route['routeUrl'],
      meta: {
        componentPath: route['componentPath'],
        title: route['menuName'],
        icon: route['menuIcon'],
        affix: !!route['affix'],
        menuCode: route['menuCode'],
        subSysCode: route['subSysCode'],
        permSigns: route['permSigns'],
      },
      // props:{requestClassificationCode: 'SS01'}
      // children: route['children']
    }
    if (route['children']) {
      const tmpBase = tmpRoute as _RouteRecordBase
      tmpBase['children'] = buildAsyncRoutes(route['children'], tmpRoute['path'])
      const firstChild = tmpBase['children'][0]
      tmpBase['redirect'] = firstChild['redirect'] ?? firstChild['path']
    }
    res.push(tmpRoute)
  })

  return res
}

/**
 * list 转 tree
 * @param {*} data
 * @returns
 */
export function treeData(data: any[]) {
  // 深复制 + 排序
  const cloneData: any[] = JSON.parse(JSON.stringify(data)).sort((d1: any, d2: any) => {
    return d1['showOrder'] - d2['showOrder'] || d1['id'] - d2['id']
  })
  // 分出  menus  buttons
  const menus = cloneData.filter((m) => m['menuType'] == '2' || m['menuType'] == '3')
  const buttons = cloneData.filter((b) => b['menuType'] === '4')

  menus.forEach((m) => {
    m['permSigns'] = buttons.filter((b) => m['menuCode'] === b['superMenuCode']).map((b) => b['permissionsSign'])
  })

  // list 转 tree
  return menus.filter((curr) => {
    const children = menus.filter((child) => curr['menuCode'] == child['superMenuCode'])
    children.length > 0 ? (curr['children'] = children) : ''
    const father = menus.find((father) => curr['superMenuCode'] == father['menuCode'])
    // 未找到 father ,即 curr 是最底层了，需要返回
    !father ? (curr['systemMenuCode'] = curr['superMenuCode']) : ''
    return !father
  })
}