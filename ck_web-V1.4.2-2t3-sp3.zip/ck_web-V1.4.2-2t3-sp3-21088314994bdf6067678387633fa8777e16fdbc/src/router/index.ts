import { createRouter, createWebHistory, createWebHashHistory, RouteRecordRaw, _RouteRecordBase } from 'vue-router'
import Layout from '@/layout/index.vue'
import {RedirectView, NotFoundView, DictDataView} from 'riking-layout'

export { treeData, buildAsyncRoutes, asyncRoutes } from './asyncRoute'

export const routes: Array<RouteRecordRaw> = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/Login.vue'),
  },
  {
    path: '/accessToken',
    name: 'accessToken',
    component: () => import('@/views/accessToken.vue'),
  },
  {
    path: '/404',
    name: '404',
    component: () => NotFoundView,
  },
  {
    path: '/redirect',
    name: 'redirect',
    component: async () => Layout,
    children: [
      {
        path: '/redirect/:path(.*)',
        name: 'redirectPath',
        component: async () => RedirectView,
      },
    ],
  },
  {

    path: '/dict',
    name: 'dict',
    component: async () => Layout,
    children:[
      {
        path: '/dict/dictData/:dictTypeCode',
        meta: {
          title: '字典码值',
          hidden: true,
        },
        component: DictDataView,
        name: 'dictData',
        props: true,
      },
    ]
  }
]

export const notFoundRoute: RouteRecordRaw = {
  path: '/:catchAll(.*)', // 此处需特别注意至于最底部
  name: 'catch404',
  redirect: '/404',
  meta: {
    hidden: true,
  },
}

export const rootRoute: RouteRecordRaw = {
  path: '/',
  component: async () => Layout,
}

const router = createRouter({
  // history: createWebHistory(import.meta.env.BASE_URL),
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes,
})

// export function resetRouter() {
//   const newRouter: any = createRouterFun()
//   router.matcher = newRouter.matcher // reset router
// }

export function resetRouter(removeRouteFns: Array<() => void>) {
  removeRouteFns.forEach((fn) => fn())
}

export default router
