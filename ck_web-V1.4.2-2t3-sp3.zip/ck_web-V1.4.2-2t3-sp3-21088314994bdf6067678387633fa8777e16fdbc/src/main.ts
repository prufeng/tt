if (!Array.prototype.hasOwnProperty('at')) {
    Object.defineProperty(Array.prototype, 'at', {
        value: function(index) {
            const length = this.length >>> 0;
            let relativeIndex = index < 0 ? index + length : index;
            return relativeIndex >= 0 && relativeIndex < length ? this[relativeIndex] : undefined;
        },
        configurable: true,
        writable: true
    });
}

import { createApp } from 'vue'

import App from './App.vue'

import store from '@/store'
import router from '@/router'
import i18n from '@/i18n'

import '@/permission'

import { ElLoading, ElFormItem } from 'element-plus'
import directives from '@/directives/index'

import 'element-plus/dist/index.css'

import RikingUI from 'riking-ui'
import 'riking-ui/dist/style.css'

import '@/style.css' // 引入项目全局样式

// 全局样式
import 'riking-ui/src/assets/styles/index.scss'

// 引入阿里云字体图标css
import 'riking-ui/src/assets/font/icon/iconfont.css'

import RikingLayout from 'riking-layout'
import 'riking-layout/dist/style.css'

import service from '@/utils/request'

import CKEditor from '@ckeditor/ckeditor5-vue';

import moment from 'moment'

// 创建 vue 实例
const app = createApp(App)

// 加载指令
app.use(ElLoading, ElFormItem).use(directives)

// 挂载 pinia
app.use(store)

// 挂载 router
app.use(router)

app.use(RikingUI, service).use(RikingLayout)

// 挂载 i18n
app.use(i18n)

app.use(CKEditor)

app.directive('preventReClick', (el, binding) => {
    function preventReClickFun(elValue, bindingValue) {
        if (!elValue.disabled) {
            elValue.disabled = true
            setTimeout(() => {
                elValue.disabled = false
            }, bindingValue.value || 3000)
        }
    }
    el.addEventListener('click', () => preventReClickFun(el, binding))
    binding.dir.unmounted = function() {
        el.removeEventListener('click', () => preventReClickFun(el, binding))
    }
});

// 挂载实例
app.mount('#app')
