<template>
  <el-dropdown @visible-change="handleVisibleChange">
    <span class="avatar-dropdown">
      <el-avatar :src="userStore.avatar || imgUrl" class="user-avatar" />
      <div class="user-name">
        <span class="hidden-xs-only">{{ userStore.username }}</span>
        <span :class="{ 'rk-dropdown-active': active }" class="rk-dropdown">
          <i class="iconfont icon_arrow_d"></i>
        </span>
      </div>
    </span>

    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item>
          <!--版本号-->
          <i class="iconfont icon_update" />
          V1.4.2
        </el-dropdown-item>

        <el-dropdown-item @click="handleUserInfo">
          <i class="iconfont icon_data_change" />个人中心
        </el-dropdown-item>

        <el-dropdown-item @click="handlePassword" ref="passwordRef">
          <i class="iconfont icon_edit" />修改密码
        </el-dropdown-item>

        <!-- <el-dropdown-item @click="handleExportFile">
          <i class="iconfont icon_download" />
          我的下载
        </el-dropdown-item> -->

        <el-dropdown-item @click="handleLogout">
          <i class="iconfont icon_sign_out" />退出登录
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>

  <user-export-file-page ref="exportFileRef"></user-export-file-page>

  <user-info-view ref="userInfoRef"></user-info-view>

  <Password ref="passwordRef"/>

</template>
//    :pass-form-items="passFormItems"
//    :user-form-items="baseFormItems"
<!-- @save-user="updateUser"
    @save-pass="updatePass"
    activeName="second" -->

<script setup lang="ts">
import { ref } from 'vue'
import { FormItemInfo } from 'riking-ui'
import { UserExportFilePage, UserInfoView } from 'riking-layout'

import useLogout from '@/hooks/useLogout'
import useUserStore from '@/store/user'

import { getUserInfo, updateUserInfo, updateUserPass, findUserBranchDict, findUserBizLineDict } from '@/apis/user'
import Password from "@/layout/Password.vue";
// import imgUrl from '@/assets/images/head.png'

const imgUrl = new URL('@/assets/images/head.png', import.meta.url).href

const userStore = useUserStore()

const { handleLogout } = useLogout()

const passwordRef = ref<FormInstance>()
const showPassword = ref(false);

const handlePassword = async () => {
  passwordRef.value.show();
}

const { dictState, waitCompleted } = useDict([], [], {
  repoBranchCode: async () => {
    const { data } = await findUserBranchDict()
    return data
  },
  lineCode: async () => {
    const { data } = await findUserBizLineDict()
    return data
  },
})

const active = ref(false)
function handleVisibleChange(val: boolean) {
  active.value = val
}

// 个人中心
const userInfoRef = ref()

const handleUserInfo = async () => {
  const { data } = await getUserInfo()
  // todo
  userInfoRef.value.open(
    data || {
      username: 'todo',
      phoneNumber: 'todo',
      email: 'todo',
      lineCodeList: 'todo',
      roleCodeList: 'todo',
      createTime: 'todo',
    },
  )
}

const updateUser = async (user: any) => {
  await updateUserInfo(user)
  ElMessage.success('修改成功')
}

const updatePass = async (pass: any) => {
  await updateUserPass(pass)
  ElMessage.success('修改成功')
}

const baseFormItems: FormItemInfo[] = [
  {
    prop: 'repoBranchCode',
    label: '上报机构',
    inputType: {
      tag: 'select',
      options: dictState.repoBranchCode,
    },
    rules: [{ required: true, message: '必填' }],
    extra: { span: 24 },
  },
  {
    prop: 'lineCode',
    label: '业务线',
    inputType: {
      tag: 'select',
      options: dictState.lineCode,
    },
    rules: [{ required: true, message: '必填' }],
    extra: { span: 24 },
  },
]

const passFormItems: FormItemInfo[] = [
  {
    prop: 'oldPassword',
    label: '旧密码',
    inputType: { tag: 'input', type: 'password' },
    rules: [{ required: true, message: '必填' }],
    extra: { span: 24 },
  },
  {
    prop: 'newPassword',
    label: '新密码',
    inputType: { tag: 'input', type: 'password' },
    rules: [{ required: true, message: '必填' }],
    extra: { span: 24 },
  },
  {
    prop: 'confirmPassword',
    label: '确认密码',
    inputType: { tag: 'input', type: 'password' },
    rules: [{ required: true, message: '必填' }],
    extra: { span: 24 },
  },
]

//我的下载
const exportFileRef = ref()

const handleExportFile = () => {
  exportFileRef.value.open()
}
</script>

<style lang="scss" scoped>
.header {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: var(--base-nav-bar-height);
  padding: 0 15px;
  background-color: #ffffff;
  border-bottom: 1px solid #f6f6f6;
  .header-lf {
    .hamburger-container {
      line-height: var(--base-nav-bar-height);
      height: 100%;
      float: left;
      font-size: 20px;
      color: #333;
      cursor: pointer;
      transition: background 0.3s;
      -webkit-tap-highlight-color: transparent;

      &:hover i {
        color: var(--el-color-primary);
      }
    }
    .is-active {
      transform: rotate(180deg);
    }
  }
  .header-ri {
    margin: 0 0 0 30px;
    .header-icon {
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #666;
      .right_menu-item {
        display: flex;
        align-items: center;
        cursor: pointer;
        position: relative;
        min-width: 30px;
        margin: 0 4px;
        text-align: center;
        justify-content: center;
        transition: background-color 0.3s;
      }
      .icon-style {
        font-size: 20px;
        color: rgb(0 0 0 / 75%);
        cursor: pointer;
      }
    }
    .el-dropdown {
      vertical-align: middle;
    }
    .avatar-dropdown {
      display: flex;
      align-content: center;
      align-items: center;
      justify-content: center;
      justify-items: center;

      .user-avatar {
        width: 36px;
        height: 36px;
        margin-left: 5px;
        cursor: pointer;
        border-radius: 50%;
      }

      .user-name {
        position: relative;
        display: flex;
        align-content: center;
        align-items: center;
        height: 40px;
        margin-left: 6px;
        line-height: 40px;
        font-size: 12px;
        cursor: pointer;
        .rk-dropdown {
          font-size: 14px;
          padding: 2px;
        }
        [class*='ri-'] {
          margin-left: 0 !important;
        }
      }
    }
  }
  .theme-switch {
    display: flex;
    justify-content: center;
    margin-top: 35px;
  }
}

.el-autocomplete__popper {
  .el-icon {
    position: relative;
    top: 2px;
    font-size: 16px;
  }
  span {
    margin: 0 0 0 10px;
    font-size: 14px;
  }
}
</style>
