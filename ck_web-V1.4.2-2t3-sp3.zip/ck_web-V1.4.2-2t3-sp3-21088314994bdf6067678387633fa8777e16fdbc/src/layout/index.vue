<template>
  <layout-view v-if="userStore.showLayout">
    <template #avatar>
      <!--<div id="subSystemList" class="list">-->

<!--      <el-menu mode="horizontal" class="list" background-color="#282c34" text-color="#fff" active-text-color="red"
        @select="handleTabClick">
        <el-menu-item v-for="(item, index) in subSystemList" :index="item" :key="index" class="menu-item"
          :class="[userStore.subSystem === item.value ? 'active' : '']">
          {{ item.label }}
        </el-menu-item>
      </el-menu>-->

      <!--<el-button class="btn" :class="[userStore.subSystem === item.value ? 'active' : '']"-->
      <!--  v-for="(item, index) in subSystemList" @click="handleTabClick(item.value, item.label)" :key="index" :l="item.label">-->
      <!--  {{ item.label }}-->
      <!--</el-button>-->
      <!--</div>-->
      <user-avatar />
    </template>
    <template #sysCenter> <SysCenter /></template>
  </layout-view>
</template>

<script setup lang="ts">
import { LayoutView, useTabsStore } from 'riking-layout'
import useUserStore from "@/store/user";
import UserAvatar from './Avatar.vue'
import { getSubSystemList } from "@/utils/subSystem";
import { onMounted } from 'vue'
import service from '@/utils/request';
import { RS } from 'riking-ui'
import useChangeTab from '@/hooks/useChangeTab'
import SysCenter from './SubSysList.vue'

const getDictByTypeCode = (data: any): Promise<RS> => {
  return service({
    url: '/dict/getDictByTypeCode',
    method: 'post',
    params: data
  })
};

const route = useRoute()
const router = useRouter();
const userTabs = useTabsStore()
const userStore = useUserStore()
const subSystemList = JSON.parse(getSubSystemList());
const { handleTabClick, setWatermark } = useChangeTab()

onMounted(async () => {
  var element = document.getElementsByClassName("right_menu-item")[3];
  element.style.display = "none";


  // // 获取ul的子元素li
  // var liElements = element.getElementsByTagName('div');



  // // 判断是否有至少两个li元素

  // // 移除前两个li元素
  // element.removeChild(liElements[3]);
  setWatermark()
})



</script>


<style scoped>
.list {
  position: absolute;
  left: 50px;
  /*display: flex;*/
  /*flex-direction: row;*/
  /*font-size: 23px;*/
}

ul.el-menu.el-menu--horizontal.list {
  height: 48px;
  width: 75%;
}

.menu-item.active {
  background: var(--el-color-primary);
  /* #5c51e3;*/
}

/*悬浮颜色*/
.el-menu--horizontal .el-menu-item:not(.is-disabled):hover {
  /*background: #5c51e3;*/
  background: var(--base-menu-background-hover);
}

/*.el-menu--horizontal .el-menu-item:not(.is-disabled):active{*/
/*  !*background: #5c51e3;*!*/
/*  background: green;*/
/*}*/



.btn {
  /*background: #409eff;*/
  background: #bdbdc0;
  color: white;
  font-size: 14px !important;
  /*font-weight: bold;*/
}

.btn.active {
  background-color: #5c51e3;
  /*color: #409eff;*/
  border-color: #fff;
}
</style>

