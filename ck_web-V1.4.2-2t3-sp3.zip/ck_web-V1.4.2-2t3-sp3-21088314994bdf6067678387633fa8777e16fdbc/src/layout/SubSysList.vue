<template>
  <div class="sys">
    <template v-if="systemMenuList?.length === 1">
      <template v-for="(item, index) in systemMenuList" :key="index">
        <div class="home" :class="systemCode === item.subSysCode ? 'sysActive' : ''" @click="toOtherSystem(item)">
          <i :class="'iconfont icon_System_Configuration'"></i>
          <div class="sys_home">{{ item.subSysName }}</div>
        </div>
      </template>
    </template>
    <template v-if="systemMenuList?.length > 1">
      <el-dropdown @visible-change="handleVisibleChange">
        <span :class="{ 'rk-dropdown-active': active }" class="rk-dropdown">
          <i class="iconfont icon_organization"></i>
          {{ sysName }}
          <i class="iconfont icon_arrow_d"></i>
        </span>
        <template #dropdown>
          <el-dropdown-menu>
            <template v-for="(item, index) in systemMenuList" :key="index">
              <el-dropdown-item :class="systemCode === item.subSysCode ? 'sysActive' : ''" @click="toOtherSystem(item)">
                <i class="iconfont icon_ManagementBackground" />
                {{ item.subSysName }}
              </el-dropdown-item>
            </template>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </template>
  </div>
</template>
<script setup lang="ts">
import useUserStore from '../store/user'
import { getToken } from '@/utils/token'
import {getSubSystem} from "@/utils/subSystem";
import { useTabsStore } from 'riking-layout'


// 子系统信息查询
function getUserSubSysList() {
  return service({
    url: '/oauth/getUserSubSysList',
    method: 'post',
  })
}

const handleVisibleChange = (val: boolean) => {
  active.value = val
}

const systemCode = ref('')
const max = ref(3)
const userStore = useUserStore()
const router = useRouter()
const route = useRoute()
const userTabs = useTabsStore()


// _self：当前窗口中打开。
// _blank 或者 不写该参数：新窗口中打开，
const toOtherSystem = (item: any) => {
  const token = getToken()
  const url = item.webUrl
  if (url) {
    systemCode.value = item.subSysCode
    sysName.value = item.subSysName
    localStorage.setItem('sysCode', item.subSysCode)
    if(url.indexOf("?")>0){
      window.location.href = `${url}&sectok3=${token}&redirect=${route.fullPath}`
    }else{
      window.location.href = `${url}?sectok3=${token}&redirect=${route.fullPath}`
    }
    userTabs.clear()
  } else {
    ElMessage.error('请维护系统路径')
  }
}

const sysName = ref('请选择')
const active = ref(false)

const systemMenuList = ref<any[]>([])
const defaultSystemName = getSubSystem()
onMounted(async () => {
  const { data } = await getUserSubSysList()
  const systems = data.filter((item: any) => {
    return item.webUrl?.length > 0
  })
  sysName.value = systems?.find((item: any) => item.subSysCode === defaultSystemName)?.subSysName as string

  systemMenuList.value = systems
})
</script>
<style lang="scss" scoped>
.sys {
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 300px;
  font-size: 18px;
  color: #ffffff;
  .home {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 9px 12px;
    border-radius: 8px;
    font-size: 14px;
    background-color: rgba(255, 255, 255, 0.15);
    margin-right: 20px;

    cursor: pointer;
    .sys_home {
      position: relative;
      margin-left: 10px;
      white-space: nowrap;
    }
  }
  // .sysActive {
  //   font-size: 16px;
  //   background-color: rgba(255, 255, 255, 0.35);
  //   // color: #b5acac;
  //   border-radius: 12px;
  // }

  .rk-dropdown {
    display: flex;
    white-space: nowrap;
    text-align: center;
    color: #ffffff;
    cursor: pointer;
    padding: 9px 12px;
    border-radius: 8px;
    font-size: 14px;
    background-color: rgba(255, 255, 255, 0.15);
    .icon_organization {
      margin-right: 13px;
    }
    .icon_arrow_d {
      margin-left: 15px;
    }
    // .sysActive {
    //   font-size: 16px;
    //   background-color: red;
    // }
  }
}
// .sysActive {
//   font-size: 16px;
//   background-color: red;
// }
</style>
