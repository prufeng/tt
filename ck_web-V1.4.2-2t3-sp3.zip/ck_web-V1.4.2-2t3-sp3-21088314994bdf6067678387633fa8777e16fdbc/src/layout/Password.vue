<template>
  <el-dialog v-model="visible" title="修改密码" width="500" :before-close="close">
    <el-form :model="form" ref="formRef">
      <el-form-item v-for="item in formItems" :label="item.label" :prop="item.prop">
        <el-input v-model="form[item.prop]" :type="item.type"/>
      </el-form-item>

      <el-form-item>
        <el-text>
          密码最小长度:6 <br/>
          密码有效期(d/天, m/月)(例：10d):666d
        </el-text>
      </el-form-item>

      <el-form-item class="abc">
        <el-button @click="submit" type="primary">修改</el-button>
        <el-button @click="cancel" type="primary">取消</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>


<script setup lang="ts">
import {FormInstance} from "element-plus";
import useLogout from "@/hooks/useLogout";
import useUserStore from "@/store/user";
import {
  removeRequestClassificationCode,
  removeSubSystem,
  removeSubSystemList,
  removeSubSystemName
} from "@/utils/subSystem";


const { handleLogout } = useLogout()

const visible = ref(false)

const show = () => {
  visible.value = true;
}

defineExpose({show})

const formItems = [
  {
    prop: 'oldPassword',
    label: '旧密码',
    type: 'password'
  },
  {
    prop: 'newPassword',
    label: '新密码',
    type: 'password'
  },
  {
    prop: 'confirmPassword',
    label: '确认密码',
    type: 'password'
  },
]

const formRef = ref<FormInstance>();

const form = ref({
  oldPassword: '',
  newPassword: '',
  confirmPassword: '',
})

const userStore = useUserStore()

const router = useRouter()

const submit = async() => {
  const result = await updatePwd(form.value)
  if(result && result.code == '200') {
    ElMessage.success('修改密码' + result.msg);
    formRef.value.resetFields();
    visible.value = false;

    clearCookie();
    await userStore.resetUserData();
    const thirdPartyLoginUrl = sessionStorage.getItem('thirdPartyLoginUrl');

    setTimeout(function(){
      if (!!thirdPartyLoginUrl) {
         window.location.href = `${thirdPartyLoginUrl}`
      } else {
        router.push(`/login`)
      }
    }, 2000)
  }
}

const cancel = () => {
  visible.value = false;
}

const close = () => {
  visible.value = false;
}

async function updatePwd(data) {
  return service({
    url: '/oauth/updatePwd',
    method: 'post',
    data: data
  })
}

// 退出时清理cookie设置
function clearCookie() {
  removeSubSystem();
  removeSubSystemList();
  removeSubSystemName()
  removeRequestClassificationCode();
}

</script>


<style scoped lang="scss">
   ::v-deep .abc {
     .el-form-item__content {
       display: flex;
       justify-content: flex-end;
     }
   }
</style>