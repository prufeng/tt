import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
  {key: 'id', type: 'selection'},
  {prop: 'queryDept', label: '查询部门编码',dictFormatKey:"queryOrg"},
  { prop: 'sendDate', label: '发送时间', formatter: (row:any) => {
      if (row.sendDate) {
        const date = new Date(row.sendDate);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
      }
      return '';
    }},

  {prop: 'queryType', label: '查询状态类型',dictFormatKey:"fileStateQueryType"},
  {prop: 'fileName', label: '文件名称'},
  {prop: 'userIp', label: '客户端真实IP',   inputType:'input' },
  {prop: 'returnQueryType', label: '文件状态',dictFormatKey:"fileStateResponseType"},
  {
    key: 'actions',
    label: '操作',
    scopedSlots: 'actions',
    fixedWidth: 200,
    fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'queryDept',
    label: '查询部门编码',
    inputType: {
      tag: 'select',
      options: 'queryOrg',
      // multiple: true,
  },
  },
  {
    prop: 'returnQueryType',
    label: '文件状态',
    inputType: {
      tag: 'select',
      options: 'fileStateResponseType',
      // multiple: true,
  },
  },
  {
    prop: 'fileName',
    label: '文件名称',
    inputType: 'input',
  },
];

export const formItems: FormItemInfo[] = [
  {prop: 'queryDept', label: '查询部门编码',inputType:  {tag: 'select', options: 'queryOrg'},  rules: [{ required: true, message: '查询部门编码不能为空', trigger: 'blur' }],    extra: { span: 24 },},
  {prop: 'sendDate', label: '发送时间',inputType:  "date-picker",   rules: [{ required: true, message: '发送时间不能为空', trigger: 'blur' }],    extra: { span: 24 },},
  {prop: 'queryType', label: '查询状态类型',inputType:   {tag: 'select', options: 'fileStateQueryType'},  rules: [{ required: true, message: '查询状态类型不能为空', trigger: 'blur' }],    extra: { span: 24 },},
  {prop: 'fileName', label: '文件名称',inputType:  "input",  rules: [{ required: true, message: '文件名称不能为空', trigger: 'blur' }],    extra: { span: 24 },},

];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {}