<template>
<rk-index-layout>
  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search"
                  :label-width="50" @keyup.enter="search">
    <!-- 自定义渲染 -->
    <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
  </rk-search-form>

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page"
                 @page-change="pageChange" @refresh="search" @selection-change="getCheckboxId">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
    </template>

    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta"
                       link></rk-button-group>
    </template>
  </rk-page-table>
</rk-index-layout>



  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed">
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems"
                    :disabled="dialogData.formDisabled">
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import {provide, onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage} from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm, RS,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm, RkIndexLayout
} from 'riking-ui'
import {columns, formItems, pagination, searchItems} from "@/views/ybjh/fileStatus/queryStatus.data";
import {getQuartzList, searchList, addQuery, queryState, deleteMore} from '@/views/ybjh/fileStatus/queryStatus.api'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm';
import oauthUser from "@/views/sys/oauthUser/oauthUser.vue";
import {addUser} from "@/views/sys/note/addresseeRules/addressee/addressee.api";
import {openBatchOptMessage} from "riking-layout";


const myComponent = ref();

useDict([], [], dictData);
let ids: [];
const getCheckboxId = async (val: any) => {
  ids = val.map((item: any) => item.id);
}
const {state, init, handlePageChange, handleSortChange, handleSelectionChange} = useState(searchList)

const handleAdd = async () => {
  open(undefined, false, "新增");
}
const handleRowId = {

}
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => {
      open(row, true, '查看');
    }
  },
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => {
      open(row, false, '编辑');
    }
  },
  {
    key: 'QUERY', label: '查询文件状态', tag: 'button', type: 'primary', handler: () => {
      queryFileState(row)
    }
  },

]
const buttons: ButtonInfo[] = [
  {
    key: 'ADD',
    label: '新增查询',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleAdd(),
  },
  {
    key: 'DELETE_BATCH',
    label: '批量删除',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => handleDelete(),
  },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const search = async () => {
  init();
  console.log(searchForm.value);
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  console.log(result.result);
  console.log(page.value);
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}


onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

const handleSave = async () => {
  const valid = await dialogFormRef.value?.asyncValidate();
  if (valid){
    dialogData.loading = true
    try {
      const formData = dialogForm.value;
      const rs = await addQuery(formData);
      search();
      close();
      ElMessage.success(rs.result)
    } finally {
      setTimeout(() => (dialogData.loading = false), 50)
    }
  }
}
const handleDelete = async () => {
  //选中的数据
  console.log(ids)
  dialogData.loading = true
  try {
    if (ids==undefined||ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    const action = await ElMessageBox.confirm('是否确认删除?', '警告', {type: 'warning'})
    if (action == 'confirm') {
      let rs = await deleteMore(ids)
      search();
      close();
      ElMessage.success("删除成功:"+rs.result+"条")
    }
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}
const queryFileState = async (row:any) => {
  dialogData.loading = true
  try {
    const formData = row;
    console.log(formData.id)
    const rs = await queryState(formData.id);
    search();
    close();
    ElMessage.success(rs.result)
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}
</script>

<style scoped></style>