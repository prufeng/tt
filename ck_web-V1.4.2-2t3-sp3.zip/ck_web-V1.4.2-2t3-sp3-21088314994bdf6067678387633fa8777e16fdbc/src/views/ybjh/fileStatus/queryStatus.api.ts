// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
enum Api {
  list = '/fileStatus/list',
  get = '/fileStatus/queryById',
  save = '/fileStatus/save',
  queryState = '/fileStatus/queryState',
  deleteBatch = '/fileStatus/deleteBatch',
}
/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'POST',
    data,
  })
}
//新增或编辑
export function addQuery(data: any) {
  return service({
    url: Api.save,
    method: 'POST',
    data,
  })
}
//查询文件状态
export function queryState(id: bigint) {
  return service({
    url: Api.queryState,
    method: 'POST',
    params:{id},
  })
}
//批量删除
export function deleteMore(data: any) {
  return service({
    url: Api.deleteBatch,
    method: 'DELETE',
    data,
  })
}

