import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
  {key: 'id', type: 'selection'},
  {prop: 'wjmc', label: '文件名称' },
  {prop: 'ywlx', label: '业务类型' ,dictFormatKey: 'ywlx'},
  {prop: 'wtdl', label: '问题大类',dictFormatKey: 'wtdl'},
  {prop: 'wtzl', label: '问题子类',dictFormatKey: 'wtzl'},
  {prop: 'wtms', label: '问题描述'},
  {
    prop: 'qqdbs',
    label: '请求单标识',
    inputType:'input' 
  },
  // {
  //   prop: 'status',
  //   label: '完成状态',
  //   inputType:'input',
  //   dictFormatKey: 'dataStatus' 
  // },
  {
      key: 'actions',
      label: '操作',
      scopedSlots: 'actions',
      fixedWidth: 200,
      fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'ywlx',
    label: '业务类型',
    labelWidth:100,
    inputType: {
      tag: 'select',
      options: 'ywlx',
      // multiple: true,
  },
  },
  {
    prop: 'wtdl',
    label: '问题大类',
    labelWidth:100,
    inputType: {
      tag: 'select',
      options: 'wtdl',
      // multiple: true,
  },
  },
  {
    prop: 'wtzl',
    label: '问题子类',
    labelWidth:100,
    inputType: {
      tag: 'select',
      options: 'wtzl',
      // multiple: true,
  },
  },
  {
    prop: 'wjmc',
    label: '文件名称',
    labelWidth:100,
    inputType: {
      tag: 'input',
  },
  },
  
];
// 基础信息
const basicColumns: FormItemInfo[] = [
  
  {
      prop: 'qqdbs',
      label: '请求单标识',
      labelWidth: 150,
      inputType: 'input',
      extra: {
          collapse: { name: 'basic', title: '基础信息' },
      },
  },

  {
      prop: 'sqjgdm',
      label: '申请机构代码',
      labelWidth: 150,
      inputType: 'input',
      extra: {
          collapse: { name: 'basic', title: '基础信息' },
      },
  },
  {
      prop: 'mbjgdm',
      label: '银行机构代码',
      labelWidth: 150,
      inputType: 'input',
      extra: {
          collapse: { name: 'basic', title: '基础信息' },
      },
  },
  {
      prop: 'jjcd',
      label: '紧急程度',
      labelWidth: 150,
      inputType: {
          tag: 'select',
          options: 'jjcd',
          multiple: false,
      },
      extra: {
          collapse: { name: 'basic', title: '基础信息' },
      },
  },
  {
      prop: 'fssj',
      label: '发送时间',
      labelWidth: 150,
      inputType: 'input',
      extra: {
          collapse: { name: 'basic', title: '基础信息' },
      },
  },
]

// 查询人信息
const personColumns: FormItemInfo[] = [
  {
      prop: 'qqrxm',
      label: '请求人姓名',
      labelWidth: 150,
      inputType: 'input',
      extra: {
          collapse: { name: 'person', title: '查询人' },
      },
  },
  {
      prop: 'qqrzjlx',
      label: '请求人证件类型',
      labelWidth: 150,
      inputType: {
          tag: 'select',
          options: 'license',
          multiple: false,
      },
      extra: {
          collapse: { name: 'person', title: '查询人' },
      },
  },
  {
      prop: 'qqrzjhm',
      label: '请求人证件号码',
      labelWidth: 150,
      inputType: 'input',
      extra: {
          collapse: { name: 'person', title: '查询人' },
      },
  },
  {
      prop: 'qqrdwmc',
      label: '请求人单位名称',
      labelWidth: 150,
      inputType: 'input',
      extra: {
          collapse: { name: 'person', title: '查询人' },
      },
  },
  {
      prop: 'qqrsjh',
      label: '请求人手机号',
      labelWidth: 150,
      inputType: 'input',
      extra: {
          collapse: { name: 'person', title: '查询人' },
      },
  },

]

export const formItems: FormItemInfo[] = [
  ...basicColumns,
  // {
  //   prop: 'jobClassName',
  //   label: '任务类名',
  //   inputType: 'input',
  //   required: true,
  // },
  {prop: 'wjmc', label: '文件名称',
  labelWidth: 150,
  inputType: 'input',
  extra: {
      collapse: { name: 'body', title: '主体信息' },
  },},
  {prop: 'ywlx', label: '业务类型',  labelWidth: 150,    inputType: {
    tag: 'select',
    options: 'ywlx',
    // multiple: true,
},
extra: {
  collapse: { name: 'body', title: '主体信息' },
},},
  {prop: 'wtdl', label: '问题大类',     labelWidth: 150, inputType: {
    tag: 'select',
    options: 'wtdl',
    // multiple: true,
},
extra: {
  collapse: { name: 'body', title: '主体信息' },
},},
  {prop: 'wtzl', label: '问题子类',   labelWidth: 150,   inputType: {
    tag: 'select',
    options: 'wtzl',
    // multiple: true,
},
extra: {
  collapse: { name: 'body', title: '主体信息' },
},},
  {prop: 'wtms', label: '问题描述',  labelWidth: 150, extra: {
    collapse: { name: 'body', title: '主体信息' },
},},
  {
    prop: 'qqdbs',
    label: '请求单标识',
    inputType:'input',
    labelWidth: 150,
    extra: {
      collapse: { name: 'body', title: '主体信息' },
  },
  },
  {
    prop: 'status',
    label: '完成状态',
    labelWidth: 150,
    inputType: {
      tag: 'select',
      options: 'dataStatus',
      // multiple: true,
  },
  extra: {
    collapse: { name: 'body', title: '主体信息' },
},
  },
  ...personColumns
];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
}