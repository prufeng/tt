<template>
<rk-index-layout>
  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search" :label-width="50" @keyup.enter="search">
    <!-- 自定义渲染 -->
    <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
  </rk-search-form>

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page" @page-change="pageChange" @refresh="search"
                 @selection-change="handleSelectionChange">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <!-- <rk-button-group :buttons="buttons" :route-meta="['ADD', 'DELETE_BATCH']"></rk-button-group> -->
      <UpAndDown :imp="imp"/>
    </template>

    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
    </template>
  </rk-page-table>
</rk-index-layout>



  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" >
    <rk-collapse-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :collapse-model-value="activeCollapse"  :disabled="dialogData.formDisabled" >
    </rk-collapse-form>
    <template #footer>
      <span class="dialog-footer">
        <!-- <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          确认
        </el-button> -->
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
  import useDictsStore from '@/store/dictStore';
  const dictsStore = useDictsStore();
  const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import {provide,onMounted, ref} from 'vue'
import { ElDialog, ElButton, ElMessage, ElLink} from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm, RS,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm, RkIndexLayout
} from 'riking-ui'
import {columns, formItems, pagination,searchItems} from "./index.data";
import {getQuartzList,searchList,auditBatch,submitBatch,impZip,getOne } from './index.api'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm';
const { state, init, handlePageChange, handleSortChange, handleSelectionChange  } = useState(searchList)
useDict([], [], dictData);
// const handleEdit = async (row: any) => {
//   open(row,false,'编辑');
//   search();
// }
const activeCollapse = ref(['basic', 'body', 'person']);
let propName = state.selectedRows.map((item) => item.id);
const onSelectionChange = async () => {
 propName = state.selectedRows.map((item) => item.id);
  await search();
  return propName;
}
defineExpose({onSelectionChange,propName});
const imp = async (data = {}) => {
  await impZip(data);
  ElMessage.success("导入成功");
  await search();
}
const openDialog = async (row: any) => {
  const result =  await getOne({'id': row.id, 'qqdbs': row.qqdbs});
  open(result.data, true, '查看');
}

// const handleAdd = async () => {
//   open(undefined,false,"新增");
// }

// const submit = async (id: any) => {
//   await submitBatch(id);
//   await search();
// }

// const audit = async (id: any) => {
//   await auditBatch(id);
//   await search();
// }
// const submits = async () => {
//   await submitBatch(ids);
//   await search();
// }

// const audits = async () => {
//   await auditBatch(ids);
//   await search();
// }
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => openDialog(row)
  },
  // {
  //       key: 'submit',
  //       label: '提交',
  //       tag: 'button',
  //       type: 'primary',
  //       handler: () => submit(row.id),
  //       invisible: row.status == "1" ? false : true
  //   },
  //   {
  //       key: 'audit',
  //       label: '审核',
  //       tag: 'button',
  //       type: 'primary',
  //       handler: () => audit(row.id)
  //       ,invisible: row.status == "2" ? false : true
  //   },
  // {
  //   key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => handleEdit(row)
  // },
 
]
const buttons: ButtonInfo[] = [
  
  // {
  //   key: 'add',
  //   label: '新增',
  //   tag: 'button',
  //   type: 'primary',
  //   icon: 'icon_add',
  //   handler: () => handleAdd(),
  // },
  // {
  //       key: 'submit',
  //       label: '提交',
  //       tag: 'button',
  //       type: 'primary',
  //       handler: () => submits(),
  //   },
  //   {
  //       key: 'audit',
  //       label: '审核',
  //       tag: 'button',
  //       type: 'primary',
  //       handler: () => audits()
   
    // },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const search = async () => {
  init();
  console.log(searchForm.value);
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  console.log(result.result);
  console.log(page.value);
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}



onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

//控制表单提交
// const handleSave = async () => {
//   dialogData.loading = true
//   try {
//     const valid = await dialogFormRef.value?.asyncValidate();
//     // console.log(dialogForm._rawValue.jobClassName);
//     console.log('value12', dialogForm._rawValue);
 
//     const myPropName = await myComponent.value.onSelectionChange();
//     console.log('value12',myPropName);
//     await addUser(myPropName);
//     search();
//     close();
//     ElMessage.success('success')
//   } finally {
//     setTimeout(() => (dialogData.loading = false), 50)
//   }
// }
</script>

<style scoped></style>