<template>
<rk-index-layout>
  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search" :label-width="50" @keyup.enter="search">
    <!-- 自定义渲染 -->
    <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
  </rk-search-form>

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page" @page-change="pageChange" @refresh="search"
                 @selection-change="handleSelectionChange">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
    </template>

    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
    </template>
  </rk-page-table>
</rk-index-layout>



  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" >
    <questionList ref="myComponent"/>
<!-- 
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :disabled="openDetail" >
    
    </rk-detail-form> -->
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog :close-on-click-modal="false" v-model="dialogData2.visible" :title="dialogData2.title" class="rk-dialog-default" @closed="closed2" >
    <!-- <questionList ref="myComponent"/> -->

    <rk-detail-form ref="dialogFormRef2" v-model="dialogForm2" :form-items="formItems" :disabled="dialogData2.formDisabled" >
    
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData2.formDisabled" :loading="dialogData2.loading" type="primary" @click="handleSave2">
          保存
        </el-button>
        <el-button @click="close2"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-model="auditDialog" title="审核" width="30%" draggable>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids)">审核通过</el-button>
        <el-button type="danger" @click="()=>{msgDialog = true;msg =''}">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
    <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog"  width="30%" draggable>
    <el-form >
      <el-form-item>
        <el-input v-model="msg"  type="textarea"  placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
      <el-button type="primary" @click="auditNotPass(ids)">提交</el-button>
      </span>
   </template>
  </el-dialog>
</template>
<script lang="ts">
  import useDictsStore from '@/store/dictStore';
import { TrapFocusElement } from 'element-plus/es/directives/trap-focus';
  const dictsStore = useDictsStore();
  const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import {provide,onMounted, ref} from 'vue'
import { ElDialog, ElButton, ElMessage, ElForm, ElFormItem, ElInput, ElLink} from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm, RS, RkDetailForm,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm, RkIndexLayout
} from 'riking-ui'
import {columns, formItems, pagination,searchItems} from "./index.data";
import {getQuartzList,searchList,auditBatch,submitBatch,add,deleteOne,reset,auditNotPassBatch } from './index.api'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm';
import questionList from '@/views/ybjh/question/questionList/index.vue';


const myComponent =  ref();
const msgDialog = ref(false);
const msg = ref("");
const auditDialog = ref(false);

useDict([], [], dictData);
const { state, init } = useState(searchList);
// const handleEdit = async (row: any) => {
//   open(row,false,'编辑');
//   search();
// }
let ids: String;
// let openDetail = false;
const handleAdd = async () => {
  open(undefined,false,"新增");
}
const handleEdit = async (row: any) => {
  const ids = state.selectedRows.map((item) => item.id)
  console.log(state.selectedRows);
  console.log(ids);
  console.log(data);
  open2(row,false,'编辑');
  search();
}
const handleDelete = async (row: any) => {
  await deleteOne(row);
  ElMessage.success('删除成功');
  search();
}
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}
const submit = async (id: any) => {
  await submitBatch(id);
  await search();
}

const handleReset = async (id: any) => {
  await reset(id);
  await search();
}

const audit = async (id: any) => {
  await auditBatch(ids);
  await search();
    // close();
    ElMessage.success("审核成功");
  auditDialog.value = false;
}

const auditNotPass = async (id: any) => {
  await auditNotPassBatch(ids,msg.value);
  await search();
  ElMessage.success("审核不通过成功");
  msgDialog.value = false;
  auditDialog.value = false;
}
const submits = async () => {
  if (ids==undefined||ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await submitBatch(ids);
  await search();

}

// const audits = async () => {
//   if (ids==undefined||ids.length == 0) {
//     ElMessage.warning('请先选择数据')
//     return
//   }
//   await auditBatch(ids);
//   await search();
// }
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => {
      open2(row, true, '查看');
    }
  },
  {
        key: 'submit',
        label: '提交',
        tag: 'button',
        type: 'primary',
        handler: () => submit(row.id),
        invisible: row.status == "1" ? false : true
    },
    {
        key: 'audit',
        label: '审核',
        tag: 'button',
        type: 'primary',
        handler: () => {
        ids = row.id;
        auditDialog.value = true
    }
     ,invisible: row.status == "2" ? false : true
    },
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => handleEdit(row),invisible: row.status == "1" ? false : true
  },
  {
    key: 'DELETE', label: '删除',   tag: 'popconfirm',  type: 'danger',
        title: '确定删除吗?', handler: () => handleDelete(row),invisible: row.status == "1" ? false : true
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => handleReset(row.id),invisible: row.status == "2" ? false : true
  },
]
const buttons: ButtonInfo[] = [
  
  {
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleAdd(),
  },
  {
        key: 'submit',
        label: '批量提交',
        tag: 'button',
        type: 'primary',
        handler: () => submits(),
    },
    {
        key: 'audit',
        label: '批量审核',
        tag: 'button',
        type: 'primary',
        handler:() => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请至少选择一条数据');
        return;
      }
      auditDialog.value = true
    }
   
    },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const search = async () => {
  init();
  console.log(searchForm.value);
  console.log(page.value.currentPage);
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  let records = result.result;
  console.log(records.current);
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}



onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef,
  form,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})
const {
  dialogData: dialogData2, open: open2, close: close2, closed: closed2,
  form: dialogForm2,
  nameRef: dialogFormRef2,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef2', {type: []})
//控制表单提交
const handleSave = async () => {
  // const myPropName = await myComponent.value.onSelectionChange();
  //   console.log('value12',myPropName);
  //   if(myPropName){
      open2(undefined,false,"新增");
    // }
    // openDetail = true;

  // const valid = await dialogFormRef.value?.asyncValidate();
  // if (valid) {
    // const data = toRaw(form.value);
    // data.status = '1';
    // delete data.type;
    // console.log(data.id);
    // await add(data);
    close();
    // await search();
  // }
}
//控制表单2提交
const handleSave2 = async () => {
  if(dialogData2.title == "编辑"){
    const valid = await dialogFormRef2.value?.asyncValidate();
  if (valid) {
    const data = toRaw(dialogForm2.value);
    data.status = '1';
    delete data.type;
    await add(data,0);
    close2();
    await search();
  }
  }
  const myPropName = await myComponent.value.onSelectionChange();
    console.log('value12',myPropName);
    // openDetail = true;
  const valid = await dialogFormRef2.value?.asyncValidate();
  if (valid) {
    const data = toRaw(dialogForm2.value);
    console.log("data" + data)
    console.log("myPropName" + myPropName)
    data.status = '1';
    delete data.type;
    await add(data,myPropName);
    close2();
    await search();
  }
}
</script>

<style scoped></style>