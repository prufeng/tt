import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
  {key: 'id', type: 'selection'},
  {prop: 'wjmc', label: '文件名称' },
  {prop: 'sfynljj', label: '是否有能力解决' ,dictFormatKey: 'sfynljj'},
  {prop: 'yjfksj', label: '预计反馈时间'},
  {prop: 'lxr', label: '联系人'},
  {prop: 'lxdh', label: '联系电话'},
  {
    prop: 'bz',
    label: '备注',
    inputType:'input' 
  },
  {
    prop: 'qqdbs',
    label: '请求单标识',
    inputType:'input' 
  },
  {
    prop: 'status',
    label: '完成状态',
    inputType:'input',
    dictFormatKey: 'dataStatus' 
  },
  {
      key: 'actions',
      label: '操作',
      scopedSlots: 'actions',
      fixedWidth: 200,
      fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {prop: 'sfynljj', label: '是否有能力解决' ,inputType: {
    tag: 'select',
    options: 'sfynljj',
  
},  labelWidth: 100,},
  {
    prop: 'wjmc',
    label: '文件名称',
    inputType: {
      tag: 'input',
     
  },
  labelWidth: 100,
  },
];

export const formItems: FormItemInfo[] = [
  // {prop: 'wjmc', label: '文件名称' },
  {prop: 'sfynljj', label: '是否有能力解决' , inputType: {
    tag: 'select',
    options: 'sfynljj',
    // multiple: true,
},},
  {prop: 'yjfksj', label: '预计反馈时间',inputType: {tag: 'date-picker', type: 'datetime', valueFormat: 'YYYY-MM-DD HH:mm:ss'}},
  {prop: 'lxr', label: '联系人'},
  {prop: 'lxdh', label: '联系电话'},
  {
    prop: 'bz',
    label: '备注',
    inputType:'input' 
  },
  // {
  //   prop: 'qqdbs',
  //   label: '请求单标识',
  //   inputType:'input' 
  // },
  // {
  //   prop: 'status',
  //   label: '完成状态',
  //   inputType: {
  //     tag: 'select',
  //     options: 'dataStatus',
  //     // multiple: true,
  // },

  // },
];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
}