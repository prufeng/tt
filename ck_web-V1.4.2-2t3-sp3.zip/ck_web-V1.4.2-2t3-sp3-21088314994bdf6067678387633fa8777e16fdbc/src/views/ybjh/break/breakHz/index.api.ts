// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
enum Api {
  list = '/breakHz/list',
  get = '/breakHz/queryById',
  delete = '/breakHz/delete',
  deleteBatch = '/breakHz/deleteBatch',
  addUser = '/breakHz/addUser'
}
/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, current: number, size: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {current, size}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
  })
}
export function submitBatch(ids:any): Promise<RS> {
  return service({
      url: '/questionList/submit',
      method: 'POST',
      params: {ids},
  })
}

export function auditBatch(ids: any): Promise<RS> {
  return service({
      url: '/questionList/audit',
      method: 'POST',
      params: {ids},
  })
}

/**
 * 删除任务
 * @param params
 */
export const deleteQuartz = (data: any) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    data: data,
    params: data
})


  // return defHttp.delete({ url: Api.delete, data: params }, { joinParamsToUrl: true }).then(() => {
  //   handleSuccess();
  // });
};
export function impZip(data = {}): Promise<RS> {
  return service({
      url: '/questionList/imp',
      method: 'POST',
      data,
      headers: {'Content-Type': 'multipart/form-data',}
  })
}