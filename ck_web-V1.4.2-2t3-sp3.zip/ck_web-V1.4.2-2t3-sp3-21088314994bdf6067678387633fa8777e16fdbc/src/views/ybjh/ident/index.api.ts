// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
enum Api {
  list = '/zkhbs/list',
  get = '/zkhbs/queryById',
  delete = '/zkhbs/delete',
  deleteBatch = '/zkhbs/deleteBatch',
  add = '/zkhbs/add',
  edit = '/zkhbs/edit',
  submit= '/zkhbs/submit',
  audit= '/zkhbs/audit',
  reset = '/zkhbs/reset'
}
/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, current: number, size: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {current, size}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
  })
}
export function submitBatch(ids:any): Promise<RS> {
  return service({
      url: Api.submit,
      method: 'POST',
      params: {ids},
  })
}

export function deleteBatch(ids:any): Promise<RS> {
  return service({
      url: Api.deleteBatch,
      method: 'DELETE',
      params: {ids},
  })
}

export function auditBatch(ids: any): Promise<RS> {
  return service({
      url: Api.audit,
      method: 'POST',
      params: {ids},
  })
}

export function auditNotPassBatch(ids: any,msg:any): Promise<RS> {
  return service({
      url: '/zkhbs/auditNotPass',
      method: 'POST',
      params: {ids,msg},
  })
}

export function add(data: any): Promise<RS> {
  console.log(data)
  return service({
      url:  Api.add,
      method: 'POST',
      data: data,
    
  })
}
export function edit(data = {}): Promise<RS>{
  return service({
      url:  Api.edit,
      method: 'POST',
      data: data,
  })
}
/**
 * 删除任务
 * @param params
 */
export const deleteOne = (data: any) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    data: data,
    params: data
})

  // return defHttp.delete({ url: Api.delete, data: params }, { joinParamsToUrl: true }).then(() => {
  //   handleSuccess();
  // });
};
export function reset(ids: any): Promise<RS>{
  return service({
      url:  Api.reset,
      method: 'POST',
      params: {ids},
  })
}