import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
  {key: 'id', type: 'selection'},
  {prop: 'bsdbs', label: '报送单标识' },
  {prop: 'bsjgdm', label: '报送机构代码'},
  {prop: 'zhlx', label: '账户类型' ,dictFormatKey: 'zhlx'},
  {prop: 'zhcd', label: '账/卡号长度'},
  {prop: 'zhbsw', label: '账/卡号标识起止位'},
  {prop: 'zhbsnr', label: '账/卡号标识内容'},
  {
    prop: 'bz',
    label: '备注',
    inputType:'input' 
  },
  {
    prop: 'status',
    label: '完成状态',
    inputType:'input',
    dictFormatKey: 'dataStatus' 
  },
  {
      key: 'actions',
      label: '操作',
      scopedSlots: 'actions',
      fixedWidth: 200,
      fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {prop: 'bsdbs', label: '报送单标识' ,inputType: {
    tag: 'input',
},  labelWidth: 100,},
  {
    prop: 'zhlx',
    label: '账户类型',
    inputType: {
      tag: 'select',
      options: 'zhlx',
  },
  labelWidth: 100,
  },
];

export const formItems: FormItemInfo[] = [
  {prop: 'bsdbs', label: '报送单标识' , inputType:'input'},
  {prop: 'bsjgdm', label: '报送机构代码', inputType:'input'},
  {prop: 'zhlx', label: '账户类型', inputType: {
    tag: 'select',
    options: 'zhlx',
},},
  {prop: 'zhcd', label: '账/卡号长度', inputType:'input'},
  {prop: 'zhbsw', label: '账/卡号标识起止位', inputType:'input' },
  {prop: 'zhbsnr', label: '账/卡号标识内容', inputType:'input' },
  {
    prop: 'bz',
    label: '备注',
    inputType:'input' 
  },
  // {
  //   prop: 'qqdbs',
  //   label: '请求单标识',
  //   inputType:'input' 
  // },
  // {
  //   prop: 'status',
  //   label: '完成状态',
  //   inputType: {
  //     tag: 'select',
  //     options: 'dataStatus',
  //     // multiple: true,
  // },

  // },
];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
}