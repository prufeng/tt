<template>
  <rk-index-layout>
    <rk-dynamic-search-form
      v-model="searchForm"
      :form-items="searchFormItems"
      :fields="advancedQueryItems"
      @search="search"
    ></rk-dynamic-search-form>
    <rk-page-table
      :columns="columns"
      :data="tableDate"
      :pagination="page"
      @page-change="pageChange"
      @refresh="search"
      :loading="loadingTable"
      @selection-change="handleSelectionChange"
    >
      <template #actions="{ row }">
        <rk-button-group :buttons="genRowButtons(row)" :route-meta="$route.meta" link max="2" />
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!-- 弹出层   -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed">
    <rk-collapse-form
      ref="dialogFormRef"
      v-model="form"
      disabled="false"
      :form-items="formItems"
      :collapse-model-value="['head', 'body', 'operator']"
    />

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 文件列表 -->
  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button v-for="fileKey in fileButtonKeys" :key="fileKey" type="primary" link
               style=" margin-bottom: 10px; display: flex; flex-direction: column;"
               @click="fileDownload(fileKey,fileButtonData[fileKey])">
      {{ fileKey }}
    </el-button>
  </el-dialog>

</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore'
const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>
<script setup lang="ts">
import { RkPageTable, RkDynamicSearchForm, RkIndexLayout, Pagination, DialogForm, RkFormInstance } from 'riking-ui'
import { columns, searchFormItems, advancedQueryItems, formItems } from './config/100707'
import { checkData, pagination } from '@/utils/utils'
import { getById, list } from './api'
import { checkFileIsExists, downloadFile, getFile } from '../r303/api'
import {ElButton, ElDialog, ElMessage} from "element-plus";
import {ref} from "vue";
const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })
useDict([], [], {
  ...dictData,
  result: async () => {},
})
const loadingTable = ref(false)
const tableDate = ref<any[]>([])
const page = ref<Pagination>(pagination)
const searchForm = ref({})
let ids: string

const dialogVisible = ref(false);
const fileButtonKeys = ref({});
const fileButtonData = ref({});

const search = async () => {
  loadingTable.value = true
  let formData = checkData(searchForm.value)
  let result = await list('100707', formData, page.value.currentPage, page.value.pageSize)
  let { current, total, records } = result.data
  console.log(records)

  tableDate.value = records
  page.value.currentPage = current
  page.value.total = total
  loadingTable.value = false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(',')
}

// @ts-ignore 行操作按钮
const genRowButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      // @ts-ignore
      handler: async () => {
        const result = await getById('100707', { id: row.id })
        open(result.data, true, '查看')
      },
    },
  ]

  if (row.isShowDoc) {
    buttons.push(
        {
          key: 'view', label: '文件列表', tag: 'button', type: 'primary',
          handler: async () => {
            const result = await getFile(row);
            const values = Object.keys(result.data);
            fileButtonData.value = result.data;
            fileButtonKeys.value = values;
            dialogVisible.value = true;
          }
        },
      // {
      //   key: 'view',
      //   label: '下载文书',
      //   tag: 'button',
      //   type: 'primary',
      //   handler: async () => {
      //     const result = await getFile({
      //       trxId: row.trxId,
      //     })
      //     if(!result.data) return
      //     let values = Object.keys(result.data)
      //     let str =values[0]
      //     fileDownload(values[0], result.data[str])
      //    }
      // }
    )
  }

  return buttons
}

//文件下载
const fileDownload = async (fileName: string, trxId: string) => {
  let res = await checkFileIsExists(fileName, trxId)
  if (res.code == 200) {
    // window.location.href = import.meta.env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX + "/farms303/downloadFile?id="+res.result;
    await downloadFile(res.result)
  } else {
    ElMessage.warning('文件不存在，无法下载')
  }
}
onMounted(() => {
  page.value = {...pagination}
  search()
})
</script>

<style scoped></style>
