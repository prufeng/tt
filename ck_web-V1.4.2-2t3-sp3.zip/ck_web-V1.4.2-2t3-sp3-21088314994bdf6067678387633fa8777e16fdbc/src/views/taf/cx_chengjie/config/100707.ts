import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'wssqzt',
        label: '文书申请状态',
        width: 170,
        dictFormatKey: 'wssqzt',
        fixed: 'left',
        sortable: true
    },
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        width: 170,
        sortable: true
    },


    {
        prop: 'applicationTime',
        label: '申请时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'fromTGOrganizationId',
        label: '发送机构编号',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationOriID',
        label: '原惩戒/解除惩戒业务申请编号',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationOrgID',
        label: '惩戒执行机构编码',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationOrgName',
        label: '惩戒执行机构名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'fkStatus',
        label: '回执状态',
        width: 170,
        dictFormatKey: 'fkStatus',
        sortable: true
    },
    {
        prop: 'fkInfo',
        label: '回执信息',
        width: 170,
        sortable: true
    },
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170,
        sortable: true
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        sortable: true
    },
    {
        prop: 'updateBy',
        label: '更新人',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        width: 120,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'wssqzt',
        label: '文书申请状态',
        inputType: {
            tag: 'select',
            options: 'wssqzt',
        },
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        // labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags:1
        },
    },

]

export const formItems: FormItemInfo[] = [
    {
        prop: 'txCode',
        label: '交易类型编码',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'messageFrom',
        label: '发送机构',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'applicationOrgID',
            multiple: false,
        },
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    /*{
        prop: 'transSerialNumber',
        label: '传输报文流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },*/
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{max:36,message:'业务申请编号长度不可超过36'},{required: true, message: '业务申请编号不能为空'}],
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'fromTGOrganizationId',
        label: '发送机构编号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'applicationOriID',
        label: '原惩戒/解除惩戒业务申请编号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'applicationOrgID',
        label: '惩戒执行机构编码',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'applicationOrgName',
        label: '惩戒执行机构名称',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },

    {
        prop: 'wssqzt',
        label: '文书申请状态',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'wssqzt',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'fkStatus',
        label: '回执状态',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'fkStatus',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    
    {
        prop: 'fkInfo',
        label: '回执信息',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    
]

export const advancedQueryItems = [
    {
        value: 'wssqzt',
        label: '文书申请状态',
        width: 170,
        inputType: { tag: 'select', options:'wssqzt'}
    },
    {
        value: 'trxId',
        label: '流水号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
            value: 'applicationID',
            label: '业务申请编号',
            // labelWidth: 170,
            inputType: 'input',
    },
    {
        value: 'applicationTime',
        label: '申请时间',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'applicationOriID',
        label: '原惩戒/解除惩戒业务申请编号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'applicationOrgID',
        label: '惩戒执行机构编码',
        // labelWidth: 170,
        inputType: 'input',
    },
    //  {
    //     value: 'applicationOriID',
    //     label: '原惩戒/解除惩戒业务申请编号',
    //     // labelWidth: 170,
    //     inputType: 'input',
    // }, 
    {
        value: 'applicationOrgName',
        label: '惩戒执行机构名称',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {value: 'importType', label: '导入方式', inputType: {tag: 'select', options: 'importType'}, labelWidth: 100},
]

export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems
}