import { FormItemInfo, TableColumnInfo } from "riking-ui";

export const columns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        width: 170,
        sortable: true
    },


    {
        prop: 'applicationTime',
        label: '申请时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        width: 170,
        sortable: true
    },
    {
        prop: 'dobjectType',
        label: '惩戒对象类型',
        width: 170,
        dictFormatKey: 'DobjectType',
        sortable: true
    },
    {
        prop: 'dobjectName',
        label: '惩戒对象姓名/机构名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'startDate',
        label: '惩戒开始时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'endDate',
        label: '惩戒结束时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'wsApplyFlag',
        label: '文书申请状态',
        width: 170,
        dictFormatKey: 'wsApplyFlag',
        sortable: true
    },
    {
        prop: 'status',
        label: '请求完成状态',
        width: 170,
        dictFormatKey: 'tafReqProcessingStatus',
        fixed: 'left',
        sortable: true
    },
    /*{
        prop: 'branchCode',
        label: '机构代码',
        width: 170,
        dictFormatKey: 'branchTree',
        sortable: true
    },*/
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170,
        sortable: true
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        sortable: true
    },
    {
        prop: 'updateBy',
        label: '更新人',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        width: 120,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]
export const columnsPolice: TableColumnInfo[] = [
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        width: 170,
        sortable: true
    },
    {
        prop: 'dpoliceCode',
        label: '惩戒公安机关代码',
        width: 170,
        sortable: true
    },


    {
        prop: 'dpoliceName',
        label: '惩戒公安机关名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'dpoliceStartDate',
        label: '惩戒公安机关惩戒开始时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'dpoliceEndDate',
        label: '惩戒公安机关惩戒结束时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'doperatorName',
        label: '经办人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'doperatorPhoneNumber',
        label: '经办人电话',
        width: 170,
        sortable: true
    },
]
export const columnsRPolice: TableColumnInfo[] = [
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        width: 170,
        sortable: true
    },
    {
        prop: 'rpoliceCode',
        label: '解除惩戒公安机关代码',
        width: 170,
        sortable: true
    },
    {
        prop: 'rpoliceName',
        label: '解除惩戒公安机关名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'roperatorName',
        label: '经办人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'roperatorPhoneNumber',
        label: '经办人电话',
        width: 170,
        sortable: true
    },
]

export const columnsObject: TableColumnInfo[] = [
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        width: 170,
        sortable: true
    },
    {
        prop: 'dobjectIDType',
        label: '惩戒对象证件类型',
        dictFormatKey: 'idType',
        width: 170,
        sortable: true
    },


    {
        prop: 'dobjectIDNumber',
        label: '惩戒对象证件号码',
        width: 170,
        sortable: true
    },

]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '请求完成状态',
        inputType: {
            tag: 'select',
            options: 'tafReqProcessingStatus',
        },
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        // labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags: 1
        },
    },

]

export const formItems: FormItemInfo[] = [
    {
        prop: 'txCode',
        label: '交易类型编码',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: { name: 'head', title: '基础信息' },
        }
    },
    {
        prop: 'messageFrom',
        label: '发送机构',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'applicationOrgID',
            multiple: false,
        },
        extra: {
            collapse: { name: 'head', title: '基础信息' },
        }
    },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: { name: 'head', title: '基础信息' },
        }
    },
    /*{
        prop: 'transSerialNumber',
        label: '传输报文流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },*/
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: { name: 'body', title: '主体信息' },
        },
        rules: [{ max: 36, message: '业务申请编号长度不可超过36' }, { required: true, message: '业务申请编号不能为空' }],
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        labelWidth: 170,
        inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' },
        rules: [
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒' },
        ],
        extra: {
            collapse: { name: 'body', title: '主体信息' },
        }
    },
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: { name: 'body', title: '主体信息' },
        }
    },



    {
        prop: 'dobjectType',
        label: '惩戒对象类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'DobjectType',
            multiple: false,
        },
        extra: {
            collapse: { name: 'body', title: '主体信息' },
        }
    },

    {
        prop: 'dobjectName',
        label: '惩戒对象姓名/机构名称',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: { name: 'body', title: '主体信息' },
        }
    },



    {
        prop: 'startDate',
        label: '惩戒开始时间',
        labelWidth: 170,
        inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD' },
        rules: [
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))$', message: '格式应为年-月-日' },
        ],
        extra: {
            collapse: { name: 'body', title: '主体信息' },
        }
    },
    {
        prop: 'endDate',
        label: '惩戒结束时间',
        labelWidth: 170,
        inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD' },
        rules: [
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))$', message: '格式应为年-月-日' },
        ],
        extra: {
            collapse: { name: 'body', title: '主体信息' },
        }
    },

]

export const advancedQueryItems = [
    {
        value: 'status',
        label: '请求完成状态',
        width: 170,
        inputType: { tag: 'select', options: 'tafReqProcessingStatus' }
    },
    {
        value: 'trxId',
        label: '流水号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'applicationID',
        label: '业务申请编号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'applicationTime',
        label: '申请时间',
        inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss ", valueFormat: 'YYYY-MM-DD HH:mm:ss' },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'dobjectId',
        label: '惩戒对象唯一标识',
        // labelWidth: 170,
        inputType: 'input',
    },


    {
        value: 'dobjectType',
        label: '惩戒对象类型',
        // labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'DobjectType',
            multiple: false,
        },
    },

    {
        value: 'dobjectName',
        label: '惩戒对象姓名/机构名称',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'startDate',
        label: '惩戒开始时间',
        inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD' },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'endDate',
        label: '惩戒结束时间',
        inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD' },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },

    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD' },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    { value: 'importType', label: '导入方式', inputType: { tag: 'select', options: 'importType' }, labelWidth: 100 },
]

export default {
    columns,
    columnsPolice,
    columnsRPolice,
    columnsObject,
    searchFormItems,
    formItems,
    advancedQueryItems
}
























