
import config100701 from './100701';
import config100703 from './100703';



const reportCodeMap = new Map()
reportCodeMap.set('100702', '100701')
reportCodeMap.set('100704', '100703')



export default {
    config100701,
    config100703,
    reportCodeMap
}

