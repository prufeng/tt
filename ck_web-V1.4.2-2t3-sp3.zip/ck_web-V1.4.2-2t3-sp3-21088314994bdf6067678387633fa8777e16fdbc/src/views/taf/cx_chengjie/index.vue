<template>
  <!--  <div class="app-container">-->
  <rk-index-layout>
    <!--  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"
                  :form-items="searchFormItems" @search="search" :label-width="50" />-->
    <rk-dynamic-search-form
      v-model="searchForm"
      :form-items="searchFormItems"
      :fields="advancedQueryItems"
      @search="search"
    ></rk-dynamic-search-form>

    <rk-page-table
      :columns="columns"
      :data="tableDate"
      :pagination="page"
      @page-change="pageChange"
      @refresh="search"
      :loading="loadingTable"
      @selection-change="handleSelectionChange"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
          <div style="margin: 0 4px"></div>
          <UpAndDown :exp="exp" />
        </div>
      </template>

      <!--<template #createTime="{ row }">-->
      <!--  <div>{{dayjs(row.createTime).format('YYYY-MM-DD HH:mm:ss') }}</div>-->
      <!--</template>-->

      <!--<template #updateTime="{ row }">-->
      <!--  <div>{{dayjs(row.updateTime).format('YYYY-MM-DD HH:mm:ss') }}</div>-->
      <!--</template>-->

      <template #actions="{ row }">
        <rk-button-group :buttons="genRowButtons(row)" :route-meta="$route.meta" link max="2" />
      </template>
      <template #subTable="{ row }">
        <el-button type="primary" :underline="false" link @click="openSubTable(row.applicationID, row.status)">{{
          row.applicationID
        }}</el-button>
      </template>
    </rk-page-table>
  </rk-index-layout>
  <!-- 弹出层   -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed">
    <rk-collapse-form
      ref="dialogFormRef"
      v-model="form"
      disabled="false"
      :form-items="formItems"
      :collapse-model-value="['head', 'body', 'operator']"
    />
    <div v-if="reportCode == '100701' || reportCode == '100703'">
      <h4>惩戒公安机关列表</h4>
      <rk-table
        :columns="columnsPolice"
        :data="tableDatePolice"
        @refresh="search"
        :loading="loadingTable"
        @selection-change="handleSelectionChange"
        :hidden-table-tools="true"
      >
      </rk-table>
    </div>
    <div v-if="reportCode == '100703'">
      <h4>解除惩戒公安机关列表</h4>
      <rk-table
        :columns="columnsRPolice"
        :data="tableDateRPolice"
        @refresh="search"
        :loading="loadingTable"
        @selection-change="handleSelectionChange"
        :hidden-table-tools="true"
      >
      </rk-table>
    </div>
    <div v-if="reportCode === '100701' || reportCode == '100703'">
      <h4>惩戒对象证件列表</h4>
      <rk-table
        :columns="columnsObject"
        :data="tableDateObject"
        @refresh="search"
        :loading="loadingTable"
        @selection-change="handleSelectionChange"
        :hidden-table-tools="true"
      >
      </rk-table>
    </div>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 子表弹出层 -->
  <el-dialog v-model="subTableVisible" title="详细信息" class="rk-dialog-default" :close-on-click-modal="false">
    <rk-page-table
      :loading="subLoading"
      :columns="subColumns"
      :data="subData"
      :pagination="subPage"
      @page-change="subPageChange"
      @refresh="subSearch(applicationID)"
      @selection-change="handleSelectionChange"
    >
      <template #actions="{ row }">
        <rk-button-group :buttons="genSubActButtons(row)" :route-meta="$route.meta" link />
      </template>
    </rk-page-table>
  </el-dialog>

  <!-- 子表form弹出层 -->
  <el-dialog v-model="subDialogData.visible" :title="subDialogData.title" class="rk-dialog-default" @closed="subClosed">
    <rk-collapse-form ref="subDialogFormRef" v-model="subForm" :form-items="subFormItems" disabled="false">
    </rk-collapse-form>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="subClose"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!--  </div>-->
  <!-- 请求单页面反馈弹出框 -->
  <el-dialog title="反馈" v-model="feedbackDialog" width="90%" @closed="clearFeedbackForm()">
    <rk-collapse-form
      ref="bodyFormRef"
      v-model="bodyForm"
      :disabled="true"
      :form-items="
        formItems.filter((item) => {
          return (
            item.extra &&
            item.extra.collapse &&
            item.extra.collapse.name === 'body' &&
            item.extra.collapse.title === '主体信息'
          )
        })
      "
      :collapse-model-value="['head', 'body', 'operator']"
    />
    <div v-if="reportCode == '100701' || reportCode == '100703'">
      <h4>惩戒公安机关列表</h4>
      <rk-table
        :columns="columnsPolice"
        :data="tableDatePolice"
        @refresh="search"
        :loading="loadingTable"
        @selection-change="handleSelectionChange"
        :hidden-table-tools="true"
      >
      </rk-table>
    </div>
    <div v-if="reportCode == '100703'">
      <h4>解除惩戒公安机关列表</h4>
      <rk-table
        :columns="columnsRPolice"
        :data="tableDateRPolice"
        @refresh="search"
        :loading="loadingTable"
        @selection-change="handleSelectionChange"
        :hidden-table-tools="true"
      >
      </rk-table>
    </div>
    <div v-if="reportCode === '100701' || reportCode == '100703'">
      <h4>惩戒对象证件列表</h4>
      <rk-table
        :columns="columnsObject"
        :data="tableDateObject"
        @refresh="search"
        :loading="loadingTable"
        @selection-change="handleSelectionChange"
        :hidden-table-tools="true"
      >
      </rk-table>
    </div>
    <div>
      <h4>反馈信息</h4>
    </div>
    <rk-detail-form ref="feedbackFormRef" v-model="feedbackForm" :form-items="feedbackItem">
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled="true" filterable style="width: 100%"> </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="saveFeedback">保存</el-button>
        <el-button @click="feedbackDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 指派机构表格弹出框 -->
  <el-dialog title="指派" v-model="assignmentDialog" width="70%">
    <rk-page-table
      ref="assignmentTable"
      :loading="assignmentLoading"
      :data="assignmentData"
      :columns="assignmentColumns"
      border="true"
      @selection-change="assignmentIdsHandleSelectionChange"
      @refresh="assignmentSearch"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <!-- 此处按钮无需做权限配置 即:route-meta="[]"即可 -->
          <rk-button-group :buttons="assignmentButtons" :route-meta="[]"></rk-button-group>
        </div>
      </template>
    </rk-page-table>
  </el-dialog>
  <!-- 指派机构form弹出框 -->
  <el-dialog
    title="新增指派"
    v-model="assignmentFormDialog"
    width="70%"
    @closed="
      () => {
        assignmentFormRef.resetFields()
      }
    "
  >
    <rk-detail-form
      ref="assignmentFormRef"
      v-model="assignmentForm"
      :form-items="[
        {
          prop: 'qqdbs',
          label: '传输报文流水号',
          labelWidth: 150,
          inputType: 'input',
          scopedSlot: 'systemCode',
        },
        {
          prop: 'rwlsh',
          label: '业务申请编号',
          labelWidth: 150,
          inputType: 'input',
          scopedSlot: 'systemCode',
        },
        {
          prop: 'branchCode',
          label: '业务操作机构',
          labelWidth: 150,
          inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
          },
          rules: [{ required: true, message: '业务操作机构不能为空' }],
        },
      ]"
    >
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled="true" filterable style="width: 100%"> </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="assignmentSave">保存</el-button>
        <el-button @click="assignmentFormDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button
      v-for="xmlKey in xmlButtonKeys"
      :key="xmlKey"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="openFile(xmlKey)"
      >{{ xmlKey }}</el-button
    >
  </el-dialog>
  <div class="img-viewer-box">
    <el-image-viewer
      v-if="showImageViewer"
      :url-list="urlList"
      @close="
        () => {
          showImageViewer = false
        }
      "
    />
  </div>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'
import { getObjectList, getPoliceList, getRemovePoliceList, getTestList, wsApply } from './api'
import moment from 'moment'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage, ElImageViewer } from 'element-plus'
import {
  assignmentDialog,
  assignmentLoading,
  assignmentData,
  assignmentColumns,
  // assignmentPage,
  // assignmentPageChange,
  assignmentSearch,
  assignmentButtons,
  assignmentQqdbs,
  assignmentRwlsh,
  assignmentIdsHandleSelectionChange,
  assignmentSave,
  assignmentFormDialog,
  assignmentFormRef,
  assignmentForm,
} from '@/utils/assignment'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  FormItemInfo,
  TableColumnInfo,
  RkDynamicSearchForm,
  RkIndexLayout,
} from 'riking-ui'

import DialogForm from 'riking-ui/dist/hooks/useDialogForm'

import { useDict } from 'riking-layout'
import UpAndDown, { expLoading } from '@/components/UpAndDown.vue'
import {
  list,
  getById,
  getAllFile,
  exportExcel,
  listByOriginalApplicationID,
  saveOffline,
  uploadOfflineAttachment,
  updateOffline,
  delOffline,
} from '@/views/taf/cx/api'
import { getUserInfo, listResult, saveData, updateRequestStatus } from '@/views/taf/fk/api'
import {
  checkData,
  checkSpecialCharacters,
  copyProperties,
  pagination,
  specialChecks,
  subPagination,
} from '@/utils/utils'
import configs from './config/sum'
import { default as fkConfigs } from '@/views/taf/fk/config/sum'
import { getRequestClassificationCode, getSubSystem } from '@/utils/subSystem'
import { getQuartzList } from '@/views/sys/config/config.api'

import {setCjDefaultValue, setCjDefaultValueObject, isEmpty} from "@/views/taf/utils";

// useDict([], [], dictData,)
useDict([], [], {
  ...dictData,
  result: async () => {
    const res = await listResult(parseInt(getRequestClassificationCode()) + 1)
    return res.data
  },
})

const reportCode = ref('') // 报文编号
const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const tableDate = ref<any[]>([])
const tableDatePolice = ref<any[]>([])
const tableDateRPolice = ref<any[]>([])

const tableDateObject = ref<any[]>([])

const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const applicationID = ref('')
const dialogVisible = ref(false)
const xmlButtonKeys = ref({})
const xmlDataList = ref({})
const showImageViewer = ref(false) //组件是否显示
const urlList = ref([]) //图片List
const config = ref({}) //图片List
let columns: TableColumnInfo[] = []
let columnsPolice: TableColumnInfo[] = [] //惩戒机关
let columnsRPolice: TableColumnInfo[] = [] //解除惩戒机关

let columnsObject: TableColumnInfo[] = [] //惩戒对象
let formItems: FormItemInfo[] = []
let searchFormItems: FormItemInfo[] = []
let advancedQueryItems = []
let ids: string

const offlineLoading = ref(false)
const addFormRef = ref<RkFormInstance>()
const addForm = ref({})
const addDialog = ref(false)
const activeCollapse = ref(['basic', 'body', 'person'])
const buttons: ButtonInfo[] = [
  // {
  //   key: 'offline',
  //   label: '线下请求单',
  //   tag: 'button',
  //   type: 'primary',
  //   icon: 'icon_add',
  //   handler: async () => {
  //     let applicationID = 'OFFLINE' + new Date().getTime();
  //     let transSerialNumber = 'tsn' + new Date().getTime();
  //     let trxId = new Date().getTime();
  //     let txCode = reportCode.value;
  //     addForm.value = {applicationID, txCode, trxId, transSerialNumber };
  //     addDialog.value = true;
  //   }
  // },
]

onMounted(async () => {
  getConfigs()
  // @ts-ignore
  const res = await getQuartzList({ systemCode: 'taf' })
  config.value = res.result.records[0]
  search()
})

const addSave = async () => {
  offlineLoading.value = true
  try {
    const valid = await addFormRef.value?.asyncValidate()
    if (!valid) {
      return
    }
    const data = toRaw(addForm.value)
    // delete data.type;
    // @ts-ignore
    if (data.id) {
      await updateOffline(reportCode.value, data)
    } else {
      await saveOffline(reportCode.value, data)
    }
    await search()
    addDialog.value = false
    ElMessage.success('保存成功')
  } finally {
    offlineLoading.value = false
  }
}

const upload = async (data = {}) => {
  // if (!data.file.name.toLowerCase().endsWith(".pdf") && !data.file.name.toLowerCase().endsWith(".jpg")) {
  //   ElMessage.error({message:"仅可上传PDF/JPG文件", grouping: true, showClose: true, duration: 0});
  //   return;
  // }
  // @ts-ignore
  const rsPromise = await uploadOfflineAttachment(reportCode.value, addForm.value.applicationID, data)
  ElMessage.success('上传成功')
}

const uploadFile = () => {
  var elementById = document.getElementById('uploadButton')
  elementById.click()
}

const getConfigs = () => {
  const path = useRoute().path
  reportCode.value = getRequestClassificationCode()
  // @ts-ignore
  const obj = configs[`config${reportCode.value}`]
  const fkObj = fkConfigs[`config${getFeedbackCode(reportCode.value)}`]
  // @ts-ignore
  const subObj = configs[`config${reportCode.value}Detail`]
  columns = obj['columns']
  columnsPolice = obj['columnsPolice']

  if(reportCode.value=='100703'){
    columnsRPolice = obj['columnsRPolice']
  }
  columnsObject = obj['columnsObject']

  formItems = obj['formItems']
  feedbackItem.value = fkObj['formItems']
  feedbackItem.value = [
    { prop: 'applicationID', label: '业务申请编号', labelWidth: 150, inputType: 'input', scopedSlot: 'systemCode' },
    ...feedbackItem.value.filter((item) => item.prop !== 'transSerialNumber' && item.prop !== 'applicationID'),
  ]

  searchFormItems = obj['searchFormItems']
  advancedQueryItems = obj['advancedQueryItems']
  if (subObj != undefined) {
    subColumns = subObj['columns']
    subFormItems = subObj['formItems']
  }
}

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(',')
}

const search = async () => {
  loadingTable.value = true
  let formData = checkData(searchForm.value)
  let result = await list(reportCode.value, formData, page.value.currentPage, page.value.pageSize)
  let { current, total, records } = result.data

  setCjDefaultValue(records);

  tableDate.value = records
  page.value.currentPage = current
  page.value.total = total
  loadingTable.value = false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const openFile = (key: string) => {
  // 将base64字符串转换为Uint8Array对象
  var data = atob(xmlDataList.value[key])
  var dataArray = new Uint8Array(data.length)
  for (var i = 0; i < data.length; i++) {
    dataArray[i] = data.charCodeAt(i)
  }
  if (key.toLocaleLowerCase().endsWith('pdf')) {
    // let pdfWindow = window.open('', 'pdf预览')
    let pdfWindow = window.open('')
    // 创建Blob对象
    const pdfBlob = new Blob([dataArray], { type: 'application/pdf' })
    // 将Blob对象转换为URL
    const pdfUrl = URL.createObjectURL(pdfBlob)
    // 将URL作为iframe的src属性值
    pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>")
  } else if (key.toLocaleLowerCase().endsWith('jpg')) {
    // 创建Blob对象
    const jpgBlob = new Blob([dataArray], { type: 'image/jpeg' })
    // 将Blob对象转换为URL
    const jpgUrl = URL.createObjectURL(jpgBlob)
    showImageViewer.value = true
    urlList.value = [jpgUrl]
  } else if (key.toLocaleLowerCase().endsWith('png')) {
    // 创建Blob对象
    const jpgBlob = new Blob([dataArray], { type: 'image/jpeg' })
    // 将Blob对象转换为URL
    const jpgUrl = URL.createObjectURL(jpgBlob)
    showImageViewer.value = true
    urlList.value = [jpgUrl]
  } else if (key.toLocaleLowerCase().endsWith('xml')) {
    // 创建Blob对象
    const xmlBlob = new Blob([dataArray], { type: 'text/xml' })
    // 将Blob对象转换为URL
    const xmlUrl = URL.createObjectURL(xmlBlob)
    let xmlWindow = window.open(xmlUrl, 'xml预览')
  } else if (key.toLocaleLowerCase().endsWith('txt')) {
    // 创建Blob对象
    const xmlBlob = new Blob([dataArray], { type: 'txt' })
    // 将Blob对象转换为URL
    const xmlUrl = URL.createObjectURL(xmlBlob)
    let xmlWindow = window.open(xmlUrl, 'txt预览')
  } else {
    ElMessage.error({ message: '暂不支持打开此种类型的文件', grouping: true, showClose: true, duration: 0 })
  }
}
const getDetailList = async (row: any) => {
  let params = {
    dobjectId: row.dobjectId,
    applicationID: row.applicationID,
    txCode: row.txCode,
    transSerialNumber: row.transSerialNumber,
  }
  let res2 = await getObjectList(params)
  if (res2?.success) {
    tableDateObject.value = res2?.result?.records || []
  }
  if (reportCode.value == '100701' || reportCode.value == '100703') {
    let res = await getPoliceList(params)
    if (res?.success) {
      tableDatePolice.value = res?.result?.records || []
      setCjDefaultValue(tableDatePolice.value);
    }
  } 
   if (reportCode.value == '100703') {
    let res = await getRemovePoliceList(params)
    if (res?.success) {
      tableDateRPolice.value = res?.result?.records || []
      setCjDefaultValue(tableDatePolice.value);
    }
  }
}
const openDialog = async (row: any, type: string) => {
  const result = await getById(reportCode.value, { id: row.id })
  if (type == '查看') {
    await getDetailList(row)

    setCjDefaultValueObject(result.data)

    open(result.data, true, '查看')
  } else {
    addForm.value = result.data
    addDialog.value = true
  }
}

const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

/**
 * 子表所需组件和方法
 * */
const subPage = ref<Pagination>(subPagination)
const subData = ref<any[]>([])
const subTableVisible = ref(false)
let subColumns = []
let subFormItems = []
const subLoading = ref(false)
const {
  dialogData: subDialogData,
  open: subOpen,
  close: subClose,
  closed: subClosed,
  form: subForm,
  nameRef: subDialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('subDialogFormRef', { type: [] })

// @ts-ignore 行操作按钮
const genRowButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      // @ts-ignore
      handler: () => {
        openDialog(row, '查看')
      },
    },
    {
      key: 'assignment',
      label: '指派',
      tag: 'button',
      type: 'primary',
      handler: () => {
        if (row.status == '4' || row.status == '5') {
          ElMessage.warning('该条数据已经生成或上报报文,无法指派机构')
          return
        }
        assignmentDialog.value = true
        assignmentForm.value = {}
        const data = toRaw(assignmentForm.value)
        // @ts-ignore
        data.qqdbs = row.transSerialNumber
        // @ts-ignore
        data.rwlsh = row.applicationID
        assignmentQqdbs.value = row.transSerialNumber
        assignmentRwlsh.value = row.applicationID
        assignmentSearch()
      },
    },

    {
      key: 'view',
      label: '预览请求附件',
      tag: 'button',
      type: 'primary',
      invisible:
        getRequestClassificationCode() == '100601' ||
        getRequestClassificationCode() == '100603' ||
        getRequestClassificationCode() == '100701' ||
        getRequestClassificationCode() == '100703',
      handler: async () => {
        const result = await getAllFile(reportCode.value, row)
        const keys = Object.keys(result.data)
        xmlButtonKeys.value = keys
        xmlDataList.value = result.data
        dialogVisible.value = true
      },
    },
  ]

  if (row.importType == '3') {
    buttons.splice(1, 0, {
      key: 'edit',
      label: '编辑',
      tag: 'button',
      type: 'primary',
      handler: () => {
        openDialog(row, '编辑')
      },
    })
    buttons.splice(2, 0, {
      key: 'del',
      label: '删除',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        try {
          const rsPromise = await delOffline(reportCode.value, row.id)
          ElMessage.success(rsPromise.data)
        } finally {
          search()
        }
      },
    })
  }

  if (row.status == 1 || row.status == 6) {
    buttons.splice(1, 0, {
      key: 'feedback',
      label: '反馈',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        // 线下请求单的只有status = 0的可以新增反馈
        if (row.importType == '3') {
          if (row.status == '3' || row.status == '5') {
            ElMessage.warning('线下请求单已反馈,无法新增反馈')
            return
          }
        } else {
          if (row.status == '4' || row.status == '5') {
            ElMessage.warning('该条数据已经生成或上报报文,无法新增反馈')
            return
          }
        }

        let toRaw1 = toRaw(bodyForm.value)
        for (const key in row) {
          if (row.hasOwnProperty(key)) {
            toRaw1[key] = row[key]
          }
        }

        let data = toRaw(feedbackForm.value)
        // @ts-ignore
        data.transSerialNumber = row.transSerialNumber
        // @ts-ignore
        data.applicationID = row.applicationID
        // @ts-ignore
        data.updateType = row.updateType
        // @ts-ignore
        data.processMeasure = row.processMeasure
        // data.balance = row.balance
        // @ts-ignore
        data.appliedBalance = row.balance
        // @ts-ignore
        data.caseType = row.caseType
        // @ts-ignore
        data.controlPeriod = row.controlPeriod
        // @ts-ignore
        data.cancelReason = row.cancelReason
        // @ts-ignore
        data.trxId = row.trxId
        // @ts-ignore
        data.feedbackOrgName = config.value.bankOrgName
        // @ts-ignore
        data.feedbackOrgId = config.value.bankOrgCode
        // @ts-ignore
        data.currency = row.currency
        // @ts-ignore
        if (data.branchCode == null) {
          // @ts-ignore
          data.branchCode = dictData.branchCode[0].value
        }
        data.applicationTime = moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
        data = copyProperties(data, row, getRequestClassificationCode())
        await getDetailList(row)
        feedbackForm.value = { ...feedbackForm.value }
        feedbackDialog.value = true
      },
    })
  }
  if (row.wsApplyFlag != '2') {
    buttons.push({
      key: 'wsApply',
      label: '文书申请',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        let res = await wsApply(reportCode.value, {
          id: row.id,
        })
        if (res?.success) {
          ElMessage.success(res.msg)
          search()
        }
      },
    })
  }
  return buttons
}

// todo 这些buttons在哪里用
const genSubActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'view',
    label: '查看',
    tag: 'button',
    type: 'primary',
    handler: () => {
      subOpen(row, '查看')
    },
  },
  {
    key: 'feedback',
    label: '反馈',
    tag: 'button',
    type: 'primary',
    handler: async () => {
      if (mainTableStatus.value == '4' || mainTableStatus.value == '5') {
        ElMessage.warning('该条数据已经生成或上报报文,无法新增反馈')
        return
      }
      let toRaw1 = toRaw(subBodyForm.value)
      for (const key in row) {
        if (row.hasOwnProperty(key)) {
          toRaw1[key] = row[key]
        }
      }

      let data = toRaw(feedbackForm.value)
      // @ts-ignore
      data.transSerialNumber = row.transSerialNumber
      // @ts-ignore
      data.applicationID = row.applicationID
      data = copyProperties(data, row, getRequestClassificationCode())

      feedbackDialog.value = true
    },
  },
]

const subSearch = async (applicationID: string) => {
  subLoading.value = true
  try {
    let data = { applicationID: applicationID }
    let result = await list(`${reportCode.value}Detail`, data, subPage.value.currentPage, subPage.value.pageSize)
    let { current, total, records } = result.data
    subData.value = records
    subPage.value.currentPage = current
    subPage.value.total = total
  } finally {
    subLoading.value = false
  }
}
const subPageChange = (p: Pagination) => {
  subPage.value = p
  subSearch(applicationID.value)
}
const openSubTable = (applicationId: string, status: string) => {
  applicationID.value = applicationId
  subTableVisible.value = true
  mainTableStatus.value = status
  subPageChange(subPagination)
}

/**
 * 反馈弹出框所需组件
 * */
const mainTableStatus = ref('')
const feedbackItem = ref([])
const feedbackDialog = ref(false)
const feedbackForm = ref({})
const feedbackFormRef = ref<RkFormInstance>()
const bodyForm = ref({})
const bodyFormRef = ref<RkFormInstance>()
const subBodyForm = ref({})
const subBodyFormRef = ref<RkFormInstance>()

function getFeedbackCode(reportCode: string) {
  switch (reportCode) {
    case '100101':
      return '100102'
    case '100103':
      return '100104'
    case '100105':
      return '100106'
    case '100201':
      return '100202'
    case '100203':
      return '100204'
    case '100205':
      return '100206'
    case '100301':
      return '100302'
    case '100303':
      return '100304'
    case '100305':
      return '100306'
    case '100307':
      return '100308'
    case '100309':
      return '100310'
    case '100601':
      return '100602'
    case '100603':
      return '100604'
    case '100701':
      return '100702'
    case '100703':
      return '100704'
    case '100713':
      return '100714'
  }
}

function clearFeedbackForm() {
  feedbackForm.value = {}
  bodyForm.value = {}
  subBodyForm.value = {}
  feedbackFormRef.value?.resetFields()
  bodyFormRef.value?.resetFields()
  subBodyFormRef.value?.resetFields()
}

/**
 * 保存反馈信息
 */
const saveFeedback = async () => {
  const valid = await feedbackFormRef.value?.asyncValidate()
  if (!valid) return
  const data = toRaw(feedbackForm.value)
  // @ts-ignore
  data.status = '1'
  // @ts-ignore
  data.deleted = '0'
  //反馈失败要确定弹窗
  if (data.prosResult == '02') {
    ElMessageBox.confirm('请确认反馈结果是否正确?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    })
      .then(async () => {
        await updateRequestStatus(getRequestClassificationCode(), data)
        await saveData(getFeedbackCode(getRequestClassificationCode()), data, true)
        await search()
        feedbackDialog.value = false
        ElMessage.success('保存成功')
      })
      .catch(() => {
        return
      })
  } else {
    await updateRequestStatus(getRequestClassificationCode(), data)
    await saveData(getFeedbackCode(getRequestClassificationCode()), data, true)
    await search()
    feedbackDialog.value = false
    ElMessage.success('保存成功')
  }
}

//主表导出
const exp = async () => {
  expLoading.value = true
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    const newObject = { ...searchForm.value }
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null
      }
    }
    await exportExcel(ids, reportCode.value, newObject)
  } finally {
    expLoading.value = false
  }
}

/**
 * 西班牙桑坦德银行需求,
 * 反馈表单涉及经办人姓名、经办人电话信息，在新增补录时如果该字段为空抓取该用户登录的oauth中对应的信息。
 * 额外要求：添加开关控制该功能
 */
watch(
  () => feedbackDialog.value,
  async (val) => {
    if (dictData.OperatorRef != undefined && feedbackDialog.value) {
      const result = await getUserInfo()
      const loginUserInfo = result.data
      if (isEmpty(feedbackForm.value.operatorName)) {
        feedbackForm.value.operatorName = loginUserInfo.username
      }
      if (isEmpty(feedbackForm.value.operatorPhoneNumber)) {
        feedbackForm.value.operatorPhoneNumber = loginUserInfo.phoneNumber
      }
    }
  },
)

/**
 * 100604 监听caseType, 值为1002-受害人账户，100604，反馈报文100604中result“反馈结果”以下的反馈内容无需反馈，详见100604
 * 将原必填字段设置为非必填
 *
 * 100714 监听updateType, 值为01-管控，开户机构标识、开户机构名称、处置方式、管控账户余额、币种为必填；02时非必填
 */
watch(
  () => [feedbackForm.value, feedbackDialog.value],
  (newForm, oldForm) => {
    let fields = []
    // @ts-ignore
    const caseType = newForm[0].caseType
    // @ts-ignore
    const updateType = newForm[0].updateType

    if (getFeedbackCode(reportCode.value) === '100702' || getFeedbackCode(reportCode.value) === '100704') {
      // 匹配结果根据字典有没有配控制是否可填
      let matchResult = feedbackItem.value.filter((item) => item.prop == 'matchResult')
      matchResult.map((item) => (item.inputType.disabled = !!dictData?.matchResultSwitch))
      feedbackItem.value = [...feedbackItem.value]

      // failReasonCd = 99 //反馈失败码原因必填
      const failReasonCd = newForm[0].failReasonCd

      let failReasonDescItem = feedbackItem.value.filter((item) => item.prop == 'failReasonDesc')
      const rules = failReasonDescItem.map((item) => item.rules.find((item) => item.required != undefined))
      rules.map((rule) => (rule.required = failReasonCd == '99' ? true : false))
      feedbackItem.value = [...feedbackItem.value]

      const prosResult = newForm[0].prosResult
      let failReasonDescItem2 = feedbackItem.value.filter((item) => item.prop == 'failReasonCd')
      const rules2 = failReasonDescItem2.map((item) => item.rules.find((item) => item.required != undefined))
      rules2.map((rule) => (rule.required = prosResult == '02' ? true : false))
      feedbackItem.value = [...feedbackItem.value]
    }
    // @ts-ignore
    if (getFeedbackCode(reportCode.value) === '100714') {
      fields = ['opnInsId', 'opnInsNm', 'processMeasure', 'balance', 'currency']
      const items = feedbackItem.value.filter((item) => fields.includes(item.prop))
      const rules = items.map((item) => item.rules.find((item) => item.required != undefined))
      rules.map((rule) => (rule.required = updateType == '02' ? false : true))
      feedbackItem.value = [...feedbackItem.value]
    }
    // 未启用部门编码，编辑页面隐藏
    if (dictData.departmentCodeRequired == undefined) {
      feedbackItem.value = feedbackItem.value.filter((item) => 'departmentCode' != item.prop)
      feedbackItem.value = [...feedbackItem.value]
    }
  },
  { deep: true },
)
</script>

<style scoped></style>
