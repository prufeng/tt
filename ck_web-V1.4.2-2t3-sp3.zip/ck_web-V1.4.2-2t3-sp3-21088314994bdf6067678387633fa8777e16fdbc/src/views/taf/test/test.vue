<template xmlns="http://www.w3.org/1999/html">
  <el-card style="margin-top: 20px">
    <template #header>
      <div class="card-header"><span>查控指令报文</span></div>
    </template>
    <el-button type="primary" @click="sendRequest('100101')">止付</el-button>
    <el-button type="primary" @click="sendRequest('100103')">止付解除</el-button>
    <el-button type="primary" @click="sendRequest('100201')">冻结</el-button>
    <el-button type="primary" @click="sendRequest('100203')">冻结解除</el-button>
    <el-button type="primary" @click="sendRequest('100205')">冻结延期</el-button>
    <el-button type="primary" @click="sendRequest('100301')">账户交易明细查询</el-button>
    <el-button type="primary" @click="sendRequest('100303')">账户持卡主体查询</el-button>
    <el-button type="primary" @click="sendRequest('100309')">客户全账户查询</el-button>
    <el-button type="primary" @click="sendRequest('100603')">可疑账户指定机构推送</el-button>
    <el-button type="primary" @click="sendRequest('100713')">涉案账户管控下发</el-button>
    <el-button type="primary" @click="sendRequest('100701')">金融惩戒监控下发</el-button>
    <el-button type="primary" @click="sendRequest('100703')">解除金融惩戒监控下发</el-button>
  </el-card>

  <el-card style="margin-top: 50px">
    <template #header>
      <div class="card-header"><span>401报文</span></div>
    </template>
    <el-button type="primary" @click="sendRequest('401')">查询流水号</el-button>
  </el-card>

  <el-card style="margin-top: 50px">
    <template #header>
      <div class="card-header"><span>二期报文</span></div>
    </template>

    <div style="width: 80%">
      <el-row :gutter="20">
<!--        <el-col :span="4">
          farms.102.001.01 <br/><br/>
          <el-button type="primary" @click="secondPhaseTest('102')">信息上报回执报文</el-button>
        </el-col>
        <el-col :span="4">
          farms.104.001.01 <br/><br/>
          <el-button type="primary" @click="secondPhaseTest('104')">交易上报回执报文</el-button>
        </el-col>-->
        <el-col :span="4">
          farms.105.001.01 <br/><br/>
          <el-button type="primary" @click="secondPhaseTest('105')">数据下发报文</el-button>
        </el-col>
        <el-col :span="4">
          farms.302.001.01 <br/><br/>
          <el-button type="primary" @click="secondPhaseTest('302')">信息查询回执报文</el-button>
        </el-col>
        <el-col :span="4">
          farms.303.001.01 <br/><br/>
          <el-button type="primary" @click="secondPhaseTest('303')">文件上传下载通知报文</el-button>
        </el-col>
      </el-row>
    </div>

  </el-card>
</template>
<script lang="ts">


import useDictsStore from '@/store/dictStore';
import {useDict} from "riking-layout";
// TODO 启动时加载，不在页面里调用   子系统设置
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
useDict([], [], dictData)
</script>

<script setup lang="ts">
import {RS} from "riking-ui";
import service from "@/utils/request";
import {ElMessage} from "element-plus";

async function sendRequest(code: string) {
  let res;
  if (code === "401") {
    await request401();
  } else {
    await testRequest(code);
  }
  ElMessage.success("成功发送");
}

function testRequest(code: string): Promise<RS> {
  return service({
    url: `/testRequest/${code}`,
    method: 'POST',
    params: {},
  })
}

function request401(): Promise<RS> {
  return service({
    url: `r401Api/request`,
    method: 'POST',
    params: {},
  });
}


/**
 * 二期报文接口测试
 */
async function secondPhaseTest(code: string) {
  let res = await farmsMock(code);
  ElMessage.success("成功发送");
}

function farmsMock(code: string): Promise<RS> {
  return service({
    url: `/farms/mock${code}`,
    method: 'POST',
    params: {},
  })
}


</script>


