import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, ): Promise<RS> {
    return service({
        url: `/black/getCkzlbbList`,
        method: 'POST',
        data,
    })
}


export function exportExcel(data = {}): Promise<RS> {
    return service({
        url: `/black/exportCkzlbbExcel`,
        method: 'POST',
        data,
        responseType: 'blob'
    })
}