import moment from "moment";
import { FormItemInfo, TableColumnInfo } from "riking-ui";
import { useDict } from 'riking-layout'
import useDictsStore from '@/store/dictStore'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
useDict([], [], dictData)
console.log(dictData);

export const columns: TableColumnInfo[] = [
    // { key: 'id', type: 'selection' },
    {
        prop: 'reportCode',
        label: '报文编号',
    },
    {
        prop: 'reportName',
        label: '模块',
    },
    {
        prop: 'trxId',
        label: '流水号',
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
    },
    {
        prop: 'status',
        label: '状态',
        // formatter: (row) => {
        //     if (row.reportCode == '107') {
        //         return dictData.tafReqProcessingStatus.filter(item => item.value == row.status)[0].label
        //     } else {
        //         return dictData.taf_status.filter(item => item.value == row.status)[0].label
        //     }
        // }
    },
    {
        prop: 'result',
        // dictFormatKey: 'result',
        label: '反馈结果',
    },
    {
        prop: 'branchCode',
        dictFormatKey: 'branchTree',
        label: '业务操作机构',
    },
    {
        prop: 'createTime',
        label: '创建时间',
        formatter: (row) => row.createTime ? moment(row.createTime).format('YYYY-MM-DD HH:mm:ss') : '-',
    },
    {
        prop: 'submitBy',
        label: '提交人',
    },
    {
        prop: 'submitTime',
        formatter: (row) => row.submitTime ? moment(row.submitTime).format('YYYY-MM-DD HH:mm:ss') : '-',
        label: '提交时间',
    },
    {
        prop: 'approveBy',
        label: '审核人',
    },
    {
        prop: 'approveTime',
        formatter: (row) => row.approveTime ? moment(row.approveTime).format('YYYY-MM-DD HH:mm:ss') : '-',
        label: '审核时间',
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [

    {
        prop: 'createTime',
        label: '创建时间',
        labelWidth: 80,
        inputType: {
            tag: 'date-picker',
            type: 'daterange',
            style: 'width: 220px',
            rangeSeparator: '-',
            format: 'YYYY-MM-DD',
            valueFormat: 'YYYY-MM-DD',
        },
        // rules: [{ required: true, message: '查控日期不能为空' }],
    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 40,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
            collapseTags: true,
            maxCollapseTags: 1,
        },
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'reportCode',
        label: '报文编号',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'reportName',
        label: '模块',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'status',
        label: '状态',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'dataStatus',
            multiple: false,
        },
    },
    {
        prop: 'fkStatus',
        label: '反馈结果',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'fkStatus',
            multiple: false,
        },
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'branchTree',
            multiple: false,
        },
    },
    {
        prop: 'createTime',
        label: '创建时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'submitBy',
        label: '提交人',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'submitTime',
        label: '提交时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'approveBy',
        label: '审核人',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'approveTime',
        label: '审核时间',
        labelWidth: 170,
        inputType: 'input',
    },
]