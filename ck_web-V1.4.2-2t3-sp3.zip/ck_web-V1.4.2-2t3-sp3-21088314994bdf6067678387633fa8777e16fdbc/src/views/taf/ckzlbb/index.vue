<template>
  <!--  <div class="app-container">-->
  <rk-index-layout>
    <rk-search-form
      ref="searchFormRef"
      v-model="searchForm"
      :loading="loadingTable"
      @keyup.enter="search"
      :form-items="searchFormItems"
      @search="search"
      :label-width="50"
    />
    <rk-page-table
      :columns="columns"
      :loading="loadingTable"
      :data="dataTable"
      @refresh="search"
      :pagination="page"
      @page-change="pageChange"
      @selection-change="handleSelectionChange"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="getMainTableButtons()" :route-meta="$route.meta" :max="9" />
          <UpAndDown :exp="exp" />
        </div> </template
      ><template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link :max="3" />
      </template>
    </rk-page-table>
  </rk-index-layout>
  <!-- 弹出层 -->
  <el-dialog
    v-model="dialogData.visible"
    :title="dialogData.title"
    class="rk-dialog-default"
    @closed="closed"
    :close-on-click-modal="false"
  >
    <rk-detail-form ref="dialogFormRef" v-model="form" :disabled="true" :form-items="formItems" />

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'
import moment from 'moment'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  RkIndexLayout,
  DialogForm,
} from 'riking-ui'
import { useDict } from 'riking-layout'
import { list } from '@/views/taf/ckzlbb/api'
import { checkData, pagination } from '@/utils/utils'
import { columns, searchFormItems, formItems } from './config'
import { exportExcel } from './api'
import UpAndDown, { expLoading } from '@/components/UpAndDown.vue'
const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

interface ISearch {
  createTime: [] | any
  branchCodeList: []
}
const searchForm = ref<ISearch>({
  createTime: [moment().add(-30, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')],
  branchCodeList: [],
})

const loadingTable = ref(false)
const data = ref<any[]>([])
const dataTable = ref<any[]>([])

const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
let ids: string

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  search()
})

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'view',
    label: '查看',
    tag: 'button',
    type: 'primary',
    handler: () => {
      open(row, true, '查看')
    },
  },
]
const handleSelectionChange = async (val: any) => {
  console.log(val)

  ids = val.map((item: any) => item.id).join(',')
}

const getMainTableButtons: () => ButtonInfo[] = () => {
  const buttons = []

  return buttons
}
const exp = async () => {
  expLoading.value = true
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    let params = checkData(searchForm.value)
    if (params.createTime) {
      params.startTime = params.createTime
      delete params.createTime
    }
    await exportExcel(params)
  } finally {
    expLoading.value = false
  }
}
const search = async () => {
  let params = checkData(searchForm.value)
  if (params.createTime) {
    params.startTime = params.createTime
    delete params.createTime
  }
  loadingTable.value = true
  let res = await list(params)
  loadingTable.value = false
  data.value = res.data
  dataTable.value = res.data.slice(0, 50)
  page.value.currentPage = 1
  page.value.total = res.data.length
}

const pageChange = (p: Pagination) => {
  dataTable.value = data.value.slice((p.currentPage - 1) * p.pageSize, p.currentPage * p.pageSize)
  page.value = p
}
</script>

<style scoped></style>
