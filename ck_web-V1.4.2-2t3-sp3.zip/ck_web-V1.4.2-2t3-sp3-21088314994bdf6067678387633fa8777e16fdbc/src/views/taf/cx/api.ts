import {RS} from 'riking-ui'
import service from '@/utils/request'
import {getCommonParams, getSubSystem} from "@/utils/subSystem";

export function saveOffline(reportCode: string, data: any): Promise<RS> {
    return service({
        url: `/${reportCode}/saveOffline`,
        method: 'POST',
        data,
    })
}

export function updateOffline(reportCode: string, data: any): Promise<RS> {
    return service({
        url: `/${reportCode}/updateOffline`,
        method: 'POST',
        data,
    })
}

export function delOffline(reportCode: string, ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/delOffline`,
        method: 'POST',
        params: {ids},
    })
}

export function uploadOfflineAttachment(reportCode: string, applicationID: string, data = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/uploadOfflineAttachment`,
        method: 'POST',
        data,
        params: {applicationID},
        headers: {'Content-Type': 'multipart/form-data',}
    })
}


export function list(reportCode: string, data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/${reportCode}/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

// export function subList(applicationID: string,reportCode: string, data = {}, current: number, size: number): Promise<RS> {
//     return service({
//         url: `/${reportCode}Detail/list`,
//         method: 'POST',
//         data,
//         params: {current, size,applicationID}
//     })
// }
export function getById(reportCode: string, params = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/getById`,
        method: 'GET',
        params,
    })
}

export function exportExcel(ids: any, reportCode: string, data = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/exportExcel`,
        method: 'POST',
        data,
        params: {ids},
        responseType: 'blob'
    })
}

export function getAllFile(reportCode: string, data = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/getAllFile`,
        method: 'POST',
        data,
        params: {},
    })
}

export function downloadZip(ids: any): Promise<RS> {
    return service({
        url: '/query/downloadZip',
        method: 'POST',
        responseType: 'blob',
        params: {ids},
    })
}

export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
    return service({
        url: '/Configuration/list',
        method: 'POST',
        data,
        params: {pageNo, pageSize, ...getCommonParams()}
    })
};

export function listByOriginalApplicationID(reportCode: string, originalApplicationID: string): Promise<RS> {
    return service({
        url: `/${reportCode}/listByOriginalApplicationID`,
        method: 'POST',
        params: {originalApplicationID: originalApplicationID},
    })
}
