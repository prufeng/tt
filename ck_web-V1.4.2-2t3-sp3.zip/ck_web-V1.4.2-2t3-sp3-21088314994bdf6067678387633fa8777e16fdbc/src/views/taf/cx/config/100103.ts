import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        width: 170
    },
    {
        prop: 'caseNumber',
        label: '案件编号',
        width: 170,
        sortable: true
    },
    {
        prop: 'caseType',
        label: '案件类型',
        width: 170,
        dictFormatKey: 'caseType',
        sortable: true
    },
    {
        prop: 'originalApplicationID',
        label: '原止付申请编号',
        width: 170,
        sortable: true
    },
    {
        prop: 'emergencyLevel',
        label: '紧急程度',
        width: 170,
        dictFormatKey: 'emergencyLevel',
        sortable: true
    },
    /*{
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },*/
    {
        prop: 'bankID',
        label: '止付账户所属银行机构编码',
        width: 170,
        sortable: true
    },
    {
        prop: 'bankName',
        label: '止付账户所属银行名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountType',
        label: '止付账号类别',
        width: 170,
        dictFormatKey: 'accountType',
        sortable: true
    },
    {
        prop: 'accountName',
        label: '止付账户名',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountNumber',
        label: '止付帐卡号',
        width: 170,
        sortable: true
    },
    {
        prop: 'withdrawalRemark',
        label: '止付解除说明',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationOrgID',
        label: '申请机构编码',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationOrgName',
        label: '申请机构名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorIDType',
        label: '经办人证件类型',
        width: 170,
        dictFormatKey: 'idType',
        sortable: true
    },
    {
        prop: 'operatorIDNumber',
        label: '经办人证件号',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorName',
        label: '经办人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorPhoneNumber',
        label: '经办人电话',
        width: 170,
        sortable: true
    },
    {
        prop: 'investigatorIDType',
        label: '协查人证件类型',
        width: 170,
        dictFormatKey: 'idType',
        sortable: true
    },
    {
        prop: 'investigatorIDNumber',
        label: '协查人证件号',
        width: 170,
        sortable: true
    },
    {
        prop: 'investigatorName',
        label: '协查人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'status',
        label: '请求完成状态',
        width: 170,
        dictFormatKey: 'tafReqProcessingStatus',
        fixed: 'left',
        sortable: true
    },
    /*{
        prop: 'branchCode',
        label: '机构代码',
        width: 170,
        dictFormatKey: 'branchTree',
        sortable: true
    },*/
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170,
        sortable: true
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        sortable: true
    },
    {
        prop: 'updateBy',
        label: '更新人',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        width: 120,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '请求完成状态',
        inputType: {
            tag: 'select',
            options: 'tafReqProcessingStatus',
        },
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        // labelWidth: 170,
        inputType: 'input',

    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        // labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags:1
        },
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'txCode',
        label: '交易类型编码',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'messageFrom',
        label: '发送机构',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'applicationOrgID',
            multiple: false,
        },
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    /*{
        prop: 'transSerialNumber',
        label: '传输报文流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },*/
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },

    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'caseNumber',
        label: '案件编号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'caseType',
        label: '案件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'caseType',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'originalApplicationID',
        label: '原止付申请编号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'emergencyLevel',
        label: '紧急程度',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'emergencyLevel',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'bankID',
        label: '止付账户所属银行机构编码',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'bankName',
        label: '止付账户所属银行名称',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountType',
        label: '止付账号类别',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'accountType',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountName',
        label: '止付账户名',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountNumber',
        label: '止付帐卡号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'withdrawalRemark',
        label: '止付解除说明',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },

    {
        prop: 'applicationTime',
        label: '申请时间',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'applicationOrgID',
        label: '申请机构编码',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'applicationOrgName',
        label: '申请机构名称',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'operatorIDType',
        label: '经办人证件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
    {
        prop: 'operatorIDNumber',
        label: '经办人证件号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
    {
        prop: 'operatorName',
        label: '经办人姓名',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
    {
        prop: 'operatorPhoneNumber',
        label: '经办人电话',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
    {
        prop: 'investigatorIDType',
        label: '协查人证件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
    {
        prop: 'investigatorIDNumber',
        label: '协查人证件号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
    {
        prop: 'investigatorName',
        label: '协查人姓名',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
]

export const advancedQueryItems = [

    {
        value: 'status',
        label: '请求完成状态',
        width: 170,
        inputType: { tag: 'select', options:'tafReqProcessingStatus'}
    },
    {
        value: 'trxId',
        label: '流水号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
            value: 'applicationID',
            label: '业务申请编号',
            // labelWidth: 170,
            inputType: 'input',
    },
    {
        value: 'caseNumber',
        label: '案件编号',
        // labelWidth: 170,
        inputType: 'input',

    },
    {
        value: 'caseType',
        label: '案件类型',
        // labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'caseType',
            multiple: false,
        },

    },
    {
        value: 'originalApplicationID',
        label: '原止付申请编号',
        // labelWidth: 170,
        inputType: 'input',

    },
    {
        value: 'emergencyLevel',
        label: '紧急程度',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'emergencyLevel',
            multiple: false,
        },

    },
    {
        value: 'bankID',
        label: '止付账户所属银行机构编码',
        labelWidth: 170,
        inputType: 'input',

    },
    {
        value: 'bankName',
        label: '止付账户所属银行名称',
        labelWidth: 170,
        inputType: 'input',

    },
    {
        value: 'accountType',
        label: '止付账号类别',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'accountType',
            multiple: false,
        },

    },
    {
        value: 'accountName',
        label: '止付账户名',
        labelWidth: 170,
        inputType: 'input',

    },
    {
        value: 'accountNumber',
        label: '止付帐卡号',
        labelWidth: 170,
        inputType: 'input',

    },
    {
        value: 'withdrawalRemark',
        label: '止付解除说明',
        labelWidth: 170,
        inputType: 'input',

    },

    {
        value: 'applicationTime',
        label: '申请时间',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        value: 'applicationOrgID',
        label: '申请机构编码',
        labelWidth: 170,

    },
    {
        value: 'applicationOrgName',
        label: '申请机构名称',
        labelWidth: 170,
        inputType: 'input',

    },
    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {value: 'importType', label: '导入方式', inputType: {tag: 'select', options: 'importType'}, labelWidth: 100},
    // {
    //     value: 'operatorIDType',
    //     label: '经办人证件类型',
    //     labelWidth: 170,
    //     inputType: {
    //         tag: 'select',
    //         options: 'idType',
    //         multiple: false,
    //     },

    // },
    // {
    //     value: 'operatorIDNumber',
    //     label: '经办人证件号',
    //     labelWidth: 170,
    //     inputType: 'input',

    // },
    // {
    //     value: 'operatorName',
    //     label: '经办人姓名',
    //     labelWidth: 170,
    //     inputType: 'input',

    // },
    // {
    //     value: 'operatorPhoneNumber',
    //     label: '经办人电话',
    //     labelWidth: 170,
    //     inputType: 'input',

    // },
    // {
    //     value: 'investigatorIDType',
    //     label: '协查人证件类型',
    //     labelWidth: 170,
    //     inputType: {
    //         tag: 'select',
    //         options: 'idType',
    //         multiple: false,
    //     },

    // },
    // {
    //     value: 'investigatorIDNumber',
    //     label: '协查人证件号',
    //     labelWidth: 170,
    //     inputType: 'input',

    // },
    // {
    //     value: 'investigatorName',
    //     label: '协查人姓名',
    //     labelWidth: 170,
    //     inputType: 'input',

    // },
]

export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems
}



































