import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        width: 170,
        sortable: true
    },

    {
        prop: 'applicationTime',
        label: '申请时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationOrgID',
        label: '申请机构编码',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateType',
        label: '更新类型',
        width: 170,
        dictFormatKey: 'updateType',
        sortable: true
    },
    {
        prop: 'caseType',
        label: '案件类型',
        width: 170,
        dictFormatKey: 'caseType',
        sortable: true
    },
    {
        prop: 'accountType',
        label: '可疑帐号类型',
        width: 170,
        dictFormatKey: 'doubtfulAccountType',
        sortable: true
    },
    /*{
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },*/
    {
        prop: 'accountNumber',
        label: '可疑帐号',
        width: 170,
        sortable: true
    },
    {
        prop: 'cardProperties',
        label: '卡属性',
        width: 170,
        dictFormatKey: 'cardProperties',
        sortable: true
    },
    {
        prop: 'organizationID',
        label: '机构 ID',
        width: 170,
        sortable: true
    },
    {
        prop: 'organizationName',
        label: '机构名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'depositBankBranch',
        label: '开户网点',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountProvince',
        label: '开户网点所在省',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountCity',
        label: '开户网点所在市',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountArea',
        label: '开户网点所在区',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountAdminisCode',
        label: '开户网点所属行政区划代码',
        width: 170,
        sortable: true,
        dictFormatKey: 'areaCode'
    },
    {
        prop: 'accountSubjectName',
        label: '开户名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountSubjectType',
        label: '开户主体类型',
        width: 170,
        dictFormatKey: 'accountSubjectType',
        sortable: true
    },
    {
        prop: 'accountOpenTime',
        label: '开户日期',
        width: 170,
        sortable: true
    },
    {
        prop: 'legalRepresentative',
        label: '法定代表人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'idType',
        label: '证件类型',
        width: 170,
        sortable: true,
        dictFormatKey: 'idType'
    },
    {
        prop: 'idNumber',
        label: '证件号',
        width: 170,
        sortable: true
    },
    {
        prop: 'police',
        label: '移送公安机关',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorName',
        label: '经办人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorPhoneNumber',
        label: '经办人电话',
        width: 170,
        sortable: true
    },
    {
        prop: 'targetOrganizationID',
        label: '接收机构 ID',
        width: 170,
        sortable: true
    },
    {
        prop: 'riskProperty',
        label: '风险特征',
        width: 170,
        sortable: true
    },
    {
        prop: 'batchNo',
        label: '批次号',
        width: 170,
        sortable: true
    },
    {
        prop: 'generateDate',
        label: '生产日期',
        width: 170,
        sortable: true
    },
    {
        prop: 'dataSource',
        label: '数据来源',
        dictFormatKey:'DataSource',
        width: 170,
        sortable: true
    },
    {
        prop: 'sendDate',
        label: '下发时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'remark',
        label: '名单说明',
        width: 170,
        sortable: true
    },
    {
        prop: 'status',
        label: '请求完成状态',
        width: 170,
        dictFormatKey: 'tafReqProcessingStatus',
        fixed: 'left',
        sortable: true
    },
    /*{
        prop: 'branchCode',
        label: '机构代码',
        width: 170,
        dictFormatKey: 'branchTree',
        sortable: true
    },*/
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170,
        sortable: true
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        sortable: true
    },
    {
        prop: 'updateBy',
        label: '更新人',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        width: 120,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '请求完成状态',
        inputType: {
            tag: 'select',
            options: 'tafReqProcessingStatus',
        },
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        // labelWidth: 170,
        inputType: 'input',

    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        // labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags:1
        },
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'txCode',
        label: '交易类型编码',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'messageFrom',
        label: '发送机构',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'applicationOrgID',
            multiple: false,
        },
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    /*{
        prop: 'transSerialNumber',
        label: '传输报文流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },*/
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'applicationOrgID',
        label: '申请机构编码',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'updateType',
        label: '更新类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'updateType',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'caseType',
        label: '案件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'caseType',
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountType',
        label: '可疑帐号类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'doubtfulAccountType',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountNumber',
        label: '可疑帐号',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'cardProperties',
        label: '卡属性',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'cardProperties',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'organizationID',
        label: '机构 ID',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'organizationName',
        label: '机构名称',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'depositBankBranch',
        label: '开户网点',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountProvince',
        label: '开户网点所在省',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountCity',
        label: '开户网点所在市',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountArea',
        label: '开户网点所在区',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountAdminisCode',
        label: '开户网点所属行政区划代码',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'areaCode',
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountSubjectName',
        label: '开户名称',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountSubjectType',
        label: '开户主体类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'accountSubjectType',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'accountOpenTime',
        label: '开户日期',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'legalRepresentative',
        label: '法定代表人姓名',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'idType',
        label: '证件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'idType'
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'idNumber',
        label: '证件号',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'police',
        label: '移送公安机关',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'operatorName',
        label: '经办人姓名',
        labelWidth: 170,
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
    {
        prop: 'operatorPhoneNumber',
        label: '经办人电话',
        labelWidth: 170,
        extra: {
            collapse: {name: 'operator', title: '经办人'},
        }
    },
    {
        prop: 'targetOrganizationID',
        label: '接收机构 ID',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'riskProperty',
        label: '风险特征',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'batchNo',
        label: '批次号',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'generateDate',
        label: '生产日期',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'dataSource',
        label: '数据来源',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'DataSource'
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'sendDate',
        label: '下发时间',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'remark',
        label: '名单说明',
        labelWidth: 170,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
]

export const advancedQueryItems = [
    {
        value: 'status',
        label: '请求完成状态',
        width: 170,
        inputType: { tag: 'select', options:'tafReqProcessingStatus'}
    },
    {
        value: 'trxId',
        label: '流水号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'applicationID',
        label: '业务申请编号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'applicationTime',
        label: '申请时间',
        // labelWidth: 170,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},

    },
    {
        value: 'applicationOrgID',
        label: '申请机构编码',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'updateType',
        label: '更新类型',
        // labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'updateType',
            multiple: false,
        },
    },
    {
        value: 'caseType',
        label: '案件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'caseType',
            multiple: false,
        },
    },
    {
        value: 'accountType',
        label: '可疑帐号类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'doubtfulAccountType',
            multiple: false,
        },
    },
    {
        value: 'accountNumber',
        label: '可疑帐号',
        labelWidth: 170,
    },
    {
        value: 'cardProperties',
        label: '卡属性',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'cardProperties',
            multiple: false,
        },
    },
    {
        value: 'organizationID',
        label: '机构 ID',
        labelWidth: 170,
    },
    {
        value: 'organizationName',
        label: '机构名称',
        labelWidth: 170,
    },
    {
        value: 'depositBankBranch',
        label: '开户网点',
        labelWidth: 170,
    },
    {
        value: 'accountProvince',
        label: '开户网点所在省',
        labelWidth: 170,
    },
    {
        value: 'accountCity',
        label: '开户网点所在市',
        labelWidth: 170,
    },
    {
        value: 'accountArea',
        label: '开户网点所在区',
        labelWidth: 170,
    },
    {
        value: 'accountAdminisCode',
        label: '开户网点所属行政区划代码',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'areaCode'
        }
    },
    {
        value: 'accountSubjectName',
        label: '开户名称',
        labelWidth: 170,
    },
    {
        value: 'accountSubjectType',
        label: '开户主体类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'accountSubjectType',
            multiple: false,
        },
    },
    {
        value: 'accountOpenTime',
        label: '开户日期',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        value: 'legalRepresentative',
        label: '法定代表人姓名',
        labelWidth: 170,
    },
    {
        value: 'idType',
        label: '证件类型',
        labelWidth: 170,

    },
    {
        value: 'idNumber',
        label: '证件号',
        labelWidth: 170,
    },
    {
        value: 'police',
        label: '移送公安机关',
        labelWidth: 170,
    },
    {
        value: 'operatorName',
        label: '经办人姓名',
        labelWidth: 170,
    },
    {
        value: 'operatorPhoneNumber',
        label: '经办人电话',
        labelWidth: 170,
    },
    {
        value: 'targetOrganizationID',
        label: '接收机构 ID',
        labelWidth: 170,
    },
    {
        value: 'riskvalueerty',
        label: '风险特征',
        labelWidth: 170,
    },
    {
        value: 'batchNo',
        label: '批次号',
        labelWidth: 170,
    },
    {
        value: 'generateDate',
        label: '生产日期',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        value: 'dataSource',
        label: '数据来源',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'DataSource',
            multiple: false,
        },
    },
    {
        value: 'sendDate',
        label: '下发时间',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        value: 'remark',
        label: '名单说明',
        labelWidth: 170,
    },
    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {value: 'importType', label: '导入方式', inputType: {tag: 'select', options: 'importType'}, labelWidth: 100},
]

export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems
}




































