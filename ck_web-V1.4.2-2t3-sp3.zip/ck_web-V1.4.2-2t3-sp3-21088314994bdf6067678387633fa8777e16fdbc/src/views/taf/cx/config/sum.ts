import config100101 from './100101';
import config100103 from './100103';
import config100201 from './100201';
import config100203 from './100203';
import config100205 from './100205';
import config100301 from './100301';
import config100303 from './100303';
import config100309 from './100309';
import config100603 from './100603';
import config100713 from './100713';

const reportCodeMap = new Map()
reportCodeMap.set('100102', '100101')
reportCodeMap.set('100104', '100103')
reportCodeMap.set('100202', '100201')
reportCodeMap.set('100204', '100203')
reportCodeMap.set('100206', '100205')
reportCodeMap.set('100302', '100301')
reportCodeMap.set('100304', '100303')
reportCodeMap.set('100310', '100309')
reportCodeMap.set('100604', '100603')
reportCodeMap.set('100714', '100713')

export default {
    config100101,
    config100103,
    config100201,
    config100203,
    config100205,
    config100301,
    config100303,
    config100309,
    config100603,
    config100713,
    reportCodeMap
}

