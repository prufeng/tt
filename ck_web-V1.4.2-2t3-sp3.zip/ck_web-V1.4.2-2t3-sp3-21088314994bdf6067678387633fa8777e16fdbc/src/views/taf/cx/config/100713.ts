import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'status',
        label: '请求完成状态',
        width: 170,
        dictFormatKey: 'tafReqProcessingStatus',
        fixed: 'left',
        sortable: true
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationOrgID',
        label: '申请机构编码',
        width: 170,
        sortable: true
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        formatter: dateFormatter,
        width: 170,
        sortable: true
    },
    {
        prop: 'updateType',
        label: '业务类型',
        width: 170,
        dictFormatKey: 'taf_updateType',
        sortable: true
    },
    {
        prop: 'caseType',
        label: '案件类型',
        width: 170,
        dictFormatKey: 'taf_caseType',
        sortable: true
    },
    {
        prop: 'caseNumber',
        label: '案件编号',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountType',
        label: '涉案账户类型',
        width: 170,
        dictFormatKey: 'taf_accountType',
        sortable: true
    },
    /*{
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },*/
    {
        prop: 'accountAttribute',
        label: '涉案账户属性',
        width: 170,
        dictFormatKey: 'taf_accountAttribute',
        sortable: true
    },
    {
        prop: 'account',
        label: '涉案账号',
        width: 170,
        sortable: true
    },
    {
        prop: 'organizationID',
        label: '机构ID',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountName',
        label: '持有人姓名或商户名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountCredentialType',
        label: '证件类型',
        width: 170,
        sortable: true
    },
    {
        prop: 'accountCredentialNumber',
        label: '证件号',
        width: 170,
        sortable: true
    },
    {
        prop: 'processMeasure',
        label: '处置建议',
        dictFormatKey:'taf_processMeasure',
        width: 170,
        sortable: true
    },
    {
        prop: 'balance',
        label: '阈值管控金额',
        width: 170,
        sortable: true
    },
    {
        prop: 'controlPeriod',
        label: '管控期限',
        width: 170,
        sortable: true
    },
    {
        prop: 'cancelReason',
        label: '撤销原因',
        dictFormatKey:'taf_cancelReason',
        width: 170,
        sortable: true
    },
    {
        prop: 'currency',
        label: '币种',
        dictFormatKey:'currency',
        width: 170,
        sortable: true
    },
    {
        prop: 'police',
        label: '移送公安机关',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorName',
        label: '经办人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorPhoneNumber',
        label: '经办人电话',
        width: 170,
        sortable: true
    },
    {
        prop: 'auditTime',
        label: '公安业务审核通过时间',
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        width: 170,
        sortable: true
    },
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170,
        sortable: true
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        sortable: true
    },
    {
        prop: 'updateBy',
        label: '更新人',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        width: 120,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '请求完成状态',
        inputType: {
            tag: 'select',
            options: 'tafReqProcessingStatus',
        },
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        // labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags:1
        },
    },

]

export const formItems: FormItemInfo[] = [
    {
        prop: 'txCode',
        label: '交易类型编码',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'messageFrom',
        label: '发送机构',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'applicationOrgID',
            multiple: false,
        },
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    /*{
        prop: 'transSerialNumber',
        label: '传输报文流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },*/
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 170,
        inputType: 'input',
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        inputType: 'input',
        labelWidth: 170,
        extra:{collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'applicationOrgID',
        label: '申请机构编码',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'updateType',
        label: '业务类型',
        inputType: {
            tag: 'select',
            options: 'taf_updateType',
            multiple: false,
        },
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'caseType',
        label: '案件类型',
        inputType: {
            tag: 'select',
            options: 'taf_caseType',
            multiple: false,
        },
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}},
        rules : [{required: false, message: '必填'}]
    },
    {
        prop: 'caseNumber',
        label: '案件编号',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'accountType',
        label: '涉案账户类型',
        inputType: {
            tag: 'select',
            options: 'taf_accountType',
            multiple: false,
        },
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'accountAttribute',
        label: '涉案账户属性',
        inputType: {
            tag: 'select',
            options: 'taf_accountAttribute',
            multiple: false,
        },
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'account',
        label: '涉案账号',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'organizationID',
        label: '机构ID',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'accountName',
        label: '持有人姓名或商户名称',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'accountCredentialType',
        label: '证件类型',
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'accountCredentialNumber',
        label: '证件号',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'processMeasure',
        label: '处置建议',
        inputType: {
            tag: 'select',
            options: 'taf_processMeasure',
            multiple: false,
        },
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'balance',
        label: '阈值管控金额',
        labelWidth: 170,
        inputType: {tag: 'input-number', controlsPosition:"right",precision:"2"},
        extra:{ collapse:{ name: 'body',title: '主体信息'}},
        rules : [{required: false, message: '必填'}]
    },
    {
        prop: 'controlPeriod',
        label: '管控期限',
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}},
        inputType: 'input-number',
        rules : [{required: false, message: '必填'}]
    },
    {
        prop: 'cancelReason',
        label: '撤销原因',
        inputType: {
            tag: 'select',
            options: 'taf_cancelReason',
            multiple: false,
        },
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}},
        rules : [{required: false, message: '必填'}]
    },
    {
        prop: 'currency',
        label: '币种',
        inputType: {
            tag: 'select',
            options: 'currency',
            multiple: false,
        },
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}},
        rules : [{required: false, message: '必填'}]
    },
    {
        prop: 'police',
        label: '移送公安机关',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
    {
        prop: 'operatorName',
        label: '经办人姓名',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'operator',title: '经办人'}}
    },
    {
        prop: 'operatorPhoneNumber',
        label: '经办人电话',
        inputType: 'input',
        labelWidth: 170,
        extra:{ collapse:{ name: 'operator',title: '经办人'}}
    },
    {
        prop: 'auditTime',
        label: '公安业务审核通过时间',
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        labelWidth: 170,
        extra:{ collapse:{ name: 'body',title: '主体信息'}}
    },
]

export const advancedQueryItems = [
    {
        value: 'status',
        label: '请求完成状态',
        width: 170,
        inputType: { tag: 'select', options:'tafReqProcessingStatus'}
    },
    {
        value: 'trxId',
        label: '流水号',
        // labelWidth: 170,
        inputType: 'input',
    },
    {
        value: 'applicationID',
        label: '业务申请编号',
        //width: 170,
        inputType: 'input'
    },
    {
        value: 'applicationOrgID',
        label: '申请机构编码',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'applicationTime',
        label: '申请时间',
        width: 170,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        value: 'updateType',
        label: '业务类型',
        width: 170,
        inputType: { tag: 'select',options: 'taf_updateType'}
    },
    {
        value: 'currency',
        label: '币种',
        width: 170,
        inputType: { tag: 'select',options: 'currency'}
    },
    {
        value: 'caseType',
        label: '案件类型',
        width: 170,
        inputType: { tag: 'select',options: 'taf_caseType'}
    },
    {
        value: 'caseNumber',
        label: '案件编号',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'accountType',
        label: '涉案账户类型',
        width: 170,
        inputType: { tag: 'select',options: 'taf_accountType'}
    },
    {
        value: 'accountAttribute',
        label: '涉案账户属性',
        width: 170,
        inputType: { tag: 'select',options: 'taf_accountAttribute'}
    },
    {
        value: 'account',
        label: '涉案账号',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'organizationID',
        label: '机构ID',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'accountName',
        label: '持有人姓名或商户名称',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'accountCredentialType',
        label: '证件类型',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'accountCredentialNumber',
        label: '证件号',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'processMeasure',
        label: '处置建议',
        width: 170,
        inputType: { tag: 'select',options: 'taf_processMeasure'}
    },
    {
        value: 'balance',
        label: '阈值管控金额',
        width: 170,
        inputType: 'input-number'
    },
    {
        value: 'controlPeriod',
        label: '管控期限',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'cancelReason',
        label: '撤销原因',
        width: 170,
        inputType: { tag: 'select',options: 'taf_cancelReason'}
    },
    {
        value: 'police',
        label: '移送公安机关',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'operatorName',
        label: '经办人姓名',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'operatorPhoneNumber',
        label: '经办人电话',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'auditTime',
        label: '公安业务审核通过时间',
        width: 170,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        value: 'importType',
        label: '导入方式',
        width: 170,
        inputType: { tag: 'select',options: 'importType'}
    },
    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {value: 'importType', label: '导入方式', inputType: {tag: 'select', options: 'importType'}, labelWidth: 100},
]

export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems
}
























