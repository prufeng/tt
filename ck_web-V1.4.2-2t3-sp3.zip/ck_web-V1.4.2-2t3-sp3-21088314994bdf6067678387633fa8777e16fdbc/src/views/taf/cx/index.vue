<template>
<!--  <div class="app-container">-->
  <rk-index-layout>
<!--  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"
                  :form-items="searchFormItems" @search="search" :label-width="50" />-->
    <rk-dynamic-search-form v-model="searchForm" :form-items="searchFormItems" :fields="advancedQueryItems"
                            @search="search" ></rk-dynamic-search-form>

    <rk-page-table :columns="columns" :data="tableDate" :pagination="page" @page-change="pageChange" @refresh="search" :loading="loadingTable"
                 @selection-change="handleSelectionChange">
    <template #operations>
      <div style="display: flex; flex-direction: row">
        <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
        <div style="margin: 0 4px;"></div>
        <UpAndDown :exp="exp"/>
      </div>
    </template>

    <!--<template #createTime="{ row }">-->
    <!--  <div>{{dayjs(row.createTime).format('YYYY-MM-DD HH:mm:ss') }}</div>-->
    <!--</template>-->

    <!--<template #updateTime="{ row }">-->
    <!--  <div>{{dayjs(row.updateTime).format('YYYY-MM-DD HH:mm:ss') }}</div>-->
    <!--</template>-->

    <template #actions="{ row }">
      <rk-button-group :buttons="genRowButtons(row)" :route-meta="$route.meta" link max="2"/>
    </template>
    <template #subTable="{ row }">
      <el-button type="primary" :underline="false" link @click="openSubTable(row.applicationID,row.status)">{{ row.applicationID }}</el-button>
    </template>
  </rk-page-table>
  </rk-index-layout>
  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed">
    <rk-collapse-form ref="dialogFormRef" v-model="form" disabled="false"
                      :form-items="formItems"
                      :collapse-model-value="['head', 'body', 'operator']"/>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 子表弹出层 -->
  <el-dialog v-model="subTableVisible" title="详细信息" class="rk-dialog-default" :close-on-click-modal="false">
    <rk-page-table :loading="subLoading" :columns="subColumns" :data="subData" :pagination="subPage" @page-change="subPageChange" @refresh="subSearch(applicationID)"
                   @selection-change="handleSelectionChange">
      <template #actions="{ row }">
        <rk-button-group :buttons="genSubActButtons(row)" :route-meta="$route.meta" link/>
      </template>
    </rk-page-table>
  </el-dialog>

  <!-- 子表form弹出层 -->
  <el-dialog v-model="subDialogData.visible" :title="subDialogData.title" class="rk-dialog-default" @closed="subClosed" >
    <rk-collapse-form
        ref="subDialogFormRef"
        v-model="subForm"
        :form-items="subFormItems"
        disabled="false"
    >
    </rk-collapse-form>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="subClose"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
<!--  </div>-->
  <!-- 请求单页面反馈弹出框 -->
  <el-dialog title="反馈" v-model="feedbackDialog" width="90%" @closed="clearFeedbackForm();">
    <rk-collapse-form v-if="getRequestClassificationCode()!=='100601'&&
                            getRequestClassificationCode()!=='100701'&&
                            getRequestClassificationCode()!=='100703'"
                      ref="bodyFormRef"
                      v-model="bodyForm" :disabled="true"
                      :form-items="formItems.filter(item => {
        return (
           item.extra &&
           item.extra.collapse &&
           item.extra.collapse.name === 'body' &&
           item.extra.collapse.title === '主体信息'
        );
      })"
                      :collapse-model-value="['head', 'body', 'operator']"/>
    <rk-collapse-form v-else         ref="subBodyFormRef"    v-model="subBodyForm"
                      :form-items="subFormItems.filter(item => {
        return (
           item.extra &&
           item.extra.collapse &&
           item.extra.collapse.name === 'body' &&
           item.extra.collapse.title === '主体信息'
        );
      })"
                      :disabled="true"/>
    <div>
      <h4>反馈信息</h4>
    </div>
    <rk-detail-form ref="feedbackFormRef" v-model="feedbackForm" :form-items= feedbackItem>
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled=true filterable style="width: 100%">
        </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="saveFeedback">保存</el-button>
        <el-button @click="feedbackDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 指派机构表格弹出框 -->
  <el-dialog title="指派" v-model="assignmentDialog"  width="70%" >

    <rk-page-table ref="assignmentTable" :loading="assignmentLoading" :data="assignmentData"
                   :columns="assignmentColumns" border="true"
                   @selection-change="assignmentIdsHandleSelectionChange" @refresh="assignmentSearch">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <!-- 此处按钮无需做权限配置 即:route-meta="[]"即可 -->
          <rk-button-group :buttons="assignmentButtons" :route-meta="[]"></rk-button-group>
        </div>
      </template>
    </rk-page-table>
  </el-dialog>
  <!-- 指派机构form弹出框 -->
  <el-dialog title="新增指派" v-model="assignmentFormDialog"  width="70%" @closed="()=>{assignmentFormRef.resetFields()}">
    <rk-detail-form ref="assignmentFormRef" v-model="assignmentForm" :form-items="[
     {
        prop: 'qqdbs',
        label: '传输报文流水号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },{
        prop: 'rwlsh',
        label: '业务申请编号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },{
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{required: true, message: '业务操作机构不能为空'}],
    },
    ]">
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled=true filterable style="width: 100%">
        </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="assignmentSave">保存</el-button>
        <el-button @click="assignmentFormDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button v-for="xmlKey in xmlButtonKeys" :key="xmlKey" type="primary" link
               style=" margin-bottom: 10px;   display: flex;  flex-direction: column;" @click="openFile(xmlKey)">{{ xmlKey
      }}</el-button>
  </el-dialog>
  <div class="img-viewer-box">
    <el-image-viewer v-if="showImageViewer" :url-list="urlList" @close="() => {showImageViewer = false}"/>
  </div>

  <!--线下请求单-->
  <el-dialog v-model="addDialog" title="线下请求单" width="90%" @closed="()=>{addFormRef.resetFields()}">
    <rk-collapse-form ref="addFormRef" v-model="addForm" :collapse-model-value="activeCollapse" :form-items="formItems">
    </rk-collapse-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="addDialog === true" type="primary" @click="uploadFile">上传附件</el-button>
        <el-button type="primary" @click="addSave">保存</el-button>
        <el-button @click="addDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>

  <template>
    <div>
      <el-upload
          ref="uploadRef"
          :on-error="()=>{ElMessage.error({ message: '上传失败', grouping: true, showClose: true, duration: 0})}"
          :show-file-list="false"
          :http-request="upload">
        >
        <el-button ref="uploadButton" id="uploadButton" type="primary">上传文件</el-button>
      </el-upload>
    </div>
  </template>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
export default {
  name :""
}
</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage, ElImageViewer} from 'element-plus'
import {
  assignmentDialog,
  assignmentLoading,
  assignmentData,
  assignmentColumns,
  // assignmentPage,
  // assignmentPageChange,
  assignmentSearch,
  assignmentButtons,
  assignmentQqdbs,
  assignmentRwlsh,
  assignmentIdsHandleSelectionChange,
  assignmentSave,
  assignmentFormDialog,
  assignmentFormRef,
  assignmentForm} from '@/utils/assignment'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  FormItemInfo, TableColumnInfo, RkDynamicSearchForm, RkIndexLayout,
} from 'riking-ui'

import DialogForm from 'riking-ui/dist/hooks/useDialogForm'

import {useDict} from 'riking-layout'
import UpAndDown, {expLoading} from "@/components/UpAndDown.vue";
import {
  list, getById, getAllFile, exportExcel, listByOriginalApplicationID, saveOffline, uploadOfflineAttachment,
    updateOffline, delOffline
} from '@/views/taf/cx/api'
import {getUserInfo, listResult, saveData, updateRequestStatus} from '@/views/taf/fk/api'
import {
  checkData,
  checkSpecialCharacters,
  copyProperties,
  pagination,
  specialChecks,
  subPagination
} from "@/utils/utils";
import configs from './config/sum';
import {default as fkConfigs} from "@/views/taf/fk/config/sum";
import {getRequestClassificationCode, getSubSystem} from "@/utils/subSystem";
import {getQuartzList} from "@/views/sys/config/config.api";

import {isEmpty} from "@/views/taf/fk/commonFk";
import {setRequiredRule} from "@/views/system/sum";

// useDict([], [], dictData,)
useDict([], [], {
  ...dictData,
  result: async () => {
    const res = await listResult(parseInt(getRequestClassificationCode())+1);
    return res.data
  },
})

const reportCode = ref(''); // 报文编号
const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const tableDate = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const applicationID = ref("");
const dialogVisible = ref(false);
const xmlButtonKeys = ref({});
const xmlDataList = ref({});
const showImageViewer = ref(false) //组件是否显示
const urlList = ref([]) //图片List
const config = ref({}) //图片List
let columns: TableColumnInfo[] = [];
let formItems = ref([]);
let searchFormItems: FormItemInfo[] = [];
let advancedQueryItems= [];
let ids: string;


const offlineLoading = ref(false);
const addFormRef = ref<RkFormInstance>()
const addForm = ref({})
const addDialog = ref(false);
const activeCollapse = ref(['basic', 'body', 'person'])
const buttons: ButtonInfo[] = [
  {
    key: 'offline',
    label: '线下请求单',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: async () => {
      let applicationID = 'OFFLINE' + new Date().getTime();
      let transSerialNumber = 'tsn' + new Date().getTime();
      let trxId = new Date().getTime();
      let txCode = reportCode.value;
      addForm.value = {applicationID, txCode, trxId, transSerialNumber };
      addDialog.value = true;
    }
  },
]

onMounted(async () => {
  page.value = {...pagination}
  getConfigs();
  // @ts-ignore
  const res = await getQuartzList({systemCode:"taf"});
  config.value=res.result.records[0]
  search()
})

const addSave = async () => {
  offlineLoading.value = true;
  try {
    const valid = await addFormRef.value?.asyncValidate();
    if (!valid) {
      return;
    }
    const data = toRaw(addForm.value);
    // delete data.type;
    // @ts-ignore
    if(data.id) {
      await updateOffline(reportCode.value, data);
    }else {
      await saveOffline(reportCode.value, data);
    }
    await search();
    addDialog.value = false;
    ElMessage.success("保存成功");
  } finally {
    offlineLoading.value = false;
  }
};

const upload = async (data = {}) => {
  // if (!data.file.name.toLowerCase().endsWith(".pdf") && !data.file.name.toLowerCase().endsWith(".jpg")) {
  //   ElMessage.error({message:"仅可上传PDF/JPG文件", grouping: true, showClose: true, duration: 0});
  //   return;
  // }
  // @ts-ignore
  const rsPromise = await uploadOfflineAttachment(reportCode.value, addForm.value.applicationID , data);
  ElMessage.success("上传成功");
}

const uploadFile = () =>{
  var elementById = document.getElementById("uploadButton");
  elementById.click();
}


const getConfigs = () => {
  const path = useRoute().path;
  reportCode.value = getRequestClassificationCode();
  // @ts-ignore
  const obj = configs[`config${reportCode.value}`];
  const fkObj = fkConfigs[`config${getFeedbackCode(reportCode.value)}`];
  // @ts-ignore
  const subObj = configs[`config${reportCode.value}Detail`];
  columns = obj['columns'];
  formItems.value = obj['formItems'];
  feedbackItem.value = fkObj['formItems'];
  feedbackItem.value = [
    {prop: 'applicationID', label: '业务申请编号', labelWidth: 150, inputType: 'input', scopedSlot: 'systemCode',}
    ,...feedbackItem.value.filter(item => item.prop!=='transSerialNumber'&&item.prop!=='applicationID')
  ]

  searchFormItems = obj['searchFormItems'];
  advancedQueryItems = obj['advancedQueryItems'];
  if (subObj!=undefined) {
    subColumns = subObj['columns'];
    subFormItems = subObj['formItems'];
  }

}

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}

const search = async () => {
  loadingTable.value = true
  let formData = checkData(searchForm.value);
  let result = await list(reportCode.value, formData, page.value.currentPage, page.value.pageSize);
  let {current, total, records} = result.data;
  tableDate.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loadingTable.value = false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const openFile = (key: string) => {
  // 将base64字符串转换为Uint8Array对象
  console.log(xmlDataList.value[key])
  var data = atob(xmlDataList.value[key]);
  var dataArray = new Uint8Array(data.length);
  for (var i = 0; i < data.length; i++) {
    dataArray[i] = data.charCodeAt(i);
  }
  if (key.toLocaleLowerCase().endsWith('pdf')) {
    // let pdfWindow = window.open("", 'pdf预览');
    let pdfWindow = window.open("");
    // 创建Blob对象
    const pdfBlob = new Blob([dataArray], {type: 'application/pdf'});
    // 将Blob对象转换为URL
    const pdfUrl = URL.createObjectURL(pdfBlob);
    // 将URL作为iframe的src属性值
    pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>");
  }else if (key.toLocaleLowerCase().endsWith('jpg')) {
    // 创建Blob对象
    const jpgBlob = new Blob([dataArray], {type: 'image/jpeg'});
    // 将Blob对象转换为URL
    const jpgUrl = URL.createObjectURL(jpgBlob);
    showImageViewer.value = true;
    urlList.value = [jpgUrl];
  }else if (key.toLocaleLowerCase().endsWith('png')) {
    // 创建Blob对象
    const jpgBlob = new Blob([dataArray], {type: 'image/jpeg'});
    // 将Blob对象转换为URL
    const jpgUrl = URL.createObjectURL(jpgBlob);
    showImageViewer.value = true;
    urlList.value = [jpgUrl];
  }else if (key.toLocaleLowerCase().endsWith('xml')) {
    // 创建Blob对象
    const xmlBlob = new Blob([dataArray], {type: 'text/xml'});
    // 将Blob对象转换为URL
    const xmlUrl = URL.createObjectURL(xmlBlob);
    let xmlWindow = window.open(xmlUrl, 'xml预览')
  }else if (key.toLocaleLowerCase().endsWith('txt')) {
    // 创建Blob对象
    const xmlBlob = new Blob([dataArray], {type: 'txt'});
    // 将Blob对象转换为URL
    const xmlUrl = URL.createObjectURL(xmlBlob);
    let xmlWindow = window.open(xmlUrl, 'txt预览')
  } else {
    ElMessage.error({message:"暂不支持打开此种类型的文件", grouping: true, showClose: true, duration: 0})
  }
};

const openDialog = async (row: any, type: string) => {
  const result = await getById(reportCode.value, {id: row.id});
  if(type == '查看') {
    open(result.data, true, '查看');
  } else {
    addForm.value = result.data;
    addDialog.value = true;
  }
}

const {dialogData, open, close, closed, form, nameRef: dialogFormRef}: DialogForm<RkFormInstance, any>
    = useDialogForm('dialogFormRef', {type: []})

/**
 * 子表所需组件和方法
 * */
const subPage = ref<Pagination>(subPagination)
const subData = ref<any []>([]);
const subTableVisible = ref(false)
let subColumns = [];
let subFormItems = [];
const subLoading = ref(false);
const {
  dialogData:subDialogData, open:subOpen, close:subClose, closed:subClosed, form:subForm,
  nameRef: subDialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('subDialogFormRef', {type: []})


// @ts-ignore 行操作按钮
const genRowButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons =  [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      // @ts-ignore
      handler: () => {openDialog(row, '查看')}
    },
    {
      key: 'assignment', label: '指派', tag: 'button', type: 'primary',
      handler: () => {
        if (row.status=="4"||row.status=="5") {
          ElMessage.warning("该条数据已经生成或上报报文,无法指派机构");
          return
        }
        assignmentDialog.value = true;
        console.log(row)
        assignmentForm.value = {};
        const data = toRaw(assignmentForm.value);
        // @ts-ignore
        data.qqdbs = row.transSerialNumber
        // @ts-ignore
        data.rwlsh = row.applicationID
        assignmentQqdbs.value =row.transSerialNumber
        assignmentRwlsh.value =row.applicationID
        assignmentSearch();
      }
    },
    {
      key: 'view', label: '预览请求附件', tag: 'button', type: 'primary',invisible: getRequestClassificationCode()=='100601' || getRequestClassificationCode()=='100603'|| getRequestClassificationCode()=='100701'|| getRequestClassificationCode()=='100703',
      handler: async () => {
        const result = await getAllFile(reportCode.value, row);
        const keys = Object.keys(result.data);
        xmlButtonKeys.value = keys;
        xmlDataList.value = result.data;
        console.log(keys);
        dialogVisible.value = true;
      }
    }
  ]

  if (row.importType == '3') {
    buttons.splice(1, 0, {
      key: 'edit', label: '编辑', tag: 'button', type: 'primary',
      handler: () => {
        openDialog(row, '编辑')
      }
    });
    buttons.splice(2, 0, {
      key: 'del', label: '删除', tag: 'button', type: 'primary',
      handler: async ()  => {
        try {
          const rsPromise = await delOffline(reportCode.value, row.id);
          ElMessage.success(rsPromise.data);
        }finally {
          search();
        }
      }
    });
  }

  if (row.status==1 || row.status == 6) {
    buttons.splice(1, 0,  {
      key: 'feedback', label: '反馈', tag: 'button', type: 'primary',
      handler: async () => {
        // 线下请求单的只有status = 0的可以新增反馈
        if(row.importType == "3") {
          if (row.status == "3" || row.status == "5") {
            ElMessage.warning("线下请求单已反馈,无法新增反馈");
            return
          }
        } else {
          if (row.status == "4" || row.status == "5") {
            ElMessage.warning("该条数据已经生成或上报报文,无法新增反馈");
            return
          }
        }

        let toRaw1 = toRaw(bodyForm.value);
        for (const key in row) {
          if (row.hasOwnProperty(key)) {
            toRaw1[key] = row[key];
          }
        }

        let data = toRaw(feedbackForm.value);
        // 生成反馈时设置数据为线下请求单
        // if(row.importType == "3") {
        //   // @ts-ignore
        //   data.importType = "3";
        //   // @ts-ignore
        //   data.status = "3";  // 已审核
        // }
        // @ts-ignore
        data.transSerialNumber = row.transSerialNumber
        // @ts-ignore
        data.applicationID = row.applicationID
        // @ts-ignore
        data.updateType = row.updateType
        // @ts-ignore
        data.processMeasure = row.processMeasure
        // data.balance = row.balance
        // @ts-ignore
        data.appliedBalance = row.balance
        // @ts-ignore
        data.caseType = row.caseType
        // @ts-ignore
        data.controlPeriod = row.controlPeriod
        // @ts-ignore
        data.cancelReason = row.cancelReason
        // @ts-ignore
        data.trxId = row.trxId
        // @ts-ignore
        data.feedbackOrgName = config.value.bankOrgName
        // @ts-ignore
        data.feedbackOrgId = config.value.bankOrgCode
        // @ts-ignore
        data.currency = row.currency
        // @ts-ignore
        if (data.branchCode == null){
          // @ts-ignore
          data.branchCode=dictData.branchCode[0].value
        }
        data = copyProperties(data, row, getRequestClassificationCode());
        if (getRequestClassificationCode()=='100203'){
          const result = await listByOriginalApplicationID('100202',row.originalApplicationID)
          if (result.data!=null){
            // @ts-ignore
            data.appliedBalance = result.data.appliedBalance
            // @ts-ignore
            data.unfreezeBalance = result.data.frozedBalance
          }
        }else if (getRequestClassificationCode()=='100205'){
          // taf 冻结延期反馈，申请冻结限额需根据原业务申请编号去冻结反馈表100202中查询，执行冻结金额与币种取100205中的金额与币种
          const result = await listByOriginalApplicationID('100202',row.originalApplicationID)
          if (result.data!=null){
            // @ts-ignore
            data.appliedBalance = result.data.appliedBalance
          }
          // @ts-ignore
          data.frozedBalance = row.balance
          // @ts-ignore
          data.currency = row.currency
        }
        feedbackForm.value = {...feedbackForm.value}
        feedbackDialog.value = true;
      },
    });
  }
  return buttons;
}

// todo 这些buttons在哪里用
const genSubActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'view', label: '查看', tag: 'button', type: 'primary',
    handler: () => {
      subOpen(row,"查看")
    }
  },
  {
    key: 'feedback', label: '反馈', tag: 'button', type: 'primary',
    handler: async () => {
      if (mainTableStatus.value == "4" || mainTableStatus.value == "5") {
        ElMessage.warning("该条数据已经生成或上报报文,无法新增反馈");
        return
      }
      let toRaw1 = toRaw(subBodyForm.value);
      for (const key in row) {
        if (row.hasOwnProperty(key)) {
          toRaw1[key] = row[key];
        }
      }


      let data = toRaw(feedbackForm.value);
      // @ts-ignore
      data.transSerialNumber = row.transSerialNumber
      // @ts-ignore
      data.applicationID = row.applicationID
      data = copyProperties(data, row, getRequestClassificationCode());

      feedbackDialog.value = true;
    },
  }
]

const subSearch = async (applicationID:string) => {
  subLoading.value = true;
  try {
    let data = {applicationID:applicationID}
    let result = await list(`${reportCode.value}Detail`,data, subPage.value.currentPage, subPage.value.pageSize);
    console.log("子查询返回值")
    let {current, total, records} = result.data;
    subData.value = records;
    subPage.value.currentPage = current;
    subPage.value.total = total;
  }finally {
    subLoading.value = false;
  }
}
const subPageChange = (p: Pagination) => {
  subPage.value = p
  subSearch(applicationID.value)
}
const openSubTable = (applicationId:string,status:string) => {
  applicationID.value = applicationId;
  subTableVisible.value = true
  mainTableStatus.value = status
  subPageChange(subPagination);
};

/**
 * 反馈弹出框所需组件
 * */
const mainTableStatus = ref('');
const feedbackItem = ref([]);
const feedbackDialog = ref(false);
const feedbackForm =ref({})
const feedbackFormRef = ref<RkFormInstance>()
const bodyForm =ref({})
const bodyFormRef = ref<RkFormInstance>()
const subBodyForm =ref({})
const subBodyFormRef = ref<RkFormInstance>()

function getFeedbackCode(reportCode:string) {
  switch (reportCode){
    case '100101':
      return '100102'
    case '100103':
      return '100104'
    case '100105':
      return '100106'
    case '100201':
      return '100202'
    case '100203':
      return '100204'
    case '100205':
      return '100206'
    case '100301':
      return '100302'
    case '100303':
      return '100304'
    case '100305':
      return '100306'
    case '100307':
      return '100308'
    case '100309':
      return '100310'
    case '100601':
      return '100602'
    case '100603':
      return '100604'
    case '100701':
      return '100702'
    case '100703':
      return '100704'
    case '100713':
      return '100714'


  }
}

function clearFeedbackForm() {
  feedbackForm.value = {};
  bodyForm.value = {};
  subBodyForm.value = {};
  feedbackFormRef.value?.resetFields()
  bodyFormRef.value?.resetFields()
  subBodyFormRef.value?.resetFields()
}

/**
 * 保存反馈信息
 */
const saveFeedback = async () => {
  const valid = await feedbackFormRef.value?.asyncValidate();
  const data = toRaw(feedbackForm.value);
  const specialChecksReturn = specialChecks(data, getSubSystem(), getFeedbackCode(getRequestClassificationCode()));
  const resultList = reportCode.value=="100713"?['01','03']:['00','12','14','24']
  // @ts-ignore
  if (specialChecksReturn.clear || !resultList.includes(data.result.substring(0,2))) {
    await feedbackFormRef.value?.clearValidate();
  }
  // 返回值 true是允许保存 , false是不允许保存
  if (!specialChecksReturn.result) {
    ElMessage.error({message:specialChecksReturn.msg, grouping: true, showClose: true, duration: 0});
    return;
  }
  //校验是否存在特殊字符
  if (checkSpecialCharacters(data)) {
    await feedbackFormRef.value?.asyncValidate();
    ElMessage.error({message:"存在特殊字符", grouping: true, showClose: true, duration: 0});
    return;
  }
  // @ts-ignore
  // if (dictData.departmentCodeRequired!=undefined && data.departmentCode==null){
  //   ElMessage.error({message:"部门字段必填！", grouping: true, showClose: true, duration: 0});
  //   return;
  // }
  //校验必填项(仅当特殊校验通过时才进行)
  // @ts-ignore
  if (!valid && specialChecksReturn.continueToVerify && !(reportCode.value == '100603' && data.caseType == '1002') && resultList.includes(data.result.substring(0,2))) {
    await feedbackFormRef.value?.asyncValidate();
    ElMessage.error({message: "存在必填项未填", grouping: true, showClose: true, duration: 0});
    return;
  }
  // @ts-ignore
  if (resultList.includes(data.result.substring(0,2)) && reportCode.value == '100603' && data.caseType == '1002'){
    ElMessage.error({message:"案件类型为受害人账户,反馈结果必填", grouping: true, showClose: true, duration: 0});
    return
  }
  // @ts-ignore
  const accountType = data.accountType;
  const reportCodeList = ['100101','100103','100105','100201','100203','100205']
  // @ts-ignore
  if (resultList.includes(data.result.substring(0,2)) && accountType=="01"&&reportCodeList.includes(reportCode.value)) {
    // @ts-ignore
    const cardNumber = data.cardNumber;
    if (cardNumber==undefined||cardNumber=='') {
      ElMessage.error({message:"账号类别为个人时,卡/折号必填", grouping: true, showClose: true, duration: 0});
      return
    }
  }
  // 生成714反馈
  // 业务类型为01，开户机构标识、开户机构名称、处置方式、管控账户余额、币种为必填，
  // 业务类型为02，这些字段非必填，请按照规范进行校验，若为01则必填，02则非必填
  // @ts-ignore
  // if ( resultList.includes(data.result.substring(0,2)) && data.updateType=="01" && reportCode.value=='100713'){
    // @ts-ignore
    // if (data.caseType==undefined||data.caseType=='') {
    //   ElMessage.error({message:"业务类型为管控时,案件类型必填", grouping: true, showClose: true, duration: 0});
    //   return
    // }
    // @ts-ignore
    // if (data.processMeasure==undefined||data.processMeasure=='') {
    //   ElMessage.error({message:"业务类型为管控时,处置方式必填", grouping: true, showClose: true, duration: 0});
    //   return
    // }
    // // @ts-ignore
    // if (data.opnInsId==undefined||data.opnInsId=='') {
    //   ElMessage.error({message:"业务类型为管控时,开户机构标识必填", grouping: true, showClose: true, duration: 0});
    //   return
    // }
    // // @ts-ignore
    // if (data.opnInsNm==undefined||data.opnInsNm=='') {
    //   ElMessage.error({message:"业务类型为管控时,开户机构名称必填", grouping: true, showClose: true, duration: 0});
    //   return
    // }
    // @ts-ignore
  //   if (data.controlPeriod==undefined||data.controlPeriod=='') {
  //     ElMessage.error({message:"业务类型为管控时,管控期限必填", grouping: true, showClose: true, duration: 0});
  //     return
  //   }
  //   // @ts-ignore
  //   if (data.balance == undefined || data.balance == '') {
  //     ElMessage.error({message:"业务类型为管控时, 管控账户余额必填", grouping: true, showClose: true, duration: 0});
  //     return
  //   }
  //   // @ts-ignore
  //   if (data.currency==undefined||data.currency=='') {
  //     ElMessage.error({message:"业务类型为管控时,币种必填", grouping: true, showClose: true, duration: 0});
  //     return
  //   }
  // }
  // // @ts-ignore
  // if (resultList.includes(data.result.substring(0,2)) && data.updateType=="02" && reportCode.value=='100713'){
  //   // @ts-ignore
  //   if (data.cancelReason==undefined||data.cancelReason=='') {
  //     ElMessage.error({message:"业务类型为撤销管控时,撤销管控原因必填", grouping: true, showClose: true, duration: 0});
  //     return
  //   }
  // }

  // @ts-ignore
  data.status = '1';
  // @ts-ignore
  data.deleted = '0'
  console.log(data)
  await updateRequestStatus(getRequestClassificationCode(),data);
  await saveData(getFeedbackCode(getRequestClassificationCode()),data,true);
  await search();
  feedbackDialog.value = false;
  ElMessage.success("保存成功");
}

//主表导出
const exp = async () => {
  expLoading.value = true;
  try {
    if (ids==undefined||ids.length == 0) {
      ids=''
    }
    const newObject = {...searchForm.value};
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null;
        console.log("转化了空串")
      }
    }
    await exportExcel(ids,reportCode.value,newObject);
  }finally {
    expLoading.value = false;
  }
}

/**
 * 西班牙桑坦德银行需求,
 * 反馈表单涉及经办人姓名、经办人电话信息，在新增补录时如果该字段为空抓取该用户登录的oauth中对应的信息。
 * 额外要求：添加开关控制该功能
 */
watch(() => feedbackDialog.value, async (val) => {
  if(dictData.OperatorRef != undefined && feedbackDialog.value) {
    const result = await getUserInfo();
    const loginUserInfo = result.data;
    if(isEmpty(feedbackForm.value.operatorName)) {
      feedbackForm.value.operatorName = loginUserInfo.username;
    }
    if(isEmpty(feedbackForm.value.operatorPhoneNumber)) {
      feedbackForm.value.operatorPhoneNumber = loginUserInfo.phoneNumber;
    }
  }
})

/**
 * 新增线下请求单的表单必填项
 */
watch(() => [addForm.value, addDialog.value], (newForm, oldForm) => {
  let fields = [];

  if ('100713' == reportCode.value) {

    const updateType = newForm[0].updateType;

    // 监听updateType, 值为01-管控，开户机构标识、开户机构名称、处置方式、管控账户余额、币种为必填；02时非必填
    fields = ['controlPeriod', 'caseType', 'balance', 'currency'];
    setRequiredRule(fields, updateType == "01", formItems.value);

    // 监听updateType, 值为01-管控，撤销原因非必填；02必填
    fields = ['cancelReason'];
    setRequiredRule(fields, updateType == "02", formItems.value);

    formItems.value = [...formItems.value]
  }
}, {deep: true})

/**
 * 100604 监听caseType, 值为1002-受害人账户，100604，反馈报文100604中result“反馈结果”以下的反馈内容无需反馈，详见100604
 * 将原必填字段设置为非必填
 *
 * 100714 监听updateType, 值为01-管控，开户机构标识、开户机构名称、处置方式、管控账户余额、币种为必填；02时非必填
 */
watch(() => [feedbackForm.value, feedbackDialog.value], (newForm, oldForm) => {
  let fields = [];
  // @ts-ignore
  const caseType = newForm[0].caseType;
  // @ts-ignore
  if (getFeedbackCode(reportCode.value) === '100604') {
    fields = ['feedbackOrgName', 'feedbackOrgId', 'accountSubjectName', 'accountNumber', 'accountStatus', 'verificationControl', 'measure', 'controlDate', 'query', 'freeze', 'stopPayment', 'batchNo']
    const items = feedbackItem.value.filter(item => fields.includes(item.prop));
    const rules = items.map(item => item.rules.find(item => item.required != undefined));
    rules.map(rule => rule.required = (caseType == "1002" ? false : true))
    feedbackItem.value = [...feedbackItem.value]
  }

  // @ts-ignore
  const updateType = newForm[0].updateType;
  // @ts-ignore
  if (getFeedbackCode(reportCode.value) === '100714') {
    fields = ['opnInsId', 'opnInsNm', 'processMeasure', 'balance', 'currency'];
    const items = feedbackItem.value.filter(item => fields.includes(item.prop));
    const rules = items.map(item => item.rules.find(item => item.required != undefined));
    rules.map(rule => rule.required = (updateType == "02" ? false : true))
    feedbackItem.value = [...feedbackItem.value]
  }
  // console.log(dictData);
  // 未启用部门编码，编辑页面隐藏
  if (dictData.departmentCodeRequired == undefined){
    feedbackItem.value = feedbackItem.value.filter(item => "departmentCode" != item.prop);
    feedbackItem.value = [...feedbackItem.value]
  }
}, {deep: true})


</script>

<style scoped>

</style>
