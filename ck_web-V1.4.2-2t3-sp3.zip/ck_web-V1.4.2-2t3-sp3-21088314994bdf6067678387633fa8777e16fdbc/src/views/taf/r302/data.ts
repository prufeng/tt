import {FormItemInfo, TableColumnInfo} from "riking-ui";
import { dateFormatter } from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'trxId', label: '流水号', width: 140, sortable: true},
    {prop: 'prcSts', label: '处理状态', dictFormatKey: 'taf_A14', width: 140, sortable: true},
    {prop: 'instgId', label: '发起参与者', width: 140, sortable: true},
    {prop: 'instdId', label: '接收参与者', width: 140, sortable: true},
    {prop: 'dataTrTp', label: '数据用途类型', dictFormatKey: 'taf_A15', width: 140, sortable: true},
    {prop: 'dataTp', label: '数据格式类型', dictFormatKey: 'taf_A16', width: 140, sortable: true},
    {prop: 'dataContt', label: '数据内容', width: 140, sortable: true},
    {prop: 'ustrd', label: '描述', width: 140, sortable: true},
    {prop: 'reportOwer', label: '报文发送方', dictFormatKey: 'taf_reportOwer', width: 140, sortable: true},
    {prop: 'sysRtnCd', label: '系统返回码', width: 140, sortable: true},
    {prop: 'sysRtnDesc', label: '系统返回说明', width: 140, sortable: true},
    {prop: 'sysRtnTm', label: '系统返回时间', width: 140, sortable: true},
    {prop: 'bizStsCd', label: '业务返回码', width: 140, sortable: true},
    {prop: 'bizStsDesc', label: '业务返回说明', width: 140, sortable: true},

    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'TrxId', label: '流水号', labelWidth: 80, },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 80,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    }
]

export const formItems: FormItemInfo[] = [

    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {max: 31, message: '超过31字符限制'}]
    },
    {
        prop: 'prcSts',
        label: '处理状态',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'taf_A14'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}]
    },
    {
        prop: 'instgId',
        label: '发起参与者',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {max: 14, message: '超过14字符限制'}]
    },
    {
        prop: 'instdId',
        label: '接收参与者',
        labelWidth: 150,
        inputType:'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 14, message: '超过14字符限制'}]
    },
    {
        prop: 'dataTrTp',
        label: '数据用途类型',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'taf_A15'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}]
    },
    {
        prop: 'dataTp',
        label: '数据格式类型',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'taf_A16'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}]
    },
    {
        prop: 'dataContt',
        label: '数据内容',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}]
    },
    {
        prop: 'ustrd',
        label: '描述',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {max: 256, message: '超过256字符限制'}]
    },
    {
        prop: 'sysRtnCd',
        label: '系统返回码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {max: 256, message: '超过256字符限制'}]
    },
    {
        prop: 'sysRtnTm',
        label: '系统返回时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {max: 256, message: '超过256字符限制'}]
    },
    {
        prop: 'sysRtnDesc',
        label: '系统返回说明',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {max: 256, message: '超过256字符限制'}]
    },
    {
        prop: 'bizStsCd',
        label: '业务返回码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {max: 256, message: '超过256字符限制'}]
    },
    {
        prop: 'bizStsDesc',
        label: '业务返回说明',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {max: 256, message: '超过256字符限制'}]
    },
]

export const advancedQueryItems = [
    // {value: 'TrxId', label: '流水号', labelWidth: 80, },
    {value: 'reportOwer', label: '报文发送方', labelWidth: 80, inputType:  {tag: 'select', options: 'taf_reportOwer',}},
    {value: 'prcSts', label: '处理状态', labelWidth: 80 , inputType:  {tag: 'select', options: 'taf_A14',}},
    {value: 'instgId', label: '发起参与者', labelWidth: 80},
    {value: 'instdId', label: '接收参与者', labelWidth: 80},
    {value: 'dataTrTp', label: '数据用途类型', labelWidth: 80 , inputType:  {tag: 'select', options: 'taf_A15',}},
    {value: 'dataTp', label: '数据格式类型', labelWidth: 80 , inputType:  {tag: 'select', options: 'taf_A16',}},
    {value: 'dataContt', label: '数据内容', labelWidth: 80, },
]
export default {
    columns,
    searchFormItems,
}
