<template>
  <rk-index-layout>
    <!--    <rk-search-form v-model="form" :form-items="searchFormItems" :label-width="50" @search="search"></rk-search-form>-->
    <rk-dynamic-search-form v-model="searchForm" :form-items="searchFormItems" :fields="advancedQueryItems"
                            @search="search" ></rk-dynamic-search-form>

    <rk-page-table ref="tableRef" :data="data" @refresh="search" @page-change="pageChange"
                   :columns="columns" :loading="loading" :pagination="paging" @selection-change="handleSelectionChange">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group
              :buttons="getMainTableButtons()"
              :route-meta="$route.meta"
              :max="9"
          />
        </div>
        <div style="margin: 0 4px;"></div>
        <UpAndDown  :exp="exp"/>
      </template>
      <template #status="{ row }">
        <el-popover
            v-if="row.status === '6'"
            placement="bottom"
            title="审核不通过原因"
            :width="250"
            trigger="hover"
        >
          <p class="tipck">操作: 审核不通过</p>
          <p class="tipck">操作人: {{row.approveBy}}</p>
          <p class="tipck">操作时间: {{row.approveTime}}</p>
          <p class="tipck">备注: {{row.approveDesc}}</p>
          <template #reference>
            <el-button  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
          </template>
        </el-popover>
        <el-popover
            v-else-if="row.status === '0'&&(row.resetBy!==null&&row.resetBy!=='')"
            placement="bottom"
            title="重置原因"
            :width="250"
            trigger="hover"
        >
          <p class="tipck">操作: 重置</p>
          <p class="tipck">操作人: {{row.resetBy}}</p>
          <p class="tipck">操作时间: {{row.resetTime}}</p>
          <p class="tipck">备注: {{row.resetDesc}}</p>
          <template #reference>
            <el-button  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
          </template>
        </el-popover>
        <el-button v-else  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
      </template>
      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta"
                         :max="9" link/>
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!--新增/查看/编辑表单-->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed">
    <rk-detail-form ref="dialogFormRef" v-model="form" :form-items="formItems" :disabled="dialogData.formDisabled" />

    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" v-if="dialogData.title.includes('编辑') || dialogData.title.includes('新增')"
                   :loading="buttonLoading" @click="save(null)">保存</el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 批量提交/审核结果弹窗 -->
  <el-dialog v-model="submitAllVisible" title="提示" :close-on-click-modal=false :destroy-on-close=true :append-to-body=true>
    <el-collapse v-model="activeNames">
      <el-collapse-item name="1">
        <template #title>
          <div class="message-text">{{submitOrAudit}} 成功 <span  style="margin:0 5px;color:#67c23a;">{{successNum}}</span> 条数据, 失败 <span style="margin:0 5px;color:#f56c6c;">{{failNum}}</span> 条数据 </div>
        </template>
        <div   style="box-sizing:border-box;"  >{{returnMassage}}</div>
      </el-collapse-item>
    </el-collapse>
  </el-dialog>

  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="审核" width="30%" draggable :append-to-body=true>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids)">审核通过</el-button>
        <el-button type="danger" @click="() => { msgDialog = true; msg = '' }">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog" title="不通过原因" width="30%" draggable :append-to-body=true>
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="auditNotPass(ids)">提交</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 指派机构表格弹出框 -->
  <el-dialog title="指派" v-model="assignmentDialog" width="70%">

    <rk-page-table ref="assignmentTable" :loading="assignmentLoading" :data="assignmentData" :columns="assignmentColumns"
                   border="true" @selection-change="assignmentIdsHandleSelectionChange" @refresh="assignmentSearch">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <!-- 此处按钮无需做权限配置 即:route-meta="[]"即可-->
          <rk-button-group :buttons="assignmentButtons" :route-meta="[]"></rk-button-group>
        </div>
      </template>
    </rk-page-table>
  </el-dialog>
  <!-- 指派机构form弹出框 -->
  <el-dialog title="新增指派" v-model="assignmentFormDialog" width="70%" @closed="() => { assignmentFormRef.resetFields() }">
    <rk-detail-form ref="assignmentFormRef" v-model="assignmentForm" :form-items="[
      {
        prop: 'rwlsh',
        label: '流水号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      }, {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
          tag: 'tree-select',
          options: 'branchCode',
          showCheckbox: true,
          checkStrictly: true,
        },
        rules: [{required: true, message: '业务操作机构不能为空'}],
      },
    ]">
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled=true filterable style="width: 100%">
        </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="assignmentSave">保存</el-button>
        <el-button @click="assignmentFormDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import {onMounted, ref} from "vue";
import {
  ButtonInfo,
  DialogForm,
  dictFormatter,
  Pagination,
  RkButtonGroup, RkFormInstance,
  useDialogForm
} from "riking-ui";
import {pagination} from "@/utils/utils";
import {add, delBatch, list, submitBatch, submitAllBatch, update, recallBatch, resetBatch,auditAllBatch, auditNotPassAllBatch
  ,auditBatch, auditNotPassBatch, handleUploadBatch,exportExcel} from './api';
import dictData from '../../../hooks/useDicts'
import {useDict} from "riking-layout";
import {columns, searchFormItems,advancedQueryItems,formItems} from "@/views/taf/r302/data";
import {Action, ElMessage} from "element-plus";
import {
  assignmentDialog,
  assignmentLoading,
  assignmentData,
  assignmentColumns,
  // assignmentPage,
  // assignmentPageChange,
  assignmentSearch,
  assignmentButtons,
  assignmentQqdbs,
  assignmentRwlsh,
  assignmentIdsHandleSelectionChange,
  assignmentSave,
  assignmentFormDialog,
  assignmentFormRef,
  assignmentForm
} from '@/utils/assignment'
import {listBusinessLine} from "@/views/query/feedback/api";
import useDictsStore from "@/store/dictStore";
import {getRequestClassificationCode} from "@/utils/subSystem";
import {derivedPageElements} from "@/views/zgfy/feedback/page";
import {expLoading, impLoading} from "@/components/UpAndDown.vue";

const buttonLoading = ref(false);
const dictsStore = useDictsStore();
const data = ref<any []>([]);
// const form = ref({})
const tableRef = ref()
const paging = ref<Pagination>(pagination)
const loading = ref(false)
const {dialogData, open, close, closed, form,nameRef: dialogFormRef}: DialogForm<RkFormInstance, any>
    = useDialogForm('dialogFormRef')
const searchForm = ref({});
useDict([], [], {
  ...dictData,
  branchCode: async () => {
    const res = await dictsStore.loadDict()
    return res.data.branchCode
  },
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data;
  },
})

onMounted(() => {
  getBusinessLine();
})

watch(paging, () => search())

// 分页事件
const pageChange = (p: Pagination) => {
  paging.value = p
}

/**
 * 查询
 */
const search = async () => {
  loading.value = true;
  try {
    console.log(searchForm.value);
    const result = await list(searchForm.value, paging.value);
    const {records, current, total} = result.data;
    data.value = records;
    paging.value.currentPage = current;
    paging.value.total = total;
  } finally {
    loading.value = false;
  }
}

// 获取checkBox 的ids
let ids: string;
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}

/**
 * 主表按钮
 */
//主表按钮组件
const getMainTableButtons:()=> ButtonInfo[] = () => {
  const buttons = [
    // {
    //   key: 'save',
    //   label: '新增',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_add',
    //   handler: () => {
    //     open(null, false, "新增")
    //   }
    // },
    // {
    //   key: 'submit',
    //   label: '提交',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_submit',
    //   handler: () => {
    //     if (ids == undefined || ids.length == 0) {
    //       submitAll();
    //       return
    //     }
    //     submit(ids);
    //   }
    // },
    // {
    //   key: 'audit',
    //   label: '审核',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_check',
    //   handler: () => {
    //     if (ids == undefined || ids.length == 0) {
    //       auditAll();
    //       return
    //     }
    //     auditDialog.value = true;
    //   },
    // },
    // {
    //   key: 'recall',
    //   label: '撤回',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_recall',
    //   handler: () => recall(ids),
    // },
    // {
    //   key: 'reset',
    //   label: '重置',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_reset',
    //   handler: () => reset(ids),
    // },
    // {
    //   key: 'delete',
    //   label: '删除',
    //   tag: 'button',
    //   type: 'danger',
    //   icon: 'icon_delete',
    //   handler: () => del(ids),
    // },
    // {
    //   key: 'upload',
    //   label: '上报',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_add',
    //   handler: () => handleUpload(ids),
    // },
  ]
  return buttons;
}

//主表右侧操作栏按钮组件
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => {
        open(row, true,  '查看');
      }
    },
  ]
  // if ((row.status<2||row.status==6)&&row.reportOwer!="2") {
  //   buttons.splice(1, 0, {
  //     key: 'edit', label: '编辑', tag: 'button', type: 'primary',
  //     handler: () => {
  //       open(row, false,  '编辑');
  //     }
  //   });
  // }
  buttons.splice(2, 0, {
    key: 'assign', label: '指派', tag: 'button', type: 'primary',
    handler: () => {
      if (row.status == "4" || row.status == "5") {
        ElMessage.warning("该条数据已经审核或上报报文,无法指派机构");
        return
      }
      assignmentDialog.value = true;
      assignmentForm.value = {};
      const data = toRaw(assignmentForm.value);

      data.rwlsh = row.trxId
      data.qqdbs = "302_" + row.trxId;
      assignmentRwlsh.value = row.trxId
      assignmentQqdbs.value = "302_" + row.trxId;
      assignmentSearch();
    }
  });
  return buttons
}

//主表批量删除方法
const del = async (ids: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    const rs = await delBatch(ids);
    ElMessage.success(rs.data);
  }finally {
    await search();
  }
}

const getTagColor = (status:string) => {
  if (status=='6') {
    return 'danger'
  } else {
    return 'primary';
  }
}

const save = async (data: any) => {
  const valid = await dialogFormRef.value?.asyncValidate();
  if (!valid) {
    return;
  }
  buttonLoading.value = true;
  try {
    data = toRaw(form.value);
    if (data.id == undefined) {
      await add(data);
    } else {
      await update(data);
    }
    ElMessage.success("保存成功");
    await search()
    close();
  } finally {
    buttonLoading.value = false
  }
}

//  提交和批量提交组件
const submitAllVisible = ref(false);
const successNum = ref(0);
const failNum = ref(0);
const returnMassage = ref('');
const submitOrAudit = ref('');
const submitAll = async () => {
  ElMessageBox.confirm(
      '是否批量提交所有待提交/待补录数据?',
      '警告',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
  )
      .then(async () => {
        const newObject = {...searchForm.value};
        for (const key in newObject) {
          if (newObject[key] === '') {
            newObject[key] = null;
            console.log("转化了空串")
          }
        }
        const rs = await submitAllBatch(newObject);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '提交'
        submitAllVisible.value = true;
        await search()
      })
      .catch(() => {
        return
      })
}
const submit = async (ids: string) => {
  try {
    const rs = await submitBatch(ids);
    ElMessage.success(rs.data);
  }finally {
    await search();
  }
}
//审核与批量审核与审核不通过组件
const auditDialog = ref(false);
const msgDialog = ref(false);
const msg = ref("")
const audit = async (ids: any) => {
  try {
    const rs = await auditBatch(ids);
    ElMessage.success(rs.data);
    close()
  }finally {
    auditDialog.value = false;
    await search();
  }
}
const auditNotPass = async (ids: any) => {
  try {
    const rs = await auditNotPassBatch(ids, msg.value);
    ElMessage.success(rs.data);
    close()
  }finally {
    msgDialog.value = false;
    auditDialog.value = false;
    await search();
  }

}

const auditAll = async () => {
  ElMessageBox.confirm(
      '是否批量审核所有待审核数据?',
      '警告',
      {
        confirmButtonText: '审核通过',
        cancelButtonText: '审核不通过',
        type: 'warning',
        distinguishCancelAndClose: true,
        confirmButtonClass:'auditButton',
        cancelButtonClass:'auditNotPassButton',
      }
  )
      .then(async () => {
        const newObject = {...searchForm.value};
        for (const key in newObject) {
          if (newObject[key] === '') {
            newObject[key] = null;
            console.log("转化了空串")
          }
        }
        const rs = await auditAllBatch(newObject);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '审核'
        submitAllVisible.value = true;
        await search()
      })
      .catch((action: Action) => {
        if (action === 'cancel') {
          ElMessageBox.prompt( '审核不通过理由','提示',{confirmButtonText: '确定',cancelButtonText: '取消',inputType:'textarea'})
              .then(async ({ value }) => {
                const newObject = {...searchForm.value};
                for (const key in newObject) {
                  if (newObject[key] === '') {
                    newObject[key] = null;
                    console.log("转化了空串")
                  }
                }
                if (value == undefined) {
                  value = "";
                }
                const rs = await auditNotPassAllBatch(newObject, value);
                successNum.value = rs.data.successNum;
                failNum.value = rs.data.failNum;
                returnMassage.value = rs.data.returnMassage;
                submitOrAudit.value = '审核不通过'
                submitAllVisible.value = true;
                await search()
              })
              .catch(() => {
                return;
              })
        }
      })
}

//撤回
const recall = async (ids: string) => {
  if (ids==undefined){
    ElMessage.error("请先选择数据");
    return
  }
  try {
    const rs = await recallBatch(ids);
    ElMessage.success(rs.data);
  }finally {
    await search();
  }
}

//上报
const handleUpload = async (ids: string) => {
  if (ids==undefined){
    ElMessage.error("请先选择数据");
    return
  }
  try {
    const rs = await handleUploadBatch(ids);
    ElMessage.success(rs.data);
  }finally {
    await search();
  }
}

//重置
const reset = async (ids: string) => {
  if (ids==undefined){
    ElMessage.error("请先选择数据");
    return
  }
  ElMessageBox.prompt('重置原因', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
      .then(async ({value}) => {
        try {
          if (value == undefined) {
            value = "";
          }
          const rs = await resetBatch(ids,value);
          ElMessage.success(rs.data);
        }finally {
          await search();
        }
      })
      .catch(() => {
        return;
      })
}

//指派

async function getBusinessLine() {
  try {
    const res = await listBusinessLine();
    const data1 = res.data;

    if (data1.length === 0) {
      ElMessage.error({message:"用户未配置业务线,无法查询数据", grouping: true, showClose: true, duration: 0});
      searchForm.value.businessLine = '';
    } else {
      searchForm.value.businessLine = data1[0].value;
    }
  } catch (error) {
    console.error('Error fetching business line:', error);
  }finally {
    search();
  }
}

//主表导出
const exp = async () => {
  expLoading.value = true;
  try {
    if (ids==undefined||ids.length == 0) {
      ids=''
    }
    const newObject = {...searchForm.value};
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null;
        console.log("转化了空串")
      }
    }
    await exportExcel(ids,newObject);
  }finally {
    expLoading.value = false;
  }
}
</script>


