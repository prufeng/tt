import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'applicationId',
        label: '业务申请编号/任务流水号',
        width: 120
    },
    {
        prop: 'ssxt',
        label: '所属系统',
        width: 120
    },
    {
        prop: 'ywlx',
        label: '业务类型',
        width: 120
    },
    {
        prop: 'bgkzhzh',
        label: '账号',
        width: 300,
    },
    {
        prop: 'bgkzhmc',
        label: '账户名称',
        width: 120,
    },
    {
        prop: 'gkfs',
        label: '管控方式',
        width: 170
    },
    {
        prop: 'qd',
        label: '渠道',
        width: 170
    },
    {
        prop: 'sfsbhkh',
        label: '是否是本行客户',
        width: 170
    },
    {
        prop: 'fkjg',
        label: '反馈结果',
        width: 170,
    },
    {
        prop: 'ywrq',
        label: '业务日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'branchCode',
        label: '分行编号',
        width: 300,
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        formatter: dateFormatter
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'applicationId',
        label: '业务申请编号/任务流水号',
        labelWidth: 100,
    },
    {
        prop: 'sfsbhkh',
        label: '是否是本行客户',
        labelWidth: 100,
    },
    {
        prop: 'ssxt',
        label: '所属系统',
        labelWidth: 100,
    }
]



export const formItems: FormItemInfo[] = [
    {
        prop: 'applicationId',
        label: '业务申请编号/任务流水号',
        labelWidth: 120,
    },
    {
        prop: 'ywlx',
        label: '业务类型',
        labelWidth: 120
    },
    {
        prop: 'ssxt',
        label: '所属系统',
        labelWidth: 120
    },
    {
        prop: 'bgkzhzh',
        label: '账号',
        labelWidth: 120,
    },
    {
        prop: 'bgkzhmc',
        label: '账户名称',
        labelWidth: 120,
    },
    {
        prop: 'gkfs',
        label: '管控方式',
        labelWidth: 120
    },
    {
        prop: 'qd',
        label: '渠道',
        labelWidth: 120
    },
    {
        prop: 'sfsbhkh',
        label: '是否是本行客户',
        labelWidth: 120
    },
    {
        prop: 'fkjg',
        label: '反馈结果',
        labelWidth: 120,
    },
    {
        prop: 'ywrq',
        label: '业务日期',
        labelWidth: 120
    },
    {
        prop: 'createBy',
        label: '创建人',
        labelWidth: 120
    },
    {
        prop: 'branchCode',
        label: '分行编号',
        labelWidth: 120,
    },
    {
        prop: 'createTime',
        label: '创建时间',
        labelWidth: 120
    }
]

export const advancedQueryItems = [
    { value: 'applicationId', label: '业务申请编号/任务流水号', inputType: 'input' },
    { value: 'ssxt', label: '所属系统', inputType: {tag: 'select', options: 'zhangHuaSsxt'}},
    { value: 'ywlx', label: '业务类型', inputType: {tag: 'select', options: 'zhangHuaYwlx'}},
    { value: 'bgkzhzh', label: '账号', inputType: 'input' },
    { value: 'bgkzhmc', label: '账户名称', inputType: 'input' },
    { value: 'gkfs', label: '管控方式', inputType: {tag: 'select', options: 'zhangHuaGkfs'}},
    { value: 'qd', label: '渠道', inputType: {tag: 'select', options: 'zhangHuaQd'}},
    { value: 'sfsbhkh', label: '是否是本行客户', inputType: {tag: 'select', options: 'zhangHuaSfbhkh'}},
    { value: 'fkjg', label: '反馈结果', inputType: {tag: 'select', options: 'zhangHuaFkjg'}},
    { value: 'ywrq', label: '业务日期', inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'}},
    { value: 'branchCode', label: '分行编号', inputType: 'input'},
]