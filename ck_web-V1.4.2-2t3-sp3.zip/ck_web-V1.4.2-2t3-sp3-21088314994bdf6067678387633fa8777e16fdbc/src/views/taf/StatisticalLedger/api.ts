import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/StatisticalLedger/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

export function getById(params = {}): Promise<RS> {
    return service({
        url: `/StatisticalLedger/getById`,
        method: 'GET',
        params,
    })
}
