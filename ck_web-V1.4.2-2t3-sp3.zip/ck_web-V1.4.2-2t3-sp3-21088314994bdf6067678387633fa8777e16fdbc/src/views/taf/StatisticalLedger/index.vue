<template>
  <!--  <div class="app-container">-->
  <rk-index-layout>
<!--    <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"-->
<!--                    :form-items="searchFormItems" @search="search" :label-width="50"/>-->
    <rk-dynamic-search-form v-if="delaySearchFormRender" v-model="searchForm" :form-items="searchFormItems" :fields="advancedQueryItems"
                            @search="search" :advanced="advanced">
    </rk-dynamic-search-form>

    <rk-page-table :columns="columns" :loading="loadingTable" :data="data" :pagination="page" @page-change="pageChange"
                   @refresh="search"
                   @selection-change="handleSelectionChange">

      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="getMainTableButtons()" :route-meta="$route.meta" max="8"/>
          <UpAndDown :exp="exp"/>
        </div>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link max="3"/>
      </template>

      <template #status="{ row }">
        <el-popover
            v-if="row.status === '6'"
            placement="bottom"
            title="审核不通过原因"
            :width="250"
            trigger="hover"
        >
          <p class="tipck">操作: 审核不通过</p>
          <p class="tipck">操作人: {{row.approveBy}}</p>
          <p class="tipck">操作时间: {{row.approveTime}}</p>
          <p class="tipck">备注: {{row.approveDesc}}</p>
          <template #reference>
            <el-button  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
          </template>
        </el-popover>
        <el-button v-else  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed"
             :close-on-click-modal="false">
    <rk-detail-form ref="dialogFormRef" v-model="form" :disabled="dialogData.formDisabled" :form-items="formItems"/>

    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 主表确认弹窗 -->
  <el-dialog v-model="auditDialog" title="提示" width="30%" draggable :append-to-body=true>
    <span>所选数据中存在未到期的管控数据,是否全部设为已确认解控?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="checkTure()">确认</el-button>
        <el-button type="danger" @click="()=>{auditDialog = false}">
          取消
        </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElMessage} from 'element-plus'
import {
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, dictFormatter,
} from 'riking-ui'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'
import {useDict} from 'riking-layout'
import {checkData, pagination} from "@/utils/utils";
import {columns, searchFormItems, formItems,advancedQueryItems} from './data';
import {
  list,
  getById
} from "./api";
import useRouteParamsStore from "@/store/routeParamsStore";
import {listBusinessLine} from "@/views/query/feedback/api";

const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const auditDialog = ref(false);
const msgDialog = ref(false);
const msg = ref("");
// 渲染后更新新advance为true, 高级查询不会展开，可能是封装的组件没监听，做法是延迟高级查询表单的渲染，在确定advance值后再渲染
const delaySearchFormRender = ref(true)
const advanced = ref(false)
let ids: string;

useDict([], [], dictData)
const store = useRouteParamsStore();
onMounted(() => {
  page.value = {...pagination}
  delaySearchFormRender.value = false;
  const params = store.getParams();
  if(Object.keys(params).length) {
    if(params.status != undefined) {
      searchForm.value = { businessLine: '', filters : [
          {key: 1, field: '', operator: '', value: ''},
          {key: 2, field: '', operator: '', value:''},
          {key: 3, field: '', operator: '', value: ''}
        ] }
    } else {
      searchForm.value = { businessLine: '', filters : [
          {key: 2, field: '', operator: '', value:''},
          {key: 3, field: '', operator: '', value: ''}
        ] }
    }
  }

  nextTick(() => {
    refresh()
    nextTick(()=>{
      store.setParams({});
      getBusinessLine();
    })
  })
})
watch(() => store.params, (newVal) => {
  if(Object.keys(newVal).length) {
    advanced.value = false
    delaySearchFormRender.value = false;

    if(newVal.status != undefined) {
      searchForm.value = { businessLine: '', filters : [
          {key: 1, field: '', operator: '', value: ''},
          {key: 2, field: '', operator: '', value:''},
          {key: 3, field: '', operator: '', value: ''}
        ] }
    } else {
      searchForm.value = { businessLine: '', filters : [
          {key: 2, field: '', operator: '', value:''},
          {key: 3, field: '', operator: '', value: ''}
        ] }
    }


    nextTick(() => {
      refresh()
      nextTick(() => {
        search();
      })
    })
  }
})

async function getBusinessLine() {
  try {

  } catch (error) {
    console.error('Error fetching business line:', error);
  }finally {
    search();
  }
}

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}
const search = async () => {
  loadingTable.value = true
  let formData = checkData(searchForm.value);
  let result = await list(formData, page.value.currentPage, page.value.pageSize);
  let {current, total, records} = result.data;
  data.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loadingTable.value = false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}



const refresh = () => {
  const routeParams = store.getParams();
  if(routeParams != undefined && Object.keys(routeParams).length > 0) {
    advanced.value = true;
    delaySearchFormRender.value = true;
  } else {
    delaySearchFormRender.value = true;
  }

}



/**
 * 主表按钮
 */
const getMainTableButtons: () => ButtonInfo[] = () => {
  const buttons = [

  ]
  return buttons;
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => {
        openDialog(row)
      }
    },
  ]
  return buttons
}

const openDialog = async (row: any) => {
  const result = await getById({id: row.id});
  open(result.data, true, '查看');
}


const {dialogData, open, close, closed, form, nameRef: dialogFormRef}: DialogForm<RkFormInstance, any>
    = useDialogForm('dialogFormRef', {type: []})

</script>

<style scoped>

</style>
