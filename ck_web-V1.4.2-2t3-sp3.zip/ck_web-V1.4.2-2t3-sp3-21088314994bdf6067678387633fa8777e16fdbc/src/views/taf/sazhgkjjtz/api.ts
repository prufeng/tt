import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/sazhgkjjtz/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

export function getById(params = {}): Promise<RS> {
    return service({
        url: `/sazhgkjjtz/getById`,
        method: 'GET',
        params,
    })
}

export function saveOrUpdate(data = {}): Promise<RS> {
    return service({
        url: `/sazhgkjjtz/saveOrUpdate`,
        method: 'POST',
        data,
    })
}
export function submit(ids:string): Promise<RS> {
    return service({
        url: `/sazhgkjjtz/submit`,
        method: 'POST',
        params:{ids},
    })
}
export function auditPass(ids:string): Promise<RS> {
    return service({
        url: `/sazhgkjjtz/auditPass`,
        method: 'POST',
        params:{ids},
    })
}
export function auditNoPass(ids:string, msg: string): Promise<RS> {
    return service({
        url: `/sazhgkjjtz/auditNoPass`,
        method: 'POST',
        params:{ids, msg},
    })
}

export function delByIds(ids: string): Promise<RS> {
    return service({
        url: `/sazhgkjjtz/delByIds`,
        method: 'POST',
        params: {ids: ids},
    })
}

export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: `/sazhgkjjtz/exportExcel`,
        method: 'POST',
        data,
        params: {ids},
        responseType: 'blob'
    })
}
