import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'status',
        label: '状态',
        width: 120,
        dictFormatKey:'taf_status',
        scopedSlots: 'status'
    },
    {
        prop: 'ssrq',
        label: '申诉日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'bgkzhzh',
        label: '被管控账户账号',
        width: 300,
    },
    {
        prop: 'bgkzhmc',
        label: '被管控账户名称',
        width: 120,
    },
    {
        prop: 'ssjjllr',
        label: '申诉救济联络人',
        width: 170
    },
    {
        prop: 'gkyy',
        label: '管控原因',
        width: 250,
    },
    {
        prop: 'gkfs',
        label: '管控方式',
        width: 170,
        dictFormatKey: 'gkfs'
    },
    {
        prop: 'gkksrq',
        label: '管控开始日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'gkzzrq',
        label: '管控终止日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'gkczrq',
        label: '管控操作日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'gkdw',
        label: '管控单位',
        width: 170,
    },
    {
        prop: 'gkdwlxr',
        label: '管控单位联系人',
        width: 170,
    },
    {
        prop: 'gkdwlxfs',
        label: '管控单位联系方式',
        width: 170
    },
    {
        prop: 'jjfa',
        label: '解决方案',
        width: 170
    },
    {
        prop: 'czqk',
        label: '处置情况',
        width: 170
    },
    {
        prop: 'branchCode',
        label: '分行编号',
        width: 300,
    },
    {
        prop: 'branchCode',
        label: '分行名称',
        dictFormatKey:'branchCode',
        width: 300,
    },
    {
        prop: 'statusRemark',
        label: '备注',
        width: 300,
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'updateBy',
        label: '更新人',
        width: 170
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        width: 120,
        formatter: dateFormatter
    },
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},

    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'bgkzhzh',
        label: '被管控账户账号',
        labelWidth: 100,
    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 100,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags:1
        },
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'ssrq',
        label: '申诉日期',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]
    },
    {
        prop: 'bgkzhzh',
        label: '被管控账户账号',
        labelWidth: 170,
    },
    {
        prop: 'bgkzhmc',
        label: '被管控账户名称',
        labelWidth: 170,
    },
    {
        prop: 'ssjjllr',
        label: '申诉救济联络人',
        labelWidth: 170
    },
    {
        prop: 'gkyy',
        label: '管控原因',
        labelWidth: 170,
    },
    {
        prop: 'gkfs',
        label: '管控方式',
        labelWidth: 170,
        // inputType: {
        //     tag: 'select',
        //     options: 'gkfs',
        //     multiple: false,
        // },
    },
    {
        prop: 'gkksrq',
        label: '管控开始日期',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]
    },
    {
        prop: 'gkzzrq',
        label: '管控终止日期',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]
    },
    {
        prop: 'gkczrq',
        label: '管控操作日期',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]
    },
    {
        prop: 'gkdw',
        label: '管控单位',
        labelWidth: 170,
    },
    {
        prop: 'gkdwlxr',
        label: '管控单位联系人',
        labelWidth: 170,
    },
    {
        prop: 'gkdwlxfs',
        label: '管控单位联系方式',
        labelWidth: 170
    },
    {
        prop: 'jjfa',
        label: '解决方案',
        labelWidth: 170
    },
    {
        prop: 'czqk',
        label: '处置情况',
        labelWidth: 170
    },
    {
        prop: 'statusRemark',
        label: '备注',
        labelWidth: 170
    },
    {
        prop: 'branchCode',
        label: '所属机构',
        labelWidth: 170,
        rules: [{required: true, message: '必填'}],
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
    },
    {
        prop: 'createBy',
        label: '创建人',
        labelWidth: 170,
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'createTime',
        label: '创建时间',
        labelWidth: 170,
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'updateBy',
        label: '更新人',
        labelWidth: 170,
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        labelWidth: 170,
        inputType: {tag:'input',disabled: true},
    },
    {prop: 'submitBy', label: '提交人', labelWidth: 170,inputType: {tag:'input',disabled: true},},
    {prop: 'submitTime', label: '提交时间', labelWidth: 170,inputType: {tag:'input',disabled: true},},
    {prop: 'approveBy', label: '审核人', labelWidth: 170,inputType: {tag:'input',disabled: true}, },
    {prop: 'approveTime', label: '审核时间', labelWidth: 170,inputType: {tag:'input',disabled: true},},
]
