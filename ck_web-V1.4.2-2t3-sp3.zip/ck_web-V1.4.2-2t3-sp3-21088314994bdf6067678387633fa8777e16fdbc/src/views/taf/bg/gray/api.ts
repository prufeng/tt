import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/gray/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

export function getById(params = {}): Promise<RS> {
    return service({
        url: `/gray/getById`,
        method: 'GET',
        params,
    })
}

export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: `/gray/exportExcel`,
        method: 'POST',
        data,
        params: {ids},
        responseType: 'blob'
    })
}
