<template>
<!--  <div class="app-container">-->
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"
                    :form-items="searchFormItems" @search="search" :label-width="50"/>

    <rk-page-table :columns="columns" :loading="loadingTable" :data="data" :pagination="page" @page-change="pageChange" @refresh="search"
                   @selection-change="handleSelectionChange">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <UpAndDown :exp="exp" />
        </div>
      </template>

      <!--<template #createTime="{ row }">-->
      <!--  <div>{{dayjs(row.createTime).format('YYYY-MM-DD HH:mm:ss') }}</div>-->
      <!--</template>-->

      <!--<template #updateTime="{ row }">-->
      <!--  <div>{{dayjs(row.updateTime).format('YYYY-MM-DD HH:mm:ss') }}</div>-->
      <!--</template>-->

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="['view']" link max="1"/>
      </template>
    </rk-page-table>
  </rk-index-layout>


  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" :close-on-click-modal="false">
    <rk-detail-form ref="dialogFormRef" v-model="form" disabled="false" :form-items="formItems"/>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
<!--  </div>-->
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage} from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, RkIndexLayout,
} from 'riking-ui'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm'
import {useDict} from 'riking-layout'
import {list, getById} from '@/views/taf/bg/gray/api'
import {checkData, pagination} from "@/utils/utils";
import {columns, searchFormItems, formItems} from '../config';
import {exportExcel} from "@/views/taf/bg/gray/api";
import UpAndDown, {expLoading, impLoading} from "@/components/UpAndDown.vue";

const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const applicationID = ref("");
let ids: string;

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  search()
})

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}

const exp = async () => {
  expLoading.value = true;
  try {
    if (ids==undefined||ids.length == 0) {
      ids=''
    }
    /*let value = searchForm.value;
    const newObject = {...searchForm.value};*/
    let formData = checkData(searchForm.value);
    await exportExcel(ids,formData);
  }finally {
    expLoading.value = false;
  }
}
const search = async () => {
  loadingTable.value=true
  let formData = checkData(searchForm.value);
  let result = await list(formData, page.value.currentPage, page.value.pageSize);
  let {current, total, records} = result.data;
  data.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loadingTable.value=false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'view', label: '查看', tag: 'button', type: 'primary',
    handler: () => {openDialog(row)}
  }
]

const openDialog = async (row: any) => {
  const result = await getById({id: row.id});
  open(result.data, true, '查看');
}

const {dialogData, open, close, closed, form, nameRef: dialogFormRef}: DialogForm<RkFormInstance, any>
    = useDialogForm('dialogFormRef', {type: []})

</script>

<style scoped>

</style>
