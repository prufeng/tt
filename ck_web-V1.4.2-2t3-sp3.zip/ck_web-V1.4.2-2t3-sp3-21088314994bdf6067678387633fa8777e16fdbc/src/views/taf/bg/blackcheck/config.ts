import { FormItemInfo, TableColumnInfo } from "riking-ui";

export const columns: TableColumnInfo[] = [
    // { key: 'id', type: 'selection' },
    {
        prop: 'dataType',
        label: '名单类型',
        width: 100,
        // dictFormatKey: 'accountTypeList',
        formatter: (row: any) => {
            if(row?.dataType == 'AccountNumber') return '卡/折号+姓名';
            else if(row?.dataType == 'IDType_IDNumber') return '证件号+姓名';
            return ''
        },
    },
    {
        prop: 'dataValue',
        label: '号码',
        width: 100,
    },
    // {
    //     prop: 'name',
    //     label: '姓名',
    //     width: 100,
    // },
    {
        prop: 'createTime',
        label: '查验结果',
        formatter: (row: any) => {
            return row.createTime ? '在涉案/可疑名单' : '不在涉案/可疑名单'
        },
        width: 100,

    },
    // {
    //     key: 'actions',
    //     label: '操作',
    //     scopedSlots: 'actions',
    //     width: 80,
    //     minWidth: 80,
    //     fixed: 'right',
    // },
]

export const searchFormItems: FormItemInfo[] = [

    {
        prop: 'dobjectName',
        label: '惩戒对象名称',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'dobjectIDType',
        label: '惩戒对象证件类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
    },
    {
        prop: 'dobjectIDNumber',
        label: '惩戒对象证件号码',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'dobjectType',
        label: '惩戒对象类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'DobjectType',
            multiple: false,
        },
    },
]

export const formItems: FormItemInfo[] = [

    {
        prop: 'dataType',
        label: '名单类型',
        labelWidth: 170,
        // inputType: {
        //     tag: 'select',
        //     options: 'idType',
        //     multiple: false,
        // },
    },
    {
        prop: 'dataValue',
        label: '号码',
        labelWidth: 170,
        inputType: 'input',
    },
    // {
    //     prop: 'name',
    //     label: '姓名',
    //     labelWidth: 170,
    //     inputType: 'input',
    // },
    {
        prop: 'createTime',
        label: '查验结果',
        labelWidth: 170,
        inputType: 'input',
    },
]