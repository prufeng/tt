<template>
  <!--  <div class="app-container">-->
  <rk-index-layout>
    <!-- <rk-search-form
      ref="searchFormRef"
      v-model="searchForm"
      :loading="loading"
      @keyup.enter="search"
      :form-items="searchFormItems"
      @search="search"
      :label-width="50"
    /> -->
    <div style="background-color: #fff; margin: 10px 0">
      <el-form ref="formRef" :model="dynamicValidateForm" label-width="auto" :inline="true" style="margin: 10px 15px">
        <div v-for="(domain, index) in dynamicValidateForm.domains" :key="index + 'key'">
          <el-form-item :prop="'idType.' + index + '.value'" label="名单类型" style="width: 25%">
            <el-select v-model="domain[2].value" clearable placeholder="Select" style="width: 90%">
              <el-option v-for="item in accountTypeList" :key="index+item.value" :label="item.label" :value="item.value"/>
            </el-select>
            <!-- <el-input v-model="domain[2].value" style="width: 200px" /> -->
          </el-form-item>
          <el-form-item :key="domain[0].key" label="号码" :prop="'cardNumber.' + index + '.value'" style="width: 25%">
            <el-input v-model="domain[0].value" clearable style="width: 90%" />
          </el-form-item>
          <el-form-item :key="domain[1].key" label="姓名" :prop="'name.' + index + '.value'" style="width: 25%">
            <el-input v-model="domain[1].value" clearable style="width: 90%" />
          </el-form-item>
        </div>
        <el-form-item>
          <el-button type="primary" @click="search()">查询</el-button>
          <el-button type="primary" @click="addDomain"> 增加 </el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- <div id="content" style="width: 100%;"> -->
    <rk-table
      :columns="columns"
      :loading="loadingTable"
      :data="data"
      @refresh="search"
      @selection-change="handleSelectionChange"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="getMainTableButtons()" :route-meta="$route.meta" :max="9" />
          <UpAndDown :imp="imp" :exp="exp" />
        </div>
      </template>
      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link :max="3" />
      </template>
    </rk-table>
    <!-- </div> -->
  </rk-index-layout>

  <!-- 弹出层 -->
  <el-dialog
    v-model="dialogData.visible"
    :title="dialogData.title"
    class="rk-dialog-default"
    @closed="closed"
    :close-on-click-modal="false"
  >
    <rk-detail-form ref="dialogFormRef" v-model="form" :disabled="dialogData.formDisabled" :form-items="formItems" />

    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!--  </div>-->
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
import { onMounted, ref, reactive } from 'vue'
import { ElDialog, ElButton, ElMessage, FormInstance } from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  RkIndexLayout,
} from 'riking-ui'
import { DialogForm } from 'riking-ui/dist/hooks/useDialogForm'
import { useDict } from 'riking-layout'
import { list, getById, delById, importExcel, saveOrUpdate } from '@/views/taf/bg/blackcheck/api'
import { checkData, pagination } from '@/utils/utils'
import { columns, searchFormItems, formItems } from './config'
import { exportExcel } from '@/views/taf/bg/cjmd/api'
import UpAndDown, { expLoading, impLoading } from '@/components/UpAndDown.vue'

const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const data = ref<any[]>([])
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const applicationID = ref('')
// const idTypeList = ref([])
const accountTypeList = ref([
  { label: '卡/折号+姓名', value: 'AccountNumber' },
  { label: '证件号+姓名', value: 'IDType_IDNumber' },
])
let ids: string

useDict([], [], dictData)
// idTypeList.value = dictData.idType

onMounted(() => {
  page.value = {...pagination}
  search()
})
const formRef = ref<FormInstance>()
const dynamicValidateForm = ref({
  domains: [
    [
      {
        key: 1,
        value: '',
      },
      {
        key: 2,
        value: '',
      },
      {
        key: 3,
        value: 'AccountNumber',
      },
    ],
  ],
})

const addDomain = () => {
  dynamicValidateForm.value.domains?.push([
    {
      key: Date.now() + 1,
      value: '',
    },
    {
      key: Date.now() + 2,
      value: '',
    },
    {
      key: Date.now() + 3,
      value: 'AccountNumber',
    },
  ])
}

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(',')
}

const getMainTableButtons: () => ButtonInfo[] = () => {
  const buttons = [
    {
      key: 'print',
      label: '打印',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => {
        var iframe: any = document.getElementById('printFrame')
        if (!iframe) {
          let div = `
          <table width='95%' align="center">
            <thead>
              <tr>
                <th>名单类型</th>
                <th>号码</th>
                <th>查验结果</th>
              </tr>
            </thead> 
            <tbody align="center">
           `
          data.value.forEach((item: any) => {
            // const idTypeValue = idTypeList.value.filter((val) => (val.value = item.idType))[0].label
            const dataTypeValue = accountTypeList.value.filter((val) => (val.value == item.dataType))[0].label
            const isSuspect = item.createTime ? '在涉案/可疑名单' : '不在涉案/可疑名单'
            div += `<tr>
                    <td>${dataTypeValue}</td>
                    <td>${item.dataValue}</td>
                    <td>${isSuspect}</td>
                </tr>`
          })
          div += `</tbody> </table>`
          iframe = document.createElement('IFRAME')
          iframe.id = 'printFrame'
          iframe.setAttribute('style', 'position:absolute;width:0px;height:0px;left:-500px;top:-500px;')
          document.body.appendChild(iframe)
          var doc = iframe.contentWindow.document
          doc.write('<html><head><title>Riking-电信反欺诈</title></head><body>' + div + '</body></html>')
          var ys = `
            .contain{display: flex; flex-direction: row;justify-content: space-between;}
            table {
              margin: 0 auto;
              border: 1px solid #000000;
              border-collapse: collapse;
            } 
            th,td {
              border: 1px solid #000000;
              text-align: center;
            }`
          var style = document.createElement('style')
          style.innerText = ys
          doc.getElementsByTagName('head')[0].appendChild(style)
          doc.close()
          iframe.contentWindow.focus()
          iframe.contentWindow.print()
          document.body.removeChild(iframe)
        }
      },
    },
  ]

  return buttons
}
const exp = async () => {
  expLoading.value = true
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    /*let value = searchForm.value;
        const newObject = {...searchForm.value};*/
    let formData = checkData(searchForm.value)
    await exportExcel(ids, formData)
  } finally {
    expLoading.value = false
  }
}

const imp = async (data = {}) => {
  await importExcel(data, 'tafBlack')
  ElMessage.success('导入成功')
  await search()
}

const search = async () => {
  // if (!formEl) return
  let values = []
  dynamicValidateForm.value.domains.forEach((item) => {
    if (item[0].value == '' || (item[1].value == '' && item[2].value == '')) {
      return;
    } else {
      values.push({
        dataValue: item[0].value,
        name: item[1].value,
        dataType: item[2].value,
      })
    }
  })
  loadingTable.value = true
  //   let formData = checkData(searchForm.value)
  let res = await list(values, page.value.currentPage, page.value.pageSize)
  loadingTable.value = false

  data.value = res.result
  page.value.currentPage = 1
  page.value.total = res.result.length
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'view',
    label: '查看',
    tag: 'button',
    type: 'primary',
    handler: () => {
      openDialog(row)
    },
  },
  {
    key: 'edit',
    label: '编辑',
    tag: 'button',
    type: 'primary',
    handler: () => open(row, false, '编辑'),
  },
  {
    key: 'delete',
    label: '删除',
    tag: 'popconfirm',
    type: 'danger',
    title: '确定删除吗',
    handler: () => deleteDialog(row),
  },
]

const deleteDialog = async (row: any) => {
  await delById(row)
  search()
  ElMessage.success('删除成功')
}

const handleSave = async () => {
  //编辑
  dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate()
    if (valid) {
      await saveOrUpdate(form.value)
      search()
      close()
      ElMessage.success('修改成功')
    }
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}

const openDialog = async (row: any) => {
  const result = {
    ...row,
    createTime: row.createTime ? '在涉案/可疑名单' : '不在涉案/可疑名单',
    dataType: row?.dataType == 'AccountNumber' ? '卡/折号+姓名' : row?.dataType == 'IDType_IDNumber' ? '证件号+姓名' : '',
  }
  open(result, true, '查看')
}

const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })
</script>

<style scoped></style>
