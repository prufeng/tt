import { RS } from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
  return service({
    url: `/dobjectList/listHeader`,
    method: 'POST',
    data,
    params: { pageNo: current, pageSize: size },
  })
}

export function getById(params = {}): Promise<RS> {
  return service({
    url: `/dobjectList/getById`,
    method: 'GET',
    params,
  })
}

export function exportExcelHeader(ids: any, data = {}): Promise<RS> {
  return service({
    url: `/dobjectList/exportExcelHeader`,
    method: 'POST',
    data,
    params: { ids },
    responseType: 'blob',
  })
}

export function exportExcel(ids: any, data = {}): Promise<RS> {
  return service({
    url: `/dobjectList/exportExcel`,
    method: 'POST',
    data,
    params: { ids },
    responseType: 'blob',
  })
}

export function listDetail(data = {}, current: number, size: number): Promise<RS> {
  return service({
    url: `/dobjectList/list`,
    method: 'POST',
    data,
    params: { pageNo: current, pageSize: size },
  })
}
