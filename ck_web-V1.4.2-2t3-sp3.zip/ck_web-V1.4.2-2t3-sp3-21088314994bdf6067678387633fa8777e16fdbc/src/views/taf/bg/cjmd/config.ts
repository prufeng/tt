import { FormItemInfo, TableColumnInfo } from "riking-ui";

export const columns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        width: 170,
    },
    {
        prop: 'dobjectType',
        label: '惩戒对象类型',
        width: 100,
        dictFormatKey: 'DobjectType'
    },
    {
        prop: 'dobjectName',
        label: '惩戒对象名称',
        width: 170,
    },
    {
        prop: 'dobjectIDType',
        label: '惩戒对象证件类型',
        width: 170,
        dictFormatKey: 'idType'
    },
    {
        prop: 'dobjectIDNumber',
        label: '惩戒对象证件号码',
        width: 170,
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'startDate',
        label: '惩戒开始时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'endDate',
        label: '惩戒结束时间',
        width: 170,
    },
    { prop: 'matchResult', label: '匹配结果', dictFormatKey: 'MatchResult' },
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importTypeTaf'
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 120,
        // scopedSlots: {
        //     default: 'createTime',
        // },
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        // scopedSlots: {
        //     default: 'createTime',
        // },
    },

    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 190,
        fixed: 'right',
    },
]

export const columnsDetail: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'applicationID',
        label: '业务申请编号',
        width: 170,
    },
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        width: 170,
    },
    {
        prop: 'dobjectType',
        label: '惩戒对象类型',
        width: 100,
        dictFormatKey: 'DobjectType'
    },
    {
        prop: 'dobjectName',
        label: '惩戒对象名称',
        width: 170,
    },
    {
        prop: 'drequesttype',
        label: '下发类型',
        width: 100,
        dictFormatKey: 'drequesttype'
    },
    {
        prop: 'dobjectIDType',
        label: '惩戒对象证件类型',
        width: 170,
        dictFormatKey: 'idType'
    },
    {
        prop: 'dobjectIDNumber',
        label: '惩戒对象证件号码',
        width: 170,
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'startDate',
        label: '惩戒开始时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'endDate',
        label: '惩戒结束时间',
        width: 170,
    },
    {
        prop: 'dpoliceCode',
        label: '惩戒公安机关代码',
        width: 170,
    },
    {
        prop: 'dpoliceName',
        label: '惩戒公安机关名称',
        width: 170,
    },
    {
        prop: 'dpoliceStartDate',
        label: '惩戒公安机关惩戒开始时间',
        width: 170
    },
    {
        prop: 'dpoliceEndDate',
        label: '惩戒公安机关惩戒结束时间',
        width: 170
    },
    { prop: 'matchResult', label: '匹配结果', dictFormatKey: 'MatchResult' },
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importTypeTaf'
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 120,
        // scopedSlots: {
        //     default: 'createTime',
        // },
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        // scopedSlots: {
        //     default: 'createTime',
        // },
    },

    // {
    //     key: 'actions',
    //     label: '操作',
    //     scopedSlots: 'actions',
    //     width: 100,
    //     minWidth: 140,
    //     fixed: 'right',
    // },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'dobjectName',
        label: '惩戒对象名称',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'dobjectIDType',
        label: '惩戒对象证件类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
    },
    {
        prop: 'dobjectIDNumber',
        label: '惩戒对象证件号码',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'dobjectType',
        label: '惩戒对象类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'DobjectType',
            multiple: false,
        },
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        labelWidth: 80,
        inputType: {
            tag: 'date-picker',
            type: 'daterange',
            style: 'width: 220px',
            rangeSeparator: '-',
            format: 'YYYY-MM-DD',
            valueFormat: 'YYYY-MM-DD',
        },
    },
    {
        prop: 'startDate',
        label: '惩戒开始时间',
        labelWidth: 80,
        inputType: {
            tag: 'date-picker',
            type: 'daterange',
            style: 'width: 220px',
            rangeSeparator: '-',
            format: 'YYYY-MM-DD',
            valueFormat: 'YYYY-MM-DD',
        },
    },
    {
        prop: 'endDate',
        label: '惩戒结束时间',
        labelWidth: 80,
        inputType: {
            tag: 'date-picker',
            type: 'daterange',
            style: 'width: 220px',
            rangeSeparator: '-',
            format: 'YYYY-MM-DD',
            valueFormat: 'YYYY-MM-DD',
        },
    },
    {
        prop: 'matchResult',
        label: '匹配结果',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'MatchResult',
            multiple: false,
        },
    },
    // {
    //     prop: 'matchResult',
    //     label: '匹配成功',
    //     labelWidth: 100,
    //     // scopedSlot: 'onlyQuerySucceeded',
    //     // inputType: {tag:'checkbox',   checked:"checked"},
    //     inputType: { tag: 'checkbox' },
    // }
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'dobjectType',
        label: '惩戒对象类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'DobjectType',
            multiple: false,
        },
    },
    {
        prop: 'dobjectName',
        label: '惩戒对象名称',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'dobjectIDType',
        label: '惩戒对象证件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
    },
    {
        prop: 'dobjectIDNumber',
        label: '惩戒对象证件号码',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'startDate',
        label: '惩戒开始时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'endDate',
        label: '惩戒结束时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'matchResult',
        label: '匹配结果',
        labelWidth: 150,
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '必填' }],
        inputType: { tag: 'select', options: 'MatchResult' }
    },
]

export const formDetailItems: FormItemInfo[] = [
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'dobjectType',
        label: '惩戒对象类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'DobjectType',
            multiple: false,
        },
    },
    {
        prop: 'dobjectName',
        label: '惩戒对象名称',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'drequesttype',
        label: '下发类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'drequesttype',
            multiple: false,
        },
    },
    {
        prop: 'dobjectIDType',
        label: '惩戒对象证件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
    },
    {
        prop: 'dobjectIDNumber',
        label: '惩戒对象证件号码',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'applicationTime',
        label: '申请时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'startDate',
        label: '惩戒开始时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'endDate',
        label: '惩戒结束时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'dpoliceCode',
        label: '惩戒公安机关代码',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'dpoliceName',
        label: '惩戒公安机关名称',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'dpoliceStartDate',
        label: '惩戒公安机关惩戒开始时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'dpoliceEndDate',
        label: '惩戒公安机关惩戒开始时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'matchResult',
        label: '匹配结果',
        labelWidth: 150,
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '必填' }],
        inputType: { tag: 'select', options: 'MatchResult' }
    },
]