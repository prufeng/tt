<template>
  <div style="display: flex; flex-direction: row">
    <el-space>
      <el-upload ref="upload" class="upload-demo" :headers=headers :limit="1"  :show-file-list="false" :on-preview="handlePreview"
        :on-remove="handleRemove" :before-remove="beforeRemove" :on-exceed="handleExceed" :on-change="onChange"
        :http-request="httpRequest">
        <el-button  v-permission:imp="$route.meta" :loading="impLoading"  v-if="imp" size="default" type="primary"  :icon="Upload">
          {{ impName==null?'导入':impName }}</el-button>
        <!--<div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>-->
      </el-upload>
<!--      v-permission:exp="$route.meta"-->
      <el-button  v-permission:expDetail="$route.meta" :loading="expDetailLoading"  v-if="exp" size="default" type="primary"
                  :icon="Download" @click="exp">{{ expName==null?'导出':expName }}</el-button>
    </el-space>
  </div>
</template>
<script setup lang="ts">
import { Delete, Edit, Search, Share, Upload, Download } from '@element-plus/icons-vue'
</script>
<script lang="ts">
export const impLoading=ref(false)
export const expDetailLoading=ref(false)
export default {
  name: "UploadButton",
  props: {
    imp: Function,
    exp: Function,
    impName: String,
    expName: String,
  },

  data() {
    return {
      headers: {},
      file: {},
      fileList: []
    };
  },
  methods: {
    httpRequest() {
      this.imp(this.file);
    },

    downloadFile() {
      console.log("download")
    },

    // 文件列表移除文件时的钩子
    handleRemove(file, fileList) {
      console.log('remove');
    },

    // 点击文件列表中已上传的文件时的钩子
    handlePreview(file) {
      console.log('preview');
    },

    // 删除文件之前的钩子，参数为上传的文件和文件列表，若返回 false 或者返回 Promise 且被 reject，则停止删除
    beforeRemove(file, fileList) {
      console.log('beforeremove');
      // return this.$confirm(`确定移除 ${ file.name }？`);
    },

    // 文件超出个数限制时的钩子
    handleExceed(files, fileList) {
      console.log('exceed');
      this.file = files
      this.imp( this.file);
      // this.$message.warning(`当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
    },

    // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
    onChange(files, fileList) {
      this.file = files;
      console.log(files, fileList);
    },
  },
}
</script>

<style scoped></style>
