<template>
  <!--  <div class="app-container">-->
  <rk-index-layout>
    <rk-search-form
      ref="searchFormRef"
      v-model="searchForm"
      :loading="loading"
      @keyup.enter="search"
      :form-items="searchFormItems"
      @search="search"
      :label-width="50"
    >
      <template #onlyQuerySucceeded>
        <el-checkbox :checked="dictData.matching != undefined ? true : false" />
      </template>
    </rk-search-form>
    <rk-page-table
      :columns="columns"
      :loading="loadingTable"
      :data="data"
      :pagination="page"
      @page-change="pageChange"
      @refresh="search"
      @selection-change="handleSelectionChange"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <UpAndDown :exp="exp" />
        </div>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link max="3" />
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!-- 弹出层 -->
  <el-dialog
    v-model="dialogData.visible"
    :title="dialogData.title"
    class="rk-dialog-default"
    @closed="closed"
    :close-on-click-modal="false"
  >
    <rk-detail-form ref="dialogFormRef" v-model="form" :disabled="dialogData.formDisabled" :form-items="formItems" />

    <template #footer>
      <span class="dialog-footer">
        <!-- <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
              保存
            </el-button> -->
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!--  </div>-->
  <!-- 弹出层详情 -->
  <el-dialog
    v-model="detailVisible"
    title="惩戒名单详情"
    class="rk-dialog-default"
    @closed="closeDetail"
    :close-on-click-modal="false"
  >
    <rk-page-table
      :columns="columnsDetail"
      :loading="loadingTable"
      :data="dataDetail"
      :pagination="pageDetail"
      @page-change="pageChangeDetail"
      @refresh="searchDetailList"
      @selection-change="handleSelectionChangeDetail"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <DownLoad :exp="expDetail" />
        </div>
      </template>
      <!-- <template #actions="{ row }">
        <rk-button-group :buttons="genActButtonsDetail(row)" :route-meta="$route.meta" link max="3" />
      </template> -->
    </rk-page-table>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'
import { formatDate } from '@/views/system/ps/cx/data'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage } from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  RkIndexLayout,
} from 'riking-ui'
import  DialogForm  from 'riking-ui/dist/hooks/useDialogForm'
import { useDict } from 'riking-layout'
import { list, getById, listDetail } from '@/views/taf/bg/cjmd/api'
import {checkData, pagination, subPagination} from '@/utils/utils'
import { columns, searchFormItems, formItems, columnsDetail } from './config'
import { exportExcel, exportExcelHeader } from '@/views/taf/bg/cjmd/api'
import UpAndDown, { expLoading, impLoading } from '@/components/UpAndDown.vue'
import DownLoad, {expDetailLoading} from './DownLoad.vue'
import {setCjDefaultValue} from "@/views/taf/utils";

const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const detailVisible = ref(false) // 明细弹窗
const data = ref<any[]>([])
const dataDetail = ref<any[]>([])
const page = ref<Pagination>(pagination)
const pageDetail = ref<Pagination>(subPagination)

const searchFormRef = ref<RkFormInstance>()
const dobjectId = ref('')
let ids: string
let idsDetail: string

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  search()
})

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(',')
}
const handleSelectionChangeDetail = async (val: any) => {
  idsDetail = val.map((item: any) => item.id).join(',')
}
const exp = async () => {
  expLoading.value = true
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    /*let value = searchForm.value;
        const newObject = {...searchForm.value};*/
    let formData = checkData(searchForm.value)
    await exportExcelHeader(ids, formData)
  } finally {
    expLoading.value = false
  }
}

//导出明细
const expDetail = async () => {
  expDetailLoading.value = true
  try {
    if (idsDetail == undefined || idsDetail.length == 0) {
      idsDetail = ''
    }
    let formData = {
      dobjectId: dobjectId.value,
    }
    await exportExcel(idsDetail, formData)
  } finally {
    expDetailLoading.value = false
  }
}
const search = async () => {
  loadingTable.value = true
  let formData = checkData(searchForm.value)
  if (formData.startDate) {
    formData.startDateFrom = formatDate(new Date(formData.startDate[0]))
    formData.startDateTo = formatDate(new Date(formData.startDate[1]))
    delete formData.startDate
  }
  if (formData.endDate) {
    formData.endDateFrom = formatDate(new Date(formData.endDate[0]))
    formData.endDateTo = formatDate(new Date(formData.endDate[1]))
    delete formData.endDate
  }
  if (formData.applicationTime) {
    formData.applicationTimeFrom = formatDate(new Date(formData.applicationTime[0]))
    formData.applicationTimeTo = formatDate(new Date(formData.applicationTime[1]))
    delete formData.applicationTime
  }
  let res = await list(formData, page.value.currentPage, page.value.pageSize)
  loadingTable.value = false
  let { pages, total, records } = res.result

  setCjDefaultValue(records);

  data.value = records
  // page.value.currentPage = page.value.currentPage
  page.value.total = total
}

//查询详情列表
const searchDetailList = async () => {
  loadingTable.value = true
  if (dobjectId.value == '') return ElMessage.warning('惩戒对象唯一标识不能为空')
  let res = await listDetail({ dobjectId: dobjectId.value }, pageDetail.value.currentPage, pageDetail.value.pageSize)
  loadingTable.value = false
  let { pages, total, records, current } = res.result

  setCjDefaultValue(records);

  dataDetail.value = records
  pageDetail.value.currentPage = current
  // pageDetail.value.pageSize = pages
  pageDetail.value.total = total
}
const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

//详情分页
const pageChangeDetail = (p: Pagination) => {
  pageDetail.value = p
  searchDetailList()
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'view',
    label: '查看',
    tag: 'button',
    type: 'primary',
    handler: () => {
      openDialog(row)
    },
  },
  {
    key: 'view',
    label: '查看明细',
    tag: 'button',
    type: 'primary',
    handler: () => {
      idsDetail = ''
      dobjectId.value = row.dobjectId
      detailVisible.value = true
      searchDetailList()
    },
  },
  {
    key: 'expDetail',
    label: '导出明细',
    tag: 'button',
    type: 'primary',
    loading: expDetailLoading.value,
    handler: async () => {
      dobjectId.value = row.dobjectId
      let params = {
        dobjectId: row.dobjectId,
      }
      expDetailLoading.value = true
      await exportExcel('', params)
      expDetailLoading.value = false
    },
  },
]

const closeDetail = () => {
  detailVisible.value = false
}
const openDialog = async (row: any) => {
  // const result = await getById({ id: row.id })
  open(row, true, '查看')
}

const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })
</script>

<style scoped></style>
