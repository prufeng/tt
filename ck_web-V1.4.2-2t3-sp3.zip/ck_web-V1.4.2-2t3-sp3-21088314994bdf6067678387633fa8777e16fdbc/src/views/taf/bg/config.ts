import { FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'dataType',
        label: '数据类型',
        width: 170,
        dictFormatKey: 'dataType'
    },
    {
        prop: 'dataValue',
        label: '数据值',
        width: 300,
    },
    {
        prop: 'operate',
        label: '操作标识',
        width: 120,
        dictFormatKey: 'operate'
    },
    {
        prop: 'dataSource',
        label: '来源',
        width: 170
    },
    {
        prop: 'caseType',
        label: '案件类型',
        width: 250,
        dictFormatKey: 'blackGrayType'
    },
    {
        prop: 'name',
        label: '姓名',
        width: 170,
    },
    {
        prop: 'idType',
        label: '证件类型',
        width: 170,
        dictFormatKey: 'idType'
    },
    {
        prop: 'idNumber',
        label: '证件号',
        width: 170
    },
    {
        prop: 'orgID',
        label: '机构ID',
        width: 170
    },

    {
        prop: 'operatorName',
        label: '公安联系人',
        width: 170
    },
    {
        prop: 'operatorPhoneNumber',
        label: '公安联系人电话',
        width: 170
    },
    {
        prop: 'operateTimeStamp',
        label: '审核通过时间',
        width: 170
    },
    {
        prop: 'cardOpenTime',
        label: '开卡时间',
        width: 170,
    },
    {
        prop: 'valid',
        label: '有效期',
        width: 170
    },
    {
        prop: 'listDescription',
        label: '名单说明',
        width: 170
    },


    {
        prop: 'illegalType',
        label: '违法事实种类',
        width: 170,
        dictFormatKey: 'illegalType'
    },
    {
        prop: 'identificationOrgName',
        label: '认定公安机关',
        width: 170
    },
    {
        prop: 'orgName',
        label: '账号归属行法人机构',
        width: 170
    },
    {
        prop: 'operatorOrgName',
        label: '移送公安机关',
        width: 170
    },
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importTypeTaf'
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        // scopedSlots: {
        //     default: 'createTime',
        // },
    },

    // {
    //     prop: 'status',
    //     label: '数据状态',
    //     width: 170,
    //     dictFormatKey: 'reqProcessingStatus'
    // },
    // {
    //     prop: 'branchCode',
    //     label: '机构代码',
    //     width: 170,
    //     dictFormatKey: 'branchTree'
    // },
    // {
    //     prop: 'tenantCode',
    //     label: '租户编号',
    //     width: 170
    // },
    // {
    //     prop: 'importType',
    //     label: '导入方式',
    //     width: 170,
    //     dictFormatKey: 'importType'
    // },
    // {
    //     prop: 'createBy',
    //     label: '创建人',
    //     width: 170
    // },
    // {
    //     prop: 'updateBy',
    //     label: '更新人',
    //     width: 170
    // },
    // {
    //     prop: 'updateTime',
    //     label: '更新时间',
    //     width: 120,
    //     // scopedSlots: {
    //     //     default: 'updateTime',
    //     // },
    // },

    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'dataType',
        label: '数据类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'dataType',
            multiple: false,
        },
    },
    {
        prop: 'dataValue',
        label: '数据值',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'operate',
        label: '操作标识',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'operate',
            multiple: false,
        },
    },
    {
        prop: 'caseType',
        label: '案件类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'blackGrayType',
            multiple: false,
        },
    },
    {
        prop: 'name',
        label: '姓名',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'orgID',
        label: '机构',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'importType',
        label: '导入方式',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'importTypeTaf',
            multiple: false,
        },
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'dataType',
        label: '数据类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'dataType',
            multiple: false,
        },
    },
    {
        prop: 'dataValue',
        label: '数据值',
        labelWidth: 170,
    },
    {
        prop: 'dataSource',
        label: '来源',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'operate',
        label: '操作标识',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'operate',
            multiple: false,
        },
    },
    {
        prop: 'caseType',
        label: '案件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'blackGrayType',
            multiple: false,
        },
    },
    {
        prop: 'name',
        label: '姓名',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'orgID',
        label: '机构',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'operatorName',
        label: '公安联系人',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'operatorPhoneNumber',
        label: '公安联系人电话',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'operateTimeStamp',
        label: '审核通过时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'cardOpenTime',
        label: '开卡时间',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'valid',
        label: '有效期',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'listDescription',
        label: '名单说明',
        labelWidth: 170,
        inputType: 'input',
    },
]
