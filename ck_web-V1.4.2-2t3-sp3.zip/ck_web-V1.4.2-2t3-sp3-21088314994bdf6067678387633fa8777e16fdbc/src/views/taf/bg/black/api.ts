import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/black/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

export function getById(params = {}): Promise<RS> {
    return service({
        url: `/black/getById`,
        method: 'GET',
        params,
    })
}

export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: `/black/exportExcel`,
        method: 'POST',
        data,
        params: {ids},
        responseType: 'blob'
    })
}

export function saveOrUpdate(data={}): Promise<RS> {
    return service({
        url: `/black/saveOrUpdate`,
        method: 'POST',
        data,
    })
}

export function delById(data = {}): Promise<RS> {
    return service({
        url: `/black/delById`,
        method: 'POST',
        data,
    })
}

export function importExcel(data = {},reportCode:string): Promise<RS> {
    return service({
        url: `/black/importExcel`,
        method: 'POST',
        data,
        params:{reportCode},
        headers:{'Content-Type': 'multipart/form-data'}
    })
}
