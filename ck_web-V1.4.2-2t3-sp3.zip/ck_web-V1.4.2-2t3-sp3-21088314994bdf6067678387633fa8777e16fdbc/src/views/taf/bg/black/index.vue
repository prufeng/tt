<template>
<!--  <div class="app-container">-->
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"
                    :form-items="searchFormItems" @search="search" :label-width="50"/>

    <rk-page-table :columns="columns" :loading="loadingTable" :data="data" :pagination="page" @page-change="pageChange" @refresh="search"
                   @selection-change="handleSelectionChange">
      <template #operations>
          <div style="display: flex; flex-direction: row">
            <UpAndDown :imp="imp" :exp="exp" />
          </div>
      </template>

      <!--<template #createTime="{ row }">-->
      <!--  <div>{{dayjs(row.createTime).format('YYYY-MM-DD HH:mm:ss') }}</div>-->
      <!--</template>-->

      <!--<template #updateTime="{ row }">-->
      <!--  <div>{{dayjs(row.updateTime).format('YYYY-MM-DD HH:mm:ss') }}</div>-->
      <!--</template>-->

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link max="3"/>
      </template>
    </rk-page-table>
  </rk-index-layout>


  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" :close-on-click-modal="false">
    <rk-detail-form ref="dialogFormRef" v-model="form" :disabled="dialogData.formDisabled" :form-items="formItems"/>

    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
<!--  </div>-->
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage} from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, RkIndexLayout,
} from 'riking-ui'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm'
import {useDict} from 'riking-layout'
import {list, getById,delById, importExcel, saveOrUpdate} from '@/views/taf/bg/black/api'
import {checkData, pagination} from "@/utils/utils";
import {columns, searchFormItems, formItems} from '../config';
import {exportExcel} from "@/views/taf/bg/black/api";
import UpAndDown, {expLoading, impLoading} from "@/components/UpAndDown.vue";

const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const applicationID = ref("");
let ids: string;

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  search()
})

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}

const exp = async () => {
  expLoading.value = true;
  try {
    if (ids==undefined||ids.length == 0) {
      ids=''
    }
    /*let value = searchForm.value;
    const newObject = {...searchForm.value};*/
    let formData = checkData(searchForm.value);
    await exportExcel(ids,formData);
  }finally {
    expLoading.value = false;
  }
}

const imp = async (data = {}) => {
  await importExcel(data,"tafBlack");
  ElMessage.success("导入成功");
  await search();
}
const search = async () => {
  loadingTable.value=true
  let formData = checkData(searchForm.value);
  let result = await list(formData, page.value.currentPage, page.value.pageSize);
  let {current, total, records} = result.data;
  data.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loadingTable.value=false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'view', label: '查看', tag: 'button', type: 'primary',
    handler: () => {openDialog(row)}
  },
  {
    key: 'edit', label: '编辑', tag: 'button', type: 'primary',
    handler: () => open(row, false, '编辑')
  },
  {
    key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
    handler: () => deleteDialog(row)
  },
]

const deleteDialog = async (row: any) => {
  await delById(row);
  search();
  ElMessage.success("删除成功");
}

const handleSave = async () => {
  //编辑
  dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate();
    if (valid) {
      await saveOrUpdate(form.value);
      search();
      close();
      ElMessage.success('修改成功')
    }
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}

const openDialog = async (row: any) => {
  const result = await getById({id: row.id});
  open(result.data, true, '查看');
}

const {dialogData, open, close, closed, form, nameRef: dialogFormRef}: DialogForm<RkFormInstance, any>
    = useDialogForm('dialogFormRef', {type: []})

</script>

<style scoped>

</style>
