import { FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'result',
        label: '比对结果',
        width: 170,
        dictFormatKey: 'compareResult'
    },
    // {
    //     prop: 'hitRate',
    //     label: '命中率',
    //     width: 170,
    // },
    {
        prop: 'dataType',
        label: '数据类型',
        width: 170,
        dictFormatKey: 'dataType'
    },
    {
        prop: 'dataValue',
        label: '数据值',
        width: 300,
    },
    {
        prop: 'dataSource',
        label: '来源',
        width: 170
    },
    {
        prop: 'operate',
        label: '操作标识',
        width: 120,
        dictFormatKey: 'operate'
    },
    {
        prop: 'caseType',
        label: '案件类型',
        width: 250,
        dictFormatKey: 'blackGrayType'
    },
    {
        prop: 'name',
        label: '姓名',
        width: 170,
    },
    {
        prop: 'orgID',
        label: '机构',
        width: 170
    },
    {
        prop: 'operatorName',
        label: '公安联系人',
        width: 170
    },
    {
        prop: 'operatorPhoneNumber',
        label: '公安联系人电话',
        width: 170
    },
    {
        prop: 'branchCode',
        label: '机构代码',
        width: 170,
        dictFormatKey: 'branchTree'
    },
    // {
    //     prop: 'createTime',
    //     label: '创建时间',
    //     width: 120,
    //     // scopedSlots: {
    //     //     default: 'createTime',
    //     // },
    // },

    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'dataType',
        label: '数据类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'dataType',
            multiple: false,
        },
    },
    {
        prop: 'dataValue',
        label: '数据值',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'operate',
        label: '操作标识',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'operate',
            multiple: false,
        },
    },
    {
        prop: 'caseType',
        label: '案件类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'blackGrayType',
            multiple: false,
        },
    },
    {
        prop: 'name',
        label: '姓名',
        labelWidth: 100,
        inputType: 'input',
    },
    /*{
        prop: 'orgID',
        label: '机构',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'caseType',
            multiple: false,
        },
    },*/
    {
        prop: 'orgID',
        label: '机构',
        labelWidth: 100,
        inputType: 'input',
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'dataType',
        label: '数据类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'dataType',
            multiple: false,
        },
    },
    {
        prop: 'dataValue',
        label: '数据值',
        labelWidth: 170,
    },
    {
        prop: 'dataSource',
        label: '来源',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'operate',
        label: '操作标识',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'operate',
            multiple: false,
        },
    },
    {
        prop: 'caseType',
        label: '案件类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'blackGrayType',
            multiple: false,
        },
    },
    {
        prop: 'name',
        label: '姓名',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'orgID',
        label: '机构',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'blackGrayType',
            multiple: false,
        },
    },
    {
        prop: 'operatorName',
        label: '公安联系人',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'operatorPhoneNumber',
        label: '公安联系人电话',
        labelWidth: 170,
        inputType: 'input',
    },
]