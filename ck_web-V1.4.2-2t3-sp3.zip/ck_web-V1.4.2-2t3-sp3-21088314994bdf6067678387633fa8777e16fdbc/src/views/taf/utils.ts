
export const setCjDefaultValueObject = (data: {}) => {
    if (isEmpty(data.startDate)) {
        data.startDate = '-';
    }
    if (isEmpty(data.endDate)) {
        data.endDate = '-';
    }
}

export const setCjDefaultValue = (data: []) => {
    data.map(item => {
        if (item.hasOwnProperty("dpoliceStartDate")) {
            if (isEmpty(item.dpoliceStartDate)) {
                item.dpoliceStartDate = '-';
            }
        }

        if (item.hasOwnProperty("dpoliceEndDate")) {
            if (isEmpty(item.dpoliceEndDate)) {
                item.dpoliceEndDate = '-';
            }
        }

        if (item.hasOwnProperty("startDate")) {
            if (isEmpty(item.startDate)) {
                item.startDate = '-';
            }
        }

        if (item.hasOwnProperty("endDate")) {
            if (isEmpty(item.endDate)) {
                item.endDate = '-';
            }
        }
    })
}

export const isEmpty = (val) => {
    if(val === '' || val === null || val === undefined) {
        return true;
    }
    return false;
}