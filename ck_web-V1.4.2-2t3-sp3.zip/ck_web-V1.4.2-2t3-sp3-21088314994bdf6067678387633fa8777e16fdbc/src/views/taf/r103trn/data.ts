import {FormItemInfo, TableColumnInfo} from "riking-ui";
import { dateFormatter } from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'trxId', label: '流水号', width: 140, sortable: true},
    {prop: 'status', label: '状态', dictFormatKey: 'taf_status', sortable: true,},
    {prop: 'fkStatus', label: '回执状态', dictFormatKey: 'fkStatus', sortable: true},
    {prop: 'jybh', label: '交易编号', width: 140, sortable: true},
    {prop: 'jyqd', label: '交易渠道', width: 140, sortable: true},
    {prop: 'fkzh', label: '付款卡（账）号', width: 140, sortable: true},
    {prop: 'fkhm', label: '付款户名', width: 140, sortable: true},
    {prop: 'skkh', label: '收款银行账号', width: 140, sortable: true},
    {prop: 'skhm', label: 'SKHM', width: 140, sortable: true},
    {prop: 'fksf', label: '付款卡身份证号', width: 140, sortable: true},
    {prop: 'cysj', label: '常用手机', width: 140, sortable: true},
    {prop: 'fkdq', label: '发卡地区', width: 140, sortable: true},
    {prop: 'jyje', label: '交易金额', width: 140, sortable: true},
    {prop: 'jybz', label: '交易币种', width: 140, dictFormatKey: 'currency', sortable: true},
    {prop: 'jysj', label: '交易时间', width: 140, sortable: true},
    {prop: 'mac', label: 'Mac地址', width: 140, sortable: true},
    {prop: 'ip', label: '交易IP', width: 140, sortable: true},
    {prop: 'sbch', label: '设备串号', width: 140, sortable: true},
    {prop: 'ddh', label: '订单号', width: 140, sortable: true},
    {prop: 'shh', label: '商户号', width: 140, sortable: true},
    {prop: 'jyzt', label: '交易状态', width: 140, sortable: true},
    {prop: 'gycs', label: '干预措施', width: 140, sortable: true},
    {prop: 'rzfs', label: '认证方式', width: 140, sortable: true},
    {prop: 'gyjg', label: '干预结果', width: 140, sortable: true},
    {prop: 'yhbm', label: '银行编码', width: 140, sortable: true},
    {prop: 'pcbh', label: '批次编号', width: 140, sortable: true},

    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    { key: 'actions', label: '操作', scopedSlots: 'actions', width: 140, minWidth: 140, fixed: 'right'},
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'trxId', label: '流水号', labelWidth: 80, },
    {prop: 'branchCode', label: '业务操作机构', labelWidth: 80, inputType: {tag: 'tree-select', options: 'branchCode', showCheckbox: true, checkStrictly: true }},
    {prop: 'businessLine', label: '业务线', labelWidth: 80, inputType: { tag: 'select', options: 'businessLine',}},
    {prop: 'status', label: '状态', labelWidth: 80, inputType:  {tag: 'select', options: 'taf_status'}},
    {prop: 'jybh', label: '交易编号', labelWidth: 80},
    {prop: 'jyqd', label: '交易渠道', labelWidth: 80},
    {prop: 'fkzh', label: '付款卡（账）号', labelWidth: 80},
    {prop: 'fkhm', label: '付款户名', labelWidth: 80},
    {prop: 'skkh', label: '收款银行账号', labelWidth: 80},
    {prop: 'skhm', label: '收款户名', labelWidth: 80},
    {prop: 'jybz', label: '交易币种', labelWidth: 80, inputType: {tag: 'select', options: 'currency'}},
    {prop: 'jysj', label: '交易时间', labelWidth: 80, inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'}},
    {prop: 'ddh', label: '订单号', labelWidth: 80},
    {prop: 'fkStatus', label: '回执状态', labelWidth: 80 , inputType:  {tag: 'select', options: 'fkStatus',}},
    {prop: 'createBy', label: '创建人', labelWidth: 80, },
    {prop: 'createTime', label: '创建时间', labelWidth: 80,inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 31, message: '超过31字符限制'}]
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
    },
    {   prop: 'jybh', label: '交易编号', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'jyqd', label: '交易渠道', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'fkzh', label: '付款卡（账）号', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'fkhm', label: '付款户名', labelWidth: 150, inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'skkh', label: '收款银行账号', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'skhm', label: '收款户名', labelWidth: 150, inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'fksf', label: '付款卡身份证号', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 18, message: '超过225字符限制'}]
    },
    {   prop: 'cysj', label: '常用手机', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'fkdq', label: '发卡地区', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'jyje', label: '交易金额', labelWidth: 150,
        inputType: {tag: 'input', type: 'number'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'jybz', label: '交易币种', labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'currency'},
    },
    {   prop: 'jysj', label: '交易时间', labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
            {required: true, message: '必填'},
        ]
    },
    {   prop: 'mac', label: 'Mac地址', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'ip', label: '交易IP', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'sbch', label: '设备串号', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'ddh', label: '订单号', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'shh', label: '商户号', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'jyzt', label: '交易状态', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'gycs', label: '干预措施', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'rzfs', label: '认证方式', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'gyjg', label: '干预结果', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'yhbm', label: '银行编码', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {   prop: 'pcbh', label: '批次编号', labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
]


export default {
    columns,
    searchFormItems,
    formItems,
}
