import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'

export function list( data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: "/accFile/list",
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    })
}

export function delBatch(ids: any): Promise<RS> {
    return service({
        url: "/accFile/del",
        method: 'POST',
        params: {ids},
    })
}

export function saveOrUpdate(data = {}): Promise<RS> {
    return service({
        url: "/accFile/saveOrUpdate",
        method: 'POST',
        data,
    });
}

export function submitAllBatch(data = {}): Promise<RS> {
    return service({
        url: "/accFile/submitAllBatch",
        method: 'POST',
        data,
    })
}

export function submitBatch(ids:any): Promise<RS> {
    return service({
        url: "/accFile/submit",
        method: 'POST',
        params: {ids},
    })
}
export function auditAllBatch(data = {}): Promise<RS> {
    return service({
        url: "/accFile/auditAllBatch",
        method: 'POST',
        data,
    })
}

export function auditNotPassAllBatch(data = {},msg:string): Promise<RS> {
    return service({
        url: "/accFile/auditNotPassAllBatch",
        method: 'POST',
        data,
        params: {msg},
    })
}

export function auditBatch(ids: any): Promise<RS> {
    return service({
        url: "/accFile/audit",
        method: 'POST',
        params: {ids},
    })
}

export function auditNotPassBatch(ids: any,msg:any): Promise<RS> {
    return service({
        url: "/accFile/auditNotPass",
        method: 'POST',
        params: {ids,msg},
    })
}

export function recallBatch(ids: any): Promise<RS> {
    return service({
        url: "/accFile/recall",
        method: 'POST',
        params: {ids},
    })
}

export function resetBatch(ids: any,msg:string): Promise<RS> {
    return service({
        url: "/accFile/reset",
        method: 'POST',
        params: {ids,msg},
    })
}

export function upload(ids:any): Promise<RS> {
    return service({
        url: "/accFile/upload",
        method: 'POST',
        params: {ids},
    })
}

export function getResult(hsy:string,trxId:string): Promise<RS> {
    return service({
        url: "/accFile/getResult",
        method: 'POST',
        params: {hsy,trxId},
    })
}

export function importExcel(data:any): Promise<RS> {
    return service({
        url: "/accFile/importExcel",
        method: 'POST',
        data,
        headers: {'Content-Type': 'multipart/form-data'},
    })
}

export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: "/accFile/exportExcel",
        method: 'POST',
        data,
        params: {ids},
        responseType: 'blob'
    })
}




