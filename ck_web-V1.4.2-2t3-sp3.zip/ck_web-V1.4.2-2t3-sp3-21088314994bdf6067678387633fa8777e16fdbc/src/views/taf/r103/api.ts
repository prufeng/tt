import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'

/**
 * 列表
 * @param data
 * @param paging
 */
export function list( data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: "/farms103/list",
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    });
}

/**
 * 删除
 * @param ids
 */
export function delBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms103/del",
        method: 'POST',
        params: {ids},
    });
}

/**
 * 新增、修改
 * @param data
 */
export function saveOrUpdate(data = {}): Promise<RS> {
    return service({
        url: "/farms103/saveOrUpdate",
        method: 'POST',
        data,
    });
}

export function submitAllBatch(data = {}): Promise<RS> {
    return service({
        url: `/farms103/submitAllBatch`,
        method: 'POST',
        data,
    })
}

export function submitBatch(data:any,ids:any): Promise<RS> {
    return service({
        url: `/farms103/submit`,
        method: 'POST',
        data,
        params: {ids},
    })
}

export function auditAllBatch(data = {}): Promise<RS> {
    return service({
        url: "/farms103/auditAllBatch",
        method: 'POST',
        data,
    })
}

export function auditNotPassAllBatch(data = {},msg:string): Promise<RS> {
    return service({
        url: "/farms103/auditNotPassAllBatch",
        method: 'POST',
        data,
        params: {msg},
    })
}

export function auditBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms103/audit",
        method: 'POST',
        params: {ids},
    })
}

export function auditNotPassBatch(ids: any,msg:any): Promise<RS> {
    return service({
        url: "/farms103/auditNotPass",
        method: 'POST',
        params: {ids,msg},
    })
}

export function recallBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms103/recall",
        method: 'POST',
        params: {ids},
    })
}

export function resetBatch(ids: any,msg:string): Promise<RS> {
    return service({
        url: "/farms103/reset",
        method: 'POST',
        params: {ids,msg},
    })
}