import {FormItemInfo, TableColumnInfo} from "riking-ui";
import { dateFormatter } from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'trxId', label: '流水号', width: 140, sortable: true},
    {prop: 'status', label: '状态', dictFormatKey: 'taf_status', sortable: true,},
    {prop: 'fkStatus', label: '回执状态', dictFormatKey: 'fkStatus', sortable: true},
    {prop: 'fnTp', label: '功能类型', dictFormatKey: 'taf_A19', width: 140, sortable: true},
    {prop: 'instgId', label: '发起参与者', width: 140, sortable: true},
    {prop: 'instdId', label: '接收参与者', width: 140, sortable: true},
    {prop: 'qryDtTm', label: '发起日期时间', width: 140, sortable: true},
    {prop: 'reqTp', label: '请求服务类型', dictFormatKey: 'taf_A18', width: 140, sortable: true},
    {prop: 'bkCardNb', label: '银行卡号', width: 140, sortable: true},
    {prop: 'fileDataContt', label: '文件数据内容', width: 140, sortable: true},
    {prop: 'ustrd', label: '附言', width: 140, sortable: true},
    {prop: 'fkInfo', label: '回执信息',  sortable: true},

    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'trxId', label: '流水号', labelWidth: 80, },
    {prop: 'status', label: '状态', labelWidth: 80 , inputType:  {tag: 'select', options: 'taf_status',}},
    {prop: 'branchCode', label: '业务操作机构', labelWidth: 80 , inputType: {tag: 'tree-select', options: 'branchCode', showCheckbox: true, checkStrictly: true },},
    {prop: 'fnTp', label: '功能类型', labelWidth: 80 , inputType:  {tag: 'select', options: 'taf_A19',}},
    {prop: 'instgId', label: '发起参与者', labelWidth: 80},
    {prop: 'instdId', label: '接收参与者', labelWidth: 80},
    {prop: 'qryDtTm', label: '发起日期时间', labelWidth: 80,inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
    {prop: 'reqTp', label: '请求服务类型', labelWidth: 80 , inputType:  {tag: 'select', options: 'taf_A18',}},
    {prop: 'bkCardNb', label: '银行卡号', labelWidth: 140},
    {prop: 'fileDataContt', label: '文件数据内容', labelWidth: 140},
    {prop: 'fkStatus', label: '回执状态', labelWidth: 80 , inputType:  {tag: 'select', options: 'fkStatus',}},
    {prop: 'createBy', label: '创建人', labelWidth: 80, },
    {prop: 'createTime', label: '创建时间', labelWidth: 80,inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: false},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 31, message: '超过31字符限制'}]
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
    },
    {
        prop: 'fnTp',
        label: '功能类型',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'taf_A19'},
    },
    {
        prop: 'instgId',
        label: '发起参与者',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 14, message: '超过14字符限制'}],
    },
    {
        prop: 'instdId',
        label: '接收参与者',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 14, message: '超过14字符限制'}]
    },
    {
        prop: 'qryDtTm',
        label: '发起日期时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]
    },
    {
        prop: 'reqTp',
        label: '请求服务类型',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'taf_A18',}
    },
    {
        prop: 'bkCardNb',
        label: '银行卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 64, message: '超过64字符限制'}]
    },
    {
        prop: 'ustrd',
        label: '附言',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 256, message: '超过256字符限制'}]
    },
    {
        prop: 'fileDataContt',
        label: '文件数据内容',
        labelWidth: 150,
        // inputType: 'input',
        inputType:{tag: 'input', type: 'textarea'},
        extra: { span: 24 },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}]
    },
]


export default {
    columns,
    searchFormItems,
    formItems,
}
