import {FormItemInfo, TableColumnInfo} from "riking-ui";
import { dateFormatter } from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'trxId', label: '流水号', width: 140, sortable: true},
    {prop: 'status', label: '状态', dictFormatKey: 'taf_status', sortable: true,},
    {prop: 'branchCode', label: '业务操作机构', width: 140, dictFormatKey: 'branchTree', sortable: true},
    {prop: 'fkStatus', label: '回执状态', dictFormatKey: 'fkStatus', sortable: true},
    {prop: 'fnTp', label: '功能类型', dictFormatKey: 'taf_A19', width: 140, sortable: true},
    {prop: 'instgId', label: '发起参与者', width: 140, sortable: true},
    {prop: 'instdId', label: '接收参与者', width: 140, sortable: true},
    {prop: 'dataTrTp', label: '数据用途类型', dictFormatKey: 'taf_A15', width: 140, sortable: true},
    {prop: 'dataTp', label: '数据格式类型', dictFormatKey: 'taf_A16', width: 140, sortable: true},
    {prop: 'dataContt', label: '数据内容', width: 140, sortable: true},
    {prop: 'description', label: '描述', width: 140, sortable: true},
    {prop: 'fkInfo', label: '回执信息',  sortable: true},

    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    { key: 'actions', label: '操作', scopedSlots: 'actions', width: 140, minWidth: 140, fixed: 'right'},
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'trxId', label: '流水号', labelWidth: 80 },
    {prop: 'branchCode', label: '业务操作机构', labelWidth: 80, inputType: {tag: 'tree-select', options: 'branchCode', showCheckbox: true, checkStrictly: true },},
    {prop: 'businessLine', label: '业务线', labelWidth: 80, inputType: { tag: 'select', options: 'businessLine',}},
    {prop: 'status', label: '状态', labelWidth: 80, inputType:  {tag: 'select', options: 'taf_status',}},
    {prop: 'fnTp', label: '功能类型', labelWidth: 80, inputType:  {tag: 'select', options: 'taf_A19',}},
    {prop: 'instgId', label: '发起参与者', labelWidth: 80},
    {prop: 'instdId', label: '接收参与者', labelWidth: 80},
    {prop: 'dataTrTp', label: '数据用途类型', labelWidth: 80, inputType:  {tag: 'select', options: 'taf_A15',}},
    {prop: 'dataTp', label: '数据格式类型', labelWidth: 80, inputType:  {tag: 'select', options: 'taf_A16',}},
    {prop: 'dataContt', label: '数据内容', labelWidth: 80},
    {prop: 'fkStatus', label: '回执状态', labelWidth: 80, inputType:  {tag: 'select', options: 'fkStatus',}},
    {prop: 'createBy', label: '创建人', labelWidth: 80},
    {prop: 'createTime', label: '创建时间', labelWidth: 80,inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 31, message: '超过31字符限制'}]
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
    },
    {
        prop: 'fnTp',
        label: '功能类型',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'taf_A19'},
    },
    {
        prop: 'instgId',
        label: '发起参与者',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 14, message: '超过14字符限制'}],
    },
    {
        prop: 'instdId',
        label: '接收参与者',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 14, message: '超过14字符限制'}]
    },
    {
        prop: 'dataTrTp',
        label: '数据用途类型',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'taf_A15',}
    },
    {
        prop: 'dataTp',
        label: '数据格式类型',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'taf_A16',}
    },
    {
        prop: 'description',
        label: '描述',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 256, message: '超过256字符限制'}]
    },
    {
        prop: 'dataContt',
        label: '数据内容',
        labelWidth: 150,
        // inputType: 'input',
        inputType:{tag: 'input', type: 'textarea'},
        extra: { span: 24 },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}]
    },
]


export default {
    columns,
    searchFormItems,
    formItems,
}
