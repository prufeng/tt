import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'

/**
 * 列表
 * @param data
 * @param paging
 */
export function list( data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: "/farms101/list",
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    });
}

/**
 * 删除
 * @param ids
 */
export function delBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms101/del",
        method: 'POST',
        params: {ids},
    });
}

/**
 * 新增、修改
 * @param data
 */
export function saveOrUpdate(data = {}): Promise<RS> {
    return service({
        url: "/farms101/saveOrUpdate",
        method: 'POST',
        data,
    });
}

export function submitAllBatch(data = {}): Promise<RS> {
    return service({
        url: `/farms101/submitAllBatch`,
        method: 'POST',
        data,
    })
}

export function submitBatch(data:any,ids:any): Promise<RS> {
    return service({
        url: `/farms101/submit`,
        method: 'POST',
        data,
        params: {ids},
    })
}

export function auditAllBatch(data = {}): Promise<RS> {
    return service({
        url: "/farms101/auditAllBatch",
        method: 'POST',
        data,
    })
}

export function auditNotPassAllBatch(data = {},msg:string): Promise<RS> {
    return service({
        url: "/farms101/auditNotPassAllBatch",
        method: 'POST',
        data,
        params: {msg},
    })
}

export function auditBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms101/audit",
        method: 'POST',
        params: {ids},
    })
}

export function auditNotPassBatch(ids: any,msg:any): Promise<RS> {
    return service({
        url: "/farms101/auditNotPass",
        method: 'POST',
        params: {ids,msg},
    })
}

export function recallBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms101/recall",
        method: 'POST',
        params: {ids},
    })
}

export function resetBatch(ids: any,msg:string): Promise<RS> {
    return service({
        url: "/farms101/reset",
        method: 'POST',
        params: {ids,msg},
    })
}

export function uploadTaf101(ids:any): Promise<RS> {
    return service({
        url: "/farms101/uploadTaf",
        method: 'POST',
        params: {ids},
    })
}

export function checkExcelData(data:any): Promise<RS> {
    return service({
        url: `/farms101/checkExcelData`,
        method: 'POST',
        data,
        headers: {'Content-Type': 'multipart/form-data',}
    })
}

export function importExcel(data:any): Promise<RS> {
    return service({
        url: `/farms101/importExcel`,
        method: 'POST',
        data,
        headers: {'Content-Type': 'multipart/form-data'},
    })
}

export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: `/farms101/exportExcel`,
        method: 'POST',
        data,
        params: {ids},
        responseType: 'blob'
    })
}