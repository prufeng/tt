<template>
  <el-dialog v-model="props.visible" title="确认" width="30%" draggable :append-to-body=true>
    <span>请确认反馈结果是否正确</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="cancel">取消</el-button>
        <el-button type="primary" @click="confirm">
          确认
        </el-button>
      </span>
    </template>
  </el-dialog>
</template>


<script setup lang="ts">
import {ElButton, ElDialog} from "element-plus";

const emits = defineEmits(['callback'])

const props = defineProps({visible: false})

// const visible = ref(false);

const cancel = () => {
  emits('callback', false);
}

const confirm = () => {
  emits('callback', true);
}

watch(() => props.visible, (val) => {
  props.visible = val;
})



</script>

<style scoped>

</style>