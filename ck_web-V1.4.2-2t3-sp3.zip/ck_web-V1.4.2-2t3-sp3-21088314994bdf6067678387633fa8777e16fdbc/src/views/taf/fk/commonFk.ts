/**
 * 100302 账户信息：开户日期 、销户日期; 关联子账户：最后交易时间; 交易明细：交易日期
 * 100304 账户持卡主体信息：开户日期、销户日期
 * 100310 账户信息：开户日期、销户日期; 关联子账户：最后交易时间
 */

// 前端非空交易，接口去掉校验
const defaultProps = [
    'accountOpenTime',
    'accountCancellationTime',
    'lastTransactionTime',
    // 'transactionTime',
]

const defaultDateValue = '1970-01-02 00:00:00';

/**
 * 开关控制 'accountOpenTime', 'accountCancellationTime', 'lastTransactionTime' 为空时，前端显示 “-”
 */
export const convertNullDateToLine = (reportCode: string, formValues: {}) => {
    const reportCodes = ['100302', '100304', '100310']
    if(!reportCodes.includes(reportCode)) {
        return;
    }
    defaultProps.map(field => {
        if (formValues.hasOwnProperty(field)) {
            const value = formValues[field];
            if (value === null || value === '') {
                formValues[field] = "-"
            }
        }
    })
}

export const setDefaultDateValue = (data: {}) => {
    defaultProps.map(p => {
        if (!data.hasOwnProperty(p)) {
            return;
        }
        let value = data[p];
        if (value == undefined || value == '' || value == '-') {
            data[p] = defaultDateValue;
        }
    })
}

export const clearDefaultDateValue = (data: {}) => {
    defaultProps.map(p => {
        if (!data.hasOwnProperty(p)) {
            return;
        }
        let value = data[p];
        if (value == defaultDateValue) {
            data[p] = null;
        }
    })
}


/**
 * 判断是否存在有效字典
 */
export const validateSwitchDict = (dictData: {}, typeCode: string) => {
    let dict = dictData[typeCode]
    if (dict != undefined) {
        return true
    }
    return false
}

/**
 * 东方会理优化需求--以下科目设置不可编辑--添加开关控制  -showFLag
 */
const disabledFieldsConfig = new Map();
disabledFieldsConfig.set("100102", ['accountNumber', 'accountName', 'accountCredentialType', 'accountCredentialNumber', 'feedbackOrgName'])
disabledFieldsConfig.set("100104", ['accountNumber', 'feedbackOrgName'])
disabledFieldsConfig.set("100202", ['accountNumber', 'accountName', 'accountCredentialType', 'accountCredentialNumber', 'feedbackOrgName'])
disabledFieldsConfig.set("100204", ['accountNumber', 'appliedBalance', 'feedbackOrgName'])
disabledFieldsConfig.set("100206", ['accountNumber', 'feedbackOrgName'])
disabledFieldsConfig.set("100302", ['feedbackOrgName'])
disabledFieldsConfig.set("100304", ['feedbackOrgName'])
disabledFieldsConfig.set("100310", ['feedbackOrgName'])
disabledFieldsConfig.set("100604", ['accountNumber', 'accountSubjectName', 'feedbackOrgName', 'batchNo', 'feedbackOrgId'])
disabledFieldsConfig.set("100714", ['feedbackOrgId', 'account'])

export const dynamicSetItemDisabled = (reportCode: string, formItems: []) => {
    const disabledFields = disabledFieldsConfig.get(reportCode)
    if (disabledFields == undefined) {
        return formItems;
    }
    formItems.filter(item => disabledFields.includes(item.prop)).map(item =>  {
        if(item.inputType === 'input') {
            item.inputType = {tag: 'input', disabled: true}
        }
        if(item.inputType != undefined && item.inputType.constructor === Object) {
            item.inputType = {...item.inputType, disabled: true}
        }
    });
    return formItems;
}

export const isEmpty = (val) => {
    if(val === '' || val === null || val === undefined) {
        return true;
    }
    return false;
}