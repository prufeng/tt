<template>
  <rk-collapse-form
    :form-items="formItems"
    :collapse-model-value="activeCollapse"
    v-model="form"
    disabled="true"
    ref="nameRef"
  >
  </rk-collapse-form>
  <div v-if="reportCode == '100701' || reportCode == '100703'">
    <h4>惩戒公安机关列表</h4>
    <rk-table :columns="columnsPolice" :data="tableDatePolice" @refresh="search" :hidden-table-tools="true"> </rk-table>
  </div>
  <div v-if="reportCode == '100703'">
    <h4>解除惩戒公安机关列表</h4>
    <rk-table :columns="columnsRPolice" :data="tableDateRPolice" @refresh="search" :hidden-table-tools="true"> </rk-table>
  </div>
  <div v-if="reportCode === '100701' || reportCode == '100703'">
    <h4>惩戒对象证件列表</h4>
    <rk-table :columns="columnsObject" :data="tableDateObject" @refresh="search" :hidden-table-tools="true"> </rk-table>
  </div>
  <div class="btnDiv">
    <rk-button-group :buttons="buttons" :route-meta="$route.meta" />
  </div>

  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 文件列表按钮 -->
    <el-button
      v-for="xmlKey in xmlButtonKeys"
      :key="xmlKey"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="
        reportCode == '100701' || reportCode == '100703' ? fileDownload(xmlKey, xmlDataList[xmlKey]) : openFile(xmlKey)
      "
    >
      {{ xmlKey }}
    </el-button>
  </el-dialog>

  <div class="img-viewer-box">
    <el-image-viewer
      v-if="showImageViewer"
      :url-list="urlList"
      @close="
        () => {
          showImageViewer = false
        }
      "
    />
  </div>
</template>

<script setup lang="ts">
import { RkButtonGroup, RkCollapseForm } from 'riking-ui'
import configs from '@/views/taf/cx/config/sum'
import configsCj from '@/views/taf/cx_chengjie/config/sum'

import { getByApplicationIDAndTrxId } from '@/views/taf/fk/api'
import { getAllFile } from '@/views/taf/cx/api'
import { ElButton, ElDialog, ElImageViewer, ElMessage } from 'element-plus'
import { ref } from 'vue'
import { getObjectList, getPoliceList, getRemovePoliceList, list, wsApply } from '../cx_chengjie/api'
import { checkFileIsExists, downloadFile, getFile } from '../r303/api'
import {setCjDefaultValue, setCjDefaultValueObject} from "@/views/taf/utils";

const activeCollapse = ref([])

const loading = ref(false)
const form = ref({})
const xmlButtonKeys = ref({})
const xmlDataList = ref({})
const showImageViewer = ref(false) //组件是否显示
const urlList = ref([]) //图片List
const dialogVisible = ref(false)
let columnsPolice: any[] = []
let columnsRPolice: any[] = []

let columnsObject: any[] = []
const tableDateObject = ref<any[]>([])
const tableDatePolice = ref<any[]>([])
const tableDateRPolice = ref<any[]>([])

const delayFormRender = ref(false)
const buttons = ref<any[]>([])
const props = defineProps(['fkReportCode', 'visible', 'trxId', 'applicationID'])

// const reportCode = configs.reportCodeMap.get(props.fkReportCode)

// let formItems = configs['config' + reportCode].formItems;
let reportCode
let formItems
if (props?.fkReportCode == '100702' || props?.fkReportCode == '100704') {
  reportCode = configsCj.reportCodeMap.get(props.fkReportCode)
  formItems = configsCj['config' + reportCode].formItems
  columnsPolice = configsCj['config' + reportCode].columnsPolice
  if (props?.fkReportCode == '100704') {
    columnsRPolice = configsCj['config' + reportCode].columnsRPolice
  }
  columnsObject = configsCj['config' + reportCode].columnsObject
} else {
  reportCode = configs.reportCodeMap.get(props.fkReportCode)
  formItems = configs['config' + reportCode].formItems
}

formItems.map((item) => {
  if (item.extra.collapse.title.includes('请求')) {
    return
  }
  const title = '请求' + item.extra.collapse.title
  item.extra.collapse.title = title
})

onMounted(() => {
  activeCollapse.value = []
  search()
})

watch(
  () => props.visible,
  (newVal) => {
    if (newVal) {
      search()
    }
  },
)

const getDobjectList = async (row) => {
  let params = {
    dobjectId: row.dobjectId,
    applicationID: row.applicationID,
    txCode: row.txCode,
    transSerialNumber: row.transSerialNumber,
  }
  let res2 = await getObjectList(params)
  if (res2?.success) {
    tableDateObject.value = res2?.result?.records || []
  }
  if (reportCode == '100701' || reportCode == '100703') {
    let res = await getPoliceList(params)
    if (res?.success) {
      tableDatePolice.value = res?.result?.records || []
      setCjDefaultValue(tableDatePolice.value);
    }
  } 
   if (reportCode == '100703') {
    let res = await getRemovePoliceList(params)
    if (res?.success) {
      tableDateRPolice.value = res?.result?.records || []
      setCjDefaultValue(tableDatePolice.value);
    }
  }
}
const search = async () => {
  loading.value = true
  try {
    const result = await getByApplicationIDAndTrxId(reportCode, props.applicationID, props.trxId)

    if (result?.data) {
      if (reportCode == '100701' || reportCode == '100703') {
        getDobjectList(result.data)
      }
    }

    setCjDefaultValueObject(result.data);

    form.value = result.data
  } finally {
    loading.value = false
  }
}

//文件下载
const fileDownload = async (fileName: string, trxId: string) => {
  let res = await checkFileIsExists(fileName, trxId)
  if (res.code == 200) {
    // window.location.href = import.meta.env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX + "/farms303/downloadFile?id="+res.result;
    await downloadFile(res.result)
  } else {
    ElMessage.warning('文件不存在，无法下载')
  }
}
const openFile = (key: string) => {
  // 将base64字符串转换为Uint8Array对象
  console.log(xmlDataList.value[key])
  var data = atob(xmlDataList.value[key])
  var dataArray = new Uint8Array(data.length)
  for (var i = 0; i < data.length; i++) {
    dataArray[i] = data.charCodeAt(i)
  }
  if (key.toLocaleLowerCase().endsWith('pdf')) {
    // let pdfWindow = window.open('', 'pdf预览')
    let pdfWindow = window.open('')
    // 创建Blob对象
    const pdfBlob = new Blob([dataArray], { type: 'application/pdf' })
    // 将Blob对象转换为URL
    const pdfUrl = URL.createObjectURL(pdfBlob)
    // 将URL作为iframe的src属性值
    pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>")
  } else if (key.toLocaleLowerCase().endsWith('jpg')) {
    // 创建Blob对象
    const jpgBlob = new Blob([dataArray], { type: 'image/jpeg' })
    // 将Blob对象转换为URL
    const jpgUrl = URL.createObjectURL(jpgBlob)
    showImageViewer.value = true
    urlList.value = [jpgUrl]
  } else if (key.toLocaleLowerCase().endsWith('png')) {
    // 创建Blob对象
    const jpgBlob = new Blob([dataArray], { type: 'image/jpeg' })
    // 将Blob对象转换为URL
    const jpgUrl = URL.createObjectURL(jpgBlob)
    showImageViewer.value = true
    urlList.value = [jpgUrl]
  } else if (key.toLocaleLowerCase().endsWith('xml')) {
    // 创建Blob对象
    const xmlBlob = new Blob([dataArray], { type: 'text/xml' })
    // 将Blob对象转换为URL
    const xmlUrl = URL.createObjectURL(xmlBlob)
    let xmlWindow = window.open(xmlUrl, 'xml预览')
  } else if (key.toLocaleLowerCase().endsWith('txt')) {
    // 创建Blob对象
    const xmlBlob = new Blob([dataArray], { type: 'txt' })
    // 将Blob对象转换为URL
    const xmlUrl = URL.createObjectURL(xmlBlob)
    let xmlWindow = window.open(xmlUrl, 'txt预览')
  } else {
    ElMessage.error({ message: '暂不支持打开此种类型的文件', grouping: true, showClose: true, duration: 0 })
  }
}

function clear() {
  nameRef.value?.clearValidate()
}

const button = [
  {
    key: 'view',
    label: '预览请求附件',
    tag: 'button',
    type: 'primary',
    handler: async () => {
      const params = {
        trxId: form.value.trxId,
        applicationID: form.value.applicationID,
        transSerialNumber: form.value.transSerialNumber,
      }
      const result = await getAllFile(reportCode, params)
      const keys = Object.keys(result.data)
      xmlButtonKeys.value = keys
      xmlDataList.value = result.data
      console.log(keys)
      dialogVisible.value = true
    },
  },
]

watch(
  () => form.value,
  (newVal) => {
    if (newVal) {
      let arr = button
      if (newVal.txCode == '100701' || newVal.txCode == '100703') {
        if (newVal?.wsApplyFlag == '2') {
          arr = [
            {
              key: 'view',
              label: '文书预览',
              tag: 'button',
              type: 'primary',
              handler: async () => {
                const params = {
                  // trxId: form.value.trxId,
                  // applicationID: '0701C2031675190606290011881425369941',
                  applicationOriID: form.value.applicationID,
                  // transSerialNumber: form.value.transSerialNumber,
                }
                let res = await list('100707', params, 1, 1)
                if (!res?.data?.records?.length > 0) return ElMessage.error({ message: '没有文书可预览' })
                const result = await getFile({
                  trxId: res.data.records[0].trxId,
                })
                const values = Object.keys(result.data)
                xmlDataList.value = result.data
                xmlButtonKeys.value = values
                dialogVisible.value = true
                // const result = await getAllFile(reportCode, params)
                // const keys = Object.keys(result.data)
                // xmlButtonKeys.value = keys
                // xmlDataList.value = result.data
                // console.log(keys)
                // dialogVisible.value = true
              },
            },
          ]
        } else {
          arr = [
            {
              key: 'view',
              label: '文书申请',
              tag: 'button',
              type: 'primary',
              handler: async () => {
                let res = await wsApply(newVal.txCode, {
                  id: newVal.id,
                })
                if (res?.success) {
                  ElMessage.success(res.msg)
                  form.value = {
                    ...newVal,
                    wsApplyFlag: '2',
                  }
                }
              },
            },
          ]
        }
      }

      buttons.value = arr
    }
  },
)
</script>

<style scoped>
.btnDiv {
  margin: 20px 0 20px 0;
  display: flex;
  flex-direction: row-reverse;
}
</style>
