import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";


export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'trxId', label: '流水号', minWidth: 230, Width: 230, sortable: true},
    {prop: 'applicationID', label: '业务申请编号', minWidth: 230, Width: 230, sortable: true},
    // {prop: 'transSerialNumber', label: '传输报文流水号', minWidth: 200, Width: 200, sortable: true},
    {prop: 'status', label: '状态', minWidth: 50,  Width: 50, dictFormatKey: 'taf_status', sortable: true, scopedSlots: 'status'},
    {prop: 'deleteState', label: '删除状态', minWidth: 50,  Width: 50, dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true},
    {prop: 'fkStatus', label: '回执状态', minWidth: 50,  Width: 50, dictFormatKey: 'fkStatus', sortable: true},
    {prop: 'fkInfo', label: '回执信息', minWidth: 50,  Width: 50, sortable: true},
    {prop: 'result', label: '反馈结果', minWidth: 200, Width: 200, sortable: true, dictFormatKey: 'result'},
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    {prop: 'operatorName', label: '经办人姓名', minWidth: 100, Width: 100, sortable: true},
    {prop: 'branchCode', label: '业务操作机构', minWidth: 150, Width: 150, dictFormatKey: 'branchTree', sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 100, Width: 100, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 150, Width: 150, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 100, Width: 100, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 150, Width: 150, formatter: dateFormatter, sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 100, Width: 100, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 150, Width: 150, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 100, Width: 100, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 150, Width: 150, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140, Width: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'applicationID', label: '业务申请编号', inputType: 'input',},
    {
        prop: 'branchCodeList', label: '业务操作机构', inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
            collapseTags: true,
            maxCollapseTags: 1
        },
    },
    {
        prop: 'businessLine', label: '业务线',
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'onlyQuerySucceeded',
        label: '匹配成功',
        labelWidth: 50,
        // scopedSlot: 'onlyQuerySucceeded',
        // inputType: {tag: 'checkbox', checked: "checked"},
        inputType: {tag:'checkbox'},
    }
]

export const formItems: FormItemInfo[] = [
    // {
    //     prop: 'transSerialNumber',
    //     label: '传输报文流水号',
    //     inputType: 'input',
    //     labelWidth: 150,
    //     rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 53, message: '超过53字符限制'}]
    // },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true},
        rules: [{required: true, message: '必填'}],
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 36,
            message: '超过36字符限制'
        }]
    },
    {
        prop: 'caseType',
        label: '案件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'caseType',
            multiple: false,
            disabled: true
        },
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'result',
        label: '反馈结果',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'result'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 4,
            message: '超过4字符限制'
        }]
    },
    {
        prop: 'operatorName',
        label: '经办人姓名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 60,
            message: '超过60字符限制'
        }]
    },
    {
        prop: 'operatorPhoneNumber',
        label: '经办人电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 30,
            message: '超过30字符限制'
        }]
    },
    {
        prop: 'feedbackOrgName',
        label: '反馈机构名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 255,
            message: '超过255字符限制'
        }]
    },
    {
        prop: 'feedbackOrgId',
        label: '反馈机构编码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 12,
            message: '超过12字符限制'
        }]
    },
    {
        prop: 'accountSubjectName',
        label: '开户主体名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 150,
            message: '超过150字符限制'
        }]
    },
    {
        prop: 'accountNumber',
        label: '账号（卡号）',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 50,
            message: '超过50字符限制'
        }]
    },
    {
        prop: 'accountType',
        label: '卡片对应账户类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'CardAccountType'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 1,
            message: '超过1字符限制'
        }]
    },
    {
        prop: 'itselfUses',
        label: '目前是否本人使用',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 1,
            message: '超过1字符限制'
        }]
    },
    {
        prop: 'holderName',
        label: '持卡人姓名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 60,
            message: '超过60字符限制'
        }]
    },
    {
        prop: 'holderNumber',
        label: '持卡人身份证号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 60,
            message: '超过60字符限制'
        }]
    },
    {
        prop: 'cardsNumber',
        label: '持卡人名下本行银行卡数量',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 10,
            message: '超过10字符限制'
        }]
    },
    {
        prop: 'februaryResults',
        label: '持卡人和账户异常排查结果',
        labelWidth: 150,
        inputType: {tag: 'input', type: 'textarea', maxlength: '500'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 500,
            message: '超过500字符限制'
        }]
    },
    {
        prop: 'measurestobeTaken',
        label: '拟采取风控措施',
        labelWidth: 150,
        inputType: {tag: 'input', type: 'textarea', maxlength: '500'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 500,
            message: '超过500字符限制'
        }]
    },
    {
        prop: 'accountStatus',
        label: '账户状态',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'AccountStatus'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 1,
            message: '超过1字符限制'
        }]
    },
    {
        prop: 'verificationControl',
        label: '风险核实及管控情况',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'VerificationControl'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 1,
            message: '超过1字符限制'
        }]
    },
    {
        prop: 'measure',
        label: '控制措施',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'Measure',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 1,
            message: '超过1字符限制'
        }]
    },
    {
        prop: 'controlDate',
        label: '管控日期',
        labelWidth: 150,
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'},
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },

    },
    {
        prop: 'query',
        label: '公安机关是否对该账户实施查询',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'Query',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 1,
            message: '超过1字符限制'
        }]
    },
    {
        prop: 'freeze',
        label: '公安机关是否对该账户实施冻结',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'Freeze',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 1,
            message: '超过1字符限制'
        }]
    },
    {
        prop: 'stopPayment',
        label: '公安机关是否对该账户实施止付',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'StopPayment',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: true, message: '必填'},
            {max: 1, message: '超过1字符限制'}]
    },
    {
        prop: 'batchNo',
        label: '批次号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {
            max: 50,
            message: '超过50字符限制'
        }]
    },
    {
        prop: 'feedbackRemark',
        label: '查询反馈说明',
        labelWidth: 150,
        inputType: {tag: 'input', type: 'textarea', maxlength: '450'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'}, {
            max: 450,
            message: '超过450字符限制'
        }]
    }, {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
]


export const advancedQueryItems = [
    {value: 'trxId', label: '流水号', inputType: 'input'},
    {value: 'applicationID', label: '业务申请编号', inputType: 'input'},
    {value: 'fkStatus', label: '回执状态', inputType: {tag: 'select', options: 'fkStatus'}},
    {value: 'fkInfo', label: '回执信息', inputType: 'input'},
    {value: 'result', label: '反馈结果', inputType: {tag: 'select', options: 'result'}, labelWidth: 100,},
    {value: 'operatorName', label: '经办人姓名', inputType: 'input', labelWidth: 100},
    {
        value: 'status',
        label: '状态',
        inputType: {tag: 'select', options: 'taf_status', multiple: false,},
        labelWidth: 100
    },

    // {value: 'trxId', label: '流水号', labelWidth: 100, inputType: 'input'},
    {value: 'deleteState', label: '删除状态', inputType: {tag: 'select', options: 'deleteStatusList'}, labelWidth: 100},
    // {value: 'fkStatus', label: '回执状态', inputType: {tag: 'select', options: 'fkStatus'}, labelWidth: 100},
    // {value: 'fkInfo', label: '回执信息', labelWidth: 100, inputType: 'input'},
    {value: 'importType', label: '导入方式', inputType: {tag: 'select', options: 'importType'}, labelWidth: 100},
    {
        value: 'create_by',
        label: '创建人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'update_by',
        label: '修改人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'update_time',
        label: '修改时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'submit_by',
        label: '提交人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'submit_time',
        label: '提交时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'approve_by',
        label: '审核人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'approve_time',
        label: '审核时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
]

export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems
}



































