import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const name = '账户信息';
export const listName = 'fkAccountTaf';
export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status'},
    {prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState',sortable: true },
    {prop: 'accountName', label: '主账户名称', minWidth: 150, sortable: true},
    {prop: 'cardNumber', label: '主账户', minWidth: 150, sortable: true},
    {prop: 'depositBankBranch', label: '开户网点', minWidth: 150, sortable: true},
    {prop: 'depositBankBranchCode', label: '开户网点代码', minWidth: 150, sortable: true},
    {prop: 'depositBankAdminisCode', label: '开户网点所属行政区划代码', minWidth: 150, sortable: true, dictFormatKey: "areaCode"},
    {prop: 'accountOpenTime', label: '开户日期', minWidth: 150,sortable: true},
    {prop: 'accountCancellationTime', label: '销户日期', minWidth: 150,sortable: true},
    {prop: 'accountCancellationBranch', label: '销户网点', minWidth: 150, sortable: true},
    {prop: 'accountCredentialType', label: '查询证照类型代码', minWidth: 150, sortable: true, dictFormatKey: 'idType'},
    {prop: 'accountCredentialNumber', label: '查询证照号码', minWidth: 150, sortable: true},
    {prop: 'accountSubjectName', label: '查询主体名称', minWidth: 150, sortable: true},
    {prop: 'telNumber', label: '联系手机', minWidth: 150, sortable: true},
    {prop: 'cardOperatorName', label: '帐/卡代办人姓名', minWidth: 150, sortable: true},
    {prop: 'cardOperatorCredentialType', label: '帐/卡代办人证件类型', minWidth: 150, dictFormatKey: 'idType', sortable: true},
    {prop: 'cardOperatorCredentialNumber', label: '帐/卡代办人证件号码', minWidth: 150, sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200   ,sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter   ,sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'txCode', label: '交易类型编码', inputType: 'input', labelWidth: 100},
    {prop: 'transSerialNumber', label: '传输报文流水号', inputType: 'input', labelWidth: 100},
    {
        prop: 'messageFrom', label: '发送机构',
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: true,
        },
        labelWidth: 100
    },
    {
        prop: 'status', label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
            multiple: true,
        },
        labelWidth: 100
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '部门编码必填' },{ max: 50, message: '部门编码最大长度为50' }],
    },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{required: true, message: '必填'}],
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 36, message: '超过36字符限制'}]
    },
    {
        prop: 'accountName',
        label: '主账户名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 180, message: '超过180字符限制'}]
    },
    {
        prop: 'cardNumber',
        label: '主账户',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'depositBankBranch',
        label: '开户网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'depositBankBranchCode',
        label: '开户网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'depositBankAdminisCode',
        label: '开户网点所属行政区划代码',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'areaCode'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 6, message: '超过6字符限制'}]
    },
    {prop: 'accountOpenTime', label: '开户日期', labelWidth: 150,rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'}],
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},},
    {
        prop: 'accountCancellationTime',
        label: '销户日期',
        labelWidth: 150
        ,rules: [
            {pattern:'^[^<>&]*$',message: '存在特殊字符'},
            {required: true, message: '必填'},
            // {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'}
        ],
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},},
    {
        prop: 'accountCancellationBranch',
        label: '销户网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },

    // todo 以下字段在本页面不存在， 需确认哪个页面要用， 分开配置
    {
        prop: 'accountCredentialType',
        label: '查询证照类型代码',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'idType'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 2, message: '超过2字符限制'}]
    },
    {
        prop: 'accountCredentialNumber',
        label: '查询证照号码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'accountSubjectName',
        label: '查询主体名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 150, message: '超过150字符限制'}]
    },
    {
        prop: 'telNumber',
        label: '联系手机',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'cardOperatorName',
        label: '帐/卡代办人姓名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 90, message: '超过90字符限制'}]
    },
    {
        prop: 'cardOperatorCredentialType',
        label: '帐/卡代办人证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'idType',
        },
    },
    {
        prop: 'cardOperatorCredentialNumber',
        label: '帐/卡代办人证件号码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'residentAddress',
        label: '住宅地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'residentTelNumber',
        label: '住宅电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'workCompanyName',
        label: '工作单位',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 150, message: '超过150字符限制'}]
    },
    {
        prop: 'workAddress',
        label: '单位地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'workTelNumber',
        label: '单位电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'emailAddress',
        label: '邮箱地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 60, message: '超过60字符限制'}]
    },
    {
        prop: 'artificialPersonRep',
        label: '法人代表',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 60, message: '超过60字符限制'}]
    },
    {
        prop: 'artificialPersonRepCredentialType',
        label: '法人代表证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'idType',
        },
    },
    {
        prop: 'artificialPersonRepCredentialNumber',
        label: '法人代表证件号码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'businessLicenseNumber',
        label: '客户原工商注册号码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 18, message: '超过18字符限制'}]
    },
    {
        prop: 'stateTaxSerial',
        label: '国税纳税号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'localTaxSerial',
        label: '地税纳税号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {prop: 'credentialExpiryDate', label: '证照失效日期', labelWidth: 150, inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'}},
    {
        prop: 'remark',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
        rules: [{required: false, message: '必填'}, {max: 450, message: '超过450字符限制'}]
    }
]


export default {
    name,
    columns,
    searchFormItems,
    formItems,
    listName
}



































