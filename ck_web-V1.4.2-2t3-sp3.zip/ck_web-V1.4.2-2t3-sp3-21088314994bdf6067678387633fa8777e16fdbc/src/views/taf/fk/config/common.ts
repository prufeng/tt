/*
import {ref} from "vue";
import {dictFormatter, Pagination, RkFormInstance} from "riking-ui";
import {pagination, subPagination} from "@/views/taf/fk/config/data";
import {
    auditAllBatch,
    auditBatch, auditNotPassAllBatch, auditNotPassBatch,
    delBatch, exportExcel,
    list, listByApplicationID, recallBatch,
    resetBatch,
    subAuditBatch, subAuditNotPassBatch, subDelBatch, submitAllBatch,
    submitBatch, subRecallBatch,
    subResetBatch,
    subSubmitBatch
} from "@/views/taf/fk/api";
import configs from "@/views/taf/fk/config/sum";
import {Action, ElMessage} from "element-plus";
import useDictsStore from '@/store/dictStore';
import {useDict} from "riking-layout";
import {getRequestClassificationCode} from "@/utils/subSystem";
import {listBusinessLine} from "@/views/query/feedback/api";
// TODO 启动时加载，不在页面里调用   子系统设置
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
useDict([], [], dictData)

export const activeName = ref('first')
export const data = ref<any []>([]);
export const subData = ref<any []>([]);
export const page = ref<Pagination>(pagination);
export const subPage = ref<Pagination>(subPagination);
export const searchFormRef = ref<RkFormInstance>()
export const searchForm = ref({ businessLine: '' });

export async function getBusinessLine() {
    try {
        const res = await listBusinessLine();
        const data1 = res.data;

        if (data1.length === 0) {
            ElMessage.error("用户未配置业务线,无法查询数据");
            searchForm.value.businessLine = '';
        } else {
            searchForm.value.businessLine = data1[0].value;
        }
    } catch (error) {
        console.error('Error fetching business line:', error);
    }finally {
        search();
    }
}
export const applicationID = ref("")
export const transSerialNumber = ref("")
export const reportCode = ref(''); // 报文编号
export const status = ref("")
export let columns: any[] = [], formItems: any[] = [], searchFormItems: any[] = [], advancedQueryItems: any[] = []
export let subTables: any[] = []
export const loading = ref(false);
export const loadingSub = ref(false);
export const auditDialog = ref(false);
export const subAuditDialog = ref(false);
export const msgDialog = ref(false);
export const subMsgDialog = ref(false);
export const msg = ref("")
export const txCode = ref("");

//主表查询方法
export const search = async () => {
    loading.value = true;
    try {
        const result = await list(reportCode.value, searchForm.value, page.value.currentPage, page.value.pageSize);
        const {current, total, records} = result.data;
        data.value = records;
        page.value.currentPage = current;
        page.value.total = total;
    }finally {
        loading.value = false;
    }
}
//获取主表页面字段配置与表单配置
export const getConfigs = () => {
    // 获取当前路由
    // const router = useRouter()
    const route = useRoute()
    const path = route.path;
    reportCode.value = getRequestClassificationCode();
    const key = `config${reportCode.value}`
    const obj = (configs as any)[key];
    columns = obj['columns'];
    formItems = obj['formItems'];
    searchFormItems = obj['searchFormItems'];
    advancedQueryItems = obj['advancedQueryItems'];
    getSubConfigs();
}
//获取从表页面字段配置与表单配置
const getSubConfigs = () => {
    let keyList: string[] = [];
    switch (reportCode.value){
        case'100302':
            keyList = ['configAccount', 'configAccountSub', 'configTransaction'];break
        case'100306':
            keyList = ['configTransaction'];break
        case'100310':
            keyList = ['configAccount100310', 'configAccountSub', 'configMeasure','configPriority'];break
        case'100406':
            keyList = ['configDoubtfulAccounts'];break
    }
    const list = []
    for (const key in keyList) {
        const obj = (configs as any)[keyList[key]];
        console.log(obj);
        console.log(keyList[key]);
        list.push({name:obj.name,items:obj.formItems, columns:obj.columns,listName:obj.listName})
    }
    subTables = list;
}
//主表页面变更触发方法
export const pageChange = (p: Pagination) => {
    page.value = p
    search()
}
//子表页面变更触发方法
export const subPageChange = (p: Pagination) => {
    subPage.value = p
    handleClick(undefined)
}

//主表提交方法
export const submit = async (ids: string) => {
    if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
    }
    const rs = await submitBatch({},reportCode.value,ids);
    await search();
    status.value=status.value = dictFormatter("2",dictData.dataStatus)
    // close();
    status.value = status.value = dictFormatter("2", dictData.dataStatus)
    ElMessage.success(rs.data);
}

//主表提交方法,详细页面保存
export const submitAndSave = async (data:any,ids: string) => {
    if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
    }
    const rs = await submitBatch(data,reportCode.value,ids);
    await search();
    status.value=status.value = dictFormatter("2",dictData.dataStatus)
    // close();
    status.value = status.value = dictFormatter("2", dictData.dataStatus)
    ElMessage.success(rs.data);
}

//主表审核方法
export const audit = async (ids: any) => {
    try {
        if (ids == undefined || ids.length == 0) {
            ElMessage.warning('请先选择数据')
            return
        }
        const rs =  await auditBatch(reportCode.value,ids);
        status.value = status.value = dictFormatter("3", dictData.dataStatus)
        ElMessage.success(rs.data);
    }finally {
        auditDialog.value = false;
        await search();
    }
}

export const auditNotPass = async (ids: any) => {
    try {
        if (ids == undefined || ids.length == 0) {
            ElMessage.warning('请先选择数据')
            return
        }
        const rs =  await auditNotPassBatch(reportCode.value,ids,msg.value);
        status.value=status.value = dictFormatter("6",dictData.dataStatus)
        ElMessage.success(rs.data);
    }finally {
        msgDialog.value = false;
        auditDialog.value = false;
        await search();
    }
}

//主表重置方法
export const reset = async (ids: string) => {
    if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
    }

    ElMessageBox.prompt('重置原因', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
        .then(async ({value}) => {
            const rs = await resetBatch(reportCode.value,ids,value);
            await search();
            status.value = status.value = dictFormatter("1", dictData.dataStatus)
            ElMessage.success(rs.data);
        })
        .catch(() => {
            return;
        })

}
//主表撤回方法
export const recall = async (ids: string) => {
    if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
    }
    const rs = await recallBatch(reportCode.value,ids);
    await search();
    status.value = status.value = dictFormatter("1", dictData.dataStatus)
    ElMessage.success(rs.data);
}

//主表批量删除方法
export const del = async (ids: string) => {
    if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
    }
    const rs = await delBatch(reportCode.value,ids);
    await search();
    ElMessage.success(rs.data);
}

//子表提交方法
export const subSubmit = async (ids: string, name: string) => {
    if (ids == undefined || ids.length == 0) {
        subSubmitAll(name);
        return
    }
    const rs = await subSubmitBatch(ids, name);
    await handleClick(undefined);
    ElMessage.success(rs.data);
}

//子表审核方法
export const subAudit = async (ids: any, name: string) => {
    try {
        if (ids == undefined || ids.length == 0) {
            ElMessage.warning('请先选择数据')
            return
        }
        const rs = await subAuditBatch(ids, name);
        ElMessage.success(rs.data);
    }finally {
        subAuditDialog.value = false;
        await handleClick(undefined);
    }
}

export const subAuditNotPass = async (ids: any, name: string) => {
    try {
        if (ids == undefined || ids.length == 0) {
            ElMessage.warning('请先选择数据')
            return
        }
        const rs =  await subAuditNotPassBatch(ids,name,msg.value);
        ElMessage.success(rs.data);
    }finally {
        subMsgDialog.value = false;
        subAuditDialog.value = false;
        await handleClick(undefined);
    }
}

//子表重置方法
export const subReset = async (ids: string, name: string) => {
    if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
    }
    ElMessageBox.prompt('重置原因', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
        .then(async ({value}) => {
            const rs =  await subResetBatch(ids, name,value);
            await handleClick(undefined);
            ElMessage.success(rs.data);
        })
        .catch(() => {
            return;
        })

}

//子表撤回方法
export const subRecall = async (ids: string, name: string) => {
    if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
    }
    const rs =  await subRecallBatch(ids, name);
    await handleClick(undefined);
    ElMessage.success(rs.data);
}

//子表批量删除方法
export const subDel = async (ids: string, name: string) => {
    if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
    }

    const rs =  await subDelBatch(ids, name);
    await handleClick(undefined);
    ElMessage.success(rs.data);
}

//获取弹窗标题名
export const getTitleName = () => {
    switch (getRequestClassificationCode()) {
        case '100102' : return '止付反馈'
        case '100104' : return '止付解除反馈'
        case '100106' : return '止付延期反馈'
        case '100202' : return '冻结反馈'
        case '100204' : return '冻结解除反馈'
        case '100206' : return '冻结延期反馈'
        case '100302' : return '账户交易明细查询反馈'
        case '100304' : return '账户持卡主体查询反馈'
        case '100306' : return '账户动态查询反馈'
        case '100308' : return '账户动态查询反馈解除'
        case '100310' : return '客户全账户查询反馈'
        case '100406' : return '可疑账户数据上报'
        case '100501' : return '涉案/可疑名单单要素验证'
        case '100503' : return '涉案/可疑名单双要素验证'
        case '100602' : return '涉赌账户核查反馈'
        case '100604' : return '可疑账户指定机构推送排查反馈'
        case '100702' : return '惩戒名单下发反馈'
        case '100704' : return '涉案账户下发反馈'
    }
}

//获取子表弹窗标题名
export const getSubTitleName = (name: string) => {
    switch (name) {
        case 'fkAccountTaf' : return '账户信息'
        case 'fkMeasureTaf' : return '强制措施'
        case 'fkPriorityTaf' : return '共有权/优先权'
        case 'fkSubAccountTaf' : return '关联子账户'
        case 'fkTransactionTaf' : return '交易明细'
        case 'fkDoubtfulAccountsTaf' : return '可疑账户明细'
    }
}

//子表查询方法
const subSearch = async (name:string) => {
    loadingSub.value = true;
    try{
        const data = {applicationID:applicationID.value}
        const result = await list(name,data, subPage.value.currentPage, subPage.value.pageSize);
        const {current, total, records} = result.data;
        subData.value = records;
        subPage.value.currentPage = current;
        subPage.value.total = total;
    }finally {
        loadingSub.value = false;
    }
}

//该属性用来记录上一次打开的标签页 , 因为在子表中使用刷新按钮是无法传入tab参数的
let tabName = "";

//标签页切换触发方法
export const handleClick = (tab: any) => {
    if (tab==undefined) {
        switch (tabName) {
            case "账户信息" : subSearch("fkAccountTaf"); break;
            case "强制措施" : subSearch("fkMeasureTaf"); break;
            case "共有权/优先权" :subSearch("fkPriorityTaf"); break;
            case "关联子账户" : subSearch("fkSubAccountTaf");break;
            case "交易明细" : subSearch("fkTransactionTaf");break;
            case "可疑账户明细" : subSearch("fkDoubtfulAccountsTaf");break;
        }
    }else {
        subPage.value.currentPage = 1;
        tabName = tab.props.label;
        switch (tab.props.label) {
            case "账户信息" : subSearch("fkAccountTaf"); break;
            case "强制措施" : subSearch("fkMeasureTaf"); break;
            case "共有权/优先权" :subSearch("fkPriorityTaf"); break;
            case "关联子账户" : subSearch("fkSubAccountTaf");break;
            case "交易明细" : subSearch("fkTransactionTaf");break;
            case "可疑账户明细" : subSearch("fkDoubtfulAccountsTaf");break;
        }
    }
}

export const submitAllVisible = ref(false);
export const successNum = ref(0);
export const failNum = ref(0);
export const returnMassage = ref('');
export const submitOrAudit = ref('');
export const submitAll = async () => {
    ElMessageBox.confirm(
        '是否批量提交所有待提交/待补录数据?',
        '警告',
        {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
        }
    )
        .then(async () => {
            const newObject = {...searchForm.value};
            for (const key in newObject) {
                if (newObject[key] === '') {
                    newObject[key] = null;
                    console.log("转化了空串")
                }
            }
            const rs = await submitAllBatch(getRequestClassificationCode(), newObject,  null, false);
            successNum.value = rs.data.successNum;
            failNum.value = rs.data.failNum;
            returnMassage.value = rs.data.returnMassage;
            submitOrAudit.value = '提交'
            submitAllVisible.value = true;
            search()
        })
        .catch(() => {
            return
        })
}
export const auditAll = async () => {
    ElMessageBox.confirm(
        '是否批量审核所有待审核数据?',
        '警告',
        {
            confirmButtonText: '审核通过',
            cancelButtonText: '审核不通过',
            type: 'warning',
            distinguishCancelAndClose: true,
            confirmButtonClass:'auditButton',
            cancelButtonClass:'auditNotPassButton',
        }
    )
        .then(async () => {
            const newObject = {...searchForm.value};
            for (const key in newObject) {
                if (newObject[key] === '') {
                    newObject[key] = null;
                    console.log("转化了空串")
                }
            }
            const rs = await auditAllBatch(getRequestClassificationCode(), newObject,null, false);
            successNum.value = rs.data.successNum;
            failNum.value = rs.data.failNum;
            returnMassage.value = rs.data.returnMassage;
            submitOrAudit.value = '审核'
            submitAllVisible.value = true;
            search()
        })
        .catch((action: Action) => {
            if (action === 'cancel') {
                ElMessageBox.prompt( '审核不通过理由','提示',{confirmButtonText: '确定',cancelButtonText: '取消',inputType:'textarea'})
                    .then(async ({ value }) => {
                        const newObject = {...searchForm.value};
                        for (const key in newObject) {
                            if (newObject[key] === '') {
                                newObject[key] = null;
                                console.log("转化了空串")
                            }
                        }
                        const rs = await auditNotPassAllBatch(getRequestClassificationCode(), newObject,null, false, value);
                        successNum.value = rs.data.successNum;
                        failNum.value = rs.data.failNum;
                        returnMassage.value = rs.data.returnMassage;
                        submitOrAudit.value = '审核不通过'
                        submitAllVisible.value = true;
                        search()
                    })
                    .catch(() => {
                        return;
                    })
            }
        })
}
export const subSubmitAll = async (name:string) => {
    ElMessageBox.confirm(
        '是否批量提交所有待提交/待补录数据?',
        '警告',
        {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
        }
    )
        .then(async () => {
            const rs = await submitAllBatch(name, {}, applicationID.value, true);
            successNum.value = rs.data.successNum;
            failNum.value = rs.data.failNum;
            returnMassage.value = rs.data.returnMassage;
            submitOrAudit.value = '提交'
            submitAllVisible.value = true;
            await handleClick(undefined);
        })
        .catch(() => {
            return
        })
}
export const subAuditAll = async (name:string) => {
    ElMessageBox.confirm(
        '是否批量审核所有待审核数据?',
        '警告',
        {
            confirmButtonText: '审核通过',
            cancelButtonText: '审核不通过',
            type: 'warning',
            distinguishCancelAndClose: true,
            confirmButtonClass:'auditButton',
            cancelButtonClass:'auditNotPassButton',
        }
    )
        .then(async () => {
            const rs = await auditAllBatch(name, {},applicationID.value, true);
            successNum.value = rs.data.successNum;
            failNum.value = rs.data.failNum;
            returnMassage.value = rs.data.returnMassage;
            submitOrAudit.value = '审核'
            submitAllVisible.value = true;
            await handleClick(undefined);
        })
        .catch((action: Action) => {
            if (action === 'cancel') {
                ElMessageBox.prompt('审核不通过理由', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
                    .then(async ({value}) => {
                        const rs = await auditNotPassAllBatch(name, {}, applicationID.value, true, value);
                        successNum.value = rs.data.successNum;
                        failNum.value = rs.data.failNum;
                        returnMassage.value = rs.data.returnMassage;
                        submitAllVisible.value = true;
                        submitOrAudit.value = '审核不通过'
                        await handleClick(undefined);
                    })
                    .catch(() => {
                        return;
                    })
            }
        })
}*/
