import config100102 from './100102';
import config100104 from './100104';
import config100202 from './100202';
import config100204 from './100204';
import config100206 from './100206';
import config100302 from './100302';
import config100304 from './100304';
import config100310 from './100310';
import config100604 from './100604';
import config100714 from './100714';
import config100702 from './100702';
import config100704 from './100704';
import configAccount from './account';
import configAccount100310 from './account100310';
import configAccountSub from './accountSub';
import configMeasure from './a-measure';
import configPriority from './a-priority';
import configTransaction from './a-transaction';
import configDoubtfulAccounts from './a-doubtfulAccounts';

export default {
    config100102,
    config100104,
    config100202,
    config100204,
    config100206,
    config100302,
    config100304,
    config100310,
    config100604,
    config100714,
    config100702,
    config100704,
    configAccount,
    configAccount100310,
    configAccountSub,
    configMeasure,
    configPriority,
    configTransaction,
    configDoubtfulAccounts,
}

