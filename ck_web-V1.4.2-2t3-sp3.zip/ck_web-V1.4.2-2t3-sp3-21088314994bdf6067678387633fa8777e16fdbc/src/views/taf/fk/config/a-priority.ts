import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const name = '共有权/优先权';
export const listName = 'fkPriorityTaf';
export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status'},
    {prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState',sortable: true },
    {prop: 'priortySerial', label: '序号', minWidth: 150, sortable: true},
    {prop: 'accountNumber', label: '账号', minWidth: 150, sortable: true},
    {prop: 'cardNumber', label: '卡号', minWidth: 150, sortable: true},
    {prop: 'credentialType', label: '证件类型代码', minWidth: 150, dictFormatKey: 'idType', sortable: true},
    {prop: 'credentialNumber', label: '证件号码', minWidth: 150, sortable: true},
    {prop: 'rightsType', label: '权利类型', minWidth: 150, sortable: true, dictFormatKey: 'RightsType'},
    {prop: 'obligeeName', label: '权利人姓名', minWidth: 150, sortable: true},
    {prop: 'rightsBalance', label: '权利金额', minWidth: 150, sortable: true},
    {prop: 'obligeeAddress', label: '权利人通讯地址', minWidth: 150, sortable: true},
    {prop: 'obligeeContactInfo', label: '权利人联系方式', minWidth: 150, sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200   ,sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter   ,sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'txCode', label: '交易类型编码', inputType: 'input', labelWidth: 100},
    {prop: 'transSerialNumber', label: '传输报文流水号', inputType: 'input', labelWidth: 100},
    {
        prop: 'messageFrom', label: '发送机构',
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: true,
        },
        labelWidth: 100
    },
    {
        prop: 'status', label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
            multiple: true,
        },
        labelWidth: 100
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '部门编码必填' },{ max: 50, message: '部门编码最大长度为50' }],
    },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{required: true, message: '必填'}],
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 36, message: '超过36字符限制'}]
    },
    {
        prop: 'priortySerial',
        label: '序号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 8, message: '超过8字符限制'}]
    },
    {
        prop: 'accountNumber',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'cardNumber',
        label: '卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'credentialType',
        label: '证件类型代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
    },
    {
        prop: 'credentialNumber',
        label: '证件号码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'rightsType',
        label: '权利类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'RightsType',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 2, message: '超过2字符限制'}]
    },
    {
        prop: 'obligeeName',
        label: '权利人姓名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 60, message: '超过60字符限制'}]
    },
    {
        prop: 'rightsBalance',
        label: '权利金额',
        labelWidth: 150,
        inputType: {tag: 'input', type: 'number'}
    },
    {
        prop: 'obligeeAddress',
        label: '权利人通讯地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 90, message: '超过90字符限制'}]
    },
    {
        prop: 'obligeeContactInfo',
        label: '权利人联系方式',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    }
]


export default {
    name,
    columns,
    searchFormItems,
    formItems,
    listName
}



































