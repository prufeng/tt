import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const name = '交易明细';
export const listName = 'fkTransactionTaf';
export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status'},
    {prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState',sortable: true },
    {prop: 'accountNumber', label: '定位账户账号', minWidth: 150, sortable: true},
    {prop: 'transactionType', label: '交易类型', minWidth: 150, sortable: true},
    {prop: 'borrowingSigns', label: '借贷标志', minWidth: 150, sortable: true, dictFormatKey: 'BorrowingSigns'},
    {prop: 'currency', label: '币种', minWidth: 150, sortable: true, dictFormatKey: 'currency'},
    {prop: 'transactionAmount', label: '交易金额', minWidth: 150, sortable: true},
    {prop: 'accountBalance', label: '交易余额', minWidth: 150, sortable: true},
    {prop: 'transactionTime', label: '交易时间', minWidth: 150,sortable: true},
    {prop: 'transactionSerial', label: '交易流水号', minWidth: 150, sortable: true},
    {prop: 'opponentName', label: '交易对方名称', minWidth: 150, sortable: true},
    {prop: 'opponentAccountNumber', label: '交易对方账卡号', minWidth: 150, sortable: true},
    {prop: 'opponentCredentialNumber', label: '交易对方证件号码', minWidth: 150, sortable: true},
    {prop: 'opponentDepositBankID', label: '交易对方账号开户行', minWidth: 150, sortable: true},
    {prop: 'transactionRemark', label: '交易摘要', minWidth: 150, sortable: true},
    {prop: 'transactionBranchName', label: '交易网点名称', minWidth: 150, sortable: true},
    {prop: 'transactionBranchCode', label: '交易网点代码', minWidth: 150, sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200   ,sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter   ,sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'txCode', label: '交易类型编码', inputType: 'input', labelWidth: 100},
    {prop: 'transSerialNumber', label: '传输报文流水号', inputType: 'input', labelWidth: 100},
    {
        prop: 'messageFrom', label: '发送机构',
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: true,
        },
        labelWidth: 100
    },
    {
        prop: 'status', label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
        },
        labelWidth: 100
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '部门编码必填' },{ max: 50, message: '部门编码最大长度为50' }],
    },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{required: true, message: '必填'}],
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 36, message: '超过36字符限制'}]
    },
    {
        prop: 'accountNumber',
        label: '定位账户账号',
        labelWidth: 150,
        inputType: 'input',
        /*inputType: {
            tag: 'select',
            options: 'accountNumberOptions',
        },*/
        // scopedSlot: 'accountNumberOptions',
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'transactionType',
        label: '交易类型',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'borrowingSigns',
        label: '借贷标志',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'BorrowingSigns',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 1, message: '超过1字符限制'}]
    },
    {
        prop: 'currency',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency'
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 10, message: '超过10字符限制'}]
    },
    {
        prop: 'transactionAmount',
        label: '交易金额',
        labelWidth: 150,
        rules: [{required: true, message: '必填'}],
        inputType: {tag: 'input', type: 'number'}
    },
    {
        prop: 'accountBalance',
        label: '交易余额',
        labelWidth: 150,
        rules: [{required: true, message: '必填'}],
        inputType: {tag: 'input', type: 'number'}
    },
    {prop: 'transactionTime', label: '交易时间', labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},],
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},},
    {
        prop: 'transactionSerial',
        label: '交易流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'opponentName',
        label: '交易对方名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 60, message: '超过60字符限制'}]
    },
    {
        prop: 'opponentAccountNumber',
        label: '交易对方账卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'opponentCredentialNumber',
        label: '交易对方证件号码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'opponentDepositBankID',
        label: '交易对方账号开户行',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 90, message: '超过90字符限制'}]
    },
    {
        prop: 'transactionRemark',
        label: '交易摘要',
        labelWidth: 150,
        inputType: 'input',
        rules: [{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'transactionBranchName',
        label: '交易网点名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'transactionBranchCode',
        label: '交易网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'transactionBranchAdminisCode',
        label: '交易网点所属行政区划代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'areaCode',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 6, message: '超过6字符限制'}]
    },
    {
        prop: 'transactionBranchTelephone',
        label: '交易网点联系电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'logNumber',
        label: '日志号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'summonsNumber',
        label: '传票号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'voucherType',
        label: '凭证种类',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 10, message: '超过10字符限制'}]
    },
    {
        prop: 'voucherCode',
        label: '凭证号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'cashMark',
        label: '现金标志',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'CashMark',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 2, message: '超过2字符限制'}]
    },
    {
        prop: 'terminalNumber',
        label: '终端号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'transactionstatus',
        label: '交易是否成功',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'TransactionStatus',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 2, message: '超过2字符限制'}]
    },
    {
        prop: 'transactionAddress',
        label: '交易发生地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'merchantName',
        label: '商户名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'merchantCode',
        label: '商户号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'ipaddress',
        label: 'IP 地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 128, message: '超过128字符限制'}]
    },
    {
        prop: 'mac',
        label: 'MAC 地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'tellerCode',
        label: '交易柜员号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'potNumber',
        label: '端口号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 10, message: '超过10字符限制'}]
    },
    {
        prop: 'imeiNumber',
        label: 'IMEI 号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'telephoneNumber',
        label: '手机号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'moneyFlow',
        label: '资金流向标志位',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'MoneyFlow',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 2, message: '超过2字符限制'}]
    },
    {
        prop: 'remark',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
        rules: [{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'jydsRef',
        label: '交易对手来源',
        labelWidth: 150,
        inputType: 'input',
        // rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
]


export default {
    name,
    columns,
    searchFormItems,
    formItems,
    listName
}



































