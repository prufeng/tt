import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    // {prop: 'transSerialNumber', label: '传输报文流水号', minWidth: 200, sortable: true},
    {prop: 'trxId',label: '流水号',width: 170,sortable: true},
    {prop: 'applicationID', label: '业务申请编号', minWidth: 200, sortable: true},
    {prop: 'status', label: '状态', dictFormatKey: 'taf_status', sortable: true, scopedSlots: 'status'},
    {prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState',sortable: true },
    {prop: 'accountName', label: '账户主体名称', minWidth: 210, sortable: true},
    {prop: 'fkStatus', label: '回执状态', dictFormatKey: 'fkStatus', sortable: true},
    {prop: 'fkInfo', label: '回执信息',  sortable: true},
    {prop: 'result', label: '止付结果', minWidth: 200, dictFormatKey: 'result', sortable: true},
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    {prop: 'accountType', label: '止付账号类别', minWidth: 210, dictFormatKey: 'paymentAccountType', sortable: true},
    {prop: 'accountNumber', label: '帐卡号', minWidth: 210, sortable: true},
    {prop: 'branchCode', label: '业务操作机构', minWidth: 200, dictFormatKey: 'branchTree', sortable: true},
    {prop: 'accountCredentialType', label: '账户主体证照类型', labelWidth: 100, dictFormatKey: 'idType', sortable: true},
    {prop: 'accountCredentialNumber', label: '账户主体证照号码', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'cardNumber', label: '卡/折号', inputType: 'input', labelWidth: 100, sortable: true},
    {prop: 'accountStatus', label: '账户状态', labelWidth: 100, inputType: 'input', sortable: true}, //todo
    {prop: 'depositBankBranch', label: '开户网点', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'depositBankBranchCode', label: '开户网点代码', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'depositBankAdminisCode', label: '开户网点所属行政区划代码', labelWidth: 100, inputType: 'input', sortable: true, dictFormatKey: 'areaCode'},
    {prop: 'accountBalance', label: '账户余额', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'startTime', label: '止付起始时间', labelWidth: 100},
    {prop: 'expireTime', label: '止付结束时间', labelWidth: 100},
    {prop: 'failureCause', label: '未能止付原因', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'feedbackOrgName', label: '反馈机构名称', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'feedbackRemark', label: '反馈说明', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'operatorName', label: '经办人姓名', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'operatorPhoneNumber', label: '经办人电话', labelWidth: 100, inputType: 'input', sortable: true},
    {prop: 'remark', label: '备注', labelWidth: 100, inputType: 'input', sortable: true},

    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    // {prop: 'transSerialNumber', label: '传输报文流水号', inputType: 'input'},
    {prop: 'applicationID', label: '业务申请编号', inputType: 'input'},
    {prop: 'branchCodeList', label: '业务操作机构', inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
            collapseTags: true,
            maxCollapseTags:1
        },},
    {
        prop: 'businessLine', label: '业务线',
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'onlyQuerySucceeded',
        label: '匹配成功',
        labelWidth: 50,
        // scopedSlot: 'onlyQuerySucceeded',
        // inputType: {tag:'checkbox',   checked:"checked"},
        inputType: {tag:'checkbox'},
    }
]

export const formItems: FormItemInfo[] = [
    // {
    //     prop: 'transSerialNumber',
    //     label: '传输报文流水号',
    //     inputType: 'input',
    //     labelWidth: 150,
    //     rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 53, message: '超过53字符限制'}]
    // },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{required: true, message: '必填'}],
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 36, message: '超过36字符限制'}]
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'result',
        label: '止付结果',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'result'}
    },
    {
        prop: 'accountType',
        label: '止付账号类别',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'paymentAccountType', disabled: true }
    },
    {
        prop: 'accountNumber',
        label: '止付帐卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'accountName',
        label: '账户主体名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 180, message: '超过180字符限制'}]
    },
    {
        prop: 'accountCredentialType',
        label: '账户主体证照类型',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'idType'}
    },
    {
        prop: 'accountCredentialNumber',
        label: '账户主体证照号码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'cardNumber',
        label: '卡/折号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'accountStatus',
        label: '账户状态',
        labelWidth: 150,
        inputType: 'input',
        // inputType: {
        //     tag: 'select',
        //     options: 'AccountStatus',
        // },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 10, message: '超过10字符限制'}]
    }, //todo
    {
        prop: 'depositBankBranch',
        label: '开户网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'depositBankBranchCode',
        label: '开户网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'depositBankAdminisCode',
        label: '开户网点所属行政区划代码',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'areaCode'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 6, message: '超过6字符限制'}]
    },
    {
        prop: 'accountBalance',
        label: '账户余额',
        labelWidth: 150,
        rules: [{required: true, message: '必填'}],
        inputType: {tag: 'input', type: 'number'},
        // rules: [{required:true, type: 'number', message: '金额必须为数字值'}]
    },
    {
        prop: 'eodAccountBalance',
        label: '前一日账户余额',
        labelWidth: 150,
        inputType: {tag: 'input', type: 'number', disabled: true},
    },
    {
        prop: 'startTime',
        label: '止付起始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {required: false,message: '必填'},
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],},
    {
        prop: 'expireTime',
        label: '止付结束时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {required: false,message: '必填'},
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]},
    {
        prop: 'failureCause',
        label: '未能止付原因',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'feedbackRemark',
        label: '反馈说明',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 450, message: '超过450字符限制'}]
    },
    {
        prop: 'feedbackOrgName',
        label: '反馈机构名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    // {
    //     prop: 'feedbackOrgId',
    //     label: '反馈机构编码',
    //     labelWidth: 150,
    //     inputType: 'input',
    //     rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    // },
    {
        prop: 'operatorName',
        label: '经办人姓名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 60, message: '超过60字符限制'}]
    },
    {
        prop: 'operatorPhoneNumber',
        label: '经办人电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'remark',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
        rules: [{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '部门编码必填' },{ max: 50, message: '部门编码最大长度为50' }],
    },
]

export const advancedQueryItems = [
    {value: 'trxId',label: '流水号',inputType: 'input' },
    {value: 'applicationID', label: '业务申请编号',inputType: 'input'},
    {value: 'fkStatus', label: '回执状态', inputType: {tag: 'select', options: 'fkStatus'}},
    {value: 'fkInfo', label: '回执信息', inputType:  'input'},
    {value: 'result', label: '止付结果', inputType: {tag: 'select', options: 'result'}},
    {value: 'accountType', label: '止付账号类别', inputType: {tag: 'select', options: 'paymentAccountType'}, labelWidth: 100},
    {value: 'accountNumber', label: '帐卡号', inputType: 'input', labelWidth: 100},
    {value: 'accountName', label: '账户主体名称', labelWidth: 100,},
    {value: 'accountCredentialType', label: '账户主体证照类型', labelWidth: 100, inputType: {tag: 'select', options: 'idType'}},
    {value: 'accountCredentialNumber', label: '账户主体证照号码', labelWidth: 100, inputType: 'input'},
    {value: 'cardNumber', label: '卡/折号', inputType: 'input', labelWidth: 100},
    {value: 'accountStatus', label: '账户状态', labelWidth: 100, inputType: {tag: 'select', options: 'AccountStatus'}},
    {value: 'depositBankBranch', label: '开户网点', labelWidth: 100, inputType: 'input'},
    {value: 'depositBankBranchCode', label: '开户网点代码', labelWidth: 100, inputType: 'input'},
    {value: 'depositBankAdminisCode', label: '开户网点所属行政区划代码', labelWidth: 100, inputType: {tag: 'select', options: 'areaCode'}},
    {value: 'accountBalance', label: '账户余额', labelWidth: 100, inputType: 'input-number'},
    {value: 'startTime', label: '止付起始时间', labelWidth: 100, inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],},
    {value: 'expireTime', label: '止付结束时间', labelWidth: 100, inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],},
    {value: 'failureCause', label: '未能止付原因', labelWidth: 100, inputType: 'input'},
    {value: 'feedbackRemark', label: '反馈说明', labelWidth: 100, inputType: 'input'},
    {value: 'feedbackOrgName', label: '反馈机构名称', labelWidth: 100, inputType: 'input'},
    {value: 'operatorName', label: '经办人姓名', labelWidth: 100, inputType: 'input'},
    {value: 'operatorPhoneNumber', label: '经办人电话', labelWidth: 100, inputType: 'input'},
    {value: 'remark', label: '备注', labelWidth: 100, inputType: 'input'},
    {value: 'status', label: '状态', inputType: {tag: 'select', options: 'taf_status',}, labelWidth: 100},

    {value: 'deleteState', label: '删除状态', inputType: {tag: 'select', options: 'deleteStatusList'}, labelWidth: 100},
    {value: 'importType', label: '导入方式', inputType: {tag: 'select', options: 'importType'}, labelWidth: 100},

    {
        value: 'create_by',
        label: '创建人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'update_by',
        label: '修改人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'update_time',
        label: '修改时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'submit_by',
        label: '提交人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'submit_time',
        label: '提交时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'approve_by',
        label: '审核人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'approve_time',
        label: '审核时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
]

export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems
}





















