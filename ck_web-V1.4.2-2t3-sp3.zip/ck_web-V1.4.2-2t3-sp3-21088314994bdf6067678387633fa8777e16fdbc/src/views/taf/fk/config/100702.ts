import { FormItemInfo, TableColumnInfo } from "riking-ui";
import { dateFormatter } from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    // {prop: 'transSerialNumber', label: '传输报文流水号', minWidth: 200, sortable: true},
    { prop: 'trxId', label: '流水号', width: 170, sortable: true },
    { prop: 'applicationID', label: '业务申请编号', minWidth: 200, sortable: true },
    { prop: 'status', label: '状态', dictFormatKey: 'taf_status', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: 'fkStatus', label: '回执状态', dictFormatKey: 'fkStatus', sortable: true },
    { prop: 'fkInfo', label: '回执信息', sortable: true },
    { prop: 'prosResult', label: '反馈结果', dictFormatKey: 'ProsResult', sortable: true },
    { prop: 'matchResult', label: '匹配结果',dictFormatKey: 'MatchResult', sortable: true },
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    { prop: 'failReasonCd', label: '反馈失败码', minWidth: 210, dictFormatKey: 'failReasonCd', sortable: true },
    { prop: 'failReasonDesc', label: '反馈失败码原因', minWidth: 210, sortable: true },
    { prop: 'branchCode', label: '业务操作机构', minWidth: 200, dictFormatKey: 'branchTree', sortable: true },

    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const columnsPolice: TableColumnInfo[] = [
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        width: 170,
        sortable: true
    },
    {
        prop: 'dpoliceCode',
        label: '惩戒公安机关代码',
        width: 170,
        sortable: true
    },


    {
        prop: 'dpoliceName',
        label: '惩戒公安机关名称',
        width: 170,
        sortable: true
    },
    {
        prop: 'dPoliceStartDate',
        label: '惩戒公安机关惩戒开始时间',
        width: 170,
        dictFormatKey: 'DobjectType',
        sortable: true
    },
    {
        prop: 'dPoliceEndDate',
        label: '惩戒公安机关惩戒结束时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'doperatorName',
        label: '经办人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'doperatorPhoneNumber',
        label: '经办人电话',
        width: 170,
        sortable: true
    },
]

export const columnsObject: TableColumnInfo[] = [
    {
        prop: 'dobjectId',
        label: '惩戒对象唯一标识',
        width: 170,
        sortable: true
    },
    {
        prop: 'dobjectIDType',
        label: '惩戒对象证件类型',
        dictFormatKey: 'idType',
        width: 170,
        sortable: true
    },


    {
        prop: 'dobjectIDNumber',
        label: '惩戒对象证件号码',
        width: 170,
        sortable: true
    },
   
]
export const searchFormItems: FormItemInfo[] = [
    // {prop: 'transSerialNumber', label: '传输报文流水号', inputType: 'input'},
    { prop: 'applicationID', label: '业务申请编号', inputType: 'input' },
    {
        prop: 'branchCodeList', label: '业务操作机构', inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
            collapseTags: true,
            maxCollapseTags: 1
        },
    },
    {
        prop: 'businessLine', label: '业务线',
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'matchResult',
        label: '匹配成功',
        labelWidth: 50,
        // scopedSlot: 'onlyQuerySucceeded',
        // inputType: {tag:'checkbox',   checked:"checked"},
        inputType: { tag: 'checkbox' },
    }
]

export const formItems: FormItemInfo[] = [
    // {
    //     prop: 'transSerialNumber',
    //     label: '传输报文流水号',
    //     inputType: 'input',
    //     labelWidth: 150,
    //     rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 53, message: '超过53字符限制'}]
    // },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: { tag: 'input', disabled: true },
        rules: [{ required: true, message: '必填' }],
        extra: {
            collapse: { name: 'head', title: '基础信息' },
        }
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 150,
        inputType: { tag: 'input', disabled: true },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: '必填' }, { max: 36, message: '超过36字符限制' }]
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{ required: true, message: '必填' }]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    // {
    //     prop: 'matchResult',
    //     label: '匹配结果',
    //     labelWidth: 150,
    //     rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '必填' }],
    //     inputType: { tag: 'select', options: 'MatchResult' }
    // },
    {
        prop: 'prosResult',
        label: '反馈结果',
        labelWidth: 150,
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: '必填' }],
        inputType: { tag: 'select', options: 'ProsResult' }
    },
    {
        prop: 'failReasonCd',
        label: '反馈失败码',
        labelWidth: 150,
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '必填' }],
        inputType: { tag: 'select', options: 'failReasonCd' }
    },

    {
        prop: 'failReasonDesc',
        label: '反馈失败码原因',
        labelWidth: 150,
        inputType: {tag: 'input', type: 'textarea', maxlength: '500'},
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '必填' }, { max: 50, message: '超过50字符限制' }]
    },

    {
        prop: 'applicationTime',
        label: '反馈时间',
        labelWidth: 150,
        inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' },
        rules: [
            { required: true, message: '必填' },
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒' },
        ]
    },
    {
        prop: 'matchResult',
        label: '匹配结果',
        labelWidth: 150,
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '必填' }],
        inputType: { tag: 'select', options: 'MatchResult' ,disabled: false}
    },
]

export const advancedQueryItems = [
    { value: 'trxId', label: '流水号', inputType: 'input' },
    { value: 'applicationID', label: '业务申请编号', inputType: 'input' },
    { value: 'fkStatus', label: '回执状态', inputType: { tag: 'select', options: 'fkStatus' } },
    { value: 'fkInfo', label: '回执信息', inputType: 'input' },
    {
        value: 'applicationTime', label: '反馈时间', labelWidth: 100, inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD' },
        rules: [
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒' },
        ],
    },
    { value: 'prosResult', label: '反馈结果', inputType: { tag: 'select', options: 'ProsResult' } },
    { value: 'matchResult', label: '匹配结果', inputType: { tag: 'select', options: 'MatchResult' } },
    { value: 'failReasonCd', label: '反馈失败码', inputType: { tag: 'select', options: 'failReasonCd' }, labelWidth: 100 },
    { value: 'failReasonDesc', label: '反馈失败码原因', inputType: 'input', labelWidth: 100 },
    { value: 'status', label: '状态', inputType: { tag: 'select', options: 'taf_status', }, labelWidth: 100 },
    { value: 'deleteState', label: '删除状态', inputType: { tag: 'select', options: 'deleteStatusList' }, labelWidth: 100 },
    { value: 'importType', label: '导入方式', inputType: { tag: 'select', options: 'importType' }, labelWidth: 100 },
    {
        value: 'create_by',
        label: '创建人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD' },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'update_by',
        label: '修改人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'update_time',
        label: '修改时间',
        labelWidth: 100,
        inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD' },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'submit_by',
        label: '提交人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'submit_time',
        label: '提交时间',
        labelWidth: 100,
        inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD' },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'approve_by',
        label: '审核人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'approve_time',
        label: '审核时间',
        labelWidth: 100,
        inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD' },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
]

export default {
    columns,
    columnsObject,
    columnsPolice,
    searchFormItems,
    formItems,
    advancedQueryItems
}





















