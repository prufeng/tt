import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";


export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'trxId',label: '流水号',width: 170,sortable: true},
    {prop: 'applicationID', label: '业务申请编号', minWidth: 200, sortable: true},
    {prop: 'status', label: '状态', dictFormatKey: 'taf_status', sortable: true, scopedSlots: 'status'},
    {prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState',sortable: true },
    {prop: 'fkStatus', label: '回执状态', dictFormatKey: 'fkStatus', sortable: true},
    {prop: 'fkInfo', label: '回执信息',  sortable: true},
    {
        prop: 'updateType',
        label: '业务类型',
        width: 170,
        dictFormatKey: 'taf_updateType',
        sortable: true
    },
    {prop: 'result', label: '反馈结果', minWidth: 200, sortable: true, dictFormatKey: 'taf_result'},
    {
        prop: 'importType',
        label: '导入方式',
        width: 170,
        dictFormatKey: 'importType',
        sortable: true
    },
    {
        prop: 'account',
        label: '涉案账号',
        width: 170,
        sortable: true
    },
    {
        prop: 'processMeasure',
        label: '处置方式',
        dictFormatKey:'taf_processMeasure',
        width: 170,
        sortable: true
    },
    {
        prop: 'processTime',
        label: '管控/撤销管控时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'balance',
        label: '管控账户余额',
        width: 170,
        sortable: true
    },
    {
        prop: 'currency',
        label: '币种',
        width: 170,
        sortable: true
    },
    {
        prop: 'feedbackOrgId',
        label: '反馈机构编码',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorName',
        label: '反馈机构经办人姓名',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorPhoneNumber',
        label: '反馈机构经办人电话',
        width: 170,
        sortable: true
    },
    {
        prop: 'operatorAdminisCode',
        label: '反馈机构经办人所属地区行政区划代码',
        dictFormatKey:'areaCode',
        width: 170,
        sortable: true
    },
    {
        prop: 'opnInsId',
        label: '开户机构标识',
        width: 170,
        sortable: true
    },
    {
        prop: 'opnInsNm',
        label: '开户机构名称',
        width: 170,
        sortable: true
    },
    {prop: 'branchCode', label: '业务操作机构', minWidth: 200, dictFormatKey: 'branchTree', sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'applicationID', label: '业务申请编号', inputType: 'input', },
    {prop: 'branchCodeList', label: '业务操作机构', inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
            collapseTags: true,
            maxCollapseTags:1
        },},
    {
        prop: 'businessLine', label: '业务线',
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'onlyQuerySucceeded',
        label: '匹配成功',
        labelWidth: 50,
        // scopedSlot: 'onlyQuerySucceeded',
        // inputType: {tag:'checkbox',   checked:"checked"},
        inputType: {tag:'checkbox'},
    }
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{required: true, message: '必填'}],
        extra: {
            collapse: {name: 'head', title: '基础信息'},
        }
    },
    {
        prop: "applicationID",
        label: "业务申请编号",
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 36, message: '超过36字符限制'}]
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: "result",
        label: "反馈结果",
        labelWidth: 150,
        inputType: {tag: 'select', options: 'taf_result'},
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'updateType',
        label: '业务类型',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'taf_updateType',disabled:true},
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'account',
        label: '涉案账号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'processMeasure',
        label: '处置方式',
        inputType: {tag: 'select', options: 'taf_processMeasure',disabled:false},
        labelWidth: 150,
        rules : [{required: true, message: '必填'}]
    },
    {
        prop: 'processTime',
        label: '管控/撤销管控时间',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},
        ], inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYYMMDDHHmmss'},
    },
    {
        prop: 'balance',
        label: '管控账户余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition:"right",precision:"2",disabled:false},
        rules : [{required: true, message: '必填'}]
    },
    {
        prop: 'currency',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            multiple: false,
        },
        rules : [{required: true, message: '必填'}]
    },
    {
        prop: 'feedbackOrgId',
        label: '反馈机构编码',
        inputType: 'input',
        labelWidth: 150,rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 12, message: '超过12字符限制'}]

    },
    // {
    //     prop: 'feedbackOrgName',
    //     label: '反馈机构名称',
    //     labelWidth: 150,rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 12, message: '超过12字符限制'}]
    //
    // },
    {
        prop: "operatorName",
        label: "经办人姓名",
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 60, message: '超过60字符限制'}]
    },
    {
        prop: "operatorPhoneNumber",
        label: "经办人电话",
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'operatorAdminisCode',
        label: '反馈机构经办人所属地区行政区划代码',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'areaCode'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 6, message: '超过6字符限制'}]
    },
    {
        prop: 'opnInsId',
        label: '开户机构标识',
        labelWidth: 150,
        inputType: {tag: 'input'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {required: true, message: '必填'}, {max: 20, message: '超过20字符限制'}]
    },
    {
        prop: 'opnInsNm',
        label: '开户机构名称',
        labelWidth: 150,
        inputType: {tag: 'input'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'}, {required: true, message: '必填'}, {max: 100, message: '超过100字符限制'}]
    },
     {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '部门编码必填' },{ max: 50, message: '部门编码最大长度为50' }],
    },
]


export const advancedQueryItems = [
    {value: 'trxId',label: '流水号',inputType: 'input' },
    {value: 'applicationID', label: '业务申请编号',inputType: 'input'},
    {value: 'fkStatus', label: '回执状态', inputType: {tag: 'select', options: 'fkStatus'}},
    {value: 'fkInfo', label: '回执信息', inputType:  'input'},
    {value: 'status', label: '状态', inputType: { tag: 'select',options: 'taf_status'}, scopedSlots: 'status'},
    {
        value: 'updateType',
        label: '业务类型',
        width: 170,
        inputType: { tag: 'select',options: 'taf_updateType'}
    },
    {value: 'result', label: '反馈结果', minWidth: 200, inputType: { tag: 'select',options: 'taf_result'}},
    {
        value: 'account',
        label: '涉案账号',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'processMeasure',
        label: '处置方式',
        width: 170,
        inputType: { tag: 'select',options: 'taf_processMeasure'}
    },
    {
        value: 'processTime',
        label: '管控/撤销管控时间',
        width: 170,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        value: 'balance',
        label: '管控账户余额',
        width: 170,
        inputType: 'input-number'
    },
    {
        value: 'currency',
        label: '币种',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'feedbackOrgId',
        label: '反馈机构编码',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'operatorName',
        label: '反馈机构经办人姓名',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'operatorPhoneNumber',
        label: '反馈机构经办人电话',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'operatorAdminisCode',
        label: '反馈机构经办人所属地区行政区划代码',
        width: 170,
        inputType: {tag: 'select', options: 'areaCode'},
    },
    {
        value: 'opnInsId',
        label: '开户机构标识',
        width: 170,
        inputType: 'input'
    },
    {
        value: 'opnInsNm',
        label: '开户机构名称',
        width: 170,
        inputType: 'input'
    },
    {value: 'deleteState', label: '删除状态', inputType: {tag: 'select', options: 'deleteStatusList'}, labelWidth: 100},
    {value: 'importType', label: '导入方式', inputType: {tag: 'select', options: 'importType'}, labelWidth: 100},
    {
        value: 'create_by',
        label: '创建人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'create_time',
        label: '创建时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'update_by',
        label: '修改人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'update_time',
        label: '修改时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'submit_by',
        label: '提交人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'submit_time',
        label: '提交时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
    {
        value: 'approve_by',
        label: '审核人',
        labelWidth: 100,
        inputType: 'input'
    },
    {
        value: 'approve_time',
        label: '审核时间',
        labelWidth: 100,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ],
    },
]

export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems
}



































