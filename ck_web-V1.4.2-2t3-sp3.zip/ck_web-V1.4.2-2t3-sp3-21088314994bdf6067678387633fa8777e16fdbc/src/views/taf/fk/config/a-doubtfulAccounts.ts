import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const name = '可疑账户明细';
export const listName = 'fkDoubtfulAccountsTaf';
export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status'},
    {prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState',sortable: true },
    {prop: 'accountName', label: '账户名', minWidth: 150, sortable: true},
    {prop: 'subjectType', label: '主体类型', minWidth: 150, sortable: true, dictFormatKey: 'accountSubjectType'},
    {prop: 'idType', label: '证件类型', minWidth: 150, dictFormatKey: 'idType', sortable: true},
    {prop: 'idNumber', label: '证件号', minWidth: 150, sortable: true},
    {prop: 'cardNumber', label: '卡/折号', minWidth: 150, sortable: true},
    {prop: 'phoneNumber', label: '联系电话', minWidth: 150, sortable: true},
    {prop: 'address', label: '通讯地址', minWidth: 150, sortable: true},
    {prop: 'postCode', label: '邮政编码', minWidth: 150, sortable: true},
    {prop: 'depositBankBranch', label: '开户网点', minWidth: 150, sortable: true},
    {prop: 'depositBankBranchPro', label: '开户网点所在省', minWidth: 150, sortable: true},
    {prop: 'depositBankBranchCit', label: '开户网点所在市', minWidth: 150, sortable: true},
    {prop: 'depositBankBranchDis', label: '开户网点所在区（县）', minWidth: 150, sortable: true},
    {prop: 'depositBankAdminisCode', label: '开户网点所属行政区划代码', minWidth: 150, sortable: true, dictFormatKey: 'areaCode'},
    {prop: 'accountOpenTime', label: '开卡时间', minWidth: 150, sortable: true},
    {prop: 'note', label: '备注', minWidth: 150, sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200   ,sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter   ,sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'txCode', label: '交易类型编码', inputType: 'input', labelWidth: 100},
    {prop: 'transSerialNumber', label: '传输报文流水号', inputType: 'input', labelWidth: 100},
    {
        prop: 'messageFrom', label: '发送机构',
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: true,
        },
        labelWidth: 100
    },
    {
        prop: 'status', label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
            multiple: true,
        },
        labelWidth: 100
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'accountName',
        label: '账户名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 150, message: '超过150字符限制'}]
    },
    {
        prop: 'subjectType',
        label: '主体类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'accountSubjectType',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 1, message: '超过1字符限制'}]
    },
    {
        prop: 'idType',
        label: '证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'idType',
            multiple: false,
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 2, message: '超过2字符限制'}]
    },
    {
        prop: 'idNumber',
        label: '证件号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'cardNumber',
        label: '卡/折号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'phoneNumber',
        label: '联系电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'address',
        label: '通讯地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'postCode',
        label: '邮政编码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 10, message: '超过10字符限制'}]
    },
    {
        prop: 'depositBankBranch',
        label: '开户网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 225, message: '超过225字符限制'}]
    },
    {
        prop: 'depositBankBranchPro',
        label: '开户网点所在省',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 10, message: '超过10字符限制'}]
    },
    {
        prop: 'depositBankBranchCit',
        label: '开户网点所在市',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 10, message: '超过10字符限制'}]
    },
    {
        prop: 'depositBankBranchDis',
        label: '开户网点所在区（县）',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: false, message: '必填'}, {max: 15, message: '超过15字符限制'}]
    },
    {
        prop: 'depositBankAdminisCode',
        label: '开户网点所属行政区划代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'areaCode',
            multiple: false,
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 6, message: '超过6字符限制'}]
    },
    {
        prop: 'accountOpenTime',
        label: '开卡时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'note',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
        rules: [{required: false, message: '必填'}, {max: 255, message: '超过255字符限制'}]
    },
]


export default {
    name,
    columns,
    searchFormItems,
    formItems,
    listName
}



































