import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const name = '关联子账户';
export const listName = 'fkSubAccountTaf';
export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status'},
    {prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', sortable: true },
    {prop: 'cardNumber', label: '主账户', minWidth: 150, sortable: true},
    {prop: 'accountNumber', label: '定位账户账号', minWidth: 150, sortable: true},
    {prop: 'accountSerial', label: '一般(子)账户序号', minWidth: 150, sortable: true},
    {prop: 'accountType', label: '一般(子)账户类别', minWidth: 150, sortable: true, dictFormatKey: 'accountType'},
    {prop: 'accountstatus', label: '账户状态', minWidth: 150, sortable: true},
    {prop: 'currency', label: '币种', minWidth: 150, sortable: true, dictFormatKey: 'currency'},
    {prop: 'cashRemit', label: '钞汇标志', minWidth: 150, sortable: true, dictFormatKey: 'cashRemit'},
    {prop: 'accountBalance', label: '账户余额', minWidth: 150, sortable: true},
    {prop: 'availableBalance', label: '可用余额', minWidth: 150, sortable: true},
    {prop: 'lastTransactionTime', label: '最后交易时间', minWidth: 150, sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200   ,sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter   ,sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'txCode', label: '交易类型编码', inputType: 'input', labelWidth: 100},
    {prop: 'transSerialNumber', label: '传输报文流水号', inputType: 'input', labelWidth: 100},
    {
        prop: 'messageFrom', label: '发送机构',
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: true,
        },
        labelWidth: 100
    },
    {
        prop: 'status', label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
            multiple: true,
        },
        labelWidth: 100
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '部门编码必填' },{ max: 50, message: '部门编码最大长度为50' }],
    },
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{required: true, message: '必填'}],
    },
    {
        prop: 'applicationID',
        label: '业务申请编号',
        labelWidth: 150,
        inputType: {tag:'input',disabled: true},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 36, message: '超过36字符限制'}]
    },
    {
        prop: 'cardNumber',
        label: '主账户',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'accountNumber',
        label: '定位账户账号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 50, message: '超过50字符限制'}]
    },
    {
        prop: 'accountSerial',
        label: '一般（子）账户序号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 8, message: '超过8字符限制'}]
    },
    {
        prop: 'accountType',
        label: '一般（子）账户类别',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 30, message: '超过30字符限制'}]
    },
    {
        prop: 'accountstatus',
        label: '账户状态',
        labelWidth: 150,
        inputType: 'input',
        // inputType: {tag: 'select', options: 'AccountStatus'},
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}, {max: 10, message: '超过10字符限制'}]
    },
    {
        prop: 'currency',
        label: '币种',
        labelWidth: 150,
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{required: true, message: '必填'}],
        inputType: {tag: 'select', options: 'currency'}
    },
    {
        prop: 'cashRemit',
        label: '钞汇标志',
        labelWidth: 150,
        inputType: {tag: 'select', options: 'cashRemit'}
    },
    {
        prop: 'accountBalance',
        label: '账户余额',
        labelWidth: 150,
        rules: [{required: true, message: '必填'}],
        inputType: {tag: 'input', type: 'number'}
    },
    {
        prop: 'availableBalance',
        label: '可用余额',
        labelWidth: 150,
        rules: [{required: true, message: '必填'}],
        inputType: {tag: 'input', type: 'number'}
    },
    {
        prop: 'lastTransactionTime',
        label: '最后交易时间',
        labelWidth: 150,
        rules: [
            {pattern:'^[^<>&]*$',message: '存在特殊字符'},
            {required: true, message: '必填'},
            // {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
    },
    {
        prop: 'lastTransactionTimeRef',
        label: '参考最后交易时间',
        labelWidth: 150,
        rules: [
            {pattern:'^[^<>&]*$',message: '存在特殊字符'},
            // {required: true, message: '必填'},
            // {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
    }
]


export default {
    name,
    columns,
    searchFormItems,
    formItems,
    listName
}



































