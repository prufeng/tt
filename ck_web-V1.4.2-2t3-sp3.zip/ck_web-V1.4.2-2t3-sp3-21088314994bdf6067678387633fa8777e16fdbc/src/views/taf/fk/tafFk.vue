<template>
<!--  <div class="app-container">-->
  <rk-index-layout>
<!--  <rk-search-form ref="searchFormRef" v-model="searchForm" @keyup.enter="search" :form-items="searchFormItems" @search="search" :label-width="50"/>-->

    <rk-dynamic-search-form v-if="delaySearchFormRender" v-model="searchForm" :form-items="searchFormItems" :fields="advancedQueryItems"
                            @search="search" :advanced="advanced">
      <template #onlyQuerySucceeded>
        <el-checkbox :checked="dictData.matching!=undefined?true:false"/>
      </template>
    </rk-dynamic-search-form>

  <rk-page-table :loading="loading" :columns="columns" :data="tableData" :pagination="page" @refresh="search"
                 @page-change="pageChange" @selection-change="handleSelectionChange">
    <template #operations>
      <div style="display: flex; flex-direction: row">
        <rk-button-group
            :buttons="tableButtons()"
            :route-meta="$route.meta" :max="9"/>
        <div style="margin: 0 4px;"></div>
        <UpAndDown :imp="imp" :exp="exp"/>
      </div>
    </template>
    <template #status="{ row }">
      <el-popover
          v-if="row.status === '6'"
          placement="bottom"
          title="审核不通过原因"
          :width="250"
          trigger="hover"
      >
        <p class="tipck">操作: 审核不通过</p>
        <p class="tipck">操作人: {{row.approveBy}}</p>
        <p class="tipck">操作时间: {{row.approveTime}}</p>
        <p class="tipck">备注: {{row.approveDesc}}</p>
        <template #reference>
          <el-button  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
        </template>
      </el-popover>
      <el-popover
          v-else-if="row.status === '0'&&(row.resetBy!==null&&row.resetBy!=='')"
          placement="bottom"
          title="重置原因"
          :width="250"
          trigger="hover"
      >
        <p class="tipck">操作: 重置</p>
        <p class="tipck">操作人: {{row.resetBy}}</p>
        <p class="tipck">操作时间: {{row.resetTime}}</p>
        <p class="tipck">备注: {{row.resetDesc}}</p>
        <template #reference>
          <el-button  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
        </template>
      </el-popover>
      <el-button v-else  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
    </template>

    <template #deleteState="{ row }">
      <el-popover v-if="row.deleteState === '4'" placement="bottom" title="删除审核不通过原因" :width="250" trigger="hover">
        <p class="tipck">操作: 删除审核不通过</p>
        <p class="tipck">操作人: {{row.approveBy}}</p>
        <p class="tipck">操作时间: {{row.approveTime}}</p>
        <p class="tipck">备注: {{row.deleteComments}}</p>
        <template #reference>
          <el-button  link :type="getDelTagColor(row.deleteState)"  >{{ dictFormatter(row.deleteState, dictData.deleteStatusList) }}</el-button>
        </template>
      </el-popover>
      <el-button v-else  link :type="getDelTagColor(row.deleteState)"  >{{ dictFormatter(row.deleteState, dictData.deleteStatusList) }}</el-button>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="[]"
                       :max="9" link/>
    </template>
  </rk-page-table>
  </rk-index-layout>
  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" :close-on-click-modal="false">
    <ShowCx :fkReportCode="reportCode" :applicationID="applicationID" :trxId="trxId" :visible="dialogData.visible"></ShowCx>

    <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
      <!-- 标签页-主信息 -->
      <el-tab-pane key="first" label="详细信息" name='first'>
        <div style="display: flex; flex-direction: row">
          <el-space wrap :size="10">
            <rk-button-group v-if="subTables.length!==0&&dialogData.title!==getTitleName() + '新增'"
                             :buttons="dialogData.title === getTitleName() + '编辑' || dialogData.title === getTitleName() + '新增' ? dialogTableButtons() : []"
                             :route-meta="$route.meta" :max="9"/>
            <el-text v-if="subTables.length!==0&&dialogData.title!==getTitleName() + '新增'" class="mx-1" size="small">状态 :</el-text>
            <el-tag v-if="subTables.length!==0&&dialogData.title!==getTitleName() + '新增'" size="large">{{ status }}</el-tag>
          </el-space>
        </div>
        <br>
        <rk-detail-form ref="dialogFormRef" v-model="form" :form-items="formItems" :disabled="dialogData.formDisabled">

        </rk-detail-form>
      </el-tab-pane>
      <!-- 标签页-从表信息 -->
      <el-tab-pane v-for="(subTable, index) in subTables" :key="'sub'+index" :label="subTable.name" :name="'sub'+index" :disabled=subTabDisabled>
        <el-checkbox v-model="checked1" label="筛选待补录数据" size="large" @change="handleClick(undefined)"/>
        <rk-page-table :loading="loadingSub" :columns="subTable.columns" :data="subData" :pagination="subPage" @page-change="subPageChange"
                       @selection-change="handleSelectionChange" @refresh="handleClick(undefined)">
          <template #operations>
            <div style="display: flex; flex-direction: row">
              <rk-button-group v-if="dialogData.title === getTitleName() + '编辑'"
                               :buttons="subButtons(subTable.listName,subTable.items)"
                               :route-meta="$route.meta" :max="9"/>
              <!-- 417report入口-->
              <el-upload ref="upload417ReportRef" :show-file-list="false" :http-request="IUpload417ReportFile">
                <el-button ref="upload417ReportButton" id="upload417ReportButton" type="primary" style="display: none;">
                  导入417report
                </el-button>
              </el-upload>
            </div>
          </template>
          <template #status="{ row }">
            <el-popover
                v-if="row.status === '6'"
                placement="bottom"
                title="审核不通过原因"
                :width="250"
                trigger="hover"
            >
              <p class="tipck">操作: 审核不通过</p>
              <p class="tipck">操作人: {{row.approveBy}}</p>
              <p class="tipck">操作时间: {{row.approveTime}}</p>
              <p class="tipck">备注: {{row.approveDesc}}</p>
              <template #reference>
                <el-button  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
              </template>
            </el-popover>
            <el-popover
                v-else-if="row.status === '0'&&(row.resetBy!==null&&row.resetBy!=='')"
                placement="bottom"
                title="重置原因"
                :width="250"
                trigger="hover"
            >
              <p class="tipck">操作: 重置</p>
              <p class="tipck">操作人: {{row.resetBy}}</p>
              <p class="tipck">操作时间: {{row.resetTime}}</p>
              <p class="tipck">备注: {{row.resetDesc}}</p>
              <template #reference>
                <el-button  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
              </template>
            </el-popover>
            <el-button v-else  link :type="getTagColor(row.status)" >{{ dictFormatter(row.status, dictData.taf_status) }}</el-button>
          </template>

          <template #deleteState="{ row }">
            <el-popover v-if="row.deleteState === '4'" placement="bottom" title="删除审核不通过原因" :width="250" trigger="hover">
              <p class="tipck">操作: 删除审核不通过</p>
              <p class="tipck">操作人: {{row.approveBy}}</p>
              <p class="tipck">操作时间: {{row.approveTime}}</p>
              <p class="tipck">备注: {{row.deleteComments}}</p>
              <template #reference>
                <el-button  link :type="getDelTagColor(row.deleteState)"  >{{ dictFormatter(row.deleteState, dictData.deleteStatusList) }}</el-button>
              </template>
            </el-popover>
            <el-button v-else  link :type="getDelTagColor(row.deleteState)"  >{{ dictFormatter(row.deleteState, dictData.deleteStatusList) }}</el-button>
          </template>

          <template #actions="{ row }">
            <rk-button-group :buttons="dialogData.title === getTitleName() + '编辑'?subGenActButtons(row,subTable.listName,subTable.items):subGenActButtons2(row,subTable.listName,subTable.items)"
                             :route-meta="$route.meta" :max="2" link/>
          </template>
        </rk-page-table>
      </el-tab-pane>
    </el-tabs>
    <template #footer v-if="isShowSave">
      <span class="dialog-footer">
        <el-button v-if="activeName === 'first'&&(dialogData.title ===getTitleName() +'编辑'||dialogData.title ===getTitleName() +'新增')" @click="showConfirm" type="primary"> 保存</el-button>
        <el-button v-if="activeName === 'first'" @click="close"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>

  <el-dialog v-model="subDialogData.visible" :title="subDialogData.title" class="rk-dialog-default" @closed="subClosed"
             :close-on-click-modal="false">
    <rk-detail-form ref="subDialogFormRef" v-model="subForm" :form-items="subFormItems"
                    :disabled="subDialogData.formDisabled">
<!--      <template #accountNumberOptions>
        <el-select v-model="subForm.accountNumber" style="width: 650px">
          <el-option v-for="item in accountNumberArr" :key="item.accountNumber" :label="item.accountNumber"
                     :value="item.accountNumber" />
        </el-select>
      </template>-->
    </rk-detail-form>
    <template #footer>
               <span class="dialog-footer">
                 <el-button type="primary"
                            v-if="subDialogData.title.includes('编辑') || subDialogData.title.includes('新增')"
                            @click="showConfirm(listName)">保存</el-button>
                 <el-button @click="subClose"> 取消 </el-button>
               </span>
    </template>
  </el-dialog>

  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="审核" width="30%" draggable :append-to-body=true>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids)">审核通过</el-button>
        <el-button type="danger" @click="()=>{msgDialog = true;msg =''}">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 子表审核弹窗 -->
  <el-dialog v-model="subAuditDialog" title="审核" width="30%" draggable :append-to-body=true>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="subAudit(ids,listName)">审核通过</el-button>
        <el-button type="danger" @click="()=>{subMsgDialog = true;msg= ''}">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog" title="不通过原因" width="30%" draggable :append-to-body=true>
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
      <el-button type="primary" @click="auditNotPass(ids)">提交</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 主表删除审核弹窗 -->
  <el-dialog v-model="auditDelDialog" title="删除审核" width="30%" draggable :append-to-body=true>
    <!-- <span>是否删除审核通过,审核不通过请输入原因?</span>-->
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入删除审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="delAudit(ids, '1')">审核通过</el-button>
        <el-button type="danger" @click="delAudit(ids, '2')">审核不通过</el-button>
        <el-button type="default" @click="() => { auditDelDialog = false; }">取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 子表删除审核弹窗 -->
  <el-dialog v-model="auditDelDialogSub" title="删除审核" width="30%" draggable :append-to-body=true>
    <!-- <span>是否删除审核通过,审核不通过请输入原因?</span>-->
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入删除审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="delAuditSub(ids, '1', listName)">审核通过</el-button>
        <el-button type="danger" @click="delAuditSub(ids, '2', listName)">审核不通过</el-button>
        <el-button type="default" @click="() => { auditDelDialogSub = false; }">取消</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 子表审核不通过原因输入弹窗 -->
  <el-dialog v-model="subMsgDialog" title="不通过原因" width="30%" draggable :append-to-body=true>
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
      <el-button type="primary" @click="subAuditNotPass(ids,listName)">提交</el-button>
      </span>
    </template>
  </el-dialog>
<!--  </div>-->
  <!-- 批量提交/审核结果弹窗 -->
  <el-dialog v-model="submitAllVisible" title="提示" :close-on-click-modal=false :destroy-on-close=true :append-to-body=true>
    <el-collapse v-model="activeNames">
      <el-collapse-item name="1">
        <template #title>
          <div class="message-text">{{submitOrAudit}} 成功 <span  style="margin:0 5px;color:#67c23a;">{{successNum}}</span> 条数据, 失败 <span style="margin:0 5px;color:#f56c6c;">{{failNum}}</span> 条数据 </div>
        </template>
        <div style="box-sizing:border-box;" v-html="returnMassage"></div>
      </el-collapse-item>
    </el-collapse>
  </el-dialog>

  <ShowConfirm :visible="confirmVisible.visible" @callback="confirmCallback"></ShowConfirm>

  <CjConfirm ref="cjConfirmSaveRef" @callback="cjSaveConfirm"/>
<!--  <CjConfirm ref="cjConfirmAuditRef" @callback="cjAuditConfirm"/>-->
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';
import {useDict} from "riking-layout";
// TODO 启动时加载，不在页面里调用   子系统设置
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
useDict([], [], dictData)
</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage, ElFormItem, Action} from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  RkDetailForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, dictFormatter, RkDynamicSearchForm, RkIndexLayout,
} from 'riking-ui'

import DialogForm from 'riking-ui/dist/hooks/useDialogForm'

import {useDict} from 'riking-layout'
import {
  exportExcel,
  importExcel,
  saveData,
  subSaveData,
  listResult,
  list,
  submitBatch,
  auditBatch,
  auditNotPassBatch,
  resetBatch,
  recallBatch,
  delBatch,
  subSubmitBatch,
  subAuditBatch,
  subAuditNotPassBatch,
  subResetBatch,
  subRecallBatch,
  subDelBatch,
  submitAllBatch,
  auditAllBatch,
  auditNotPassAllBatch,
  listAccountNumber,
  checkExcelData,
  uploadTaf,
  delBatchAudit,
  delAuditNotPass,
  subDelBatchAudit,
  subDelBatchAuditNotPass,
  delAllBatch,
  auditDelAllBatch,
  auditDelNotPassAllBatch,
  getByApplicationIDAndTrxId, getUserInfo,resendTheRequestToESB
} from '@/views/taf/fk/api'
import {pagination, subPagination} from "@/views/taf/fk/config/data";
import UpAndDown from "@/components/UpAndDown.vue";
import {impLoading,expLoading} from "@/components/UpAndDown.vue";
import {listBusinessLine} from "@/views/query/feedback/api";
import {checkData, checkSpecialCharacters, specialChecks} from "@/utils/utils";
import {getRequestClassificationCode, getSubSystem} from "@/utils/subSystem";
import configs from "@/views/taf/fk/config/sum";
import {
  clearDefaultDateValue, convertNullDateToLine,
  dynamicSetItemDisabled, isEmpty,
  setDefaultDateValue,
  validateSwitchDict
} from "@/views/taf/fk/commonFk";
import useRouteParamsStore from '@/store/routeParamsStore';
import ShowCx from './ShowCx.vue';
import router from "@/router";
import ShowConfirm from "@/views/taf/fk/ShowConfirm.vue";
import CjConfirm from "@/views/taf/fk/CjConfirm.vue";

 const activeNames = ref(['1'])
 const activeName = ref('first')
 const tableData = ref<any []>([]);
 const subData = ref<any []>([]);
 const page = ref<Pagination>(pagination);
 const subPage = ref<Pagination>(subPagination);
 const searchFormRef = ref<RkFormInstance>()
 const searchForm = ref({ businessLine: ''});
 const subFormItems = ref([]);
 let listName = "";

useDict([], [], {
  ...dictData,
  result: async () => {
    const res = await listResult(getRequestClassificationCode());
    // // 定义应答码前两位集合
    // let arr = []
    // switch (reportCode.value) {
    //   case "100102":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11', '12', '13', '99']
    //     break;
    //   case "100104":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11','19','99']
    //     break;
    //   case "100202":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11', '14', '15', '99']
    //     break;
    //   case "100204":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '21', '24', '13', '99']
    //     break;
    //   case "100206":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11', '14', '20','24', '99']
    //     break;
    //   case "100302":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11', '22', '24', '99']
    //     break;
    //   case "100304":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11', '22', '24', '99']
    //     break;
    //   case "100310":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11', '22', '24', '99']
    //     break;
    //   case "100604":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11', '22', '24', '99']
    //     break;
    //   case "100714":
    //     arr = ['00', '01', '02', '03', '06', '08', '09', '10', '11', '22', '24', '99']
    //     break;
    // }
    // const newRes = res.data.filter(f => arr.includes(f.value.slice(0, 2)))
    // return newRes
    return res.data
  },
  branchCode: async () => {
    const res = await dictsStore.loadDict()
    return res.data.branchCode
  },
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data;
  },
})

 const applicationID = ref("")
 const parentId = ref("")
 const branchCode = ref("")
 const transSerialNumber = ref("")
 const reportCode = ref(''); // 报文编号
 const status = ref("")
 let columns: any[] = [],  searchFormItems: any[] = [], advancedQueryItems: any[] = []

const formItems = ref([]);

 let subTables: any[] = []
 const loading = ref(false);
 const loadingSub = ref(false);
 const auditDialog = ref(false);
 const subAuditDialog = ref(false);
 const msgDialog = ref(false);
 const subMsgDialog = ref(false);
 const msg = ref("");
 const txCode = ref("");
 const businessLineUser = ref();
 const checked1 = ref(false)

// 渲染后更新新advance为true, 高级查询不会展开，可能是封装的组件没监听，做法是延迟高级查询表单的渲染，在确定advance值后再渲染
const delaySearchFormRender = ref(true)
const advanced = ref(false)

const cjConfirmSaveRef = ref<FormInstance>();
// const cjConfirmAuditRef = ref<FormInstance>();

const confirmReportCode = ['100302', '100304', '100310']
const confirmVisible = reactive({visible: false})

const callSave = () => {
  if(subDialogData.visible) {
    save1(null, listName)
  } else {
    save()
  }
}

const showConfirm = () => {
  // 100702 100704 惩戒失败提醒开关  三菱个性化需求
  if (reportCode.value === '100702' || reportCode.value === '100704') {
    let flag = validateSwitchDict(dictData, 'cjsbtx');
    let prosResult = form.value.prosResult;
    // 反馈结果为失败，且开关打开的情况下，进行提醒
    if (flag && prosResult == "02") {
      cjConfirmSaveRef.value.show();
      return;
    }
  }

  if(confirmReportCode.includes(txCode.value)) {
    callSave()
    return;
  }

  let flag = validateSwitchDict(dictData, 'SaveReminder')
  if(flag) {
    confirmVisible.visible = true;
  } else {
    callSave()
  }
}
const confirmCallback = (flag: boolean) => {
  confirmVisible.visible = false;
  if(flag) {
    callSave()
  }
}

// 惩戒保存确认
const cjSaveConfirm = (flag: boolean) => {
  if(flag) {
    callSave()
  }
}

// // 惩戒审核确认
// const cjAuditConfirm = (flag: boolean) => {
//   if(flag) {
//     audit(ids)
//   }
// }

const store = useRouteParamsStore();

//初始化
onMounted(() => {
  page.value = {...pagination}
  delaySearchFormRender.value = false;
  const params = store.getParams();
  if(Object.keys(params).length) {
    if(params.status != undefined) {
      searchForm.value = { businessLine: '', filters : [
          {key: 1, field: '', operator: '', value: ''},
          {key: 2, field: '', operator: '', value:''},
          {key: 3, field: '', operator: '', value: ''}
        ] }
    } else {
      searchForm.value = { businessLine: '', filters : [
          {key: 2, field: '', operator: '', value:''},
          {key: 3, field: '', operator: '', value: ''}
        ] }
    }
  }

  nextTick(() => {
    refresh()
    nextTick(()=>{
      setRouteParams();
      store.setParams({});
      getBusinessLine();
    })
  })

  getConfigs();
  if (dictData.matching!=undefined){
    if(reportCode.value === '100702' || reportCode.value === '100704'){
      searchForm.value.matchResult=true
    }else{
      searchForm.value.onlyQuerySucceeded=true
    }
  }
})

//主表查询方法
 const search = async () => {
  loading.value = true;
  try {
    let formData = checkData(searchForm.value);
    //100702和100704匹配成功参数
    if(formData.matchResult) formData.matchResult ='01'
    else if(!formData.matchResult) delete formData.matchResult
  
    const result = await list(reportCode.value, formData, page.value.currentPage, page.value.pageSize);
    const {current, total, records} = result.data;
    tableData.value = records;
    page.value.currentPage = current;
    page.value.total = total;
  }finally {
    loading.value = false;
  }
}

/**
 * 代办汇总跳转到反馈页面
 */
const setRouteParams = () => {
  const routeParams = store.getParams();

  if(routeParams != undefined && Object.keys(routeParams).length > 0) {
    let filters;
    if (routeParams['searchTime'] == null || routeParams['searchTime'] == undefined) {
      filters = [
        {key: 1, field: 'status', operator: 'eq', value: routeParams['status']}
      ];
    } else {
      filters = [
        {key: 1, field: 'status', operator: 'eq', value: routeParams['status']},
        {key: 2, field: 'create_time', operator: 'ge', value: routeParams['searchTime'][0]},
        {key: 3, field: 'create_time', operator: 'le', value: routeParams['searchTime'][1]}
      ];
    }

    if(routeParams['status'] == undefined) {
      filters.shift();
    }

    const params = {
      filters,
      businessLine: routeParams['businessLine'],
      branchCodeList: routeParams['branchCode'],
    }

    searchForm.value = params;
  }
  // store.setParams({});
}

async function getBusinessLine() {
  try {
    const res = await listBusinessLine();
    const data1 = res.data;
    businessLineUser.value=res.data;
    if (data1.length === 0) {
      ElMessage.error({message:"用户未配置业务线,无法查询数据", grouping: true, showClose: true, duration: 0});
      searchForm.value.businessLine = '';
    } else {
      searchForm.value.businessLine = data1[0].value;
    }
  } catch (error) {
    console.error('Error fetching business line:', error);
  }finally {
    search();
  }
}

watch(() => store.params, (newVal) => {
  if(Object.keys(newVal).length) {
    advanced.value = false
    delaySearchFormRender.value = false;

    if(newVal.status != undefined) {
      searchForm.value = { businessLine: '', filters : [
          {key: 1, field: '', operator: '', value: ''},
          {key: 2, field: '', operator: '', value:''},
          {key: 3, field: '', operator: '', value: ''}
        ] }
    } else {
      searchForm.value = { businessLine: '', filters : [
          {key: 2, field: '', operator: '', value:''},
          {key: 3, field: '', operator: '', value: ''}
        ] }
    }


    nextTick(() => {
      refresh()
      nextTick(() => {
        setRouteParams();
        search();
      })
    })
  }
})

const refresh = () => {
  const routeParams = store.getParams();
  if(routeParams != undefined && Object.keys(routeParams).length > 0) {
    advanced.value = true;
    delaySearchFormRender.value = true;
  } else {
    delaySearchFormRender.value = true;
  }

}

// watch(() => [searchForm.value], (newForm, oldForm) => {
//   console.log(newForm)
// }, {deep: true})

//获取主表页面字段配置与表单配置
 const getConfigs = () => {
  // 获取当前路由
  // const router = useRouter()
  const route = useRoute()
  const path = route.path;
  reportCode.value = getRequestClassificationCode();
  const key = `config${reportCode.value}`
  const obj = (configs as any)[key];
  columns = obj['columns'];
  if(dictData.showIsOpenAccount == undefined) {
    columns = columns.filter(item => "isOpenAccount" != item.prop);
  }
  formItems.value = obj['formItems'];
  searchFormItems = obj['searchFormItems'];
  advancedQueryItems = obj['advancedQueryItems'];
  getSubConfigs();
}
//获取从表页面字段配置与表单配置
const getSubConfigs = () => {
  let keyList: string[] = [];
  switch (reportCode.value){
    case'100302':
      keyList = ['configAccount', 'configAccountSub', 'configTransaction'];break
    case'100306':
      keyList = ['configTransaction'];break
    case'100310':
      keyList = ['configAccount100310', 'configAccountSub', 'configMeasure','configPriority'];break
    case'100406':
      keyList = ['configDoubtfulAccounts'];break
  }
  const list = []
  for (const key in keyList) {
    const obj = (configs as any)[keyList[key]];
    // console.log(obj);
    // console.log(keyList[key]);
    list.push({name:obj.name,items:obj.formItems, columns:obj.columns,listName:obj.listName})
  }
  subTables = list;
}
//主表页面变更触发方法
 const pageChange = (p: Pagination) => {
  page.value = p
  search()
}
//子表页面变更触发方法
 const subPageChange = (p: Pagination) => {
  subPage.value = p
  handleClick(undefined)
}

//主表提交方法
 const submit = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  /*checkCardNumber();
   if (isNull.value==true){
     isNull.value=false
     return
   }*/
   try {
     const rs = await submitBatch({},reportCode.value,ids);
     status.value=status.value = dictFormatter("2",dictData.taf_status)
     // close();
     status.value = status.value = dictFormatter("2", dictData.taf_status)
     ElMessage.success(rs.data);
   }finally {
     await search();
   }
}

//主表提交方法,详细页面保存
 const submitAndSave = async (data:any,ids: string) => {
   if (ids == undefined || ids.length == 0) {
     ElMessage.warning('请先选择数据')
     return
   }
   try {
     const valid = await dialogFormRef.value?.asyncValidate();
     const data = toRaw(form.value);
     const specialChecksReturn = specialChecks(data, getSubSystem(), reportCode.value);
     if (specialChecksReturn.clear) {
       await dialogFormRef.value?.clearValidate();
     }
     // 返回值 true是允许保存 , false是不允许保存
     if (!specialChecksReturn.result) {
       ElMessage.error({message:specialChecksReturn.msg, grouping: true, showClose: true, duration: 0});
       return;
     }
     //校验是否存在特殊字符
     if (checkSpecialCharacters(data)) {
       await dialogFormRef.value?.asyncValidate();
       ElMessage.error({message:"存在特殊字符", grouping: true, showClose: true, duration: 0});
       return;
     }
     //校验必填项(仅当特殊校验通过时才进行)
     if (!valid && specialChecksReturn.continueToVerify) {
       await dialogFormRef.value?.asyncValidate();
       ElMessage.error({message:"存在必填项未填", grouping: true, showClose: true, duration: 0});
       return;
     }
     const rs = await submitBatch(data, reportCode.value, ids);
     status.value = status.value = dictFormatter("2", dictData.taf_status)
     // close();
     status.value = status.value = dictFormatter("2", dictData.taf_status)
     ElMessage.success(rs.data);
   } finally {
     await search();
   }
}

//主表审核方法
 const audit = async (ids: any) => {
  try {
    if (reportCode.value == "100702" || reportCode.value == "100704") {
      let flag = validateSwitchDict(dictData, 'cjsbtx');
      // 开启开关，并且反馈失败的情况
      if (flag && existFailProsResult) {
        await cjAudit(ids)
        return;
      }
    }

    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    const rs =  await auditBatch(reportCode.value,ids);
    status.value = status.value = dictFormatter("3", dictData.taf_status)
    ElMessage.success(rs.data);
  }finally {
    auditDialog.value = false;
    await search();
  }
}

/**
 * 惩戒页面 100702，100704页面审核
 * 惩戒反馈或惩戒解除反馈如果存在失败，先提示消息，然后在提示审核通过消息
 */
const cjAudit = async (ids: any) => {
    ElMessageBox.confirm(
        '无特殊原因不建议反馈失败，如需反馈失败，请先联系总行！',
        '警告',
        {
          confirmButtonText: '确认',
          cancelButtonText: '取消',
          type: 'warning',
          distinguishCancelAndClose: true,
          confirmButtonClass:'auditButton',
          cancelButtonClass:'auditNotPassButton',
          // customStyle: ''
        }
    ).then(async () =>
        {
          try {
            if (ids == undefined || ids.length == 0) {
              ElMessage.warning('请先选择数据')
              return
            }
            const rs =  await auditBatch(reportCode.value, ids);
            status.value = status.value = dictFormatter("3", dictData.taf_status)
            ElMessage.success(rs.data);
          }finally {
            auditDialog.value = false;
            await search();
          }
        }
    ).catch((action: Action) => {})
}

const auditNotPass = async (ids: any) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    const rs =  await auditNotPassBatch(reportCode.value,ids,msg.value);
    status.value=status.value = dictFormatter("6",dictData.taf_status)
    ElMessage.success(rs.data);
  }finally {
    msgDialog.value = false;
    auditDialog.value = false;
    await search();
  }
}

//主表重置方法
 const reset = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }

  ElMessageBox.prompt('重置原因', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
      .then(async ({value}) => {
        const rs = await resetBatch(reportCode.value,ids,value);
        await search();
        status.value = status.value = dictFormatter("1", dictData.taf_status)
        ElMessage.success(rs.data);
      })
      .catch(() => {
        search();
        return;
      })

}
//主表撤回方法
 const recall = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  const rs = await recallBatch(reportCode.value,ids);
  await search();
  status.value = status.value = dictFormatter("1", dictData.taf_status)
  ElMessage.success(rs.data);
}
// 全量删除
const delAll = async () => {
  ElMessageBox.confirm('是否批量删除所有待补录/待提交数据?', '警告', {confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning'})
      .then(async () => {
        const newObject = {...searchForm.value};
        for (const key in newObject) {
          if (newObject[key] === '') {
            newObject[key] = null;
          }
        }
        const rs = await delAllBatch(getRequestClassificationCode(), newObject,  null, false,reportCode.value);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '批量删除';
        submitAllVisible.value = true;
        search()
      }).catch(() => {
        return;
      });
}
//主表批量删除方法
const del = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
   ElMessageBox.confirm('您确定删除所选中的待提交或待补录的数据吗?', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning',}
   ).then(async () => {
     try {
       const rs = await delBatch(reportCode.value,ids);
       ElMessage.success(rs.data);
     }finally {
       await search();
     }
   }).catch(() => {
     return;
   });
}
const auditDelDialog = ref(false);
// 全量删除审核
const auditDelAll = async () => {
  ElMessageBox.confirm('是否批量删除审核所有删除待审核数据?', '警告', {
        confirmButtonText: '审核通过',
        cancelButtonText: '审核不通过',
        type: 'warning',
        distinguishCancelAndClose: true,
        confirmButtonClass:'auditButton',
        cancelButtonClass:'auditNotPassButton',
      }
  ).then(async () => {
        const newObject = {...searchForm.value};
        for (const key in newObject) {
          if (newObject[key] === '') {
            newObject[key] = null;
          }
        }
        const rs = await auditDelAllBatch(getRequestClassificationCode(), newObject,null, false);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '删除审核'
        submitAllVisible.value = true;
        search();
      }).catch((action: Action) => {
        if (action === 'cancel') {
          ElMessageBox.prompt( '删除审核不通过理由','提示',{confirmButtonText: '确定',cancelButtonText: '取消',inputType:'textarea'})
              .then(async ({ value }) => {
                if (value == null || value == '') {
                  ElMessage.warning('删除审核不通过原因必填！')
                  return;
                }
                const newObject = {...searchForm.value};
                for (const key in newObject) {
                  if (newObject[key] === '') {
                    newObject[key] = null;
                  }
                }
                const rs = await auditDelNotPassAllBatch(getRequestClassificationCode(), newObject,null, false, value);
                successNum.value = rs.data.successNum;
                failNum.value = rs.data.failNum;
                returnMassage.value = rs.data.returnMassage;
                submitOrAudit.value = '删除审核不通过'
                submitAllVisible.value = true;
                search();
              }).catch(() => {
                return;
              });
        }
      })
}
const delAudit = async (ids: string, type: string) => {
  if ((msg.value == null || msg.value == '') && type == '2') {
    ElMessage.warning('删除审核不通过原因必填！')
    return;
  }
  try {
    let rs;
    if (type == '1') {
      rs = await delBatchAudit(reportCode.value,ids);
    } else {
      rs = await delAuditNotPass(reportCode.value,ids,msg.value);
    }
    ElMessage.success(rs.data);
  }finally {
    await search();
    auditDelDialog.value = false;
  }
}

const auditDelDialogSub = ref(false);
const delAuditSub = async (ids: string, type: string, name: string) => {
  if ((msg.value == null || msg.value == '') && type == '2') {
    ElMessage.warning('删除审核不通过原因必填！')
    return;
  }
  try {
    let rs;
    if (type == '1') {
      rs = await subDelBatchAudit(ids,name);
    } else {
      rs = await subDelBatchAuditNotPass(ids,msg.value,name);
    }
    ElMessage.success(rs.data);
  }finally {
    await handleClick(undefined);
    await search();
    auditDelDialogSub.value = false;
  }
}

const handleUpload = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  try {
    const rs = await uploadTaf(ids, reportCode.value);
    ElMessage.success(rs.data);
  } finally {
    await search();
  }

}
//主表重发ESB方法
const resendTheRequestToTheESB = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  ElMessageBox.confirm('您确定重新发送请求给ESB吗?', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning',}
  ).then(async () => {
    try {
      loading.value = true;
      const rs = await resendTheRequestToESB(reportCode.value,ids);
      ElMessageBox.alert(rs.data, '反馈结果', {
        confirmButtonText: 'OK',
        dangerouslyUseHTMLString: true,
        customStyle: {
          'max-width': '70%'
        }
      })
    }finally {
      await search();
      loading.value = false;
    }
  }).catch(() => {
    return;
  });
}
//子表提交方法
 const subSubmit = async (ids: string, name: string) => {
  if (ids == undefined || ids.length == 0) {
    subSubmitAll(name);
    return
  }
  const rs = await subSubmitBatch(ids, name);
  await handleClick(undefined);
  ElMessage.success(rs.data);
}

//子表审核方法
 const subAudit = async (ids: any, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    const rs = await subAuditBatch(ids, name);
    ElMessage.success(rs.data);
  }finally {
    subAuditDialog.value = false;
    await handleClick(undefined);
  }
}

 const subAuditNotPass = async (ids: any, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    const rs =  await subAuditNotPassBatch(ids,name,msg.value);
    ElMessage.success(rs.data);
  }finally {
    subMsgDialog.value = false;
    subAuditDialog.value = false;
    await handleClick(undefined);
  }
}

//子表重置方法
 const subReset = async (ids: string, name: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  ElMessageBox.prompt('重置原因', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
      .then(async ({value}) => {
        const rs =  await subResetBatch(ids, name,value);
        await handleClick(undefined);
        ElMessage.success(rs.data);
      })
      .catch(() => {
        return;
      })

}

//子表撤回方法
 const subRecall = async (ids: string, name: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  const rs =  await subRecallBatch(ids, name);
  await handleClick(undefined);
  ElMessage.success(rs.data);
}
const subDelAll = async (name:string) => {
  ElMessageBox.confirm('是否批量删除所有待补录/待提交数据?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
  ).then(async () => {
    const rs = await delAllBatch(name, {applicationID:applicationID.value,branchCode:branchCode.value==null?'null':branchCode.value,trxId:trxId.value}, applicationID.value, true, reportCode.value);
    successNum.value = rs.data.successNum;
    failNum.value = rs.data.failNum;
    returnMassage.value = rs.data.returnMassage;
    submitOrAudit.value = '批量删除';
    submitAllVisible.value = true;
    await handleClick(undefined);
  }).catch(() => {
    return
  })
}
const subDelAuditAll = async (name:string) => {
  ElMessageBox.confirm('是否批量删除审核所有删除待审核数据?', '警告', {
        confirmButtonText: '审核通过',
        cancelButtonText: '审核不通过',
        type: 'warning',
        distinguishCancelAndClose: true,
        confirmButtonClass:'auditButton',
        cancelButtonClass:'auditNotPassButton',
      }
  ).then(async () => {
        const rs = await auditDelAllBatch(name, {},applicationID.value, true);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '删除审核';
        submitAllVisible.value = true;
        await handleClick(undefined);
      }).catch((action: Action) => {
        if (action === 'cancel') {
          ElMessageBox.prompt('删除审核不通过理由', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
              .then(async ({value}) => {
                if (value == null || value == '') {
                  ElMessage.warning('删除审核不通过原因必填！')
                  return;
                }
                const rs = await auditDelNotPassAllBatch(name, {}, applicationID.value, true, value);
                successNum.value = rs.data.successNum;
                failNum.value = rs.data.failNum;
                returnMassage.value = rs.data.returnMassage;
                submitAllVisible.value = true;
                submitOrAudit.value = '删除审核不通过';
                await handleClick(undefined);
              }).catch(() => {
                return;
              })
        }
      })
}
//子表批量删除方法
 const subDel = async (ids: string, name: string) => {
  // if (ids == undefined || ids.length == 0) {
  //   ElMessage.warning('请先选择数据')
  //   return
  // }
   if (ids == undefined || ids.length == 0) {
     subDelAll(name);
     return
   }
   ElMessageBox.confirm('您确定删除所选中的待提交或待补录的数据吗?', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning',}
   ).then(async () => {
     try {
       const rs = await subDelBatch(ids, name);
       ElMessage.success(rs.data);
     }finally {
       await handleClick(undefined);
       await search(); // 刷新最外层页面
     }
   }).catch(() => {
     return;
   });
}

//获取弹窗标题名
 const getTitleName = () => {
  switch (getRequestClassificationCode()) {
    case '100102' : return '止付反馈'
    case '100104' : return '止付解除反馈'
    case '100106' : return '止付延期反馈'
    case '100202' : return '冻结反馈'
    case '100204' : return '冻结解除反馈'
    case '100206' : return '冻结延期反馈'
    case '100302' : return '账户交易明细查询反馈'
    case '100304' : return '账户持卡主体查询反馈'
    case '100306' : return '账户动态查询反馈'
    case '100308' : return '账户动态查询反馈解除'
    case '100310' : return '客户全账户查询反馈'
    case '100406' : return '可疑账户数据上报'
    case '100501' : return '涉案/可疑名单单要素验证'
    case '100503' : return '涉案/可疑名单双要素验证'
    case '100602' : return '涉赌账户核查反馈'
    case '100604' : return '可疑账户指定机构推送排查反馈'
    case '100702' : return '惩戒管控反馈'
    case '100704' : return '解除惩戒管控反馈'
    case '100714' : return '涉案账户管控下发反馈'
  }
}

//获取子表弹窗标题名
 const getSubTitleName = (name: string) => {
  switch (name) {
    case 'fkAccountTaf' : return '账户信息'
    case 'fkAccountTaf310' : return '账户信息'
    case 'fkMeasureTaf' : return '强制措施'
    case 'fkPriorityTaf' : return '共有权/优先权'
    case 'fkSubAccountTaf' : return '关联子账户'
    case 'fkTransactionTaf' : return '交易明细'
    case 'fkDoubtfulAccountsTaf' : return '可疑账户明细'
  }
}

//子表查询方法
const subSearch = async (name:string) => {
  const value = checked1.value;
  loadingSub.value = true;
  try{
    let formData = checkData(searchForm.value);
    const res = await list(reportCode.value, formData, page.value.currentPage, page.value.pageSize);
    const zbData=res.data.records.filter(f=>f.id==parentId.value)[0]
    let data = {applicationID:applicationID.value,branchCode:zbData.branchCode==null?'null':zbData.branchCode,trxId:trxId.value}
    if (value) {
      data = {applicationID:applicationID.value,status:'0',branchCode:zbData.branchCode==null?'null':zbData.branchCode,trxId:trxId.value}
    }
    const result = await list(name,data, subPage.value.currentPage, subPage.value.pageSize);
    const {current, total, records} = result.data;
    subData.value = records;
    subPage.value.currentPage = current;
    subPage.value.total = total;
  }finally {
    loadingSub.value = false;
  }
}

//该属性用来记录上一次打开的标签页 , 因为在子表中使用刷新按钮是无法传入tab参数的
let tabName = "";
const accountNumberArr = ref<any[]>([])
const trxId = ref()


const accountNumberOption = () => {
  //100302的定位账户账号下拉框取fkSubAccountTaf的accountNumber,100306取100306的accountNumber
  listAccountNumber( {applicationID: applicationID.value},reportCode.value=='100306'?reportCode.value:'fkSubAccountTaf'
  ).then(res => {
    accountNumberArr.value = res.result
  })
}

//标签页切换触发方法
 const handleClick = (tab: any) => {
  if (tab==undefined) {
    switch (tabName) {

      case "账户信息" : reportCode.value=='100310'?subSearch("fkAccountTaf310"):subSearch("fkAccountTaf"); break;
      case "强制措施" : subSearch("fkMeasureTaf"); break;
      case "共有权/优先权" :subSearch("fkPriorityTaf"); break;
      case "关联子账户" : subSearch("fkSubAccountTaf");break;
      case "交易明细" :
        accountNumberOption();
        subSearch("fkTransactionTaf");break;
      case "可疑账户明细" : subSearch("fkDoubtfulAccountsTaf");break;
    }
  }else {
    subPage.value.currentPage = 1;
    tabName = tab.props.label;
    switch (tab.props.label) {
      case "账户信息" : reportCode.value=='100310'?subSearch("fkAccountTaf310"):subSearch("fkAccountTaf"); break;
      case "强制措施" : subSearch("fkMeasureTaf"); break;
      case "共有权/优先权" :subSearch("fkPriorityTaf"); break;
      case "关联子账户" : subSearch("fkSubAccountTaf");break;
      case "交易明细" :
        accountNumberOption();
        subSearch("fkTransactionTaf");break;
      case "可疑账户明细" : subSearch("fkDoubtfulAccountsTaf");break;
    }
  }
}
const isNull=ref(false);
const applicationIDs=ref([]);
//校验卡折号
const checkCardNumber = () => {
  tableData.value.map((item,index)=>{
    const accountType=item.accountType
    const reportCodeList = ['100102','100104','100106','100202','100204','100206']
    if (accountType=="01"&&reportCodeList.includes(reportCode.value)) {
      const cardNumber = item.cardNumber;
      if (cardNumber==undefined||cardNumber=='') {
        applicationIDs.value.push(item.applicationID)
        isNull.value=true
      }
    }
  })
  if (isNull.value==true){
    const applicationIDToString=applicationIDs.value.join(',')
    ElMessage.error({message:'业务申请编号'+applicationIDToString+'账号类别为个人时,卡/折号必填', grouping: true, showClose: true, duration: 0});
    applicationIDs.value=[]
  }
}

 const submitAllVisible = ref(false);
 const successNum = ref(0);
 const failNum = ref(0);
 const returnMassage = ref('');
 const submitOrAudit = ref('');
 const submitAll = async () => {
  ElMessageBox.confirm(
      '是否批量提交所有待提交/待补录数据?',
      '警告',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
  )
      .then(async () => {
        /*checkCardNumber();
        if (isNull.value==true){
          isNull.value=false
          return
        }*/
        const newObject = {...searchForm.value};
        for (const key in newObject) {
          if (newObject[key] === '') {
            newObject[key] = null;
            // console.log("转化了空串")
          }
        }
        const rs = await submitAllBatch(getRequestClassificationCode(), newObject,  null, false,reportCode.value);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '提交'
        submitAllVisible.value = true;
        search()
      })
      .catch(() => {
        return
      })
}

 const auditAll = async () => {
  ElMessageBox.confirm(
      '是否批量审核所有待审核数据?',
      '警告',
      {
        confirmButtonText: '审核通过',
        cancelButtonText: '审核不通过',
        type: 'warning',
        distinguishCancelAndClose: true,
        confirmButtonClass:'auditButton',
        cancelButtonClass:'auditNotPassButton',
      }
  )
      .then(async () => {
        const newObject = {...searchForm.value};
        for (const key in newObject) {
          if (newObject[key] === '') {
            newObject[key] = null;
            // console.log("转化了空串")
          }
        }
        const rs = await auditAllBatch(getRequestClassificationCode(), newObject,null, false);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '审核'
        submitAllVisible.value = true;
        search()
      })
      .catch((action: Action) => {
        if (action === 'cancel') {
          ElMessageBox.prompt( '审核不通过理由','提示',{confirmButtonText: '确定',cancelButtonText: '取消',inputType:'textarea'})
              .then(async ({ value }) => {
                const newObject = {...searchForm.value};
                for (const key in newObject) {
                  if (newObject[key] === '') {
                    newObject[key] = null;
                    // console.log("转化了空串。")
                  }
                }
                const rs = await auditNotPassAllBatch(getRequestClassificationCode(), newObject,null, false, value);
                successNum.value = rs.data.successNum;
                failNum.value = rs.data.failNum;
                returnMassage.value = rs.data.returnMassage;
                submitOrAudit.value = '审核不通过'
                submitAllVisible.value = true;
                search()
              })
              .catch(() => {
                return;
              })
        }
      })
}

 const subSubmitAll = async (name:string) => {
  ElMessageBox.confirm('是否批量提交所有待提交/待补录数据?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
  ).then(async () => {
        const rs = await submitAllBatch(name, {branchCode:branchCode.value==null?'null':branchCode.value,trxId:trxId.value}, applicationID.value, true,reportCode.value);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '提交'
        submitAllVisible.value = true;
        await handleClick(undefined);
      }).catch(() => {
        return
      })
}
 const subAuditAll = async (name:string) => {
  ElMessageBox.confirm(
      '是否批量审核所有待审核数据?',
      '警告',
      {
        confirmButtonText: '审核通过',
        cancelButtonText: '审核不通过',
        type: 'warning',
        distinguishCancelAndClose: true,
        confirmButtonClass:'auditButton',
        cancelButtonClass:'auditNotPassButton',
      }
  )
      .then(async () => {
        const rs = await auditAllBatch(name, {branchCode:branchCode.value==null?'null':branchCode.value,trxId:trxId.value},applicationID.value, true);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '审核'
        submitAllVisible.value = true;
        await handleClick(undefined);
      })
      .catch((action: Action) => {
        if (action === 'cancel') {
          ElMessageBox.prompt('审核不通过理由', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
              .then(async ({value}) => {
                const rs = await auditNotPassAllBatch(name, {}, applicationID.value, true, value);
                successNum.value = rs.data.successNum;
                failNum.value = rs.data.failNum;
                returnMassage.value = rs.data.returnMassage;
                submitAllVisible.value = true;
                submitOrAudit.value = '审核不通过'
                await handleClick(undefined);
              })
              .catch(() => {
                return;
              })
        }
      })
}

//获取checkBox 的ids
let ids: string;

 // 检查选中行是否存在反馈失败的
let existFailProsResult: boolean = false;

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");

  const result = val.filter((item: any) => item.prosResult == "02");
  existFailProsResult = result.length ? true : false;
}

const checkResult = async (data: {}) => {
  if (data.hasOwnProperty('prosResult')) {
    let value = data['prosResult'];

    // let b = false;
    // if (value == undefined || value == '' || value == '-') {
    //   return false;
    // }
    if ("01" === value) {
      return true;
    }

    // fail
    if ("02" === value) {
      let failReasonCd = data['failReasonCd'];
      if (failReasonCd == undefined || failReasonCd == '') {
        return true;
      }
      return false;
    }
  }

  if (data.hasOwnProperty('result')) {
    let value = data['result'];
    if (value == undefined || value == '') {
      return false;
    }
    return "0000" === value;
  }
}

//主表保存方法
const save = async () => {
  // 部分日期必填项存在实际情况没有值的，此处设置个默认值，用以通过校验
  setDefaultDateValue(form.value)
  let valid = await dialogFormRef.value?.asyncValidate();
  const data = toRaw(form.value);

  // 结果为失败的，没成功也可以继续保存
  const succ = await checkResult(form.value);
  if (!succ) {
    valid = true;
  }

  if(!valid) return; // 校验未通过不能保存
  // 100304 不填销户日期不走这个校验
  if(reportCode.value === '100304') {
    let accountCancellationTime = data.accountCancellationTime;
    if(accountCancellationTime != '1970-01-02 00:00:00') {
      accountCancellationTime = new Date(accountCancellationTime);
      let accountOpenTime = new Date(data.accountOpenTime);
      if (accountCancellationTime.getTime() < accountOpenTime.getTime()){
        ElMessage.warning("销户日期需大于等于开户日期");
        return
      }
    }
  }

  const specialChecksReturn = specialChecks(data, getSubSystem(), reportCode.value);
  const resultList = reportCode.value=="100714"?['01','03']:['00','12','14','24']

  if (specialChecksReturn.clear || !resultList.includes(data?.result?.substring(0,2))) {
    await dialogFormRef.value?.clearValidate();
  }
  // if (dictData.departmentCodeRequired!=undefined && data.departmentCode==null){
  //   ElMessage.error({message:"部门字段必填！", grouping: true, showClose: true, duration: 0});
  //   return;
  // }
  // 返回值 true是允许保存 , false是不允许保存
  if (!specialChecksReturn.result && resultList.includes(data?.result?.substring(0,2))) {
    ElMessage.error({message:specialChecksReturn.msg, grouping: true, showClose: true, duration: 0});
    return;
  }
  //校验是否存在特殊字符
  if (checkSpecialCharacters(data) && resultList.includes(data?.result?.substring(0,2))) {
    await dialogFormRef.value?.asyncValidate();
    ElMessage.error({message:"存在特殊字符", grouping: true, showClose: true, duration: 0});
    return;
  }
  //校验必填项(仅当特殊校验通过时才进行)
  if (!valid && specialChecksReturn.continueToVerify && !(reportCode.value == '100604' && data.caseType == '1002') && resultList.includes(data?.result?.substring(0,2))) {
    await dialogFormRef.value?.asyncValidate();
    ElMessage.error({message:"存在必填项未填", grouping: true, showClose: true, duration: 0});
    return;
  }
  data.status = '1';
  const accountType = data.accountType;
  const reportCodeList = ['100102','100104','100106','100202','100204','100206']
  if (accountType=="01"&&reportCodeList.includes(reportCode.value) && resultList.includes(data?.result?.substring(0,2))) {
    const cardNumber = data.cardNumber;
    if (cardNumber==undefined||cardNumber=='') {
      ElMessage.error({message:"账号类别为个人时,卡/折号必填", grouping: true, showClose: true, duration: 0});
      return
    }
  }

  /*if (data.updateType=='01' && resultList.includes(data?.result?.substring(0,2))){
    if (data.opnInsId==undefined||data.opnInsId=='') {
      ElMessage.error({message:"业务类型为管控时,开户机构标识必填", grouping: true, showClose: true, duration: 0});
      return
    }
    if (data.opnInsNm==undefined||data.opnInsNm=='') {
      ElMessage.error({message:"业务类型为管控时,开户机构名称必填", grouping: true, showClose: true, duration: 0});
      return
    }
    if (data.processMeasure == undefined || data.processMeasure == '') {
      ElMessage.error({message: "业务类型为管控时,处置方式必填", grouping: true, showClose: true, duration: 0});
      return
    }
    if ((data.balance == undefined || data.balance == null || data.balance.toString() == '') && resultList.includes(data?.result?.substring(0,2))) {
      ElMessage.error({message: "业务类型为管控时,管控账户余额必填", grouping: true, showClose: true, duration: 0});
      return
    }
    if ((data.currency == undefined || data.currency == '') && resultList.includes(data?.result?.substring(0,2))) {
      ElMessage.error({message: "业务类型为管控时,币种必填", grouping: true, showClose: true, duration: 0});
      return
    }
  }*/

  delete data.type;
    for (const key in data) {
      if (Object.prototype.hasOwnProperty.call(data, key)) {
        // 检查属性名称的首字母是否为大写
        if (key[0] === key[0].toUpperCase()) {
          // 删除属性
          delete data[key];
        }
      }
    }
  clearDefaultDateValue(data); // 验证通过后重置为null保存
  await saveData(reportCode.value, data,false);
  if (dialogData.title ===getTitleName() +'新增') {
    close();
  }
  await search();
  status.value = status.value = dictFormatter("1", dictData.taf_status)
  if (subTables.length === 0) {
    close();
  }
  ElMessage.success("保存成功");
}

const getTagColor = (status:string) => {
  if (status=='6') {
    return 'danger'
  } else {
    return 'primary';
  }
}
const getDelTagColor = (status:string) => {
  if (status=='4') {
    return 'danger'
  } else {
    return 'primary';
  }
}
const imp = async (data = {}) => {
  impLoading.value = true;
  try {
    //@ts-ignore
  var name = data.name;
  if (name == null) {
    name = data[0].name;
  }
  if (!name.toLowerCase().endsWith(".xlsx") && !name.toLowerCase().endsWith(".xls")) {
    ElMessage.error({message:"仅可上传Excel文件", grouping: true, showClose: true, duration: 0});
    return;
  }
  var needBeOverridden = await checkExcelData(reportCode.value,data);
  if (needBeOverridden.data) {
    ElMessageBox.confirm(
        '检测到上传文件中的数据已存在,是否覆盖?',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
    )
        .then(async () => {
          try {
            const rs = await importExcel(reportCode.value,data,null,null,false);
            await ElMessageBox.alert(
                rs.data,
                '导入结果',
                {
                  customClass:'customMessageBox',
                  dangerouslyUseHTMLString: true,
                }
            )
            await search();
          }finally {
            impLoading.value = false;
          }
        })
        .catch(() => {
          ElMessage.warning("取消导入");
          impLoading.value = false;
          return
        })
  } else {

      const rs = await importExcel(reportCode.value,data,null,null,false);
      await ElMessageBox.alert(
          rs.data,
          '导入结果',
          {
            customClass:'customMessageBox',
            dangerouslyUseHTMLString: true,
          }
      )
      await search();
  }
  }finally {
    impLoading.value = false;
  }
}

const exp = async () => {
  expLoading.value = true;
  try {
    if (ids==undefined||ids.length == 0) {
      ids=''
    }
    let formData = checkData(searchForm.value);
    await exportExcel(reportCode.value, ids,formData);
  }finally {
    expLoading.value = false;
  }
}
const subTabDisabled = ref(false);

//主表按钮组件
//@ts-ignore
const tableButtons:()=> ButtonInfo[] = () =>{
  const buttons =  [
    {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => {
        if (ids == undefined || ids.length == 0) {
          submitAll();
          return
        }
        submit(ids);}
    },
    {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      icon: 'icon_check',
      handler: () => {
        if (ids == undefined || ids.length == 0) {
          auditAll();
          return
        }
        auditDialog.value = true;
      },
    },
    {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      icon: 'icon_recall',
      handler: () => recall(ids),
    },
    {
      key: 'reset',
      label: '重置',
      tag: 'button',
      type: 'primary',
      icon: 'icon_reset',
      handler: () => reset(ids),
    },
    {
      key: 'delete',
      label: '删除',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      // handler: () => del(ids),
      handler: () => {
        if (ids == undefined || ids.length == 0) {
          delAll();
          return
        }
        del(ids);
      }
    },
    {
      key: 'delverify',
      label: '删除审核',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      handler: () => {
        msg.value = null;
        if (ids == undefined || ids.length == 0) {
          // ElMessage.warning('请先选择数据')
          auditDelAll();
          return
        }
        auditDelDialog.value = true;
      }
    },
    {
      key: 'upload',
      label: '上报',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: () => handleUpload(ids),
    },
  ]
  if (reportCode.value==='100406'||reportCode.value==='100501'||reportCode.value==='100503') {
    buttons.splice(0, 0,     {
      key: 'save',
      label: '新增',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: () => {
        applicationID.value = ''
        activeName.value = 'first'
        subTabDisabled.value = true;
        if (reportCode.value==='100501') {
          form.value = {};
          dialogFormRef.value?.resetFields()
          const data = toRaw(form.value);
          data.listSource = '200501'
        }else if (reportCode.value==='100503') {
          form.value = {};
          dialogFormRef.value?.resetFields()
          const data = toRaw(form.value);
          data.listSource1 = '200501'
          data.listSource2 = '200501'
        }
        open(null, false, getTitleName()+"新增")
      },
    });
  }
  if (reportCode.value==='100102'||reportCode.value==='100202'||reportCode.value==='100206'||reportCode.value==='100714') {
    buttons.splice(0, 0,     {
      key: 'esb',
      label: '重发请求给ESB',
      tag: 'button',
      type: 'primary',
      icon: 'icon_reset',
      handler: () => {
        resendTheRequestToTheESB(ids)
      },
    });
  }
  return buttons;
}
//是否展示保存按钮
let isShowSave=ref<boolean>(true);

//@ts-ignore
const dialogTableButtons: () => ButtonInfo[] = () => {
  const buttons = [
    {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      icon: 'icon_check',
      handler: () => {
        ids = form.value.id;
        auditDialog.value = true
      },
    },
    {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      icon: 'icon_recall',
      handler: () => recall(form.value.id),
    },
    // {
    //   key: 'reset',
    //   label: '重置',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_reset',
    //   handler: () => reset(form.value.id),
    // },

  ]
  if (status.value == "待提交" || status.value == "待补录" || status.value == "待补录（审核未通过）" || status.value == "待补录（上报失败）") {
    buttons.splice(0, 0,{
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => submitAndSave(toRaw(form.value), form.value.id),
    });
    buttons.splice(4, 0,    {
      key: 'save',
      label: '保存',
      tag: 'button',
      type: 'primary',
      icon: 'icon_update',
      handler: () => {
        showConfirm()
      }
    });
    isShowSave.value=false
  }
  return buttons;
}
//主表按钮组件2  当状态为已审核或之后的文件使用,不允许编辑保存
const parentsButtons2: ButtonInfo[] = [
  {
    key: 'submit',
    label: '提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => submit(form.value.id),
  },
  {
    key: 'audit',
    label: '审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => {
      ids = form.value.id;
      auditDialog.value = true;
    },
  },
  {
    key: 'recall',
    label: '撤回',
    tag: 'button',
    type: 'primary',
    icon: 'icon_recall',
    handler: () => recall(form.value.id),
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => reset(form.value.id),
  },
]
//主表右侧操作栏按钮组件
//@ts-ignore
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
  {
    key: 'view', label: '查看', tag: 'button', type: 'primary',
    handler: () => {
      //外加新增按钮组件
      subTabDisabled.value = false;
      applicationID.value = row.applicationID;
      branchCode.value = row.branchCode;
      transSerialNumber.value = row.transSerialNumber;
      trxId.value = row.trxId;
      parentId.value = row.id;
      activeName.value = 'first'
      status.value = dictFormatter(row.status, dictData.taf_status)
      open(row, true, getTitleName() + '查看');
    }
  },
]
  //如果没有子表待审核不显示修改按钮  100302 100310 有子表
  if ((row.status==0||row.status==1||row.status==5||row.status==6) || (row.status==2 && (reportCode.value=='100302'||reportCode.value=='100310'))) {
    if (row.deleteState == '1' || row.deleteState == '4' || row.deleteState == undefined) {
      // 获取当前表单配置按钮权限
      var perms = useRoute().meta.permSigns;
      if (reportCode.value=='100302'|| reportCode.value=='100310') {
        // 获取字典302和310编辑开关
        let isOpen = (dictData.editFlag302And310 != undefined)
        // 定义页面权限是否有编辑权限
        let editPermissions = perms.includes('edit')
        // 定义最终结果 字典302和310编辑开关开则走权限 关则走现有逻辑
        let editResult = isOpen ? editPermissions :  true
        if (editResult) {
          buttons.splice(1, 0, {
            key: 'edit', label: '编辑', tag: 'button', type: 'primary',
            handler: () => {
              //外加新增按钮组件
              subTabDisabled.value = false;
              applicationID.value = row.applicationID;
              branchCode.value = row.branchCode;
              transSerialNumber.value = row.transSerialNumber;
              txCode.value = row.txCode;
              parentId.value = row.id;
              console.log("父表值 "+parentId.value)
              trxId.value = row.trxId;
              if (row.branchCode == null){
                row.branchCode=dictData.branchCode[0].value
              }
              // console.log(row);
              activeName.value = 'first'
              status.value = dictFormatter(row.status, dictData.taf_status)
              if (row.status > 2 && row.status != 6 && row.status != 5) {
                open(row, true, getTitleName());
              } else {
                let disabled = false;
                if (row.status == 2) {
                  disabled = true;
                }
                open(row, disabled, getTitleName() + '编辑');
              }
            }
          });
        }
      } else {
        if (perms.includes('edit')) {
          buttons.splice(1, 0, {
            key: 'edit', label: '编辑', tag: 'button', type: 'primary',
            handler: () => {
              //外加新增按钮组件
              subTabDisabled.value = false;
              applicationID.value = row.applicationID;
              branchCode.value = row.branchCode;
              transSerialNumber.value = row.transSerialNumber;
              txCode.value = row.txCode;
              trxId.value = row.trxId;
              //702 704特殊处理匹配失败不要默认值
              if(row.branchCode == null){
                if(reportCode.value =='100702' || reportCode.value =='100704'){
                  if(row.prosResult=='01') row.branchCode=dictData.branchCode[0].value;
                }else{
                  row.branchCode=dictData.branchCode[0].value
                }
              }
              //  if(row.branchCode == null){
              //   row.branchCode=dictData.branchCode[0].value
              // }
              // console.log(row);
              activeName.value = 'first'
              status.value = dictFormatter(row.status, dictData.taf_status)
              if (row.status > 2 && row.status != 6 && row.status != 5) {
                open(row, true, getTitleName());
              } else {
                let disabled = false;
                if (row.status == 2) {
                  disabled = true;
                }
                open(row, disabled, getTitleName() + '编辑');
              }
            }
          });
        }
      }
    }
  }
  return buttons
}


//子表保存方法
const save1 = async (data: any, name: string) => {
  // 部分日期必填项存在实际情况没有值的，此处设置个默认值，用以通过校验
  setDefaultDateValue(subForm.value)
  const valid = await subDialogFormRef.value?.asyncValidate();
  // 反馈结果不是0000，视为反馈失败 这里实时查询
  let formData = checkData(searchForm.value);
  const res = await list(reportCode.value, formData, page.value.currentPage, page.value.pageSize);
  const zbData=res.data.records.filter(f=>f.id==parentId.value)[0]
  let reportFail="0000"!=zbData.result
  if (reportFail){
    // 清除必填提示
    subDialogFormRef.value?.clearValidate()
  }
  if (valid || reportFail){
    data = toRaw(subForm.value);
    clearDefaultDateValue(data); // 验证通过后重置为null保存
    data.status = '1';
    data.txCode = txCode.value;
    // data.deleted = '0';
    data.applicationID = applicationID.value;
    data.transSerialNumber = transSerialNumber.value;
    // data.branchCode = branchCode.value;
    // if (dictData.departmentCodeRequired!=undefined && data.departmentCode==null){
    //   ElMessage.error({message:"部门字段必填！", grouping: true, showClose: true, duration: 0});
    //   return;
    // }

    // 销户日期需大于等于开户日期
    if(['100302', '100310'].includes(reportCode.value)) {
      let accountCancellationTime = data.accountCancellationTime;
      if(accountCancellationTime != null) {
        accountCancellationTime = new Date(accountCancellationTime);
        let accountOpenTime = new Date(data.accountOpenTime);
        if (accountCancellationTime.getTime() < accountOpenTime.getTime()){
          ElMessage.warning("销户日期需大于等于开户日期");
          return
        }
      }
    }


    delete data.type;
    let rs = await subSaveData(data, name,false,parentId.value);
    subClose();
    subClosed();
    ElMessage.success("保存成功");
    handleClick(undefined);
  }

}
//子表表头按钮组件
//@ts-ignore
const subButtons: (name: string, items: any) => ButtonInfo[] = (name: string, items: any) => {
  const buttons = [
    {
      key: 'add',
      label: '新增',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: async () => {
        listName = name;
        subFormItems.value = items
        if ((reportCode.value=='100302'||reportCode.value=='100306')&&accountNumberArr.value.length!=0){
          // subForm._rawValue.accountNumber=accountNumberArr.value[0].accountNumber
        }
        // subForm._rawValue.trxId=trxId.value
        // subForm._rawValue.applicationID=applicationID.value
        subForm.value.trxId=trxId.value;
        subForm.value.applicationID=applicationID.value;
        // 新增时自动从请求带入主账户名称和主账户
        if (reportCode.value=='100302'&& tabName=='账户信息'){
          const res=await getByApplicationIDAndTrxId(parseInt(reportCode.value)-1,applicationID.value,trxId.value)
          subForm.value.accountName=res.data.accountName
          subForm.value.cardNumber=res.data.cardNumber
        }
        subOpen(subForm.value, false, getSubTitleName(name) + '新增')
      }
    },
    {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => subSubmit(ids, name),
    },
    {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      icon: 'icon_check',
      handler: () => {
        listName = name;
        if (ids==null|| ids.length == 0) {
          subAuditAll(name);
          return;
        }
        subAuditDialog.value = true;
      },
    },
    {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      icon: 'icon_recall',
      handler: () => subRecall(ids, name),
    },
    {
      key: 'reset',
      label: '重置',
      tag: 'button',
      type: 'primary',
      icon: 'icon_reset',
      handler: () => subReset(ids, name),
    },
    // {
    //   key: 'del',
    //   label: '批量删除',
    //   tag: 'button',
    //   type: 'danger',
    //   icon: 'icon_delete',
    //   handler: () => subDel(ids, name),
    // },
    {
      key: 'subDelete',
      label: '删除',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      handler: () => subDel(ids, name),
    },
    {
      key: 'subDelverify',
      label: '删除审核',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      handler: () => {
        listName = name;
        msg.value = null;
        if (ids == undefined || ids.length == 0) {
          // ElMessage.warning('请先选择数据')
          subDelAuditAll(name);
          return
        }
        auditDelDialogSub.value = true;
      }
    }
  ];

  if (getSubSystem()==='taf' && getRequestClassificationCode()==='100302' && name === 'fkTransactionTaf') {
    buttons.push({
      key: 'imp417report',
      label: '导入417report',
      tag: 'button',
      type: 'primary',
      loading: isSubImpLoading.value,
      icon: 'icon_upload',
      handler: () => {
        var elementById = document.getElementById("upload417ReportButton");
        elementById.click();
      }
    })
  }
  return buttons;
}

//子表行操作栏组件
//@ts-ignore
const subGenActButtons: (row: any, name: string, items: any) => ButtonInfo[] = (row: any, name: string, items: any) => {
  const buttons = [
  {
    key: 'view', label: '查看', tag: 'button', type: 'primary',
    handler: () => {
      subFormItems.value = items
      subOpen(row, true, getSubTitleName(name) + '查看');
    }
  },
]
  if (row.status == 3) {
    buttons.splice(1, 0,
        {
          key: 'reset', label: '重置', tag: 'button', type: 'primary',
          handler: () => subReset(row.id, name)
        });
  }
  if (row.status == 2) {
    buttons.splice(1, 0,
        {
          key: 'recall', label: '撤回', tag: 'button', type: 'primary',
          handler: () => subRecall(row.id, name)
        });
  }
  /*if (row.status <2||row.status==6) {
    buttons.splice(1, 0,
        {
          key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
          handler: () => subDel(row.id, name)
        });
  }*/
  if (row.status == 2) {
    buttons.splice(1, 0,
        {
          key: 'audit', label: '审核', tag: 'button', type: 'primary',
          handler: () => {
            listName = name;
            ids = row.id;
            subAuditDialog.value = true;
          },
        });
  }
  if (row.status == 1 && (row.deleteState == '1' || row.deleteState == '4'|| row.deleteState == undefined)) {
    buttons.splice(1, 0, {
      key: 'submit', label: '提交', tag: 'button', type: 'primary',
      handler: () => subSubmit(row.id, name)
    });
  }
  if ((row.status<2||row.status==6||row.status==5) && (row.deleteState == '1' || row.deleteState == '4'|| row.deleteState == undefined)) {
    buttons.splice(1, 0,{
      key: 'edit', label: '编辑', tag: 'button', type: 'primary',
      handler: () => {
        listName = name;
        subFormItems.value = items
        if (row.status > 2 && row.status != 6&& row.status != 5) {
          subOpen(row, true, getSubTitleName(name));
        } else {
          subOpen(row, false, getSubTitleName(name) + '编辑');
        }
      }
    });
  }
  return buttons
}

//@ts-ignore
const subGenActButtons2: (row: any, name: string, items: any) => ButtonInfo[] = (row: any, name: string, items: any) => {
  const buttons = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => {
        subFormItems.value = items
        subOpen(row, true, getSubTitleName(name) + '查看');
      }
    },
  ]
  return buttons
}

const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

const {
  dialogData: subDialogData,
  open: subOpen,
  close: subClose,
  closed: subClosed,
  form: subForm,
  nameRef: subDialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('subDialogFormRef', {type: []})

const isSubImpLoading = ref(false);
const IUpload417ReportFile = async (data = {},dd:any) => {
  try {
    isSubImpLoading.value=true
    //@ts-ignore
    var name = data.file.name;
    if (name == null) {
      name = data[0].name;
    }
    if (!name.toLowerCase().endsWith(".xlsx") && !name.toLowerCase().endsWith(".xls")) {
      ElMessage.error({message: "仅可上传Excel文件", grouping: true, showClose: true, duration: 0});
      return;
    }
    const rs = await importExcel(reportCode.value, data, applicationID.value, businessLineUser.value[0].value, true);
    await ElMessageBox.alert(`<div style="max-height: 500px; overflow-y: auto;">${rs.data}</div>`, '导入结果', {
          customClass: 'customMessageBox',
          dangerouslyUseHTMLString: true,
        }
    );
    await search();
  } finally {
    isSubImpLoading.value=false
    await handleClick(undefined);
  }
}

watch(() => dialogData.visible, async (val) => {
  if ( dialogData.visible) {
      //弹窗打开时外层选中了数据需要清空ids
        ids = undefined
    }else{
      //弹窗关闭时 刷新列表
      search()
    }
  // 西班牙桑坦德银行需求, 反馈表单涉及经办人姓名、经办人电话信息，在新增补录时如果该字段为空抓取该用户登录的oauth中对应的信息。额外要求：添加开关控制该功能
  if(dictData.OperatorRef != undefined && dialogData.visible) {
    const result = await getUserInfo();
    const loginUserInfo = result.data;
    if(isEmpty(form.value.operatorName)) {
      form.value.operatorName = loginUserInfo.username;
    }
    if(isEmpty(form.value.operatorPhoneNumber)) {
      form.value.operatorPhoneNumber = loginUserInfo.phoneNumber;
    }
  }
})

/**
 * 100604 监听caseType, 值为1002-受害人账户，100604，反馈报文100604中result“反馈结果”以下的反馈内容无需反馈，详见100604
 * 将原必填字段设置为非必填
 *
 * 100714 监听updateType, 值为01-管控，开户机构标识、开户机构名称、处置方式、管控账户余额、币种为必填；02时非必填
 */
watch(() => [form.value, dialogData.visible], (newForm, oldForm) => {
  let fields = [];
  const caseType = newForm[0].caseType;
  if (reportCode.value === '100702' || reportCode.value === '100704') {
      const failReasonCd = newForm[0].failReasonCd
      let failReasonDescItem = formItems.value.filter((item) => item.prop == 'failReasonDesc')
      const rules = failReasonDescItem.map((item) => item.rules.find((item) => item.required != undefined))
      rules.map((rule) => (rule.required = failReasonCd == '99' ? true : false))
      formItems.value = [...formItems.value]
      const prosResult = newForm[0].prosResult
      let failReasonDescItem2 = formItems.value.filter((item) => item.prop == 'failReasonCd')
      const rules2 = failReasonDescItem2.map((item) => item.rules.find((item) => item.required != undefined))
      rules2.map((rule) => (rule.required = prosResult == '02' ? true : false))
      formItems.value = [...formItems.value]
      // 匹配结果根据字典有没有配控制是否可填
      let matchResult = formItems.value.filter((item) => item.prop == 'matchResult')
      matchResult.map((item) => (item.inputType.disabled = !!dictData?.matchResultSwitch))
      formItems.value = [...formItems.value]
    }
  if(reportCode.value === '100604') {
    fields = ['feedbackOrgName', 'feedbackOrgId', 'accountSubjectName', 'accountNumber', 'accountStatus', 'verificationControl', 'measure', 'controlDate', 'query', 'freeze', 'stopPayment', 'batchNo']
    const items = formItems.value.filter(item => fields.includes(item.prop));
    const rules = items.map(item => item.rules.find(item => item.required != undefined));
    rules.map(rule => rule.required = (caseType == "1002" ? false : true))
    formItems.value = [...formItems.value]
  }

  // 100102 止付 如果结果是成功 开始时间 结束时间必填
  const result = newForm[0].result;
  if(reportCode.value === '100102') {
    fields = ['startTime', 'expireTime']
    const items = formItems.value.filter(item => fields.includes(item.prop));
    const rules = items.map(item => item.rules.find(item => item.required != undefined));
    rules.map(rule => rule.required = (result == '0000' ? true : false))
    formItems.value = [...formItems.value]
  }

  const updateType = newForm[0].updateType;
  if (reportCode.value === '100714') {
    fields = ['opnInsId', 'opnInsNm', 'processMeasure', 'balance', 'currency'];
    const items = formItems.value.filter(item => fields.includes(item.prop));
    const rules = items.map(item => item.rules.find(item => item.required != undefined));
    rules.map(rule => rule.required = (updateType == "02" ? false : true))
    formItems.value = [...formItems.value]
  }

  // console.log(dictData);
  // 未启用部门编码，编辑页面隐藏
  if (dictData.departmentCodeRequired == undefined){
    formItems.value = formItems.value.filter(item => "departmentCode" != item.prop);
    formItems.value = [...formItems.value]
  }

  // 前一日账户余额
  if (dictData.showEODAccountBalance == undefined){
    formItems.value = formItems.value.filter(item => "eodAccountBalance" != item.prop);
    formItems.value = [...formItems.value]
  }

  // 交易对手来源 西班牙桑坦德银行需求
  if (dictData.LastTransactionTimeRef == undefined){
    formItems.value = formItems.value.filter(item => "jydsRef" != item.prop);
    formItems.value = [...formItems.value]
  }

  // 东方会理优化需求--以下科目设置不可编辑--添加开关控制  -showFLag
  if (dictData.ShowFlag != undefined) {
    const items = dynamicSetItemDisabled(reportCode.value, formItems.value);
    formItems.value = [...items]
  }
}, {deep: true})

watch(() => form.value.id, (val) => {
  // 开关控制 'accountCancellationTime', 'lastTransactionTime' 为空时，前端显示 “-”
  if(dictData.DateDefaultFlag != undefined) {
    convertNullDateToLine(reportCode.value, form.value)
  }
})

watch(subForm.value, (newVal, oldVal) => {
  // 未启用部门编码，编辑页面隐藏
  if (dictData.departmentCodeRequired == undefined){
    subFormItems.value = subFormItems.value.filter(item => "departmentCode" != item.prop);
    subFormItems.value = [...subFormItems.value]
  }

  // 参考最后交易时间 西班牙桑坦德银行需求
  if (dictData.LastTransactionTimeRef == undefined){
    subFormItems.value = subFormItems.value.filter(item => "lastTransactionTimeRef" != item.prop);
    subFormItems.value = [...subFormItems.value]
  }

  // 参考交易对收来源 西班牙桑坦德银行需求
  if (dictData.jydsRef == undefined){
    subFormItems.value = subFormItems.value.filter(item => "jydsRef" != item.prop);
    subFormItems.value = [...subFormItems.value]
  }
}, {deep: true})

watch(() => subForm.value.id, (val) => {
  // 开关控制 'accountCancellationTime', 'lastTransactionTime' 为空时，前端显示 “-”
  if(dictData.DateDefaultFlag != undefined) {
    convertNullDateToLine(reportCode.value, subForm.value)
  }
})

defineExpose({confirmCallback})

</script>

<style scoped>
.auditNotPassButton {
  background: #F56C6CFF;
  border-color: #F56C6CFF;
  color: #fff;
}

.auditNotPassButton:hover {
  background: #e08282; /* 鼠标悬停时的背景色 */
  border-color: #e08282; /* 鼠标悬停时的边框颜色 */
  color: #fff; /* 鼠标悬停时的文字颜色 */
}
/*.auditButton{*/
/*  background: var(--el-color-success);*/
/*  border-color: var(--el-color-success);*/
/*  color: #fff;*/
/*}*/
</style>
