<template>
  <el-dialog v-model="visible" title="确认" width="30%" draggable :append-to-body=true>
    <span>无特殊原因不建议反馈失败，如需反馈失败，请先联系总行！</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="cancel">取消</el-button>
        <el-button type="primary" @click="confirm">确认</el-button>
      </span>
    </template>
  </el-dialog>
</template>


<script setup lang="ts">
import {ElButton, ElDialog} from "element-plus";

const emits = defineEmits(['callback'])

const visible = ref(false)

const show = () => {
  visible.value = true;
}

defineExpose({show})


const confirm = () => {
  visible.value = false;
  emits('callback', true);
}

const cancel = () => {
  visible.value = false;
}

const close = () => {
  visible.value = false;
}


</script>

<style scoped>

</style>