import {RS} from 'riking-ui'
import service from '@/utils/request'
export function list(reportCode: string, data = {}, current: number, size: number) {
    return service({
        url: `/${reportCode}/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

export function getByApplicationIDAndTrxId(reportCode: number,applicationId: string,trxId: string) {
    return service({
        url: `/${reportCode}/getByApplicationIDAndTrxId`,
        method: 'GET',
        params:{applicationId,trxId},
    })
}

export function listByApplicationID(data = {}, current: number, size: number,name:string, applicationID:string): Promise<RS> {
    return service({
        url: `/${name}/listByApplicationID`,
        method: 'POST',
        data,
        params: {current, size, applicationID ,}
    })
}

export function listResult(reportCode: string): Promise<RS> {
    return service({
        url: `/dict/listResult`,
        method: 'GET',
        params: {reportCode: reportCode}
    })
}

export function listAccountNumber(data: any,subSystemCode: string): Promise<RS> {
    return service({
        url: `${subSystemCode}/listAccountNumber`,
        method: 'POST',
        data
    })
}

export function saveData(reportCode: string,data = {},isFk:boolean): Promise<RS> {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    if (data.id != undefined) {
        return service({
            url: `/${reportCode}/update`,
            method: 'POST',
            data,
        });
    } else {
        return service({
            url: `/${reportCode}/save`,
            method: 'POST',
            data,
            params: {isFk:isFk}
        });
    }

}

export function uploadTaf(ids:any,fkReportCode:string): Promise<RS> {
    return service({
        url: "/sysReportCount/uploadTaf",
        method: 'POST',
        params: {ids,fkReportCode},
    })
}
export function updateRequestStatus(reportCode: string,data = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/updateRequestStatus`,
        method: 'POST',
        data,
    });
}
export function subSaveData(data = {}, name:string,isFk:boolean,parentId:string): Promise<RS> {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    delete data.TransactionTime;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    delete data.TransactionStatus;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    delete data.LastTransactionTime;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    delete data.AccountOpenTime;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    delete data.AccountCancellationTime;
    // delete data.transactionstatus;
    // @ts-ignore
    if (data.id != undefined) {
        return service({
            url: `/${name}/update`,
            method: 'POST',
            data,
            params: {parentId:parentId}

        });
    } else {
        return service({
            url: `/${name}/save`,
            method: 'POST',
            data,
            params: {isFk:isFk,parentId:parentId}
        });
    }
}

export function submitBatch(data:any,reportCode: string,ids:any): Promise<RS> {
    return service({
        url: `/${reportCode}/submit`,
        method: 'POST',
        data,
        params: {ids,reportCode},
    })
}

export function subSubmitBatch(ids:any,name:string): Promise<RS> {
    return service({
        url: `/${name}/submit`,
        method: 'POST',
        params: {ids:ids,reportCode:name},
    })
}

export function auditBatch(reportCode: string,ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/audit`,
        method: 'POST',
        params: {ids},
    })
}
export function auditNotPassBatch(reportCode: string,ids: any,msg:any): Promise<RS> {
    return service({
        url: `/${reportCode}/auditNotPass`,
        method: 'POST',
        params: {ids,msg},
    })
}
export function subAuditBatch(ids: any,name:string): Promise<RS> {
    return service({
        url: `/${name}/audit`,
        method: 'POST',
        params: {ids},
    })
}
export function subAuditNotPassBatch(ids: any,name:string,msg:any): Promise<RS> {
    return service({
        url: `/${name}/auditNotPass`,
        method: 'POST',
        params: {ids,msg},
    })
}

export function resetBatch(reportCode: string,ids: any,msg:string): Promise<RS> {
    return service({
        url: `/${reportCode}/reset`,
        method: 'POST',
        params: {ids,msg},
    })
}

export function subResetBatch(ids: any ,name:string,msg:string): Promise<RS> {
    return service({
        url: `/${name}/reset`,
        method: 'POST',
        params: {ids,msg},
    })
}
export function recallBatch(reportCode: string,ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/recall`,
        method: 'POST',
        params: {ids},
    })
}

export function subRecallBatch(ids: any ,name:string): Promise<RS> {
    return service({
        url: `/${name}/recall`,
        method: 'POST',
        params: {ids},
    })
}
export function delBatch(reportCode: string,ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/del`,
        method: 'POST',
        params: {ids},
    })
}
export function resendTheRequestToESB(reportCode: string,ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/resendTheRequestToTheESB`,
        method: 'POST',
        params: {ids},
    })
}
export function delBatchAudit(reportCode: string,ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/delAudit`,
        method: 'POST',
        params: {ids},
    })
}
export function delAuditNotPass(reportCode: string, ids: any, msg:string): Promise<RS> {
    return service({
        url: `/${reportCode}/delAuditNotPass`,
        method: 'POST',
        params: {ids,msg},
    })
}

export function subDelBatch(ids: any,name:string): Promise<RS> {
    return service({
        url: `/${name}/del`,
        method: 'POST',
        params: {ids},
    })
}

export function subDelBatchAudit(ids: any, name:string): Promise<RS> {
    return service({
        url: `/${name}/delAudit`,
        method: 'POST',
        params: {ids},
    })
}
export function subDelBatchAuditNotPass(ids: any, msg:string, name:string): Promise<RS> {
    return service({
        url: `/${name}/delAuditNotPass`,
        method: 'POST',
        params: {ids,msg},
    })
}

export function checkExcelData(reportCode: string,data:any): Promise<RS> {
    return service({
        url: `/${reportCode}/checkExcelData`,
        method: 'POST',
        data,
        params: {reportCode},
        headers: {'Content-Type': 'multipart/form-data',}
    })
}
export function importExcel(reportCode: string,data:any, applicationID:string,businessLine:string,is417report:boolean): Promise<RS> {
    return service({
        url: `/${reportCode}/importExcel`,
        method: 'POST',
        data,
        params: {reportCode,applicationID,businessLine,is417report},
        headers: {'Content-Type': 'multipart/form-data'},
    })
}

export function exportExcel(reportCode: string,ids:any,data = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/exportExcel`,
        method: 'POST',
        data,
        params: {ids,reportCode},
        responseType: 'blob'
    })
}

export function auditAllBatch(name: string,data = {},applicationID:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: `/${name}/auditAllBatch`,
        method: 'POST',
        data,
        params: {requestClassificationCode:name,applicationID,isSubTable},
    })
}
export function submitAllBatch(name: string,data = {},applicationID:string,isSubTable:boolean,reportCode:string): Promise<RS> {
    return service({
        url: `/${name}/submitAllBatch`,
        method: 'POST',
        data,
        params: {requestClassificationCode:name,applicationID,isSubTable,reportCode},
    })
}
export function auditNotPassAllBatch(name: string,data = {},applicationID:string,isSubTable:boolean,msg:string): Promise<RS> {
    return service({
        url: `/${name}/auditNotPassAllBatch`,
        method: 'POST',
        data,
        params: {requestClassificationCode:name,applicationID,isSubTable,msg},
    })
}

export function delAllBatch(name: string,data = {},applicationID:string,isSubTable:boolean,reportCode:string): Promise<RS> {
    return service({
        url: `/${name}/delAllBatch`,
        method: 'POST',
        data,
        params: {requestClassificationCode:name,applicationID,isSubTable,reportCode},
    })
}
export function auditDelAllBatch(name: string,data = {},applicationID:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: `/${name}/auditDelAllBatch`,
        method: 'POST',
        data,
        params: {requestClassificationCode:name,applicationID,isSubTable},
    })
}
export function auditDelNotPassAllBatch(name: string,data = {},applicationID:string,isSubTable:boolean,msg:string): Promise<RS> {
    return service({
        url: `/${name}/auditDelNotPassAllBatch`,
        method: 'POST',
        data,
        params: {requestClassificationCode:name,applicationID,isSubTable,msg},
    })
}

export function getUserInfo() {
    return service({
        url: `/oauth/getUserInfo`,
        method: 'GET'
    })
}