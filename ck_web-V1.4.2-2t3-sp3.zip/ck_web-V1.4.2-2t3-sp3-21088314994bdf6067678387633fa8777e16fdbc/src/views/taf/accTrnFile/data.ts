import {FormItemInfo, TableColumnInfo} from "riking-ui";
import { dateFormatter } from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    { prop: 'trxId', label: '流水号', minWidth: 200, sortable: true},
    { prop: 'status', label: '状态', dictFormatKey: 'taf_status', sortable: true, scopedSlots: 'status'},
    { prop: 'kh', label: '银行卡号', width: 140, sortable: true },
    { prop: 'xm', label: '姓名', width: 120, sortable: true },
    { prop: 'date', label: '交易时间', width: 180, sortable: true },
    { prop: 'dfkh', label: '交易对方账号', width: 160, sortable: true },
    { prop: 'dfxm', label: '交易对方姓名', width: 140, sortable: true },
    { prop: 'jdbs', label: '借贷标识', dictFormatKey: 'taf_JDBS', width: 100, sortable: true },
    { prop: 'jyje', label: '交易金额', width: 120, sortable: true },
    { prop: 'ye', label: '交易后余额', width: 120, sortable: true },
    { prop: 'jyzy', label: '交易摘要', width: 200, sortable: true },
    { prop: 'ip', label: 'IP', width: 120, sortable: true },
    { prop: 'mac', label: 'MAC', width: 120, sortable: true },
    { prop: 'jylsh', label: '交易流水号', width: 160, sortable: true },
    { prop: 'sljgmc', label: '受理机构名称', width: 160, sortable: true },
    { prop: 'jylx', label: '交易类型', width: 120, sortable: true },
    { prop: 'yhbm', label: '银行编码', width: 120, sortable: true },
    { prop: 'pcbh', label: '批次编号', width: 120, sortable: true },

    {prop: 'fkStatus', label: '回执状态', minWidth: 200, sortable: true},
    {prop: 'fkInfo', label: '回执信息', minWidth: 200, sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'trxId', label: '流水号', labelWidth: 120 ,inputType:'input'},
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 80,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    }
]


export const formItems: FormItemInfo[] = [
    {
        prop: 'kh',
        label: '银行卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'xm',
        label: '姓名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'date',
        label: '交易时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'dfkh',
        label: '交易对方账号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'dfxm',
        label: '交易对方姓名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'jdbs',
        label: '借贷标识',
        labelWidth: 150,
        inputType:  {tag: 'select', options: 'taf_JDBS'},
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'jyje',
        label: '交易金额',
        labelWidth: 150,
        inputType:  { tag: 'input-number', controlsPosition:"right",precision:"2"},
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'ye',
        label: '交易后余额',
        labelWidth: 150,
        inputType:  { tag: 'input-number', controlsPosition:"right",precision:"2"},
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'jyzy',
        label: '交易摘要',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    }    ,
    {
        prop: 'ip',
        label: 'IP',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'mac',
        label: 'MAC',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'jylsh',
        label: '交易流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'sljgmc',
        label: '受理机构名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'jylx',
        label: '交易类型',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'yhbm',
        label: '银行编码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{required: true, message: '必填'},{max: 500, message: '超过500字符限制'}]
    },
    {
        prop: 'pcbh',
        label: '批次编号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<|>&]*$',message: '存在特殊字符'},{max: 500, message: '超过500字符限制'}]
    }
]

export const advancedQueryItems = [
    {value: 'status', label: '状态', labelWidth: 80 , inputType:  {tag: 'select', options: 'taf_status'}},
    {value: 'kh', label: '银行卡号', labelWidth: 140},
    {value: 'xm', label: '姓名', labelWidth: 120},
    {value: 'date', label: '交易时间', labelWidth: 180,inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'}},
    {value: 'dfkh', label: '交易对方账号', labelWidth: 160},
    {value: 'dfxm', label: '交易对方姓名', labelWidth: 140},
    {value: 'jdbs', label: '借贷标识', labelWidth: 100,inputType:  {tag: 'select', options: 'taf_JDBS'}},
    {value: 'jyje', label: '交易金额', labelWidth: 120,inputType:  { tag: 'input-number', controlsPosition:"right",precision:"2"}},
    {value: 'ye', label: '交易后余额', labelWidth: 120,inputType:  { tag: 'input-number', controlsPosition:"right",precision:"2"}},
    {value: 'jyzy', label: '交易摘要', labelWidth: 200},
    {value: 'ip', label: 'IP', labelWidth: 120},
    {value: 'mac', label: 'MAC', labelWidth: 120},
    {value: 'jylsh', label: '交易流水号', labelWidth: 160},
    {value: 'sljgmc', label: '受理机构名称', labelWidth: 160},
    {value: 'jylx', label: '交易类型', labelWidth: 120},
    {value: 'yhbm', label: '银行编码', labelWidth: 120},
    {value: 'pcbh', label: '批次编号', labelWidth: 120},
    {value: 'fkStatus', label: '回执状态', labelWidth: 120},
    {value: 'fkInfo', label: '回执信息', labelWidth: 120},
    {value: 'createBy', label: '创建人', labelWidth: 80},
    {value: 'createTime', label: '创建时间', labelWidth: 80,inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },


]
export default {
    columns,
    searchFormItems,
}
