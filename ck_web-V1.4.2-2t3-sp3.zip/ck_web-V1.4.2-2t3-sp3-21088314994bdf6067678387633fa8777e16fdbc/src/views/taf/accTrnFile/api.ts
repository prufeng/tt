import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'

export function list( data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: "/accTrnFile/list",
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    })
}

export function delBatch(ids: any): Promise<RS> {
    return service({
        url: "/accTrnFile/del",
        method: 'POST',
        params: {ids},
    })
}

export function add(data = {}): Promise<RS> {
    return service({
        url: "/accTrnFile/add",
        method: 'POST',
        data,
    })
}

export function update(data = {}): Promise<RS> {
    return service({
        url: "/accTrnFile/update",
        method: 'POST',
        data,
    })
}

export function submitBatch(ids: any): Promise<RS> {
    return service({
        url: "/accTrnFile/submitBatch",
        method: 'POST',
        params: {ids},
    })
}

export function submitAllBatch(data = {}): Promise<RS> {
    return service({
        url: "/accTrnFile/submitAllBatch",
        method: 'POST',
        data,
    })
}

export function recallBatch(ids: any): Promise<RS> {
    return service({
        url: "/accTrnFile/recallBatch",
        method: 'POST',
        params: {ids},
    })
}

export function resetBatch(ids: any,desc:string): Promise<RS> {
    return service({
        url: "/accTrnFile/resetBatch",
        method: 'POST',
        params: {ids,desc},
    })
}

export function auditAllBatch(data = {}): Promise<RS> {
    return service({
        url: "/accTrnFile/auditAllBatch",
        method: 'POST',
        data,
    })
}


export function auditNotPassAllBatch(data = {},desc:string): Promise<RS> {
    return service({
        url: "/accTrnFile/auditNotPassAllBatch",
        method: 'POST',
        data,
        params: {desc},
    })
}

export function auditBatch(ids: any): Promise<RS> {
    return service({
        url: "/accTrnFile/auditBatch",
        method: 'POST',
        params: {ids},
    })
}


export function auditNotPassBatch(ids: any,desc:string): Promise<RS> {
    return service({
        url: "/accTrnFile/auditNotPassBatch",
        method: 'POST',
        params: {ids,desc},
    })
}

export function handleUploadBatch(ids: any): Promise<RS> {
    return service({
        url: "/accTrnFile/handleUploadBatch",
        method: 'POST',
        params: {ids},
    })
}

export function importExcel(data:any): Promise<RS> {
    return service({
        url: "/accTrnFile/importExcel",
        method: 'POST',
        data,
        headers: {'Content-Type': 'multipart/form-data'},
    })
}

export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: "/accTrnFile/exportExcel",
        method: 'POST',
        data,
        params: {ids},
        responseType: 'blob'
    })
}