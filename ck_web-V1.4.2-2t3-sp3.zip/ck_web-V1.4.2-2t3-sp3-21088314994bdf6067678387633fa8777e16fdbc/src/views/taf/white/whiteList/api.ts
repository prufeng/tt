import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/whiteList/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}
