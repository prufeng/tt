<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"
                    :form-items="searchFormItems" @search="search" :label-width="50"/>

    <rk-page-table :columns="columns" :loading="loadingTable" :data="data" :pagination="page" @page-change="pageChange"
                   @refresh="search">
    </rk-page-table>
  </rk-index-layout>

  <!--  </div>-->
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage} from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, RkIndexLayout, dictFormatter,
} from 'riking-ui'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm'
import {useDict} from 'riking-layout'
import {list,} from './api'
import {checkData, pagination} from "@/utils/utils";
import {columns, searchFormItems} from './data';


const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const applicationID = ref("");
const auditDialog = ref(false);
const auditRow = ref({});
const msgDialog = ref(false);
const msg = ref("")

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  search()
})


const search = async () => {
  loadingTable.value = true
  let formData = checkData(searchForm.value);
  let result = await list(formData, page.value.currentPage, page.value.pageSize);
  let {current, total, records} = result.data;
  data.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loadingTable.value = false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}


</script>

<style scoped>

</style>
