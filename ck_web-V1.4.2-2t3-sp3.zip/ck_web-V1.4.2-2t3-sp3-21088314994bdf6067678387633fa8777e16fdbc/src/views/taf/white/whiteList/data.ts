import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {
        prop: 'cifNo',
        label: 'CIF号',
        width: 170,
    },
    {
        prop: 'fkRemark',
        label: '查询反馈结果原因',
        width: 300,
    },
    {
        prop: 'branchCode',
        label: '归属分行',
        width: 300,
    },
    {
        prop: 'branchCode',
        label: '分行名称',
        dictFormatKey:'branchCode',
        width: 300,
    },
    {
        prop: 'createTime',
        label: '导入日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'submitBy',
        label: '上传者',
        width: 170
    },
    {
        prop: 'approveBy',
        label: '审核者',
        width: 250,
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'cifNo',
        label: 'CIF号',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 100,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags:1
        },
    },
]
