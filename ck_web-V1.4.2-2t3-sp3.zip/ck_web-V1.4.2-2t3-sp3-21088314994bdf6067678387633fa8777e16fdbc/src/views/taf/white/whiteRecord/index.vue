<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"
                    :form-items="searchFormItems" @search="search" :label-width="50"/>

    <rk-page-table :columns="columns" :loading="loadingTable" :data="data" :pagination="page" @page-change="pageChange"
                   @refresh="search">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="getMainTableButtons()" :route-meta="$route.meta" max="3"/>
          <UpAndDown :exp="exp" exp-name="白名单模板下载" />
          <el-upload
              ref="uploadRef"
              :show-file-list="false"
              :http-request="uploadExcelFile">
            <el-button ref="uploadButton" id="uploadButton" type="primary" style="display: none;">
              上传
            </el-button>
          </el-upload>
        </div>
      </template>
      <template #fileNameOperate="{ row }">
        <el-button link @click="downLoad(row)" type="primary">{{ row.fileName }}</el-button>
      </template>
      <template #importStatusOperate="{ row }">
        <el-popover
            v-if="row.importStatus === '5'"
            placement="bottom"
            title="审核不通过原因"
            :width="250"
            trigger="hover"
        >
          <p class="tipck">操作: 审核不通过</p>
          <p class="tipck">操作人: {{ row.approveBy }}</p>
          <p class="tipck">操作时间: {{ row.approveTime }}</p>
          <p class="tipck">备注: {{ row.approveDesc }}</p>
          <template #reference>
            <el-button link :type="getTagColor(row.importStatus)">
              {{ dictFormatter(row.importStatus, dictData.importStatus) }}
            </el-button>
          </template>
        </el-popover>
        <el-button v-else link :type="getTagColor(row.importStatus)">
          {{ dictFormatter(row.importStatus, dictData.importStatus) }}
        </el-button>
      </template>
      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link max="3"/>
      </template>
    </rk-page-table>
  </rk-index-layout>


  <!-- 上传文件弹窗 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-small" @closed="closed"
             :close-on-click-modal="false">
    <rk-detail-form ref="dialogFormRef" v-model="form" :disabled="dialogData.formDisabled" :form-items="formItems"/>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="uploadFile">
          上传文件
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="审核" width="30%" draggable :append-to-body=true>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="auditData(auditRow)">审核通过</el-button>
        <el-button type="danger" @click="()=>{msgDialog = true;msg =''}">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog" title="不通过原因" width="30%" draggable :append-to-body=true>
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
      <el-button type="primary" @click="auditNot(auditRow)">提交</el-button>
      </span>
    </template>
  </el-dialog>
  <!--  </div>-->
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage} from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, RkIndexLayout, dictFormatter,
} from 'riking-ui'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm'
import {useDict} from 'riking-layout'
import {list, delById, uploadExcel, audit, auditNotPass, downloadFile,exportExcel} from './api'
import {checkData, pagination} from "@/utils/utils";
import {columns, searchFormItems, formItems} from './data';
import UpAndDown, {expLoading} from "@/components/UpAndDown.vue";


const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const applicationID = ref("");
const auditDialog = ref(false);
const auditRow = ref({});
const msgDialog = ref(false);
const msg = ref("")

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  search()
})

/**
 * 主表按钮
 */
const getMainTableButtons: () => ButtonInfo[] = () => {
  const buttons = [
    {
      key: 'upload',
      label: '上传',
      tag: 'button',
      type: 'primary',
      icon: 'icon_upload',
      handler: () => {
        open({branchCode: dictData.branchCode[0].value}, false, "上传")
      }
    },
  ]
  return buttons;
}
//row列按钮
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'audit', label: '审核', tag: 'button', type: 'primary',
    handler: () => {
      auditRow.value = row
      auditDialog.value = true
    }
  },
  {
    key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
    handler: () => deleteDialog(row)
  },
]
//上传文件按钮逻辑
const uploadFile = async () => {
  const valid = await dialogFormRef.value?.asyncValidate();
  if (valid) {
    var elementById = document.getElementById("uploadButton");
    elementById.click();
  }
}

const getTagColor = (status: string) => {
  if (status == '5') {
    return 'danger'
  } else {
    return 'primary';
  }
}
//下载文件
const downLoad = async (row: any) => {
  await downloadFile(row)
}
//上传文件
const uploadExcelFile = async (data = {}) => {
  try {
    var name = data.file.name;
    if (name == null) {
      name = data[0].name;
    }
    console.log("上传的文件：" + name);
    if (!name.toLowerCase().endsWith(".xlsx") && !name.toLowerCase().endsWith(".xls")) {
      ElMessage.error({message: "仅可上传Excel文件", grouping: true, showClose: true, duration: 0});
      return;
    }
    const rs = await uploadExcel(data, form._rawValue.branchCode);
    ElMessage.success(rs.data);
    closed()
  } finally {
    await search();
  }
}
//查询
const search = async () => {
  loadingTable.value = true
  let formData = checkData(searchForm.value);
  let result = await list(formData, page.value.currentPage, page.value.pageSize);
  let {current, total, records} = result.data;
  data.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loadingTable.value = false
}
//分页
const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

//删除
const deleteDialog = async (row: any) => {
  await delById(row);
  ElMessage.success("删除成功");
  search();
}

//审核通过
const auditData = async (row: any) => {
  const res = await audit(row);
  if (res.code == 200) {
    ElMessage.success("审核成功");
    auditDialog.value = false
    search();
  }
}

//审核不通过
const auditNot = async (row: any) => {
  const res = await auditNotPass(row, msg.value);
  if (res.code == 200) {
    ElMessage.success("审核成功");
    auditDialog.value = false
    msgDialog.value = false
    search();
  }
}

//导出模板
const exp = async () => {
  expLoading.value = true;
  try {
    await exportExcel({});
  }finally {
    expLoading.value = false;
  }
}


const {dialogData, open, close, closed, form, nameRef: dialogFormRef}: DialogForm<RkFormInstance, any>
    = useDialogForm('dialogFormRef', {type: []})

</script>

<style scoped>

</style>
