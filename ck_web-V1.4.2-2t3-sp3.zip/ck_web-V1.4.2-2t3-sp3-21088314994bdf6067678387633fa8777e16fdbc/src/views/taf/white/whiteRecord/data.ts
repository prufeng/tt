import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {
        prop: 'importStatus',
        label: '数据状态',
        width: 170,
        scopedSlots:'importStatusOperate',
        dictFormatKey: 'importStatus'
    },
    {
        prop: 'fileName',
        label: '导入文件名',
        scopedSlots: 'fileNameOperate',
        width: 300,
    },
    {
        prop: 'branchCode',
        label: '分行编号',
        width: 300,
    },
    {
        prop: 'branchCode',
        label: '分行名称',
        dictFormatKey:'branchCode',
        width: 300,
    },
    {
        prop: 'failedReason',
        label: '导入失败原因',
        width: 300,
    },
    {
        prop: 'createTime',
        label: '导入日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'createBy',
        label: '上传者',
        width: 170
    },
    {
        prop: 'approveBy',
        label: '审核者',
        width: 250,
    },

    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'importStatus',
        label: '数据状态',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'importStatus',
            multiple: false,
        },
    },
    {
        prop: 'createTimeArr',
        label: '导入日期',
        inputType: {tag: 'date-picker', type: 'daterange', valueFormat: 'YYYY-MM-DD'}
    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 100,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags:1
        },
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'branchCode',
        label: '所属机构',
        rules: [{required: true, message: '必填'}],
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        extra: {span: 18},
    },
]
