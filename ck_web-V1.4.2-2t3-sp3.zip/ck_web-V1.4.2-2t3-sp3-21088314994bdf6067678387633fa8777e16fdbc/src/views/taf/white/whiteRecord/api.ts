import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/whiteRecord/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

export function delById(data = {}): Promise<RS> {
    return service({
        url: `/whiteRecord/delById`,
        method: 'POST',
        data,
    })
}

export function audit(data = {}): Promise<RS> {
    return service({
        url: `/whiteRecord/audit`,
        method: 'POST',
        data,
    })
}

export function auditNotPass(data = {}, approveDesc: string): Promise<RS> {
    return service({
        url: `/whiteRecord/auditNotPass`,
        method: 'POST',
        data,
        params: {approveDesc},
    })
}

export function uploadExcel(data = {}, branchCode: string): Promise<RS> {
    return service({
        url: `/whiteRecord/uploadExcel`,
        method: 'POST',
        data,
        params: {branchCode},
        headers: {'Content-Type': 'multipart/form-data'}
    })
}

export function downloadFile(data = {}): Promise<RS> {
    return service({
        url: "/whiteRecord/downloadFile",
        method: 'POST',
        responseType: 'blob',
        data
    })
}

export function exportExcel(data = {}): Promise<RS> {
    return service({
        url: `/whiteRecord/exportExcel`,
        method: 'POST',
        data,
        responseType: 'blob'
    })
}
