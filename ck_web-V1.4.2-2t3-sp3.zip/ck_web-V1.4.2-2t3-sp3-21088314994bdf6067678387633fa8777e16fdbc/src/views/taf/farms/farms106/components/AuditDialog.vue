<template>
  <el-dialog v-model="visible" title="审核" width="10%" draggable :close-on-click-modal="false"
             class="rk-dialog-default" destroy-on-close @close="visible = false">
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="auditPass">审核通过</el-button>
        <el-button type="danger" @click="auditNotPass">审核不通过</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import {ref} from "vue";
import {defineProps} from "vue";

const props = defineProps(['showDialog'])

const emit = defineEmits(['audit', 'auditNotPass']);


const visible = ref(false)

const auditPass = () => {
  emit('audit')
  visible.value = false;
}

const auditNotPass = () => {
  emit('auditNotPass')
  visible.value = false;
}

const show = () => {
  visible.value = true;
}

defineExpose({show})

const audit=()=>{

}


</script>

<style scoped>

</style>