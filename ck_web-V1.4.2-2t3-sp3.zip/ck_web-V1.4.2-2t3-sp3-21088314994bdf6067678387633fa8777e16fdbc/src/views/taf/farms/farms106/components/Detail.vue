<template>
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" @closed="closed" :close-on-click-modal="false"
             class="rk-dialog-default" destroy-on-close>
    <rk-detail-form ref="formRef" v-model="form" :form-items="formItems" :disabled="dialogData.formDisabled"></rk-detail-form>

    <template #footer>
         <span class="dialog-footer">
           <el-button @click="closed"> 取消 </el-button>
           <el-button @click="save" v-if="showSaveBtn"> 保存 </el-button>
         </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import {DialogForm, Pagination, RkFormInstance, useDialogForm} from "riking-ui";
import { formItems, pagination} from "../page";
import {ref} from "vue";
import {createByFarms105, add} from "../api";
import {ElMessage} from "element-plus";

const dialogForm: DialogForm<RkFormInstance, any> = useDialogForm('formRef')
const {dialogData, open, close, closed, form, nameRef: formRef} = dialogForm

const data = ref<any []>([]);
const loading = ref(false);
const paging = ref<Pagination>(pagination);

const emit = defineEmits(['onClosed'])
// const {subColumns} = defineProps(['subColumns']);

onMounted(() => {
  // console.log("mountedDetail")
})

watch(() => dialogData.visible, () => {
  if (dialogData.visible == false) {
    emit('onClosed')
  }
})


// 从farms105页面的“反馈”操作打开该编辑页
const openFromFarms105 = async (trxId,fktjz) => {
  // 根据trxId查询一条farms105的数据，将相关字段赋值到farms106,填入表单
  const result = await createByFarms105(trxId, fktjz);
  await open(result.data, false, '编辑')
}

defineExpose({open, openFromFarms105})


const save = async ()=>{
  const valid = await formRef.value?.asyncValidate();
  if(valid) {
    const data = toRaw(form.value);
    await add(data);
  }
  ElMessage.success("保存成功");
  close();
  emit('onClosed')
}



// const showSaveBtn = ref(false);
const showSaveBtn = computed(() => {
  return dialogData.title.includes('查看') ? false : true;
})

</script>

<style scoped>

</style>