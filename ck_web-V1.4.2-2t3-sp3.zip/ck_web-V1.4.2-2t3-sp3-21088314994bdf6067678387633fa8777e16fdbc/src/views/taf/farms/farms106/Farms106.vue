<template>
  <rk-index-layout>
    <rk-dynamic-search-form v-model="searchForm" :form-items="searchFormItems" :fields="advancedQueryItems"
                            @search="search"></rk-dynamic-search-form>

    <rk-page-table :loading="loading" :columns="columns" :data="data" :pagination="paging" @refresh="search"
                   @page-change="pageChange" @selection-change="selectionChange">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="Buttons" :route-meta="$route.meta" :max="9"></rk-button-group>
          <div style="margin: 0 4px;"></div>
          <UpAndDown :imp="imp" :exp="exp"/>
        </div>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="setRowButtons(row)" :route-meta="$route.meta" link/>
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!--查看页面-->
  <Detail ref="detailRef" @onClosed="search"></Detail>

  <AuditDialog ref="auditDialogRef" @audit="audit" @auditNotPass="auditNotPass"></AuditDialog>
</template>


<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {Action, ElMessage,} from 'element-plus'
import dictData from '@/hooks/useDicts'
import {
  RkPageTable,
  RkButtonGroup,
  Pagination,
  ButtonInfo,
  RkDynamicSearchForm, RkIndexLayout, dictFormatter,
} from 'riking-ui'

import {useDict} from 'riking-layout'
import {
  list,
  submitBatch,
  submitAll,
  auditBatch,
  auditBatchNotPass,
  auditAll,
  auditAllNotPass,
  resetBatch,
  recallBatch,
  delBatch,
  uploadBatch
} from './api'
import {columns, searchFormItems, advancedQueryItems, pagination} from "./page";
import UpAndDown from "@/components/UpAndDown.vue";
import {listBusinessLine} from "@/views/query/feedback/api";
import Detail from './components/Detail.vue';
import AuditDialog from './components/AuditDialog.vue';

useDict([], [], {
  ...dictData,
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data;
  },
})

let ids: string;
let trxIds: string;
const data = ref<any []>([]);
const subData = ref<any []>([]);
const paging = ref<Pagination>(pagination);
const searchForm = ref({businessLine: ''});
const loading = ref(false);

const detailRef = ref(null);

const auditDialogRef = ref(null);

const route = useRoute();

onMounted(() => {
  // 从farms105页面点击反馈跳转过来则trxId有值，从菜单栏直接打开该页面trxId值为undefined
  console.log('route', route)
  const trxId = route.query.trxId;
  const fktjz = route.query.fktjz;
  if (trxId != undefined) {
    detailRef.value.openFromFarms105(trxId, fktjz);
  }

  getBusinessLine();
})

watch(paging, () => search())

//主表查询方法
const search = async () => {
  loading.value = true;
  try {
    const result = await list(searchForm.value, paging.value);
    const {current, total, records} = result.data;
    data.value = records;
    paging.value.currentPage = current;
    paging.value.total = total;
  } finally {
    loading.value = false;
  }
}

/**
 * 提交
 */
const submit = async () => {
  if (ids != undefined && ids.length > 0) {
    await submitBatch(ids);
  } else {
    await submitAll();
  }
  ElMessage.success("提交成功");
  await search();
}

/**
 * 审核
 */
const showAuditDialog = async () => {
  // 批量审核选中数据
  if (ids.length > 0) {
    auditDialogRef.value.show();
  }

  // 批量审核全部待审核数据
  if (ids.length == 0) {
    ElMessageBox.confirm(
        '是否批量审核所有待审核数据?',
        '警告',
        {
          confirmButtonText: '审核通过',
          cancelButtonText: '审核不通过',
          type: 'warning',
          distinguishCancelAndClose: true,
          confirmButtonClass: 'auditButton',
          cancelButtonClass: 'auditNotPassButton',
        }
    ).then(async () => {
      loading.value = true;
      const res = await auditAll();

      await search()
      loading.value = false;
    }).catch((action: Action) => {
      const res = auditAllNotPass();

      search()
      loading.value = false;
    })
  }
}

const audit = async () => {
  const res = await auditBatch(ids);

  await search();
}

const auditNotPass = async () => {
  const res = await auditBatchNotPass(ids, "");

  await search();
}

/**
 * 撤回
 */
const recall = async () => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await recallBatch(ids, "");
  await search()
}

/**
 * 重置
 */
const reset = async () => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await resetBatch(ids, "");
  await search()
}

/**
 * 删除
 */
const del = async () => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await delBatch(ids);
  await search()
}

const upload = async () => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  console.log('trxIds: ', trxIds);
  // const res=await uploadBatch(ids);
  const res=await uploadBatch(trxIds);
  ElMessage.success(res.data)
}


/**
 * 查看
 */
const view = async (row) => {
  detailRef.value.open(row, true, '查看');
}


//主表按钮组件
const Buttons: ButtonInfo[] = [
  {
    key: 'submit',
    label: '提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => submit()
  },
  {
    key: 'audit',
    label: '审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => showAuditDialog()
  },
  {
    key: 'recall',
    label: '撤回',
    tag: 'button',
    type: 'primary',
    icon: 'icon_recall',
    handler: () => recall()
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => reset()
  },
  {
    key: 'delete',
    label: '删除',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => del()
  },
  {
    key: 'upload',
    label: '上报',
    tag: 'button',
    type: 'primary',
    icon: 'icon_upload',
    handler: () => upload()
  },
]

/**
 * 设置行按钮
 */
const setRowButtons = (row) => {
  const buttons: ButtonInfo[] = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => {
        detailRef.value.open(row, true, '查看');
      }
    },
  ]
  if (row.status == 0 ||row.status == 1 || row.status == 5 || row.status == 6 || row.status == null){
    buttons.splice(1,0,{
      key: 'edit', label: '编辑', tag: 'button', type: 'primary',
      handler: () => {
        detailRef.value.open(row, false, '编辑');
      }
    },)
  }
  return buttons;
}

// 选择事件
const selectionChange = (newSelection: any[]) => {
  ids = newSelection.map(item => item.id).join(',');
  trxIds = newSelection.map(item => item.trxId).join(',');
}

// 分页事件
const pageChange = (p: Pagination) => {
  paging.value = p
}

const exp = async () => {
  // expLoading.value = true;
  // try {
  //   let copyIds='';
  //   if (!(ids == undefined || ids.length == 0)) {
  //     copyIds = ids.toString()
  //   }
  //   console.log('导出',copyIds)
  //   const newObject = {...form.value};
  //   for (const key in newObject) {
  //     if (newObject[key] === '') {
  //       newObject[key] = null;
  //       console.log("转化了空串")
  //     }
  //   }
  //   // var branchCodeList = Array.from(form.value.branchCodeList).join('-|-');
  //   await exportExcel(routeName, copyIds, newObject);
  // } finally {
  //   expLoading.value = false;
  // }
}

const imp = async (data = {}) => {
}

async function getBusinessLine() {
  try {
    const res = await listBusinessLine();
    const data1 = res.data;

    if (data1.length === 0) {
      ElMessage.error({message: "用户未配置业务线,无法查询数据", grouping: true, showClose: true, duration: 0});
      searchForm.value.businessLine = '';
    } else {
      searchForm.value.businessLine = data1[0].value;
    }
  } catch (error) {
    console.error('Error fetching business line:', error);
  } finally {
    search();
  }
}


</script>

<style>
.auditNotPassButton {
  background: #F56C6CFF;
  border-color: #F56C6CFF;
  color: #fff;
}

.auditNotPassButton:hover {
  background: #e08282; /* 鼠标悬停时的背景色 */
  border-color: #e08282; /* 鼠标悬停时的边框颜色 */
  color: #fff; /* 鼠标悬停时的文字颜色 */
}

/*.auditButton{*/
/*  background: var(--el-color-success);*/
/*  border-color: var(--el-color-success);*/
/*  color: #fff;*/
/*}*/
</style>
