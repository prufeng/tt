import {FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {prop: 'status', label: '状态', dictFormatKey: 'taf_status', sortable: true,},
    {
        prop: 'fnTp',
        label: '功能类型',
        width: 170,
        dictFormatKey: 'taf_A19',
        sortable: true
    },
    {
        prop: 'instgId',
        label: '发起参与者',
        width: 170,
        sortable: true
    },
    {
        prop: 'instdId',
        label: '接收参与者',
        width: 170,
        sortable: true
    },
    {
        prop: 'rtnDtTm',
        label: '返回日期时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'reqTp',
        label: '请求服务类型',
        width: 170,
        dictFormatKey: 'taf_A18',
        sortable: true
    },
    {
        prop: 'dataTrTp',
        label: '数据用途类型',
        width: 170,
        dictFormatKey: 'taf_A15',
        sortable: true
    },
    {
        prop: 'dataTp',
        label: '数据格式类型',
        width: 170,
        dictFormatKey: 'taf_A16',
        sortable: true
    },
    {
        prop: 'orgnBatchNo',
        label: '原发起方批次号',
        width: 170,
        sortable: true
    },
    {
        prop: 'orgnReqId',
        label: '原发起方请求id',
        width: 170,
        sortable: true
    },
    {
        prop: 'description',
        label: '描述',
        width: 170,
        sortable: true
    },
    {
        prop: 'status',
        label: '数据状态',
        width: 170,
        dictFormatKey: 'taf_status',
        sortable: true
    },
    {
        prop: 'fkStatus',
        label: '回执状态',
        width: 170,
        dictFormatKey: 'fkStatus',
        sortable: true
    },
    {
        prop: 'fkInfo',
        label: '回执信息',
        width: 170,
        sortable: true
    },

    {
        prop: 'fklx',
        label: '反馈类型',
        width: 170,
        dictFormatKey: 'taf_fklx',
        sortable: true
    },
    {
        prop: 'fktjz',
        label: '反馈条件值',
        width: 170,
        sortable: true
    },
    {
        prop: 'bkjg',
        label: '布控结果',
        width: 170,
        dictFormatKey: 'taf_bkjg',
        sortable: true
    },
    {
        prop: 'cwyy',
        label: '布控失败原因',
        width: 170,
        sortable: true
    },
    {
        prop: 'yhbm',
        label: '银行总行编码',
        width: 170,
        sortable: true
    },
    {
        prop: 'pcbh',
        label: '批次编号',
        width: 170,
        sortable: true
    },

    {
        prop: 'branchCode',
        label: '机构代码',
        width: 170,
        sortable: true
    },
    {
        prop: 'submitBy',
        label: '提交人',
        width: 170,
        sortable: true
    },
    {
        prop: 'submitDesc',
        label: '提交描述',
        width: 170,
        sortable: true
    },
    {
        prop: 'submitTime',
        label: '提交时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'approveBy',
        label: '审核人',
        width: 170,
        sortable: true
    },
    {
        prop: 'approveDesc',
        label: '审核描述',
        width: 170,
        sortable: true
    },
    {
        prop: 'approveTime',
        label: '审核时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'resetBy',
        label: '重置人',
        width: 170,
        sortable: true
    },
    {
        prop: 'resetDesc',
        label: '重置描述',
        width: 170,
        sortable: true
    },
    {
        prop: 'resetTime',
        label: '重置时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170,
        sortable: true
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateBy',
        label: '更新人',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        width: 170,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        inputType: 'input',
    },
    // {
    //     prop: 'branchCodeList',
    //     label: '业务操作机构',
    //     inputType: {
    //         tag: 'tree-select',
    //         options: 'branchCode',
    //         showCheckbox: true,
    //         checkStrictly: true,
    //         multiple: true,
    //     },
    // },
]

export const advancedQueryItems = [
    {
        value: 'fklx',
        label: '反馈类型',
        inputType: {
            tag: 'select',
            options: 'taf_fklx',
            multiple: false,
        },
    },
    {
        value: 'fktjz',
        label: '反馈条件值',
        inputType: 'input',
    },
    {
        value: 'bkjg',
        label: '布控结果',
        inputType: {
            tag: 'select',
            options: 'taf_bkjg',
            multiple: false,
        },
    },
    {
        value: 'cwyy',
        label: '布控失败原因',
        inputType: 'input',
    },
    {
        value: 'yhbm',
        label: '银行编码',
        inputType: 'input',
    },
    {
        value: 'pcbh',
        label: '批次编号',
        inputType: 'input',
    },

    {
        value: 'fnTp',
        label: '功能类型',
        inputType: {
            tag: 'select',
            options: 'taf_A19',
            multiple: false,
        },
    },
    {
        value: 'instgId',
        label: '发起参与者',
        inputType: 'input',
    },
    {
        value: 'instdId',
        label: '接收参与者',
        inputType: 'input',
    },
    {
        value: 'rtnDtTm',
        label: '返回日期时间',
        inputType: 'input'
    },
    {
        value: 'reqTp',
        label: '请求服务类型',
        inputType: {
            tag: 'select',
            options: 'taf_A18',
            multiple: false,
        },
    },
    {
        value: 'dataTrTp',
        label: '数据用途类型',
        inputType: {
            tag: 'select',
            options: 'taf_A15',
            multiple: false,
        },
    },
    {
        value: 'dataTp',
        label: '数据格式类型',
        inputType: {
            tag: 'select',
            options: 'taf_A16',
            multiple: false,
        },
    },
    {
        value: 'dataContt',
        label: '数据内容',
        inputType: 'input',
    },
    {
        value: 'orgnBatchNo',
        label: '原发起方批次号',
        inputType: 'input',
    },
    {
        value: 'orgnReqId',
        label: '原发起方请求id',
        inputType: 'input',
    },
    {
        value: 'description',
        label: '描述',
        inputType: 'input',
    },
    {
        value: 'fkStatus',
        label: '回执状态',
        inputType: {
            tag: 'select',
            options: 'fkStatus',
            multiple: false,
        },
    },
    {
        value: 'fkInfo',
        label: '回执信息',
        inputType: 'input',
    },

    {
        value: 'status',
        label: '数据状态',
        inputType: {
            tag: 'select',
            options: 'taf_status',
            multiple: false,
        },
    },
    {
        value: 'branchCode',
        label: '机构代码',
        inputType: {
            tag: 'select',
            options: 'branchCode',
            multiple: false,
        },
    },
    {
        value: 'departmentCode',
        label: '部门编码',
        inputType: {
            tag: 'select',
            options: 'departmentCode',
            multiple: false,
        },
    },

    {
        value: 'createBy',
        label: '创建人',
        inputType: 'input',
    },
    {
        value: 'createTime',
        label: '创建时间',
        inputType: 'input',
    },
    {
        value: 'updateBy',
        label: '更新人',
        inputType: 'input',
    },
    {
        value: 'updateTime',
        label: '更新时间',
        inputType: 'input',
    },


]

export const formItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 170,
        // inputType: 'input',
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'fnTp',
        label: '功能类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_A19',
            multiple: false,
            disabled: true
        },
    },
    {
        prop: 'instgId',
        label: '发起参与者',
        labelWidth: 170,
        // inputType: 'input',
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'instdId',
        label: '接收参与者',
        labelWidth: 170,
        // inputType: 'input',
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'rtnDtTm',
        label: '返回日期时间',
        labelWidth: 170,
        // inputType: 'input',
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'reqTp',
        label: '请求服务类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_A18',
            multiple: false,
            disabled: true,
        },
    },
    {
        prop: 'dataTrTp',
        label: '数据用途类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_A15',
            multiple: false,
            disabled: true,
        },
    },
    {
        prop: 'dataTp',
        label: '数据格式类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_A16',
            multiple: false,
            disabled: true,
        },
    },
    {
        prop: 'orgnBatchNo',
        label: '原发起方批次号',
        labelWidth: 170,
        // inputType: 'input',
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'orgnReqId',
        label: '原发起方请求id',
        labelWidth: 170,
        // inputType: 'input',
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'description',
        label: '描述',
        labelWidth: 170,
        // inputType: 'input',
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'fklx',
        label: '反馈类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_fklx',
            multiple: false,
            disabled: true,
        },
    },
    {
        prop: 'fktjz',
        label: '反馈条件值',
        labelWidth: 170,
        // inputType: 'input',
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'bkjg',
        label: '布控结果',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_bkjg',
            multiple: false,
        },
    },
    {
        prop: 'cwyy',
        label: '布控失败原因',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'yhbm',
        label: '银行总行编码',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'pcbh',
        label: '批次编号',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'branchCode',
        label: '机构代码',
        labelWidth: 170,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
            multiple: false,
        },
    },


]

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 50,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}


export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems,
    pagination,
}
























