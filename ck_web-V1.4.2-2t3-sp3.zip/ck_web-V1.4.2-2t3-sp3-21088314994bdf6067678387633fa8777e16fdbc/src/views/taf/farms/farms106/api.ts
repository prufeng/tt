import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: `/farms106/list`,
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    })
}

export function createByFarms105(trxId, fktjz): Promise<RS> {
    return service({
        url: `/farms106/createByFarms105`,
        method: 'POST',
        params: {trxId, fktjz}
    })
}

export function add(data: {}): Promise<RS> {
    return service({
        url: `/farms106/save`,
        method: 'POST',
        data,
    })
}

export function submitBatch(ids: string ): Promise<RS> {
    return service({
        url: `/farms106/submitBatch`,
        method: 'POST',
        params: {ids},
    })
}

export function submitAll(): Promise<RS> {
    return service({
        url: `/farms106/submitAll`,
        method: 'POST',
    })
}

export function auditBatch(ids: string ): Promise<RS> {
    return service({
        url: `/farms106/auditBach`,
        method: 'POST',
        params: {ids},
    })
}

export function auditBatchNotPass(ids: string , msg: any): Promise<RS> {
    return service({
        url: `/farms106/auditBatchNotPass`,
        method: 'POST',
        params: {ids, msg},
    })
}

export function auditAll(): Promise<RS> {
    return service({
        url: `/farms106/auditAll`,
        method: 'POST',
    })
}

export function auditAllNotPass(): Promise<RS> {
    return service({
        url: `/farms106/auditAllNotPass`,
        method: 'POST',
    })
}

export function resetBatch(ids: string , msg: any): Promise<RS> {
    return service({
        url: `/farms106/resetBatch`,
        method: 'POST',
        params: {ids, msg},
    })
}

export function recallBatch(ids: string , msg: any): Promise<RS> {
    return service({
        url: `/farms106/recallBatch`,
        method: 'POST',
        params: {ids, msg},
    })
}

export function delBatch(ids: string ): Promise<RS> {
    return service({
        url: `/farms106/delBatch`,
        method: 'POST',
        params: {ids},
    })
}

export function uploadBatch(ids: string ): Promise<RS> {
    return service({
        url: `/farms106/upload`,
        method: 'POST',
        params: {ids},
    })
}

// export function listFarms105ByTrxId(trxId): Promise<RS> {
//     return service({
//         url: `/farms105/listByTrxId`,
//         method: 'POST',
//         params: {trxId}
//     })
// }





