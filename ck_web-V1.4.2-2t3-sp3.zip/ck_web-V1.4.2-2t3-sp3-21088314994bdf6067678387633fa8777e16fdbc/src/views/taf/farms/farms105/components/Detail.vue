<template>
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" @closed="closed" :close-on-click-modal="false"
             class="rk-dialog-default" destroy-on-close>
    <rk-detail-form ref="formRef" v-model="form" :form-items="formItems"
                    :disabled="dialogData.formDisabled"></rk-detail-form>

    <rk-page-table :loading="loading" :columns="subColumns" :data="data" :pagination="paging"
                   @page-change="pageChange" @selection-change="selectionChange">
      <template #actions="{ row }">
        <rk-button-group :buttons="setRowButtons(row)" :route-meta="$route.meta" link/>
      </template>
    </rk-page-table>

    <template #footer>
         <span class="dialog-footer">
           <el-button @click="closed"> 取消 </el-button>
         </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import {ButtonInfo, DialogForm, Pagination, RkFormInstance, useDialogForm} from "riking-ui";
import {getSubColumns, formItems, pagination} from "../page";
import {checkFarms106Datacontt, listDataCntt} from "../api";
import {ref} from "vue";
import {ElMessage} from "element-plus";

const dialogForm: DialogForm<RkFormInstance, any> = useDialogForm('formRef')
const {dialogData, open, close, closed, form, nameRef: formRef} = dialogForm

watch(() => dialogData.visible, () => {
  if (dialogData.visible == false) {
    emit('onClosed')
  }
})

let trxId = "";
const subColumns = ref([]);
const dataTrTp = ref("");
const fktjz = ref("");
const openSelf = (row) => {
  trxId = row.trxId;
  dataTrTp.value = row.dataTrTp;
  console.log("dataTrTp："+ dataTrTp.value);
  subColumns.value = getSubColumns(row.dataTrTp);
  open(row, true, '查看');
  search();
}

defineExpose({openSelf})

const emit = defineEmits(['onClosed'])
// const {subColumns} = defineProps(['subColumns']);

const data = ref<any []>([]);
const loading = ref(false);
const paging = ref<Pagination>(pagination);

onMounted(() => {
  console.log("mountedDetail")
})

const setRowButtons = (row) => {
  const buttons: ButtonInfo[] = [
    {
      key: 'feedback', label: '反馈', tag: 'button', type: 'primary',
      handler: () => feedback(row.trxId, row)
    },
  ]
  return buttons;
}

const router = useRouter();
const feedback = async (trxId, row) => {
  console.log("trxId："+ trxId);
  if (dataTrTp.value == "01") { // 新增预警布控
    fktjz.value = row.kh;
  } else if (dataTrTp.value == "02" || dataTrTp.value == "03") { // 修改预警布控  撤销预警布控
    fktjz.value = row.cxtjz;
  } else if (dataTrTp.value == "04") { // 事中控制措施解除
    fktjz.value = row.jctjz;
  }
  console.log("fktjz："+fktjz.value);
  var result = await checkFarms106Datacontt(trxId, fktjz.value);
  if (result.data != null && result.data == true) {
    router.push('/106/farms106?trxId=' + trxId + '&fktjz=' + fktjz.value);
    // ElMessage.warning(result.data);
  }
}

const search = async () => {
  if(trxId === "") {
    return;
  }
  loading.value = true;
  try {
    // const trxId = form.value.trxId;
    const result = await listDataCntt(trxId, paging.value);
    const {current, total, records} = result.data;
    data.value = records;
    paging.value.currentPage = current;
    paging.value.total = total;
  } finally {
    loading.value = false;
  }
}

// 分页事件
const pageChange = (p: Pagination) => {
  paging.value = p
}

// 选择事件
let ids = [];
const selectionChange = (newSelection: any[]) => {
  ids = newSelection.map(item => item.id)
}


//子表所需代码
// const save = async () => {
//   const valid = await formRef.value?.asyncValidate();
//   if (!valid) {
//     return;
//   }
//   const data = toRaw(form.value);
//
//   // await subUpdateData(reportCode, data, reportCode);
//   close();
//   closed();
//   ElMessage.success("保存成功");
//   // handleClick(undefined);
//
// }


const showSaveBtn = computed(() => {
  return dialogData.title.includes('查看') ? false : true;
})

</script>

<style scoped>

</style>