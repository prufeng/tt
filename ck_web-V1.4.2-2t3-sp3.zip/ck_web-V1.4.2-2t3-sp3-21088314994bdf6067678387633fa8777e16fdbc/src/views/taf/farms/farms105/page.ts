import {FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'status',
        label: '数据状态',
        width: 170,
        dictFormatKey: 'tafReqProcessingStatus',
        sortable: true
    },
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'fnTp',
        label: '功能类型',
        width: 170,
        dictFormatKey: 'taf_A19',
        sortable: true
    },
    {
        prop: 'orgnInstgId',
        label: '原发起方',
        width: 170,
        sortable: true
    },
    {
        prop: 'ntfyDtTm',
        label: '通知日期时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'dataTrTp',
        label: '数据用途类型',
        width: 170,
        dictFormatKey: 'taf_A15',
        sortable: true
    },
    {
        prop: 'dataTp',
        label: '数据格式类型',
        width: 170,
        dictFormatKey: 'taf_A16',
        sortable: true
    },
    {
        prop: 'dataCntt',
        label: '数据内容',
        width: 170,
        sortable: true
    },
    {
        prop: 'orgnBatchNo',
        label: '原发起方批次号',
        width: 170,
        sortable: true
    },
    {
        prop: 'orgnReqId',
        label: '原发起方请求id',
        width: 170,
        sortable: true
    },
    {
        prop: 'requestType',
        label: '请求服务类型',
        width: 170,
        dictFormatKey: 'taf_A18',
        sortable: true
    },
    {
        prop: 'instructedId',
        label: '接收参与者',
        width: 170,
        sortable: true
    },
    {
        prop: 'description',
        label: '描述',
        width: 170,
        sortable: true
    },
    {
        prop: 'branchCode',
        label: '机构代码',
        width: 170,
        sortable: true
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        width: 170,
        sortable: true
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170,
        sortable: true
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateBy',
        label: '更新人',
        width: 170,
        sortable: true
    },
    {
        prop: 'updateTime',
        label: '更新时间',
        width: 170,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        inputType: 'input',
    },
    // {
    //     prop: 'branchCodeList',
    //     label: '业务操作机构',
    //     inputType: {
    //         tag: 'tree-select',
    //         options: 'branchCode',
    //         showCheckbox: true,
    //         checkStrictly: true,
    //         multiple: true,
    //     },
    // },
]

export const advancedQueryItems = [
    {
        value: 'trxId',
        label: '流水号',
        inputType: 'input',
    },
    {
        value: 'fnTp',
        label: '功能类型',
        inputType: {
            tag: 'select',
            options: 'taf_A19',
            multiple: false,
        },
    },
    {
        value: 'orgnInstgId',
        label: '原发起方',
        inputType: 'input',
    },
    {
        value: 'ntfyDtTm',
        label: '通知日期时间',
        inputType: 'input',
    },
    {
        value: 'dataTrTp',
        label: '数据用途类型',
        inputType: {
            tag: 'select',
            options: 'taf_A15',
            multiple: false,
        },
    },
    {
        value: 'dataTp',
        label: '数据格式类型',
        inputType: {
            tag: 'select',
            options: 'taf_A16',
            multiple: false,
        },
    },
    {
        value: 'dataCntt',
        label: '数据内容',
        inputType: 'input',
    },
    {
        value: 'orgnBatchNo',
        label: '原发起方批次号',
        inputType: 'input',
    },
    {
        value: 'orgnReqId',
        label: '原发起方请求id',
        inputType: 'input',
    },
    {
        value: 'requestType',
        label: '请求服务类型',
        inputType: {
            tag: 'select',
            options: 'taf_A18',
            multiple: false,
        },
    },
    {
        value: 'instructedId',
        label: '描述',
        inputType: 'input',
    },
    {
        value: 'description',
        label: '接收参与者',
        inputType: 'input',
    },
    {
        value: 'status',
        label: '数据状态',
        inputType: {
            tag: 'select',
            options: 'tafReqProcessingStatus',
            multiple: false,
        },
    },
    {
        value: 'branchCode',
        label: '机构代码',
        inputType: {
            tag: 'select',
            options: 'branchCode',
            multiple: false,
        },
    },
    {
        value: 'departmentCode',
        label: '部门编码',
        inputType: {
            tag: 'select',
            options: 'departmentCode',
            multiple: false,
        },
    },

    {
        value: 'createBy',
        label: '创建人',
        inputType: 'input',
    },
    {
        value: 'createTime',
        label: '创建时间',
        inputType: 'input',
    },
    {
        value: 'updateBy',
        label: '更新人',
        inputType: 'input',
    },
    {
        value: 'updateTime',
        label: '更新时间',
        inputType: 'input',
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'fnTp',
        label: '功能类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_A19',
            multiple: false,
        },
    },
    {
        prop: 'orgnInstgId',
        label: '原发起方',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'ntfyDtTm',
        label: '通知日期时间',
        labelWidth: 170,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
    },
    {
        prop: 'dataTrTp',
        label: '数据用途类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_A15',
            multiple: false,
        },
    },
    {
        prop: 'dataTp',
        label: '数据格式类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_A16',
            multiple: false,
        },
    },
    // {
    //     prop: 'dataCntt',
    //     label: '数据内容',
    //     labelWidth: 170,
    //     inputType: 'input',
    // },
    {
        prop: 'orgnBatchNo',
        label: '原发起方批次号',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'orgnReqId',
        label: '原发起方请求id',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'requestType',
        label: '请求服务类型',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'taf_A18',
            multiple: false,
        },
    },
    {
        prop: 'instructedId',
        label: '接收参与者',
        labelWidth: 170,
        inputType: 'input',
    },
    {
        prop: 'description',
        label: '描述',
        labelWidth: 170,
        inputType: 'input',
    },
    // {
    //     prop: 'status',
    //     label: '数据状态',
    //     labelWidth: 170,
    //     inputType: {
    //         tag: 'select',
    //         options: 'status',
    //         multiple: false,
    //     },
    // },
    {
        prop: 'branchCode',
        label: '机构代码',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'branchCode',
            multiple: false,
        },
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 170,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
            multiple: false,
        },
    },
]

export const subColumns_01: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'kh',
        label: '账户',
        width: 170,
        sortable: true
    },
    {
        prop: 'bkgzbh',
        label: '布控规则编号',
        width: 170,
        sortable: true
    },
    {
        prop: 'bkgz',
        label: '布控规则',
        width: 170,
        sortable: true
    },
    {
        prop: 'jylssjfw',
        label: '交易流水时间范围',
        width: 170,
        sortable: true
    },
    {
        prop: 'bkts',
        label: '布控天数',
        width: 170,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const subColumns_02: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'cxlx',
        label: '撤销类型',
        width: 170,
        dictFormatKey: 'taf_cxlx',
        sortable: true
    },
    {
        prop: 'cxtjz',
        label: '撤销条件值',
        width: 170,
        sortable: true
    },
    {
        prop: 'bkgzbh',
        label: '布控规则编号',
        width: 170,
        sortable: true
    },
    {
        prop: 'bkgz',
        label: '布控规则',
        width: 170,
        sortable: true
    },
    {
        prop: 'jylssjfw',
        label: '交易流水时间范围',
        width: 170,
        sortable: true
    },
    {
        prop: 'bkts',
        label: '布控天数',
        width: 170,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const subColumns_03: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'cxlx',
        label: '撤销类型',
        width: 170,
        dictFormatKey: 'taf_cxlx',
        sortable: true
    },
    {
        prop: 'cxtjz',
        label: '撤销条件值',
        width: 170,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const subColumns_04: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'trxId',
        label: '流水号',
        width: 170,
        sortable: true
    },
    {
        prop: 'jclx',
        label: '解除类型',
        width: 170,
        dictFormatKey: 'taf_jclx',
        sortable: true
    },
    {
        prop: 'jctjz',
        label: '解除条件值',
        width: 170,
        sortable: true
    },
    {
        prop: 'czyy',
        label: '操作原因',
        width: 170,
        sortable: true
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 150,
        fixed: 'right',
    },
]

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 50,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}

export const getSubColumns = (dataTrTp) => {

    if(dataTrTp === '01') return subColumns_01;
    if(dataTrTp === '02') return subColumns_02;
    if(dataTrTp === '03') return subColumns_03;
    if(dataTrTp === '04') return subColumns_04;
}

export default {
    columns,
    searchFormItems,
    formItems,
    advancedQueryItems,
    pagination,
    getSubColumns,
    subColumns_01
}























