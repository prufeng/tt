<template>
  <rk-index-layout>
    <rk-dynamic-search-form v-model="searchForm" :form-items="searchFormItems" :fields="advancedQueryItems"
                            @search="search"></rk-dynamic-search-form>

    <rk-page-table :loading="loading" :columns="columns" :data="data" :pagination="paging" @refresh="search"
                   @page-change="pageChange" @selection-change="handleSelectionChange">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <!--<rk-button-group :buttons="setButtons()" :route-meta="$route.meta"></rk-button-group>-->
          <!--<div style="margin: 0 4px;"></div>-->
          <UpAndDown :exp="exp"/>
        </div>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="setRowButtons(row)" :route-meta="$route.meta" link/>
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!--查看页面-->
  <Detail ref="detailRef"></Detail>
</template>


<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElMessage,} from 'element-plus'
import dictData from '@/hooks/useDicts'
import {
  RkPageTable,
  RkButtonGroup,
  Pagination,
  ButtonInfo,
  RkDynamicSearchForm, RkIndexLayout,
} from 'riking-ui'

import {useDict} from 'riking-layout';
import {list,exportExcel} from './api';
import {columns, searchFormItems, advancedQueryItems, pagination, getSubColumns, subColumns_01} from "./page";
import UpAndDown, {expLoading} from "@/components/UpAndDown.vue";
import {listBusinessLine} from "@/views/query/feedback/api";
import {buttons} from "@/views/jyt/data/config/config";
import Detail from './components/Detail.vue';

useDict([], [], {
  ...dictData,
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data;
  },
})

const data = ref<any []>([]);
const subData = ref<any []>([]);
const paging = ref<Pagination>(pagination);
const searchForm = ref({businessLine: ''});
const loading = ref(false);

const detailRef = ref(null);

//初始化
onMounted(() => {
  getBusinessLine();
})

watch(paging, () => search())

//主表查询方法
const search = async () => {
  loading.value = true;
  try {
    const result = await list(searchForm.value, paging.value);
    const {current, total, records} = result.data;
    data.value = records;
    paging.value.currentPage = current;
    paging.value.total = total;
  } finally {
    loading.value = false;
  }
}

/**
 * 查看
 */
const view = async (row) => {
  detailRef.value.openSelf(row);
}


// 获取checkBox 的ids
let ids: string;
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}

// 分页事件
const pageChange = (p: Pagination) => {
  paging.value = p
}

const router = useRouter();
const feedback = (trxId) => {
  router.push('/106/farms106?trxId=' + trxId);
}

/**
 * 设置行按钮
 */
const setRowButtons = (row) => {
  const buttons: ButtonInfo[] = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => view(row)
    },
    // {
    //   key: 'feedback', label: '反馈', tag: 'button', type: 'primary',
    //   handler: () => feedback(row.trxId)
    // },
  ]
  return buttons;
}

/**
 * 设置表头按钮
 */
const setButtons = () => {
  // 按钮和方法的映射关系， 按钮的key属性作为mapping的键，值为需要绑定的方法
  const buttonMethodMapping = {
    // 'batchUpdate': batchUpdate,
    // 'mock': mockData,
  }
  // 为表头按钮绑定对应的方法
  buttons.forEach(item => {
    item.handler = () => buttonMethodMapping[item.key]();
  })
  return buttons;
}

//主表导出
const exp = async () => {
  expLoading.value = true;
  try {
    if (ids==undefined||ids.length == 0) {
      ids=''
    }
    const newObject = {...searchForm.value};
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null;
        console.log("转化了空串")
      }
    }
    await exportExcel(ids,newObject);
  }finally {
    expLoading.value = false;
  }
}


async function getBusinessLine() {
  try {
    const res = await listBusinessLine();
    const data1 = res.data;

    if (data1.length === 0) {
      ElMessage.error({message: "用户未配置业务线,无法查询数据", grouping: true, showClose: true, duration: 0});
      searchForm.value.businessLine = '';
    } else {
      searchForm.value.businessLine = data1[0].value;
    }
  } catch (error) {
    console.error('Error fetching business line:', error);
  } finally {
    search();
  }
}


</script>

<style>
.auditNotPassButton {
  background: #F56C6CFF;
  border-color: #F56C6CFF;
  color: #fff;
}

.auditNotPassButton:hover {
  background: #e08282; /* 鼠标悬停时的背景色 */
  border-color: #e08282; /* 鼠标悬停时的边框颜色 */
  color: #fff; /* 鼠标悬停时的文字颜色 */
}

/*.auditButton{*/
/*  background: var(--el-color-success);*/
/*  border-color: var(--el-color-success);*/
/*  color: #fff;*/
/*}*/
</style>
