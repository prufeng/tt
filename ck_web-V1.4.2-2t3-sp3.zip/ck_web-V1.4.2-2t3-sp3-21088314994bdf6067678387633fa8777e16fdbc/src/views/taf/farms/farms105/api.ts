import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'


export function list(data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: `/farms105/list`,
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    })
}

// export function listByTrxId(trxId): Promise<RS> {
//     return service({
//         url: `/farms105/listByTrxId`,
//         method: 'POST',
//         params: {trxId}
//     })
// }

export function checkFarms106Datacontt(trxId, fktjz): Promise<RS> {
    return service({
        url: `/farms106/checkFarms106Datacontt`,
        method: 'POST',
        params: {trxId, fktjz}
    })
}

export function listDataCntt(trxId, paging: Pagination): Promise<RS> {
    return service({
        url: `/farms105DataCntt/list`,
        method: 'POST',
        params: {trxId, currentPage: paging.currentPage, pageSize: paging.pageSize}
    })
}

export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: "/farms105/exportExcel",
        method: 'POST',
        data,
        params: {ids},
        responseType: 'blob'
    })
}

