<template>
  <rk-index-layout>
    <rk-search-form v-model="searchForm" :form-items="searchFormItems" :label-width="50" @search="search"></rk-search-form>

    <rk-page-table ref="tableRef" :data="data" @refresh="search" @page-change="pageChange"
                    :columns="columns" :loading="loading" :pagination="paging" @selection-change="handleSelectionChange">
<!--      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group
              :buttons="getMainTableButtons()"
              :route-meta="$route.meta"
              :max="9"
          />
        </div>
      </template>-->
      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta"
                         :max="9" link/>
      </template>
    </rk-page-table>

  </rk-index-layout>

  <!-- 新增/修改 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" :close-on-click-modal="false">
    <rk-detail-form ref="dialogFormRef" v-model="form" :form-items="formItems" :disabled="dialogData.formDisabled"/>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="save" type="primary"> 确定 </el-button>
        <el-button @click="close"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 批量提交/审核结果弹窗 -->
  <el-dialog v-model="submitAllVisible" title="提示" :close-on-click-modal=false :destroy-on-close=true :append-to-body=true>
    <el-collapse v-model="activeNames">
      <el-collapse-item name="1">
        <template #title>
          <div class="message-text">{{submitOrAudit}} 成功 <span  style="margin:0 5px;color:#67c23a;">{{successNum}}</span> 条数据, 失败 <span style="margin:0 5px;color:#f56c6c;">{{failNum}}</span> 条数据 </div>
        </template>
        <div   style="box-sizing:border-box;"  >{{returnMassage}}</div>
      </el-collapse-item>
    </el-collapse>
  </el-dialog>

  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="审核" width="30%" draggable :append-to-body=true>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids)">审核通过</el-button>
        <el-button type="danger" @click="()=>{msgDialog = true;msg =''}">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog" title="不通过原因" width="30%" draggable :append-to-body=true>
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
      <el-button type="primary" @click="auditNotPass(ids)">提交</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 文件列表 -->
  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button v-for="fileKey in fileButtonKeys" :key="fileKey" type="primary" link
               style=" margin-bottom: 10px;   display: flex;  flex-direction: column;" @click="fileDownload(fileKey,fileButtonData[fileKey])">{{ fileKey
      }}</el-button>
  </el-dialog>
</template>

<script setup lang="ts">
import {ref} from "vue";
import {
  ButtonInfo,
  DialogForm,
  Pagination,
  RkButtonGroup, RkDetailForm,
  RkFormInstance, RkPageTable,
  useDialogForm
} from "riking-ui";
import {pagination} from "@/utils/utils";
import {
  delBatch, list, saveOrUpdate, submitAllBatch, submitBatch, auditAllBatch,
  auditNotPassAllBatch, auditBatch, auditNotPassBatch, recallBatch, resetBatch,
  getFile, checkFileIsExists, downloadFile
} from './api';
import dictData from '../../../hooks/useDicts'
import {useDict} from "riking-layout";
import {columns, formItems, searchFormItems} from "@/views/taf/r303/data";
import {Action, ElButton, ElDialog, ElMessage, ElCollapse, ElCollapseItem, ElForm, ElFormItem, ElInput} from
      "element-plus";


const data = ref();
const searchForm = ref({})
const tableRef = ref()
const paging = ref<Pagination>(pagination)
const loading = ref(false)
const activeNames = ref(['1'])
const auditDialog = ref(false);
const msgDialog = ref(false);
const msg = ref("")
const dialogVisible = ref(false);
const fileButtonKeys = ref({});
const fileButtonData = ref({});


useDict([], [], {
  ...dictData
})

onMounted(() => search())

watch(paging, () => search())

// 分页事件
const pageChange = (p: Pagination) => {
  paging.value = p
}

// 获取checkBox 的ids
let ids: string;
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}

/**
 * 查询
 */
const search = async () => {
  loading.value = true;
  try {
    const newObject = {...searchForm.value};
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null;
        console.log("转化了空串")
      }
    }
    const result = await list(newObject, paging.value);
    const {records, current, total} = result.data;
    data.value = records;
    paging.value.currentPage = current;
    paging.value.total = total;
  } finally {
    loading.value = false;
  }
}

/**
 * 主表按钮
 */
const getMainTableButtons:()=> ButtonInfo[] = () =>{
  const buttons =  [
    {
      key: 'save',
      label: '新增',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: () => {
        open(null, false, "新增")
      },
    },
    {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => {
        if (ids == undefined || ids.length == 0) {
          submitAll();
          return
        }
        submit(ids);}
    },
    {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      icon: 'icon_check',
      handler: () => {
        if (ids == undefined || ids.length == 0) {
          auditAll();
          return
        }
        auditDialog.value = true;
      },
    },
    {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      icon: 'icon_recall',
      handler: () => recall(ids),
    },
    {
      key: 'reset',
      label: '重置',
      tag: 'button',
      type: 'primary',
      icon: 'icon_reset',
      handler: () => reset(ids),
    },
    {
      key: 'delete',
      label: '删除',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      handler: () => del(ids),
    },
    {
      key: 'upload',
      label: '上报',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: () => handleUpload(ids),
    },
  ]
  return buttons;
}

//主表右侧操作栏按钮组件
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => {
        open(row, true, '查看');
      }
    },
    {
      key: 'view', label: '文件列表', tag: 'button', type: 'primary', handler: async () => {
        const result = await getFile(row);
        const values = Object.keys(result.data);
        fileButtonData.value = result.data;
        fileButtonKeys.value = values;
        dialogVisible.value = true;
      }
    },
  ]
  /*if (row.status==0||row.status==5||row.status==6||row.status==null) {
    buttons.splice(1, 0, {
      key: 'edit', label: '编辑', tag: 'button', type: 'primary',
      handler: () => {
        open(row, false, '编辑');
      }
    });
  }*/
  return buttons
}

//主表批量删除方法
const del = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  const rs = await delBatch(ids);
  await search();
  ElMessage.success(rs.data);
}

const {dialogData, open, close, closed, form, nameRef: dialogFormRef}
    : DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

//主表保存方法
const save = async () => {
  const valid = await dialogFormRef.value?.asyncValidate();
  if (valid){
    // const res=await saveOrUpdate(form.value)
    // ElMessage.success(res.msg);
    close();
    await search();
  }
}

//主表批量提交方法
const submitAllVisible = ref(false);
const successNum = ref(0);
const failNum = ref(0);
const returnMassage = ref('');
const submitOrAudit = ref('');
const submitAll = async () => {
  ElMessageBox.confirm(
      '是否批量提交所有待提交/待补录数据?',
      '警告',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
  )
      .then(async () => {
        const newObject = {...searchForm.value};
        for (const key in newObject) {
          if (newObject[key] === '') {
            newObject[key] = null;
            console.log("转化了空串")
          }
        }
        const rs = await submitAllBatch(newObject);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '提交'
        submitAllVisible.value = true;
        search()
      })
      .catch(() => {
        return
      })
}

//主表提交方法
const submit = async (ids: string) => {
  try {
    const rs = await submitBatch(ids);
    ElMessage.success(rs.data);
  }finally {
    await search();
  }
}

//主表批量审核方法
const auditAll = async () => {
  ElMessageBox.confirm(
      '是否批量审核所有待审核数据?',
      '警告',
      {
        confirmButtonText: '审核通过',
        cancelButtonText: '审核不通过',
        type: 'warning',
        distinguishCancelAndClose: true,
        confirmButtonClass:'auditButton',
        cancelButtonClass:'auditNotPassButton',
      }
  )
      .then(async () => {
        const newObject = {...searchForm.value};
        for (const key in newObject) {
          if (newObject[key] === '') {
            newObject[key] = null;
            console.log("转化了空串")
          }
        }
        const rs = await auditAllBatch(newObject);
        successNum.value = rs.data.successNum;
        failNum.value = rs.data.failNum;
        returnMassage.value = rs.data.returnMassage;
        submitOrAudit.value = '审核'
        submitAllVisible.value = true;
        search()
      })
      .catch((action: Action) => {
        if (action === 'cancel') {
          ElMessageBox.prompt( '审核不通过理由','提示',{confirmButtonText: '确定',cancelButtonText: '取消',inputType:'textarea'})
              .then(async ({ value }) => {
                const newObject = {...searchForm.value};
                for (const key in newObject) {
                  if (newObject[key] === '') {
                    newObject[key] = null;
                    console.log("转化了空串。")
                  }
                }
                const rs = await auditNotPassAllBatch( newObject,value);
                successNum.value = rs.data.successNum;
                failNum.value = rs.data.failNum;
                returnMassage.value = rs.data.returnMassage;
                submitOrAudit.value = '审核不通过'
                submitAllVisible.value = true;
                search()
              })
              .catch(() => {
                return;
              })
        }
      })
}


//主表审核方法
const audit = async (ids: any) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    const rs =  await auditBatch(ids);
    ElMessage.success(rs.data);
  }finally {
    auditDialog.value = false;
    await search();
  }
}
//审核不通过原因
const auditNotPass = async (ids: any) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    const rs =  await auditNotPassBatch(ids,msg.value);
    // status.value = dictFormatter("6",dictData.taf_status)
    ElMessage.success(rs.data);
  }finally {
    msgDialog.value = false;
    auditDialog.value = false;
    await search();
  }
}

//主表撤回方法
const recall = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  const rs = await recallBatch(ids);
  await search();
  // status.value = dictFormatter("1", dictData.taf_status)
  ElMessage.success(rs.data);
}

//主表重置方法
const reset = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }

  ElMessageBox.prompt('重置原因', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
      .then(async ({value}) => {
        const rs = await resetBatch(ids,value);
        await search();
        // status.value = dictFormatter("1", dictData.taf_status)
        ElMessage.success(rs.data);
      })
      .catch(() => {
        return;
      })

}

//文件下载
const fileDownload = async (fileName:string,trxId:string) => {
  let res = await checkFileIsExists(fileName,trxId);
  if (res.code == 200) {
    // window.location.href = import.meta.env.VITE_CONFIG_SERVER_PROXY_URL_PREFIX + "/farms303/downloadFile?id="+res.result;
    await downloadFile(res.result)
  } else {
    ElMessage.warning('文件不存在，无法下载');
  }
};

</script>


