import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    // {key: 'id', type: 'selection'},
    // {prop: 'status', label: '数据状态', minWidth: 200, sortable: true, dictFormatKey: 'taf_status'},
    {prop: 'trxId', label: '流水号', minWidth: 200, sortable: true},
    {prop: 'reportOwer', label: '报文发送方', minWidth: 200, sortable: true,dictFormatKey:'taf_reportOwer'},
    {prop: 'fnTp', label: '功能类型', minWidth: 200, sortable: true,dictFormatKey:'taf_gnlx'},
    {prop: 'instgId', label: '发起参与者', minWidth: 200, sortable: true},
    {prop: 'instdId', label: '接收参与者', minWidth: 200, sortable: true},
    {prop: 'rptDtTm', label: '通知日期时间', minWidth: 200, sortable: true, formatter: dateFormatter,},
    {prop: 'dataTrTp', label: '数据用途类型', minWidth: 200, sortable: true,dictFormatKey:'taf_sjytlx'},
    /*{prop: 'description', label: '描述', minWidth: 200, sortable: true},
    {prop: 'branchCode', label: '业务操作机构', minWidth: 200, dictFormatKey: 'branchTree', sortable: true},
    {prop: 'fkStatus', label: '回执状态', minWidth: 200, sortable: true},
    {prop: 'fkInfo', label: '回执信息', minWidth: 200, sortable: true},*/
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    {prop: 'createTime', label: '数据日期', minWidth: 200, formatter: dateFormatter, sortable: true},
    /*{prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true},*/
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },

]

export const formItems: FormItemInfo[] = [
    {
        prop: 'trxId',
        label: '流水号',
        labelWidth: 80,
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '必填'}, {max: 31,message: '超过31字符限制'}]
    },
    {prop: 'fnTp', label: '功能类型', labelWidth: 80,inputType: {tag: 'select', options: 'taf_gnlx'}},
    {prop: 'instgId', label: '发起参与者', labelWidth: 80,},
    {prop: 'instdId', label: '接收参与者', labelWidth: 80,},
    {
        prop: 'rptDtTm',
        label: '通知日期时间',
        labelWidth: 80,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'}
    },
    {prop: 'dataTrTp', label: '数据用途类型', labelWidth: 80,inputType: {tag: 'select', options: 'taf_sjytlx'}},
    {prop: 'description', label: '描述', labelWidth: 80,},
]

export const searchFormItems: FormItemInfo[] = [
    /*{
        prop: 'status',
        label: '数据状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'taf_status'}
    },*/
    {prop: 'trxId', label: '流水号', labelWidth: 80,},
    {prop: 'fnTp', label: '功能类型', labelWidth: 80,inputType: {tag: 'select', options: 'taf_gnlx'}},
    {prop: 'instgId', label: '发起参与者', labelWidth: 80,},
    {prop: 'instdId', label: '接收参与者', labelWidth: 80,},
    {
        prop: 'rptDtTm',
        label: '通知日期时间',
        labelWidth: 80,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'}
    },
    {prop: 'dataTrTp', label: '数据用途类型', labelWidth: 80,inputType: {tag: 'select', options: 'taf_sjytlx'}},
    {prop: 'description', label: '描述', labelWidth: 80,},
    {prop: 'createBy', label: '创建人', labelWidth: 80,},
    {
        prop: 'createTime',
        label: '创建时间',
        labelWidth: 80,
        inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'}
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {tag: 'tree-select', options: 'branchCode', showCheckbox: true, checkStrictly: true},
    },
]


export default {
    columns,
    formItems,
    searchFormItems,
}
