import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'

export function list( data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: "/farms303/list",
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    })
}

export function delBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms303/del",
        method: 'POST',
        params: {ids},
    })
}

export function saveOrUpdate(data = {}): Promise<RS> {
    return service({
        url: "/farms303/saveOrUpdate",
        method: 'POST',
        data,
    });
}

export function submitAllBatch(data = {}): Promise<RS> {
    return service({
        url: "/farms303/submitAllBatch",
        method: 'POST',
        data,
    })
}

export function submitBatch(ids:any): Promise<RS> {
    return service({
        url: "/farms303/submit",
        method: 'POST',
        params: {ids},
    })
}
export function auditAllBatch(data = {}): Promise<RS> {
    return service({
        url: "/farms303/auditAllBatch",
        method: 'POST',
        data,
    })
}

export function auditNotPassAllBatch(data = {},msg:string): Promise<RS> {
    return service({
        url: "/farms303/auditNotPassAllBatch",
        method: 'POST',
        data,
        params: {msg},
    })
}

export function auditBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms303/audit",
        method: 'POST',
        params: {ids},
    })
}

export function auditNotPassBatch(ids: any,msg:any): Promise<RS> {
    return service({
        url: "/farms303/auditNotPass",
        method: 'POST',
        params: {ids,msg},
    })
}

export function recallBatch(ids: any): Promise<RS> {
    return service({
        url: "/farms303/recall",
        method: 'POST',
        params: {ids},
    })
}

export function resetBatch(ids: any,msg:string): Promise<RS> {
    return service({
        url: "/farms303/reset",
        method: 'POST',
        params: {ids,msg},
    })
}

export function getFile(data = {}): Promise<RS> {
    return service({
        url: "/farms303/getFile",
        method: 'POST',
        data,
        params: {},
    })
}

export function checkFileIsExists(fileName: string,trxId: string): Promise<RS> {
    return service({
        url: "/farms303/checkFileIsExits",
        method: 'get',
        params: { fileName,trxId },
    })
}
export function downloadFile(id: string): Promise<RS> {
    return service({
        url: "/farms303/downloadFile",
        method: 'get',
        responseType:'blob',
        params: { id },
    })
}




