import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'

export function list( data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: "/messageRecord/list",
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    })
}

export function exportExcel(data = {}): Promise<RS> {
    return service({
        url: `/messageRecord/exportExcel`,
        method: 'POST',
        data,
        responseType: 'blob'
    })
}
