<template>
  <rk-index-layout>
    <rk-search-form v-model="form" :form-items="searchFormItems" :label-width="50" @search="search">
    </rk-search-form>

    <rk-page-table ref="tableRef" :data="data" @refresh="search" @page-change="pageChange"
                    :columns="columns" :loading="loading" :pagination="paging">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <UpAndDown :exp="exp"/>
        </div>
      </template>
    </rk-page-table>

  </rk-index-layout>
</template>

<script setup lang="ts">
import {ref} from "vue";
import {Pagination} from "riking-ui";
import {checkData, pagination} from "@/utils/utils";
import {list,exportExcel} from './api';
import dictData from '../../../hooks/useDicts'
import {useDict} from "riking-layout";
import {columns, searchFormItems} from "@/views/taf/report/data";
import UpAndDown , {expLoading, impLoading} from "@/components/UpAndDown.vue";


const data = ref();
const form = ref({})
const tableRef = ref()
const paging = ref<Pagination>(pagination)
const loading = ref(false)


useDict([], [], {
  ...dictData
})

onMounted(() => search())

watch(paging, () => search())

// 分页事件
const pageChange = (p: Pagination) => {
  paging.value = p
}

/**
 * 查询
 */
const search = async () => {
  loading.value = true;
  try {
    const newObject = {...form.value};
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null;
        console.log("转化了空串")
      }
    }
    const result = await list(newObject, paging.value);
    const {records, current, total} = result.data;
    data.value = records;
    paging.value.currentPage = current;
    paging.value.total = total;
  } finally {
    loading.value = false;
  }
}

/**
 * 导出
 */
const exp = async () => {
  expLoading.value = true;
  try {
    let formData = checkData(form.value);
    await exportExcel(formData);
  } finally {
    expLoading.value = false;
  }
}

</script>


