import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {prop: 'txCode', label: '模块', width: 140, sortable: true},
    {prop: 'trxId', label: '流水号', width: 140, sortable: true},
    {prop: 'msgTp', label: '报文编号', width: 140, sortable: true},
    {prop: 'reportOwer', label: '报文发送方', width: 140, sortable: true, dictFormatKey:'reportOwer'},
    {prop: 'messageContent', label: '消息内容-明文', width: 140, sortable: true},
    {prop: 'encrypteMessageContent', label: '消息内容-加密', labelWidth: 80, },
    {prop: 'createTime', label: '创建时间', width: 140, sortable: true},
]

export const searchFormItems: FormItemInfo[] = [
    {prop: 'trxId', label: '流水号', labelWidth: 80, },
    {prop: 'msgTp', label: '报文编号', labelWidth: 80, },
    {prop: 'reportOwer', label: '报文发送方', labelWidth: 80 , inputType:  {tag: 'select', options: 'reportOwer',}},
    {prop: 'messageContent', label: '消息内容-明文', labelWidth: 80, },
    {
        prop: 'createTimeArr',
        label: '创建时间',
        inputType: { tag: 'date-picker', type: 'daterange', valueFormat: 'YYYY-MM-DD' }
    },
]


export default {
    columns,
    searchFormItems,
}
