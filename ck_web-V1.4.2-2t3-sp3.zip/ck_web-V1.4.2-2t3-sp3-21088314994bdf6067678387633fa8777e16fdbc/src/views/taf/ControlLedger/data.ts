import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {
        prop: 'applicationId',
        label: '业务申请编号/任务流水号',
        width: 120
    },
    {
        prop: 'ywlx',
        label: '业务类型',
        width: 120
    },
    {
        prop: 'bgkzhzh',
        label: '被管控账户账号',
        width: 300,
    },
    {
        prop: 'bgkzhmc',
        label: '被管控账户名称',
        width: 120,
    },
    {
        prop: 'gkfs',
        label: '管控方式',
        width: 170
    },
    {
        prop: 'jkbs',
        label: '解控标识',
        width: 170
    },
    {
        prop: 'jkfs',
        label: '解控方式',
        width: 170
    },
    {
        prop: 'je',
        label: '金额',
        width: 300,
    },
    {
        prop: 'gkksrq',
        label: '管控开始日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'gkzzrq',
        label: '管控终止日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'jkrq',
        label: '解控日期',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'branchCode',
        label: '分行编号',
        width: 300,
    },
    {
        prop: 'createBy',
        label: '创建人',
        width: 170
    },
    {
        prop: 'createTime',
        label: '创建时间',
        width: 120,
        formatter: dateFormatter
    },
    {
        prop: 'updateBy',
        label: '操作人',
        width: 170
    },
    {
        prop: 'updateTime',
        label: '操作时间',
        width: 120,
        formatter: dateFormatter
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'applicationId',
        label: '业务申请编号/任务流水号',
        labelWidth: 100,
    },
    {
        prop: 'bgkzhzh',
        label: '被管控账户账号',
        labelWidth: 100,
    },
    {
        prop: 'jkbs',
        label: '解控标识',
        labelWidth: 100,
    }
]



export const formItems: FormItemInfo[] = [
    {
        prop: 'applicationId',
        label: '业务申请编号/任务流水号',
        labelWidth: 120,
    },
    {
        prop: 'ywlx',
        label: '业务类型',
        labelWidth: 120
    },
    {
        prop: 'bgkzhzh',
        label: '被管控账户账号',
        labelWidth: 120,
    },
    {
        prop: 'bgkzhmc',
        label: '被管控账户名称',
        labelWidth: 120,
    },
    {
        prop: 'gkfs',
        label: '管控方式',
        labelWidth: 120
    },
    {
        prop: 'jkbs',
        label: '解控标识',
        labelWidth: 120
    },
    {
        prop: 'jkfs',
        label: '解控方式',
        labelWidth: 120
    },
    {
        prop: 'gkksrq',
        label: '管控开始日期',
        labelWidth: 120,
        inputType: {tag: 'date-input', type: 'datetime', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]
    },
    {
        prop: 'gkzzrq',
        label: '管控终止日期',
        labelWidth: 120,
        inputType: {tag: 'date-input', type: 'datetime', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]
    },
    {
        prop: 'jkrq',
        label: '解控日期',
        labelWidth: 120,
        inputType: {tag: 'date-input', type: 'datetime', format: 'YYYY-MM-DD HH:mm:ss', valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]
    },
    {
        prop: 'je',
        label: '金额',
        labelWidth: 120,
        inputType: 'input-number'
    },
    {
        prop: 'createBy',
        label: '创建人',
        labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'branchCode',
        label: '分行编号',
        labelWidth: 120,
    },
    {
        prop: 'createTime',
        label: '创建时间',
        labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'updateBy',
        label: '操作人',
        labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    },
    {
        prop: 'updateTime',
        label: '操作时间',
        labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    }
]

export const advancedQueryItems = [
    { value: 'applicationId', label: '业务申请编号/任务流水号', inputType: 'input' },
    { value: 'ywlx', label: '业务类型', inputType: {tag: 'select', options: 'zhangHuaYwlx'}},
    { value: 'bgkzhzh', label: '被管控账户账号', inputType: 'input' },
    { value: 'bgkzhmc', label: '被管控账户名称', inputType: 'input' },
    { value: 'gkfs', label: '管控方式', inputType: {tag: 'select', options: 'zhangHuaGkfs'}},
    { value: 'jkbs', label: '解控标识', inputType: {tag: 'select', options: 'zhangHuaJkbs'}},
    { value: 'jkfs', label: '解控方式', inputType: {tag: 'select', options: 'zhangHuaJkfs'}},
    { value: 'gkksrq', label: '管控开始日期', inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'}},
    { value: 'gkzzrq', label: '管控终止日期', inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'}},
    { value: 'jkrq', label: '解控日期', inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD ", valueFormat: 'YYYY-MM-DD'}},
    { value: 'je', label: '金额', inputType: 'input-number' },
    { value: 'branchCode', label: '分行编号', inputType: 'input'},
]