import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/ControlLedger/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

export function getById(params = {}): Promise<RS> {
    return service({
        url: `/ControlLedger/getById`,
        method: 'GET',
        params,
    })
}

export function check(ids:string,flag:boolean): Promise<RS> {
    return service({
        url: `/ControlLedger/check`,
        method: 'POST',
        params:{ids,flag},
    })
}

export function withdraw(ids:string): Promise<RS> {
    return service({
        url: `/ControlLedger/withdraw`,
        method: 'POST',
        params:{ids},
    })
}

export function synchronous(): Promise<RS> {
    return service({
        url: `/ControlLedger/synchronous`,
        method: 'POST',
        params:{},
    })
}

