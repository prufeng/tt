<template>
  <div id="lineChart" style="width: 100%; height: 100%"></div>
</template>
<script setup lang="ts">
// echarts标准格式
const echartInit = () => {
  //获取DOM元素并初始化
  const myChart1 = echarts.init(
    document.getElementById('lineChart') as HTMLElement,
  )
  // const category = ref([])
  // const dottedBase = ref(+new Date())
  // var readyData = []
  // var successData = []
  // var failData = []
  // var startData = []
  // var list = data ? data.data : []
  // for (var i = 0; i < list.length; i++) {
  //   var obj = list[i]
  //   category.push(obj.label)
  //   readyData.push(obj.readyCount)
  //   successData.push(obj.successCount)
  //   failData.push(obj.failCount)
  //   startData.push(obj.startCount)
  // }

  // 指定图表的配置项和数据
  const option = {
    title: {
      text: '日期分布',
      top: '12%',
      left: '5%',
      textStyle: {
        color: '#333',
        fontSize: '16',
      },
    },
    tooltip: {
      trigger: 'axis',
    },
    legend: {
      data: ['待执行', '进行中', '成功', '失败'],
      top: '12%',
      textStyle: {
        color: '#333',
        fontSize: 12,
      },
      itemHeight: '10',
      orient: 'horizontal',
      icon: 'roundRect',
      itemGap: 20,
    },
    color: ['#FCB900', '#dab87e', '#e04e46', '#dc9470'],
    grid: {
      //调整图表位置
      left: '3%',
      right: '8%',
      top: '22%',
      bottom: '15%',
      containLabel: true,
    },
    xAxis: [
      {
        nameLocation: 'end', //x轴name位置 ，还可选'start'，'center'
        nameGap: 5, //name离X轴距离
        data: ['8-10', '8-11', '8-12', '8-13', '8-14', '8-15', '8-16'],
        boundaryGap: false, //x坐标轴从零刻度开始
        axisTick: {
          //轴刻度线
          show: false,
        },
        axisLine: {
          lineStyle: {
            color: '#99c5ff',
          },
        },
        axisLabel: {
          color: '#333',
        },
      },
    ],
    yAxis: [
      {
        min: 0, //Y轴最小值
        splitNumber: 5, //Y轴刻度修改 MAX/splitNumber=间距
        type: 'value',
        axisTick: {
          show: false,
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#99c5ff',
            width: 1,
            type: 'solid',
          },
        },
        splitLine: {
          lineStyle: {
            color: '#e4e8ea',
          },
        },
        axisLabel: {
          color: '#666',
        },
      },
    ],
    series: [
      {
        name: '待执行',
        type: 'line',
        lineStyle: {
          width: 1,
          color: '#ffa726',
          shadowColor: 'rgba(71,216,190, 0.5)',
          shadowBlur: 2,
          shadowOffsetY: 0,
        },
        itemStyle: {
          color: '#ffa726',
          borderWidth: 2,
          borderColor: '#00bda4',
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(
            0,
            0,
            0,
            1,
            [
              {
                offset: 0,
                color: 'rgba(82,194,194, .7)',
              },
              {
                offset: 0.8,
                color: 'rgba(82,194,194, .2)',
              },
            ],
            false,
          ),
          shadowColor: 'rgba(0, 0, 0, 0.2)',
          shadowBlur: 20,
        },
        data: [0.1, 0.5, 0.3, 0.3, 0.4, 0.7, 0.8],
      },
      {
        name: '进行中',
        type: 'line',
        lineStyle: {
          width: 1,
          color: '#3ea3f5',
          shadowColor: 'rgba(71,216,190, 0.5)',
          shadowBlur: 2,
          shadowOffsetY: 0,
        },
        itemStyle: {
          color: '#3ea3f5',
          borderWidth: 2,
          borderColor: '#3ea3f5',
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(
            0,
            0,
            0,
            1,
            [
              {
                offset: 0,
                color: 'rgba(61, 130, 234, 0.7)',
              },
              {
                offset: 0.8,
                color: 'rgba(61, 130, 234, 0.2)',
              },
            ],
            false,
          ),
          shadowColor: 'rgba(0, 0, 0, 0.2)',
          shadowBlur: 10,
        },
        data: [0.8, 0.5, 0.2, 0.3, 0.5, 0.7, 0.2],
      },
      {
        name: '成功',
        type: 'line',
        lineStyle: {
          width: 1,
          color: '#00bda4',
          shadowColor: 'rgba(71,216,190, 0.5)',
          shadowBlur: 2,
          shadowOffsetY: 0,
        },
        itemStyle: {
          color: '#00bda4',
          borderWidth: 2,
          borderColor: '#00bda4',
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(
            0,
            0,
            0,
            1,
            [
              {
                offset: 0,
                color: 'rgba(82,194,194, .7)',
              },
              {
                offset: 0.8,
                color: 'rgba(82,194,194, .2)',
              },
            ],
            false,
          ),
          shadowColor: 'rgba(0, 0, 0, 0.2)',
          shadowBlur: 20,
        },
        data: [0.4, 0.9, 0.9, 0.6, 0.1, 0.2, 0.4],
      },
      {
        name: '失败',
        type: 'line',
        lineStyle: {
          width: 1,
          color: '#ff6666',
          shadowColor: 'rgba(71,216,190, 0.5)',
          shadowBlur: 2,
          shadowOffsetY: 0,
        },
        itemStyle: {
          color: '#ff6666',
          borderWidth: 2,
          borderColor: '#db4b46',
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(
            0,
            0,
            0,
            1,
            [
              {
                offset: 0,
                color: 'rgba(239, 39, 81, 0.7)',
              },
              {
                offset: 0.8,
                color: 'rgba(239, 39, 81, 0.2)',
              },
            ],
            false,
          ),
          shadowColor: 'rgba(0, 0, 0, 0.2)',
          shadowBlur: 20,
        },
        data: [0.4, 0.5, 0.5, 0.3, 0.5, 0.7, 0.8],
      },
    ],
  }
  // 使用刚指定的配置项和数据显示图表。
  myChart1.setOption(option)
  window.onresize = function () {
    setTimeout(function () {
      myChart1.resize()
    }, 300)
  }
}

onMounted(() => {
  echartInit()
})
</script>
<style scoped></style>
