<template>
  <div class="app-container">
    国际化： {{ t('msg.test') }}

    <div class="home card">
      <line-chart></line-chart>
      <pie-chart></pie-chart>
      <img class="home-bg" src="@/assets/images/welcome01.png" alt="welcome" />
    </div>
  </div>
</template>
<script lang="ts">

</script>
<script setup lang="ts">
import LineChart from './LineChart.vue'
import PieChart from './PieChart.vue'
const { t } = useI18n()
</script>
<style scoped lang="scss">
.home {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  .home-bg {
    width: 70%;
    margin-bottom: 20px;
  }
}
</style>
