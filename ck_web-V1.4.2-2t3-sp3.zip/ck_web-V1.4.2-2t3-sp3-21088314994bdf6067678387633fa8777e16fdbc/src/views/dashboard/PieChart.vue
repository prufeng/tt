<template>
  <div id="pieChart" style="width: 100%; height: 100%"></div>
</template>
<script setup lang="ts">
// echarts标准格式
const echartInit = () => {
  //获取DOM元素并初始化
  const myChart = echarts.init(
    document.getElementById('pieChart') as HTMLElement,
  )
  // 指定图表的配置项和数据
  const option = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c} ({d}%)',
    },
    legend: {
      orient: 'vertical',
      show: true,
      top: '12%',
      left: '20px',
      data: ['待执行', '进行中', '成功', '失败'],
    },
    title: {
      text: '总体调度概况',
      top: '12%',
      left: 'center',
      textStyle: {
        color: '#333',
        fontSize: '16',
      },
    },
    color: ['#ffa726', '#3ea3f5', '#00bda4', '#ff6666'],
    series: [
      {
        type: 'pie',
        radius: ['35%', '55%'],
        center: ['50%', '55%'],
        labelLine: {
          lineStyle: {
            length: 15,
            length2: 15,
          },
        },
        label: {
          itemStyle: {
            trigger: 'item',
            borderWidth: 0,
            borderRadius: 4,
          },
        },

        data: [
          {
            value: 11,
            name: '待执行',
          },
          {
            value: 11,
            name: '进行中',
          },
          {
            value: 22,
            name: '成功',
          },
          {
            value: 33,
            name: '失败',
          },
        ],
      },
    ],
  }
  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option)
  window.onresize = function () {
    setTimeout(function () {
      myChart.resize()
    }, 300)
  }
}

onMounted(() => {
  echartInit()
})
</script>
<style scoped></style>
