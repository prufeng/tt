// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import { RS } from 'riking-ui'
import service from '@/utils/request';
enum Api {
  list = '/sysReportCount/list',
  createAndUploadReport = '/sysReportCount/createAndUploadReport',
  create = '/sysReportCount/create',
  reset = '/sysReportCount/reset'

}

export const list = (data: any): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'post',
    data
  })
};

export const createAndUploadReport = (data: any): Promise<RS> => {
  return service({
    url: Api.createAndUploadReport,
    method: 'POST',
    data
  })
};

export const reset = (data: any): Promise<RS> => {
  return service({
    url: Api.reset,
    method: 'POST',
    data
  })
};

export const create = (data: any): Promise<RS> => {
  return service({
    url: Api.create,
    method: 'POST',
    data
  })
};
