import { FormItemInfo, Pagination, TableColumnInfo } from "riking-ui";
export const columns: TableColumnInfo[] = [
  {
    key: 'id',
    type: 'selection',

  },
  {
    prop: 'fkParentReportName',
    label: '报表大类',
  },
  {
    prop: 'fkReportCode',
    label: '报表编号',
  },
  {
    prop: 'fkReportName',
    label: '报表名称',
    fixedWidth: 300,
  },
  {
    prop: 'b',
    label: '待处理',

  },
  {
    prop: 'a',
    label: '待生成',
  },
  {
    prop: 'c',
    label: '已生成',
  },
  {
    prop: 'd',
    label: '已上报',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'createTimeArr',
    label: '数据日期',
    inputType: { tag: 'date-picker', type: 'daterange', valueFormat: 'YYYY-MM-DD' }
  },
  // {
  //   prop: 'branchCodeList', label: '业务操作机构', labelWidth: 100,
  //   inputType: {
  //     tag: 'tree-select',
  //     options: 'branchCode',
  //     multiple: true,
  //     showCheckbox: true,
  //     checkStrictly: true,
  //   }
  // },
  // {
  //   prop: 'businessLine', label: '业务线', labelWidth: 100,
  //   inputType: {
  //     tag: 'select',
  //     options: 'businessLine',
  //   }
  // },

];