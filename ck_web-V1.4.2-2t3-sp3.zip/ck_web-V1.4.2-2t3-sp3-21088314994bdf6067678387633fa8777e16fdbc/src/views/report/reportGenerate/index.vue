<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" v-model="searchForm" :form-items="searchItems" @search="search" :label-width="50">
    </rk-search-form> 
    <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" @refresh="search"
      :span-method="objectSpanMethod" @selection-change="handleSelectionChange">
      <template #operations>
        <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
      </template>
    </rk-page-table>
  </rk-index-layout>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { RkPageTable, RkButtonGroup, ButtonInfo } from 'riking-ui'
import { columns, searchItems } from "./data";
import { list, createAndUploadReport, create, reset } from './api'
import { getSubSystem } from "@/utils/subSystem";
import moment from "moment";

useDict([], [], dictData)
const tableRef = ref('tableRef')
const selectedItems = ref([]);
const { state, init } = useState({
  refname: 'tableRef',
  columns,
})

const defaultDateRangeValue = [moment().add(-29, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')] // 默认日期范围


const createLoading = ref<boolean>(false);


const handleCreate = async () => {
  if (selectedItems.value.length == 0) {
    ElMessage.warning('请至少选择一条数据');
    return;
  }
  createLoading.value = true;
  const fkReportCode = [];
  selectedItems.value.forEach((item: { fkReportCode: any; }) => {
    fkReportCode.push(item.fkReportCode)
  });
  const formData = new FormData();
  formData.append("fkReportCode", fkReportCode)
  formData.append('systemCode', getSubSystem())
  let res = await create(formData);
  createLoading.value = false;
  ElMessage.success(res.msg)
  search();
}

const handleCreateAndUploadReport = async () => {
  if (selectedItems.value.length == 0) {
    ElMessage.warning('请至少选择一条数据');
    return;
  }
  const fkReportCode = [];
  selectedItems.value.forEach((item: { fkReportCode: any; }) => {
    fkReportCode.push(item.fkReportCode)
  });
  const formData = new FormData();
  formData.append("fkReportCode", fkReportCode)
  formData.append('systemCode', getSubSystem())
  let res = await createAndUploadReport(formData);
  ElMessage.success(res.msg)
  search();
}

const handleReset = async () => {
  if (selectedItems.value.length == 0) {
    ElMessage.warning('请至少选择一条数据！');
    return;
  }
  if (getSubSystem() == 'zgfy' && selectedItems.value.length > 1) {
    ElMessage.warning('只能选择一条数据！');
    return;
  }
  const fkReportCode = [];
  selectedItems.value.forEach((item: { fkReportCode: any; }) => {
    fkReportCode.push(item.fkReportCode)
  });
  const formData = new FormData();
  formData.append("fkReportCode", fkReportCode)
  formData.append('systemCode', getSubSystem())
  let res = await reset(formData);
  ElMessage.success(res.msg)
  search();
}



const handleSelectionChange = (items: any) => {
  selectedItems.value = items;
}


const buttons: ButtonInfo[] = [
  {
    key: 'create',
    label: '生成',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleCreate(),
  },
  {
    key: 'upload',
    label: '生成并上报',
    tag: 'button',
    type: 'primary',
    icon: 'icon_upload',
    handler: () => handleCreateAndUploadReport(),
  },
  {
    key: 'reset',
    label: '报文重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => handleReset(),
  },
]
const data = ref<any[]>([]);
const searchForm = ref({
  createTimeArr: defaultDateRangeValue,
})

const search = async () => {
  init();
  const params = {
    ...searchForm.value,
    systemCode: getSubSystem()
  }
  let res = await list(params);
  data.value = res.result;
}

onMounted(() => {
  search();
})

const objectSpanMethod = ({
  row,
  column,
  rowIndex,
  columnIndex,
}) => {
  if (columnIndex === 1) {
    let obj = {}
    // 上一行该列数据是否一样
    if (rowIndex !== 0 && row.fkParentReportName === data.value[rowIndex - 1].fkParentReportName) {
      obj = {
        rowspan: 0,
        colspan: 0
      }
    } else {
      let rowSpan = 1
      // 判断下一行是否相等
      for (let i = rowIndex + 1; i < data.value.length; i++) {
        if (row.fkParentReportName !== data.value[i].fkParentReportName) {
          break
        }
        rowSpan++
      }
      obj = {
        rowspan: rowSpan,
        colspan: 1
      }
    }
    return obj
  }
}

</script>

<style scoped></style>