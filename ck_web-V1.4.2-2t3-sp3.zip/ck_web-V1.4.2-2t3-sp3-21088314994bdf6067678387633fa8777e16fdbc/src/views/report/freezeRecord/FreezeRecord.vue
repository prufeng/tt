<template>
  <div class="app-container">
    <rk-search-form ref="searchFormRef" v-model="searchForm" @keyup.enter="search" :form-items="searchItems"
                    @search="search" :label-width="50"/>

    <rk-page-table :data="data" :columns="columns" :loading="loading" @refresh="search" hidden-table-tools>
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <UpAndDown :exp="exp"/>
        </div>
      </template>
    </rk-page-table>
  </div>
</template>


<script lang="ts">
import useDictsStore from '@/store/dictStore'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
import {RkFormInstance, RkPageTable, RkSearchForm, RS} from "riking-ui";
import {onMounted, ref} from "vue";
import {getSubSystem} from "@/utils/subSystem";
import moment from "moment/moment";
import {expExcel} from "@/views/report/api";
import {dateFormatter} from "@/utils/utils";

interface ISearch {
  searchTime: [] | any,
  subSystem: string | undefined
}

const data = ref<any []>([]);
const loading = ref(false)
const expLoading = ref(false)
const searchFormRef = ref<RkFormInstance>()
const subSystem = getSubSystem();
const defaultDateRangeValue = [moment().add(-9, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')] // 默认日期范围
const defaultSystemValue = (getSubSystem() === 'ybjh') ? undefined : getSubSystem() // 默认选择系统

const searchForm = ref<ISearch>({
  searchTime: defaultDateRangeValue,
  subSystem: defaultSystemValue,
})


onMounted(() => {
  search();
})

const search = async () => {
  loading.value = true;
  try {
    const value = searchForm.value;
    const params: any = {};
    params.subSystem = value?.subSystem;
    if (params.subSystem == undefined) {
      params.subSystem = "ybjh";
    }
    const searchTime = value.searchTime;
    if (searchTime) {
      params.startDate = searchTime[0];
      params.endDate = searchTime[1];
    }
    let result = await service({
      url: `/online/freezeRecord`,
      method: 'GET',
      params,
    });
    data.value = result.data;
    console.log(result);
  } finally {
    loading.value = false;
  }
}

const exp = async () => {
  expLoading.value = true;
  try {
    let searchTime = searchForm.value.searchTime;
    await expExcel(searchTime[0], searchTime[1]);
  } finally {
    expLoading.value = false;
  }
}

const searchItems = [
  {
    prop: 'searchTime',
    label: '数据日期',
    labelWidth: 80,
    inputType: {
      tag: 'date-picker',
      type: 'daterange',
      style: "width: 220px",
      rangeSeparator: '-',
      format: "YYYY-MM-DD",
      valueFormat: 'YYYY-MM-DD'
    },
    rules: [{required: true, message: '数据日期不能为空'}]
  },
]

let columns = [
  // {prop: 'subSystem', label: '系统', labelWidth: 150, sortable: true},
  {prop: 'radicalCode', label: '客户号', labelWidth: 150, sortable: true},
  {prop: 'radicalName', label: '客户名称', labelWidth: 150, sortable: true},
  {prop: 'dadt', label: '请求日期', labelWidth: 150, sortable: true},
  {prop: 'ah', label: '执行号', labelWidth: 150, sortable: true},
  {prop: 'agencyName', label: '有权机关名称', labelWidth: 150, sortable: true},
  {prop: 'frozenAcct', label: '冻结账户', labelWidth: 150, sortable: true},
  {prop: 'frozenAmount', label: '要求冻结金额', labelWidth: 150, sortable: true},
  {prop: 'frozenAmountR', label: '实际执行金额', labelWidth: 150, sortable: true},
  {prop: 'frozenAmountN', label: '未冻结金额', labelWidth: 150, sortable: true},
  {prop: 'controlAmount', label: '实控金额', labelWidth: 150, sortable: true},
  {prop: 'measure', label: '控制措施', labelWidth: 150, sortable: true},
  {prop: 'startTime', label: '冻结日期从', labelWidth: 150, sortable: true},
  {prop: 'expireTime', label: '冻结日期至', labelWidth: 150, sortable: true},
  {prop: 'oddNo', label: '请求单号', labelWidth: 150, sortable: true},
  {prop: 'operatorName', label: '审判员', labelWidth: 150, sortable: true},
  {prop: 'tel', label: '联系电话', labelWidth: 150, sortable: true},
  // {key: 'actions', label: '操作', labelWidth: 150, fixed: 'right''}
]

</script>

<style scoped>

</style>








