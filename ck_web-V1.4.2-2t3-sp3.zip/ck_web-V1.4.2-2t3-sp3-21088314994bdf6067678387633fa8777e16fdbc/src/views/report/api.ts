import {RS} from "riking-ui";
import service from "@/utils/request";

export function expExcel(startDate: string, endDate: string): Promise<RS> {
    return service({
        url: `/online/exp`,
        method: 'POST',
        params: {startDate, endDate},
        responseType: 'blob'
    })
}

export function expExcelReqSt(startDate: string, endDate: string, subSystem: string): Promise<RS> {
    return service({
        url: `/st/exp`,
        method: 'POST',
        params: {startDate, endDate, subSystem},
        responseType: 'blob'
    })
}

export function listSt(params: {}): Promise<RS> {
    return service({
        url: `/st/reqStatusSt`,
        method: 'GET',
        params,
    })
}