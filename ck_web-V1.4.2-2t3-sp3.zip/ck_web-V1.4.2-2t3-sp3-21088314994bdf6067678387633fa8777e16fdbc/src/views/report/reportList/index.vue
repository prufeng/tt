<template>
  <rk-index-layout>
    <rk-search-form
      ref="searchFormRef"
      v-model="searchForm"
      :loading="loading"
      :form-items="getSubSystem() == 'zgfy'?searchItemsZgfy:searchItems"
      @search="search"
      @keyup.enter="search"
      :label-width="50"
    >
      <template #reportCode>
        <el-select v-model="searchForm.reportCode" clearable>
          <el-option
            v-for="item in reportCodeArr"
            :key="item.fkReportCode"
            :label="item.fkReportCode + '-' + item.fkReportName"
            :value="item.fkReportCode"
          />
        </el-select>
      </template>
    </rk-search-form>
    <rk-page-table
      ref="tableRef"
      :loading="state.loading"
      :columns="getSubSystem() == 'zgfy' ?columnsZgfy : columns"
      :data="data"
      :pagination="page"
      @page-change="pageChange"
      @refresh="search"
      @selection-change="handleSelectionChange"
      @sort-change="sortChange"
    >
      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
      </template>
      <template #operations>
        <rk-button-group :buttons="buttons" :route-meta="['UPLOAD_BATCH']"></rk-button-group>
      </template>
    </rk-page-table>
  </rk-index-layout>
  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button
      v-for="xmlKey in xmlButtonKeys"
      :key="xmlKey"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="openXml(xmlKey)"
      >{{ xmlKey }}</el-button
    >
    <el-button
      v-for="pdfKey in pdfButtonKeys"
      :key="pdfKey"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="openPdf(pdfKey)"
      >{{ pdfKey }}</el-button
    >
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage } from 'element-plus'
import { useDict } from 'riking-layout'
import {
  RkPageTable,
  RkCollapseForm,
  RkButtonGroup,
  RkSearchForm,
  TableColumnInfo,
  RkInput,
  RkDetailForm,
  RS,
  Pagination,
  ButtonInfo,
  FormItemInfo,
  RkFormInstance,
  useDialogForm,
} from 'riking-ui'
import { columns, columnsZgfy, pagination, searchItems,searchItemsZgfy } from './data'
import {
  getQuartzList,
  getFkReportCode,
  upload,
  getXml,
  getPdf,
  downloadZip,
  checkFileIsExists,
  resetById,
} from './api'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'
import { getSubSystem } from '@/utils/subSystem'
import { BASE_PREFIX } from '@/utils/request'

useDict([], [], dictData)

const { state, init } = useState({
  refname: 'tableRef',
  columns,
})
const handleCreateAndUpload = async () => {
  search()
}
const loading = ref(false)
const data = ref<any[]>([])
const reportCodeArr = ref<any[]>([])
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

/**
 * A 待生成
 * B 待处理
 * C 已生成
 * D 已上报
 */
const search = async () => {
  const params = {
    ...searchForm.value,
    systemCode: getSubSystem(),
    reportCode: searchForm.value.reportCode == '' ? null : searchForm.value.reportCode,
  }
  let result = await getQuartzList(params, page.value.currentPage, page.value.pageSize, sort.value)
  let records = result.result
  data.value = records.records
  page.value.currentPage = records.current
  page.value.pageSize = records.size
  page.value.total = records.total
}

const buttons: ButtonInfo[] = [
  {
    key: 'batchUpload',
    label: '批量上报',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleBatchUpload(),
  },
]
const dialogVisible = ref(false)
const xmlButtonKeys = ref({})
const xmlDataList = ref({})
const pdfButtonKeys = ref({})
const pdfDataList = ref({})
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'download',
      label: '下载',
      tag: 'button',
      type: 'primary',
      handler: () => handleDownload(row),
    },
    {
      key: 'previewXml',
      label: '预览XML',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        const result = await getXml(row)
        const keys = Object.keys(result.data)
        pdfButtonKeys.value = {}
        xmlButtonKeys.value = keys
        xmlDataList.value = result.data
        console.log(keys)
        dialogVisible.value = true
      },
    },
    {
      key: 'reset',
      label: '报文重置',
      tag: 'button',
      type: 'primary',
      // icon: 'icon_reset',
      handler: async () => {
        let res = await resetById(row.id)
        ElMessage.success(res.msg)
        await search()
      },
    },
  ]
  if (row.isUpload != '1') {
    buttons.splice(1, 0, {
      key: 'upload',
      label: '上报',
      tag: 'button',
      type: 'primary',
      handler: () => handleUpload(row),
    })
  }

  if ((getSubSystem() === 'zgfy' && row.reportCode == '1004') || row.hasDoc) {
    buttons.splice(2, 0, {
      key: 'previewPdf',
      label: '预览回执文书',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        const result = await getPdf(row)
        if (result.data === '反馈压缩包中没有文书PDF附件') {
          ElMessage.warning('反馈压缩包中没有文书PDF附件')
          return
        }
        const keys = Object.keys(result.data)
        xmlButtonKeys.value = {}
        pdfButtonKeys.value = keys
        pdfDataList.value = result.data
        console.log(keys)
        dialogVisible.value = true
      },
    })
  }
  return buttons
}

const openXml = (key: any) => {
  // 将base64字符串转换为Uint8Array对象
  console.log(xmlDataList.value[key])
  var xmlData = atob(xmlDataList.value[key])
  var xmlArray = new Uint8Array(xmlData.length)
  for (var i = 0; i < xmlData.length; i++) {
    xmlArray[i] = xmlData.charCodeAt(i)
  }
  // 创建Blob对象
  var xmlBlob = new Blob([xmlArray], { type: 'text/xml' })
  // 将Blob对象转换为URL
  var xmlUrl = URL.createObjectURL(xmlBlob)
  let xmlWindow = window.open(xmlUrl, 'xml预览')
}

const openPdf = (key: any) => {
  // 将base64字符串转换为Uint8Array对象
  console.log(pdfDataList.value[key])
  var pdfData = atob(pdfDataList.value[key])
  var pdfArray = new Uint8Array(pdfData.length)
  // let pdfWindow = window.open('', 'pdf预览')
  let pdfWindow = window.open('')
  // 将base64字符串转换为Uint8Array对象
  for (var i = 0; i < pdfData.length; i++) {
    pdfArray[i] = pdfData.charCodeAt(i)
  }
  // 创建Blob对象
  var pdfBlob = new Blob([pdfArray], { type: 'application/pdf' })
  // 将Blob对象转换为URL
  var pdfUrl = URL.createObjectURL(pdfBlob)
  // 将URL作为iframe的src属性值
  pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>")
}

const handleDownload = async (row: any) => {
  let res = await checkFileIsExists(row.id)
  if (res.code == 200) {
    window.location.href = BASE_PREFIX + '/sysReportZipRecord/downloadZip?id=' + row.id
  } else {
    ElMessage.warning('文件不存在，无法下载')
  }
}

const selectedItems = ref([])

const handleSelectionChange = (items: any) => {
  selectedItems.value = items
}

const handleBatchUpload = async () => {
  if (selectedItems.value.length == 0) {
    ElMessage.warning('请至少选择一条数据')
    return
  }
  const zipIds: any = []
  selectedItems.value.forEach((item: { id: any }) => {
    zipIds.push(item.id)
  })
  const params = {
    zipIds: zipIds.toString(),
    systemCode: getSubSystem(),
  }
  let res = await upload(params)
  ElMessage.success(res.msg)
  search()
}
const handleUpload = async (row: any) => {
  const params = {
    zipIds: row.id,
    systemCode: getSubSystem(),
  }
  let res = await upload(params)
  ElMessage.success(res.msg)
  search()
}
onMounted(() => {
  page.value = {...pagination}
  // if (getSubSystem() == 'zgfy' || getSubSystem() == 'jcy') {
  //   searchItems.splice(1, 0, {
  //     prop: 'qqdbs',
  //     label: '请求单标识',
  //     labelWidth: 80,
  //   })
  // }
  search()
  fkReportCode()
})

const fkReportCode = () => {
  getFkReportCode({
    systemCode: getSubSystem(),
  }).then((res) => {
    reportCodeArr.value = res.result
  })
}

const sort = ref({})
const sortChange = ({ column, prop, order }) => {
  sort.value = {
    prop,
    order,
  }
  search()
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData,
  open,
  close,
  closed,
  form: dialogForm,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })
</script>

<style scoped></style>
