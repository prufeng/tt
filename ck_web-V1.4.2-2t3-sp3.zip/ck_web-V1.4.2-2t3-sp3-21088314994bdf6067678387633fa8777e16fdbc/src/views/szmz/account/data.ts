import { ButtonInfo, FormItemInfo, Pagination, TableColumnInfo } from "riking-ui";
import { ElMessage } from "element-plus";

export const buttons: ButtonInfo[] = [

]

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}


export const subPagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}