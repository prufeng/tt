import { ButtonInfo, FormItemInfo, Pagination, TableColumnInfo } from "riking-ui";

export const columns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { key: 'id', type: 'expand', label: '展开', width: 50, minWidth: 40, scopedSlots: 'expand' },
    { prop: 'jls', label: '记录数', fixedWidth: 100, align: 'right', sortable: true },
    { prop: 'wjm', label: '文件名称', fixedWidth: 200, sortable: true },
    { prop: 'wjscsj', label: '文件生成时间', fixedWidth: 150, sortable: true },
    { prop: 'wjid', label: '文件id', fixedWidth: 250, sortable: true },
    { prop: 'qmz', label: '签名值', sortable: true },
]

export const recordSearchFormItems: FormItemInfo[] = [
    {
        prop: 'branchCodeList', label: '业务操作机构',
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
]

export const subColumns: TableColumnInfo[] = [
    { prop: 'sqbh', label: '申请唯一号', width: 210, sortable: true },
    { prop: 'hdbh', label: '核对编号', width: 220, sortable: true },
    { prop: 'hddxbh', label: '核对对象编号', width: 240, sortable: true },
    { prop: 'xm', label: '姓名', width: 80, sortable: true },
    { prop: 'zjlx', label: '证件类型', width: 100, dictFormatKey: 'szmz_zjlx', sortable: true },

    { prop: 'zjhm', label: '证件号码', width: 150, sortable: true },
    { prop: 'hdqqzylx', label: '核对请求资源类型', width: 130, dictFormatKey: 'szmz_qqzylx', sortable: true },
    { prop: 'qqsj', label: '核对请求时间', width: 150, sortable: true },
    { prop: 'srhdqsrq', label: '可支配收入核定起始日期', width: 200, sortable: true },
    { prop: 'srhdjzrq', label: '可支配收入核定截止日期', width: 200, sortable: true },

    { prop: 'cchdrq', label: '财产核定日期', width: 150, sortable: true },
    { prop: 'dezcydz', label: '大额支出约定值', width: 130, align: 'right', sortable: true },
    { prop: 'zcqsrq', label: '支出起始日期', width: 150, sortable: true },
    { prop: 'zcjzrq', label: '支出截止日期', width: 150, sortable: true },
    { prop: 'dxsqs', label: '核对对象授权书', width: 270, sortable: true },
    { prop: 'dxsqsqmz', label: '核对对象授权书签名值', width: 150, sortable: true },
    { prop: 'dxsqsmy', label: '核对对象授权书密钥', width: 150, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 200,
        fixed: 'left',
    },

]

// 银行大额支出信息明细表
export const formItem: FormItemInfo[] = [
    { prop: 'yhdm', label: '银行名称', extra: { span: 24 } },
    { prop: 'zcrq', label: '支出日期', inputType: 'date-picker', extra: { span: 24 } },
    { prop: 'yhzh', label: '银行卡号/存折号', extra: { span: 24 } },
    { prop: 'zcje', label: '支出金额', inputType: { tag: 'input-number', controlsPosition:"right",precision:"2"}, extra: { span: 24 } },
    { prop: 'zczy', label: '支出摘要', extra: { span: 24 } },
    { prop: 'zcbz', label: '支出备注', extra: { span: 24 } },
]

// 高级查询
export const advancedQueryItems = [
    { value: 'jls', label: '记录数', inputType: { tag: 'input' } },
    { value: 'wjm', label: '文件名称', inputType: { tag: 'input' } },
    { value: 'wjscsj', label: '文件生成时间', inputType: { tag: 'input' } },
    { value: 'wjid', label: '文件id', inputType: { tag: 'input' } },
    { value: 'qmz', label: '签名值', inputType: { tag: 'input' } },
]   