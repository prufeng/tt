import { RS } from 'riking-ui'
import service from '@/utils/request'
import { getCurrentInstance } from 'vue';


export function list(data = {}, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz-qqheader/list',
        method: 'POST',
        data,
        params: { requestCode }
    })
}
export function cxSearchList(data = {}, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz-qqheader/list',
        method: 'POST',
        data,
        params: { current: 1, size: 10, requestCode }
    })
}

export function subList(data = {}, params = {}): Promise<RS> {
    return service({
        url: '/szmz-qqsjx/list',
        method: 'POST',
        data,
        params
    })
}

export function getOne(params = {}): Promise<RS> {
    return service({
        url: '/query/getOne',
        method: 'GET',
        params: { ...params },
    })
}

export function checkPdf(params = {}): Promise<RS> {
    return service({
        url: '/szmz-qqsjx/checkPdf',
        method: 'GET',
        params,
    })
}
