<template>
  <rk-index-layout>
    <rk-dynamic-search-form v-model="searchForm" :form-items="recordSearchFormItems" :fields="advancedQueryItems"
      @search="search"></rk-dynamic-search-form>
    <rk-page-table :loading="loading" :columns="columns" :data="data" :pagination="page" @page-change="pageChange"
      @refresh="search" @expand-change="expandChange" @sort-change="sortChange">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="buttons()" :route-meta="$route.meta"></rk-button-group>
        </div>
      </template>
      <template #expand="{ row }">
        <rk-page-table :data="subData" :columns="subColumns" border="true" max-height="200" hiddenTableTools
          style="margin-left: 49px;width:95%" :pagination="subPage"
          @page-change="(p: Pagination) => subPageChange(p, row)" @sort-change="subSortChange">
          <template #actions="{ row: subRow }">
            <rk-button-group :buttons="genActButtons(row, subRow)" :route-meta="$route.meta" :max='2' link />
          </template>
        </rk-page-table>
      </template>
    </rk-page-table>
  </rk-index-layout>
  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed">
    <rk-collapse-form ref="dialogFormRef" v-model="form" :form-items="formItem" :collapse-model-value="activeCollapse"
      disabled="false">
    </rk-collapse-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="close"> 保存</el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-model="assignmentDialog" width="70%">

    <rk-page-table ref="assignmentTable" :loading="assignmentLoading" :data="assignmentData" :columns="assignmentColumns"
      border="true" @selection-change="assignmentIdsHandleSelectionChange" @refresh="assignmentSearch">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <!-- 此处按钮无需做权限配置 -->
          <rk-button-group :buttons="assignmentButtons" :route-meta="[]"></rk-button-group>
        </div>
      </template>
    </rk-page-table>
  </el-dialog>
  <!-- 分配机构form弹出框 -->
  <el-dialog v-model="assignmentFormDialog" width="70%" @closed="() => { assignmentFormRef.resetFields() }">
    <rk-detail-form ref="assignmentFormRef" v-model="assignmentForm" :form-items="[
      {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      }, {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      }, {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
          tag: 'tree-select',
          options: 'branchCode',
          showCheckbox: true,
          checkStrictly: true,
        },
        rules: [{required: true, message: '业务操作机构不能为空'}],
      },
    ]">
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled=true filterable style="width: 100%">
        </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="assignmentSave">保存</el-button>
        <el-button @click="assignmentFormDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';
import { pa } from 'element-plus/es/locale';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage } from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  FormItemInfo, TableColumnInfo, RkDynamicSearchForm,
} from 'riking-ui'
import { pagination, subPagination } from "./data";
import { DialogForm } from 'riking-ui/dist/hooks/useDialogForm'
import { useDict } from 'riking-layout'
import { columns, recordSearchFormItems, subColumns, formItem, advancedQueryItems } from "./page";
import { list, subList, getOne, cxSearchList, checkPdf } from './api'
import { useRoute } from 'vue-router'
import {
  assignmentDialog,
  assignmentLoading,
  assignmentData,
  assignmentColumns,
  // assignmentPage,
  // assignmentPageChange,
  assignmentSearch,
  assignmentButtons,
  assignmentQqdbs,
  assignmentRwlsh,
  assignmentIdsHandleSelectionChange,
  assignmentSave,
  assignmentFormDialog,
  assignmentFormRef,
  assignmentForm
} from '@/utils/assignment'
import { getRequestClassificationCode } from "@/utils/subSystem";
import {BASE_PREFIX} from "@/utils/request";

let fullPath = window.location.href;
let parts = fullPath.split('/');
let requestCode = parts[parts.length - 1];

const loading = ref(false)
const data = ref<any[]>([]);
const subData = ref<any[]>([]);
const page = ref<Pagination>(pagination)
const subPage = ref<Pagination>(subPagination)
const searchForm = ref({})
const sort = ref({})
const subSort = ref({})
const selectedRow = ref([])

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  search()
})


const search = async () => {
  loading.value = true
  const params = {
    ...searchForm.value,
    current: page.value.currentPage,
    pageSize: page.value.pageSize,
    requestCode,
    ...sort.value
  }
  let result = await list(params, requestCode);
  let { current, total, records } = result.data;
  data.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loading.value = false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}
const subPageChange = (p: Pagination, row: any) => {
  subPage.value = p
  subSearch()
}

const buttons: () => ButtonInfo[] = () => [
  // {
  //   key: 'add',
  //   label: '线下请求单',
  //   tag: 'button',
  //   type: 'primary',
  //   icon: 'icon_add',
  //   handler: () => {
  //     dialogData.visible = true;
  //   }
  // },
]
const sortChange = ({ column, prop, order }) => {
  sort.value = {
    prop, order
  }
  search();
}

const subSortChange = ({ column, prop, order }) => {
  subSort.value = {
    prop, order
  }
  subSearch();
}

const {
  dialogData, open, close, closed, form,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

const genActButtons: (row: any, subRow: any) => ButtonInfo[] = (row: any, subRow: any) => [
  {
    key: 'viewPdf', label: '预览承诺和授权书', tag: 'button', type: 'primary',
    handler: () => {
      checkPdfHandle(subRow.id)
    }
  },
  {
    key: 'assign', label: '指派', tag: 'button', type: 'primary',
    handler: () => {
      if (row.status == "4" || row.status == "5") {
        ElMessage.warning("该条数据已经生成或上报报文,无法分配机构");
        return
      }
      assignmentDialog.value = true;
      const data = toRaw(assignmentForm.value);
      data.qqdbs = row.wjid
      data.rwlsh = subRow.sqbh
      assignmentQqdbs.value = row.wjid
      assignmentRwlsh.value = subRow.sqbh
      assignmentSearch();
    }
  },
]

const activeCollapse = ref(['basic', 'body', 'person'])

const subSearch = async () => {
  const data = {
    parentId: selectedRow.value.id,
    branchCodeList: searchForm.value.branchCodeList
  }

  const params = {
    current: subPage.value.currentPage,
    size: subPage.value.pageSize,
    requestCode,
    ...subSort.value,
    wjid: selectedRow.value.wjid,
  }
  let result = await subList(data, params);
  let { current, total, records } = result.data;
  subData.value = records;
  subPage.value.currentPage = current;
  subPage.value.total = total;
}

const expandChange = (row) => {
  selectedRow.value = row;
  subSearch()
}

const checkPdfHandle = async (id: number) => {
  const params = {
    id,
    requestCode: 'qqsjx'
  }
  let res = await checkPdf(params);
  if (res.status == '1') {
    window.open(BASE_PREFIX + `/szmz-qqsjx/previewPdf?reportCode=${requestCode}&id=${id}&isDownloadPdfFile=false`, "_blank");
  } else if (res.status == '2') {
    const action = await ElMessageBox.confirm('是否下载并预览授权书?', '提示', { type: 'info' })
    if (action == 'confirm') {
      window.open(BASE_PREFIX + `/szmz-qqsjx/previewPdf?reportCode=${requestCode}&id=${id}&isDownloadPdfFile=true`, "_blank");
    }
  } else if (res.status == '3') {
    ElMessage.warning(res.msg)

  }
}

</script>

<style scoped>
.request-body :deep(.el-table__expanded-cell .table-header) {
  display: none;
}

.request-body :deep(.el-table__row) {
  background: gainsboro !important;
}

.request-body :deep(.el-table__expanded-cell .el-table__row) {
  background: transparent !important;
}
</style>
