import { RS } from 'riking-ui'
import service from '@/utils/request'
import { getSubSystem } from "@/utils/subSystem";

export function list(data = {}, current: number, size: number, requestCode: string, sort: {}): Promise<RS> {
    return service({
        url: '/szmz/fk/list',
        method: 'POST',
        data,
        params: { current, size, requestCode, ...sort }
    })
}
//分页查询
export function fkSearchList(data = {}, requestCode: string) {
    return service({
        url: '/szmz/fk/list',
        method: 'POST',
        data,
        params: { current: 1, size: 10, requestCode }
    })
}

export function subList(data = {}, current: number, size: number, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz/fk/sub/list',
        method: 'POST',
        data,
        params: { current, size, requestCode }
    })
}

export function saveData(data = {}, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz/fk/save',
        method: 'POST',
        data,
        params: {
            requestCode
        }
    })
}


export function subSaveData(data = {}, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz/fk/sub/save',
        method: 'POST',
        data,
        params: {
            requestCode
        }
    })
}

export function submitBatch(data: any, ids: any, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz/fk/submit',
        method: 'POST',
        data,
        params: { ids, requestCode },
    })
}

export function revokeBatch(ids: any, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz/fk/revoke',
        method: 'POST',
        params: { ids, requestCode },
    })
}


export function auditBatch(data: any, ids: any, requestCode: string, status: string, msg: string): Promise<RS> {
    return service({
        url: '/szmz/fk/audit',
        method: 'POST',
        data,
        params: { ids, requestCode, status, msg },
    })
}


export function resetBatch(params: any): Promise<RS> {
    return service({
        url: '/szmz/fk/reset',
        method: 'POST',
        params,
    })
}



export function subDelBatch(ids: any, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz/fk/del',
        method: 'POST',
        params: {
            ids, requestCode
        },
    })
}


export function importExcel(data: any): Promise<RS> {
    return service({
        url: '/szmz/fk/importExcel',
        method: 'POST',
        data,
        headers: { 'Content-Type': 'multipart/form-data' },
    })
}

export function exportExcel(data: {}, ids: any, requestCode: string): Promise<RS> {
    return service({
        url: '/szmz/fk/exportExcel',
        method: 'POST',
        data,
        params: { ids, requestCode },
        responseType: 'blob'
    })
}
export function listBusinessLine(): Promise<RS> {
    return service({
        url: `/dict/listBusinessLine`,
        method: 'GET',
        params: { subSystem: getSubSystem() }
    })
}

export function checkPdf(params = {}): Promise<RS> {
    return service({
        url: '/szmz-qqsjx/checkPdf',
        method: 'GET',
        params,
    })
}