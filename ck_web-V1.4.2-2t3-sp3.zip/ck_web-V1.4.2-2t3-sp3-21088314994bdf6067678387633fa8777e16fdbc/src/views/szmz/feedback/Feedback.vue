<template>
  <RkIndexLayout>
    <rk-dynamic-search-form v-model="searchForm" :form-items="searchItems" :fields="advancedQueryItems"
                            @search="search"></rk-dynamic-search-form>
    <rk-page-table :loading="loading" :columns="columns" :data="data" :pagination="page" @refresh="search"
                   @page-change="pageChange" @selection-change="handleSelectionChange" @sort-change="sortChange">
      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link :max="2"/>
      </template>
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="buttons()" :route-meta="$route.meta" :max="4"></rk-button-group>
          <div style="margin: 0 4px;"></div>
          <UpAndDown :imp="imp" :exp="exp"/>
        </div>
      </template>
      <template #status="{ row }">
        <el-popover v-if="row.status === '6'" placement="bottom" title="审核不通过原因" :width="250" trigger="hover">
          <p class="tipck">操作: 审核不通过</p>
          <p class="tipck">操作人: {{ row.approveBy }}</p>
          <p class="tipck">操作时间: {{ row.approveTime }}</p>
          <p class="tipck">备注: {{ row.approveDesc }}</p>
          <template #reference>
            <el-button size="default" link :type="getTagColor(row.status)">
              {{ dictFormatter(row.status, dictData.dataStatus) }}
            </el-button>
          </template>
        </el-popover>
        <el-popover v-else-if="row.status === '0' && (row.resetBy !== null && row.resetBy !== '')" placement="bottom"
                    title="重置原因" :width="250" trigger="hover">
          <p class="tipck">操作: 重置</p>
          <p class="tipck">操作人: {{ row.resetBy }}</p>
          <p class="tipck">操作时间: {{ row.resetTime }}</p>
          <p class="tipck">备注: {{ row.resetDesc }}</p>
          <template #reference>
            <el-button size="default" link :type="getTagColor(row.status)">
              {{ dictFormatter(row.status, dictData.dataStatus) }}
            </el-button>
          </template>
        </el-popover>
        <el-button v-else size="default" link :type="getTagColor(row.status)">
          {{ dictFormatter(row.status, dictData.dataStatus) }}
        </el-button>
      </template>
    </rk-page-table>
  </RkIndexLayout>
  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed">
    <!-- 弹出层头信息 -->
    <rk-detail-form ref="dialogFormRef" v-model="form" :form-items="parentsFormItems"
                    :disabled="dialogData.formDisabled">
    </rk-detail-form>
    <div style="width:100%;text-align: right;">
      <el-button type="primary" @click="save()">
        保存
      </el-button>
    </div>
    <el-tabs v-model="activeName" class="demo-tabs">
      <el-tab-pane :label="tabPaneLabel" :name="1">
        <rk-page-table :loading="subLoading" :columns="subColumns" :data="subData" :pagination="subPage"   @page-change="subPageChange"
        @refresh="subSearch">
          <template #actions="{ row }">
            <rk-button-group :buttons="subGenActButtons(row)" :route-meta="$route.meta" :max="4" link/>
          </template>
          <template #operations>
            <div style="display: flex; flex-direction: row">
              <rk-button-group :buttons="subButtons()" :route-meta="$route.meta"></rk-button-group>
            </div>
          </template>
        </rk-page-table>
      </el-tab-pane>
    </el-tabs>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消 </el-button>
      </span>
    </template>

  </el-dialog>
  <el-dialog v-model="subDialogData.visible" :title="subDialogData.title" class="rk-dialog-small" @closed="subClosed">
    <rk-detail-form ref="subDialogFormRef" v-model="subForm" :form-items="formItems"
                    :disabled="subDialogData.formDisabled">
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" v-if="subDialogData.title.includes('编辑') || subDialogData.title.includes('新增')"
                   @click="subSave()">保存</el-button>
        <el-button @click="subClose"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="警告" width="30%" draggable>
    <span>是否批量审核所有待审核数据?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids, '3')">审核通过</el-button>
        <el-button type="danger" @click="() => { msgDialog = true; msg = '' }">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog" title="不通过原因" width="30%" draggable :append-to-body=true>
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids, '6')">提交</el-button>
      </span>
    </template>
  </el-dialog>
</template>


<script setup lang="ts">
//主表所需代码
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage, selectKey} from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  RkDetailForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, dictFormatter, DialogForm, RkDynamicSearchForm
} from 'riking-ui'
import {useDict} from 'riking-layout'
import {pagination, subPagination} from "./data";
import {columns, searchItems, columns00401, getPageData, advancedQueryItems} from "./page";
import {
  list,
  subList,
  exportExcel,
  checkPdf,
  submitBatch,
  auditBatch,
  resetBatch, subSaveData, subDelBatch, fkSearchList, importExcel, listBusinessLine, revokeBatch, saveData
} from './api'
import {parentsFormItems} from './page';
import {useRoute} from 'vue-router'
import {getRequestClassificationCode} from "@/utils/subSystem";
import {BASE_PREFIX} from "@/utils/request";

let fullPath = window.location.href;
let parts = fullPath.split('/');
let requestCode = parts[parts.length - 1];
const activeName = ref(1)
const loading = ref(false)
const subLoading = ref(false)
const data = ref<any[]>([]);
const subData = ref<any[]>([]);
const page = ref<Pagination>(pagination);
const subPage = ref<Pagination>(subPagination);
const searchFormRef = ref<RkFormInstance>()
const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef')

const {
  dialogData: subDialogData,
  open: subOpen,
  close: subClose,
  closed: subClosed,
  form: subForm,
  nameRef: subDialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('subDialogFormRef')
let subColumns: any[] = [], formItems: any[] = [], formItems1: any[] = [], tabPaneLabel: string = ''
const pageData = getPageData(requestCode);
subColumns = pageData.subColumns
tabPaneLabel = pageData.tabPaneLabel
formItems = pageData.formItems
const searchForm = ref({businessLine: ''});

const msg = ref("")


useDict([], [], {
  ...dictData,
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data;
  },
})
const msgDialog = ref(false);


const actionType = ref(false)
onMounted(() => {
  page.value = {...pagination}
  getBusinessLine();
})
const auditDialog = ref(false);

const search = async () => {
  loading.value = true
  let result = await list(searchForm.value, page.value.currentPage, page.value.pageSize, requestCode, sort.value);
  let {current, total, records} = result.data;
  data.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loading.value = false
}

const subSearch = async () => {
  subLoading.value = true
  const params = {
    parentId: form.value.id
  }
  let result = await subList(params, subPage.value.currentPage, subPage.value.pageSize, requestCode);
  let {current, total, records} = result.data;
  subData.value = records;
  subPage.value.currentPage = current;
  subPage.value.total = total;
  subLoading.value = false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const subPageChange = (p: Pagination) => {
  subPage.value = p

  subSearch()
}

let ids: string, subIds: string;
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}
const handleSubSelectionChange = async (val: any) => {
  subIds = val.map((item: any) => item.id).join(",");
}

const submit = async (ids: string) => {

  if (ids) {
    try {
      const res = await submitBatch(searchForm.value, ids, requestCode);
      ElMessage.success(res.data);
    } finally {
      await search();
    }
  } else {
    ElMessageBox.confirm(
        '是否批量提交所有待提交/待补录数据?',
        '警告',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
    )
        .then(async () => {
          try {
            const res = await submitBatch(searchForm.value, ids, requestCode);
            ElMessage.success(res.data);
          } finally {
            await search();
          }
        })
  }

}

const audit = async (ids: any, status: string) => {
  try {
    const res = await auditBatch(searchForm.value, ids, requestCode, status, msg.value);
    ElMessage.success(res.data);

  } finally {
    auditDialog.value = false
    msgDialog.value = false
    await search();
  }
}

const auditAll = async () => {

  ElMessageBox.confirm(
      '是否批量审核所有待审核数据?',
      '警告',
      {
        confirmButtonText: '审核通过',
        cancelButtonText: '审核不通过',
        type: 'warning',
        distinguishCancelAndClose: true,
        confirmButtonClass: 'auditButton',
        cancelButtonClass: 'auditNotPassButton',
      }
  )
      .then(async () => {
            try {
              const res = await auditBatch(searchForm.value, ids, requestCode, "3", msg.value);
              ElMessage.success(res.data);
            } finally {
              auditDialog.value = false
              await search();
            }
          }
      ).catch((action: Action) => {
    if (action === 'cancel') {
      ElMessageBox.prompt('审核不通过理由', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        inputType: 'textarea'
      })
          .then(async ({value}) => {
            try {
              const res = await auditBatch(searchForm.value, ids, requestCode, "6", value);
              ElMessage.success(res.data);
            } finally {
              auditDialog.value = false
              await search();
            }
          })
          .catch(() => {
            return;
          })
    }
  })

}


const reset = async (ids: string) => {

  ElMessageBox.prompt('重置原因', '提示', {confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea'})
      .then(async ({value}) => {
        const params = {
          ids, requestCode, resetDesc: value
        }
        const res = await resetBatch(params);

        ElMessage.success(res.data);
      })
      .catch(() => {
        return;
      }).finally(()=>{
     search();
  })



}

const revoke = async (ids: string) => {
  const res = await revokeBatch(ids, requestCode);
  await search();
  ElMessage.success(res.data);
}

const subDel = async (ids: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await subDelBatch(ids, requestCode);
  ElMessage.success("删除成功");
  subSearch()
}


const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: async () => {
        const params = {
          parentId: row.id
        }
        actionType.value = true
        await open(row, false, '查看');
        subSearch()
      }
    },
    {
      key: 'viewPdf', label: '预览承诺和授权书', tag: 'button', type: 'primary',
      handler: () => {
        checkPdfHandle(row.id)
      }
    }
  ]
  // 待补录、待提交都可以提交数据
  if (row.status == "0" || row.status == "1" || row.status == '6') {
    buttons.push({
      key: 'submit', label: '提交', tag: 'button', type: 'primary',
      handler: () => {
        submit(row.id);
      }
    }, {
      key: 'edit', label: '编辑', tag: 'button', type: 'primary',
      handler: async () => {
        const params = {
          parentId: row.id
        }
        actionType.value = false
       await  open(row, false, '编辑');
        subSearch()
      }
    },)
  }

  return buttons;
}

async function getBusinessLine() {
  try {
    const res = await listBusinessLine();
    const data1 = res.data;

    if (data1.length === 0) {
      ElMessage.error({message:"用户未配置业务线,无法查询数据", grouping: true, showClose: true, duration: 0});
      searchForm.value.businessLine = '';
    } else {
      searchForm.value.businessLine = data1[0].value;
    }
  } catch (error) {
    console.error('Error fetching business line:', error);
  } finally {
    search();
  }
}


const save = async () => {
  let data = toRaw(form.value);
  let res = await saveData(data, requestCode);
  search()
  ElMessage.success(res.msg);
}

//子表所需代码
const subSave = async () => {
  let data = toRaw(subForm.value);
  data.parentId = form.value.id
  let res = await subSaveData(data, requestCode);
  ElMessage.success(res.msg);
  const params = {
    parentId: form.value.id
  }
  subSearch()
  subClose();
  subClosed();
}

const sort = ref({})
const sortChange = ({column, prop, order}) => {
  sort.value = {
    prop, order
  }
  search();
}

const buttons: () => ButtonInfo[] = () => [
  {
    key: 'submit',
    label: '批量提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => {
      submit(ids);
    }
  },
  {
    key: 'audit',
    label: '批量审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        auditAll();
        return
      }
      auditDialog.value = true
    }
  },
  {
    key: 'reset',
    label: '批量重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => {
      if (ids == undefined || ids == '') {
        ElMessage.warning('请至少选择一条数据');
        return;
      }
      reset(ids)
    },
  },
  {
    key: 'recall',
    label: '批量撤回',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => {
      if (ids == undefined || ids == '') {
        ElMessage.warning('请至少选择一条数据');
        return;
      }
      revoke(ids)
    },
  },

]

const subButtons: () => ButtonInfo[] = () => {
  let buttons = []

  if (!actionType.value) {
    buttons.push({
          key: 'add',
          label: '新增',
          tag: 'button',
          type: 'primary',
          icon: 'icon_add',
          handler: () => subOpen({}, false, '新增')
        },
    )
    buttons.push(
        {
          key: 'batchDelete',
          label: '批量删除',
          tag: 'button',
          type: 'danger',
          icon: 'icon_delete',
          handler: () => {
            subDel(subIds)
          },
        },
    )
  }

  return buttons;

}

const subGenActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  let buttons: ButtonInfo[];
  if (!actionType.value) {
    buttons = [
      {
        key: 'view', label: '查看', tag: 'button', type: 'primary',
        handler: () => {
          subOpen(row, true, '查看');
        }
      },
      {
        key: 'edit', label: '编辑', tag: 'button', type: 'primary',
        handler: () => {
          subOpen(row, false, '编辑');
        }
      },
      {
        key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
        handler: () => subDel(row.id)
      }]
  } else {
    buttons = [
      {
        key: 'view', label: '查看', tag: 'button', type: 'primary',
        handler: () => {
          subOpen(row, true, '查看');
        }
      },
      {
        key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
        handler: () => subDel(row.id)
      }]
  }
  return buttons;
};


const getTagColor = (status: string) => {
  if (status == '6') {
    return 'danger'
  } else {
    return 'primary';
  }
}

const checkPdfHandle = async (id: number) => {
  const params = {
    id,
    requestCode
  }
  let res = await checkPdf(params);
  if (res.status == '1') {
    window.open(BASE_PREFIX + `/szmz-qqsjx/previewPdf?reportCode=${requestCode}&id=${id}&isDownloadPdfFile=false`, "_blank");
  } else if (res.status == '2') {
    const action = await ElMessageBox.confirm('是否下载并预览授权书?', '提示', {type: 'info'})
    if (action == 'confirm') {
      window.open(BASE_PREFIX + `/szmz-qqsjx/previewPdf?reportCode=${requestCode}&id=${id}&isDownloadPdfFile=true`, "_blank");
    }
  } else if (res.status == '3') {
    ElMessage.warning(res.msg)

  }
}

const imp = async (data) => {
  const da = {
    file: data.raw ? data.raw : data[0], requestCode
  }
  const rs = await importExcel(da);
  await ElMessageBox.alert(
      rs.data,
      '导入结果',
      {
        customClass: 'customMessageBox',
        dangerouslyUseHTMLString: true,
      }
  )
  search();
}

const exp = async () => {
  const newObject = {...searchForm.value};
  await exportExcel(newObject, ids, requestCode);
}

</script>
<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
let fullPath = window.location.href;
let parts = fullPath.split('/');
let requestCode = parts[parts.length - 1];

</script>
<style scoped></style>
