import { FormItemInfo, SearchFormField, TableColumnInfo } from "riking-ui";

export const getPageData: TableColumnInfo = (requestClassificationCode: string) => {
    let tabPaneLabel: string = "";
    let subColumns: TableColumnInfo = []
    let formItems: FormItemInfo[] = []
    if (requestClassificationCode == "ckxx") {
        tabPaneLabel = '银行存款（含外汇）信息明细表'
        subColumns = columns00401
        formItems = formItem00401
    } else if (requestClassificationCode == "lcxx") {
        tabPaneLabel = '银行理财信息明细'
        subColumns = columns00402
        formItems = formItem00402
    } else if (requestClassificationCode == "gjsxx") {
        tabPaneLabel = '银行贵金属信息明细'
        subColumns = columns00403
        formItems = formItem00403
    } else if (requestClassificationCode == "zqxx") {
        tabPaneLabel = '银行债券信息明细表'
        subColumns = columns00404
        formItems = formItem00404
    } else if (requestClassificationCode == "lxxx") {
        tabPaneLabel = '银行利息信息（包括活期、定期等结息）明细表'
        subColumns = columns00405
        formItems = formItem00405
    } else if (requestClassificationCode == "dezcxx") {
        tabPaneLabel = '银行大额支出信息明细表'
        subColumns = columns00406
        formItems = formItem00406
    }
    return {
        tabPaneLabel,
        subColumns,
        formItems
    }
}

// 最外层搜索区域
export const searchItems: FormItemInfo[] = [
    {
        prop: 'xm',
        label: '姓名',
        inputType: 'input',
    },
    {
        prop: 'zjhm',
        label: '证件号码',
        inputType: 'input',
    },
    {
        prop: 'branchCodeList', label: '业务操作机构',
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线',
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'status', label: '数据状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',  
        }
    },
];
// 最外层搜索列表table列
export const columns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },

    { prop: 'status', label: '数据状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },

    { prop: 'sqbh', label: '申请唯一号', fixedWidth: 210, sortable: true },
    { prop: 'hdbh', label: '核对编号', fixedWidth: 230, sortable: true },
    { prop: 'hddxbh', label: '核对对象编号', fixedWidth: 230, sortable: true },
    { prop: 'xm', label: '姓名', sortable: true },
    { prop: 'zjlx', label: '证件类型', dictFormatKey: "szmz_zjlx", sortable: true },

    { prop: 'zjhm', label: '证件号码', fixedWidth: 150, sortable: true },
    { prop: 'hdqqzylx', label: '核对请求资源类型', sortable: true },
    { prop: 'srhdqsrq', label: '可支配收入核定起始日期', sortable: true },
    { prop: 'srhdjzrq', label: '可支配收入核定截至日期', sortable: true },
    { prop: 'cchdrq', label: '财产核定日期', sortable: true },

    { prop: 'dezcydz', label: '大额支出约定值', sortable: true },
    { prop: 'zcqsrq', label: '支出起始日期', sortable: true },
    { prop: 'zcjzrq', label: '支出截至日期', sortable: true },
    { prop: 'dxsqs', label: '核对对象授权书', fixedWidth: 270, sortable: true },
    { prop: 'cxsj', label: '查询时间', sortable: true },
    { prop: 'dxsqsqmz', label: '核对对象授权书签名值', fixedWidth: 210, sortable: true },
    { prop: 'dxsqsmy', label: '核对对象授权书密钥', fixedWidth: 260, sortable: true },
    { prop: 'submitBy', label: '提交人', fixedWidth: 210, sortable: true },
    { prop: 'submitTime', label: '提交时间', fixedWidth: 210, sortable: true },
    { prop: 'approveBy', label: '审核人', fixedWidth: 260, sortable: true },
    { prop: 'approveTime', label: '审核时间', fixedWidth: 260, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 220,
        minWidth: 220,
        fixed: 'right',
    },
]
// 弹框展示的主数据信息
export const parentsFormItems: FormItemInfo[] = [

    {
        prop: 'sqbh',
        label: '申请唯一号',
        labelWidth: 150,
        inputType: {
            tag: "input",
            disabled: true
        },
    },
    {
        prop: 'hdbh',
        label: '核对编号',
        labelWidth: 150,
        inputType: {
            tag: "input",
            disabled: true
        },
    },
    {
        prop: 'hddxbh',
        label: '核对对象编号',
        labelWidth: 150,
        inputType: {
            tag: "input",
            disabled: true
        },
    },
    {
        prop: 'xm',
        label: '姓名',
        labelWidth: 150,
        inputType: {
            tag: "input",
            disabled: true
        },
    },
    {
        prop: 'zjlx',
        label: '证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'szmz_zjlx',
            disabled: true
        },
    },
    {
        prop: 'zjhm',
        label: '证件号码',
        labelWidth: 150,
        inputType: {
            tag: "input",
            disabled: true
        },
    },
    {
        prop: 'hdqqzylx',
        label: '核对请求资源类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'szmz_qqzylx',
            disabled: true
        },
    },
    {
        prop: 'qqsj',
        label: '核对请求时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-picker',
            disabled: true
        },
    }, {
        prop: 'srhdqsrq',
        label: '可支配收入核定起始日期',
        labelWidth: 150,
        inputType: {
            tag: 'date-picker',
            disabled: true
        },
    }, {
        prop: 'srhdjzrq',
        label: '可支配收入核定截止日期',
        labelWidth: 150,
        inputType: {
            tag: 'date-picker',
            disabled: true
        },
    },
    {
        prop: 'cchdrq',
        label: '财产核定日期',
        labelWidth: 150,
        inputType: {
            tag: 'date-picker',
            disabled: true
        },
    },
    {
        prop: 'dezcydz',
        label: '大额支出约定值',
        labelWidth: 150,
        inputType: {
            tag: "input",
            disabled: true
        },
    },
    {
        prop: 'zcqsrq',
        label: '支出起始日期',
        labelWidth: 150,
        inputType: {
            tag: 'date-picker',
            disabled: true
        },
    },
    {
        prop: 'zcjzrq',
        label: '支出截止日期',
        labelWidth: 150,
        inputType: {
            tag: 'date-picker',
            disabled: true
        },
    },
    {
        prop: 'dxsqs',
        label: '核对对象授权书',
        labelWidth: 150,
        inputType: {
            tag: "input",
            disabled: true
        },
    },
    {
        prop: 'cxsj', label: '查询时间', inputType: { tag: 'date-picker', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD' }

    },
    {
        prop: 'state',
        label: '用户查询状态',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'szmz_yhcxzt',
            disabled: false
        },
    },
]
//银行存款（含外汇）信息明细表
export const columns00401: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'yhdm', label: '银行代码' },
    { prop: 'yhmc', label: '银行名称' },
    { prop: 'khzh', label: '客户账号', fixedWidth: 180 },
    { prop: 'zhye', label: '账户余额' },
    { prop: 'departmentCode', label: '部门编码' },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
//银行理财信息明细
export const columns00402: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'yhdm', label: '银行代码' },
    { prop: 'yhmc', label: '银行名称' },
    { prop: 'zh', label: '理财账号', fixedWidth: 180 },
    { prop: 'lczsz', label: '理财总市值' },
    { prop: 'departmentCode', label: '部门编码' },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
//银行贵金属信息明细
export const columns00403: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'yhdm', label: '银行代码' },
    { prop: 'yhmc', label: '银行名称' },
    { prop: 'gjszh', label: '贵金属账/卡号', fixedWidth: 180 },
    { prop: 'gjszsz', label: '贵金属总市值' },
    { prop: 'departmentCode', label: '部门编码' },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 银行债券信息明细表
export const columns00404: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'yhdm', label: '银行代码' },
    { prop: 'yhmc', label: '银行名称' },
    { prop: 'zqzh', label: '债券账号', fixedWidth: 180 },
    { prop: 'zqzjz', label: '债券总价值' },
    { prop: 'departmentCode', label: '部门编码' },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 银行利息信息（包括活期、定期等结息）明细表
export const columns00405: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'yhdm', label: '银行代码' },
    { prop: 'yhmc', label: '银行名称' },
    { prop: 'khzh', label: '客户账号', fixedWidth: 180 },
    { prop: 'jxrq', label: '结息日期', format: "YYYY-MM-DD HH:mm:ss" },
    { prop: 'lxje', label: '利息金额' },
    { prop: 'departmentCode', label: '部门编码' },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 银行大额支出信息明细表
export const columns00406: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'yhdm', label: '银行代码' },
    { prop: 'yhmc', label: '银行名称' },
    { prop: 'zcrq', label: '支出日期', fixedWidth: 180 },
    { prop: 'yhzh', label: '银行卡号/存折号' },
    { prop: 'zcje', label: '支出金额' },
    { prop: 'zczy', label: '支出摘要' },
    { prop: 'zcbz', label: '支出备注' },
    { prop: 'departmentCode', label: '部门编码' },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
//银行存款（含外汇）信息明细表
export const formItem00401: FormItemInfo[] = [
    { prop: 'yhdm', label: '银行代码', extra: { span: 24 } },
    { prop: 'yhmc', label: '银行名称', extra: { span: 24 } },
    { prop: 'khzh', label: '客户账号', extra: { span: 24 } },
    { prop: 'zhye', label: '账户余额', inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, extra: { span: 24 } },
    { prop: 'departmentCode', label: '部门编码', extra: { span: 24 } },
]
//银行理财信息明细
export const formItem00402: FormItemInfo[] = [

    { prop: 'yhdm', label: '银行代码', extra: { span: 24 } },
    { prop: 'yhmc', label: '银行名称', extra: { span: 24 } },
    { prop: 'zh', label: '理财账号', extra: { span: 24 } },
    { prop: 'lczsz', label: '理财总市值', inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, extra: { span: 24 } },
    { prop: 'departmentCode', label: '部门编码', extra: { span: 24 } },


]
//银行贵金属信息明细
export const formItem00403: FormItemInfo[] = [
    { prop: 'yhdm', label: '银行代码', extra: { span: 24 } },
    { prop: 'yhmc', label: '银行名称', extra: { span: 24 } },
    { prop: 'gjszh', label: '贵金属账/卡号', extra: { span: 24 } },
    { prop: 'gjszsz', label: '贵金属总市值', inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, extra: { span: 24 } },
    { prop: 'departmentCode', label: '部门编码', extra: { span: 24 } },

]
// 银行债券信息明细表
export const formItem00404: FormItemInfo[] = [

    { prop: 'yhdm', label: '银行代码', extra: { span: 24 } },
    { prop: 'yhmc', label: '银行名称', extra: { span: 24 } },
    { prop: 'zqzh', label: '债券账号', extra: { span: 24 } },
    { prop: 'zqzjz', label: '债券总价值', inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, extra: { span: 24 } },
    { prop: 'departmentCode', label: '部门编码', extra: { span: 24 } },

]
// 银行利息信息（包括活期、定期等结息）明细表
export const formItem00405: FormItemInfo[] = [

    { prop: 'yhdm', label: '银行代码', extra: { span: 24 } },
    { prop: 'yhmc', label: '银行名称', extra: { span: 24 } },
    { prop: 'khzh', label: '客户账号', extra: { span: 24 } },
    {
        prop: 'jxrq', label: '结息日期', inputType: { tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD' }
        , extra: { span: 24 }
    },

    { prop: 'lxje', label: '利息金额', inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, extra: { span: 24 } },
    { prop: 'departmentCode', label: '部门编码', extra: { span: 24 } },

]
// 银行大额支出信息明细表
export const formItem00406: FormItemInfo[] = [
    { prop: 'yhdm', label: '银行代码', extra: { span: 24 } },
    { prop: 'yhmc', label: '银行名称', extra: { span: 24 } },
    { prop: 'zcrq', label: '支出日期', inputType: 'date-picker', extra: { span: 24 } },
    { prop: 'yhzh', label: '银行卡号/存折号', extra: { span: 24 } },
    { prop: 'zcje', label: '支出金额', inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, extra: { span: 24 } },
    { prop: 'zczy', label: '支出摘要', extra: { span: 24 } },
    { prop: 'zcbz', label: '支出备注', extra: { span: 24 } },
    { prop: 'departmentCode', label: '部门编码', extra: { span: 24 } },

]

// 高级查询
export const advancedQueryItems: SearchFormField[] = [
    { value: 'zjhm', label: '证件号码', inputType: { tag: 'input' } },

    { value: 'sqbh', label: '申请唯一号', inputType: { tag: 'input' } },
    { value: 'srhdqsrq', label: '可支配收入核定起始日期', inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
    { value: 'srhdjzrq', label: '可支配收入核定截至日期', inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
    { value: 'cchdrq', label: '财产核定日期', inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
    { value: 'dezcydz', label: '大额支出约定值', inputType: { tag: 'input' } },
    { value: 'zcqsrq', label: '支出起始日期', inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
    { value: 'zcjzrq', label: '支出截至日期', inputType: {tag: 'date-input', type: 'date', format: 'YYYY-MM-DD', valueFormat: 'YYYY-MM-DD HH:mm:ss'} },
    { value: 'dxsqs', label: '核对对象授权书', inputType: { tag: 'input' } },
    { value: 'cxsj', label: '查询时间', inputType: { tag: 'input' } },
    { value: 'dxsqsqmz', label: '核对对象授权书签名值', inputType: { tag: 'input' } },
    { value: 'dxsqsmy', label: '核对对象授权书密钥', inputType: { tag: 'input' } },
]

