import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: "id", type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'jyt_status', width: 130, sortable: true},
    {prop: 'ssyh', label: '所属银行', width: 140, dictFormatKey: 'bank', sortable: true},
    {prop: 'yhkh', label: '银行卡号', width: 140, sortable: true},
    {prop: 'sjly', label: '数据来源', width: 140, sortable: true},
    {prop: 'yjsj', label: '预警时间', width: 190, sortable: true},
    {prop: 'xfrq', label: '下发日期', width: 190, sortable: true},
    {prop: 'xfsj', label: '下发时间', width: 190, sortable: true},
    {prop: 'dataTime', label: '数据日期', width: 190, sortable: true},
    {prop: 'disposeBy', label: '处理人', width: 80, sortable: true},
    {prop: 'disposeTime', label: '处理日期', width: 190, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 230,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'jyt_status',}
    },
    {prop: 'ssyh', label: '所属银行', labelWidth: 80, inputType: 'input'},
    {prop: 'yhkh', label: '银行卡号', labelWidth: 80, inputType: 'input'},
    {prop: 'sjly', label: '数据来源', labelWidth: 80, inputType: 'input'},
    {prop: 'yjsj', label: '预警时间', labelWidth: 80, inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD HH:mm:ss'},},
    {prop: 'xfrq', label: '下发日期', labelWidth: 80, inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'}},
    {prop: 'xfsj', label: '下发时间', labelWidth: 80, inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD HH:mm:ss'}},

    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
]

export const formItems: FormItemInfo[] = [
    {prop: 'ssyh', label: '所属银行', labelWidth: 80, inputType: {tag: 'select', options: 'bank',}},
    {prop: 'yhkh', label: '银行卡号', labelWidth: 80, inputType: 'input'},
    {prop: 'sjly', label: '数据来源', labelWidth: 80, inputType: 'input'},
    {prop: 'yjsj', label: '预警时间', labelWidth: 80, inputType: 'input'},
    {prop: 'xfrq', label: '下发日期', labelWidth: 80, inputType: 'input'},
    {prop: 'xfsj', label: '下发时间', labelWidth: 80, inputType: 'input'},
    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
    {
        prop: 'status',
        label: '状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'jyt_status',}
    },
]

export default {
    columns,
    searchFormItems,
    formItems
}
