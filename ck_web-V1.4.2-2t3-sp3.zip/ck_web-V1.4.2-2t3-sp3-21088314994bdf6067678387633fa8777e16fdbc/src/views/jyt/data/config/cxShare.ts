import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'jyt_status', width: 130, sortable: true},
    {prop: 'name', label: '姓名', width: 190, sortable: true},
    {prop: 'phone', label: '电话', width: 140, sortable: true},
    {prop: 'documentNumber', label: '证件号', width: 140, sortable: true},
    {prop: 'dataTime', label: '数据日期', width: 190, sortable: true},
    {prop: 'disposeBy', label: '处理人', width: 80, sortable: true},
    {prop: 'disposeTime', label: '处理日期', width: 190, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 230,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'jyt_status',}
    },
    {prop: 'name', label: '姓名', labelWidth: 80, inputType: 'input'},
    {prop: 'phone', label: '电话', labelWidth: 80, inputType: 'input'},
    {prop: 'documentNumber', label: '证件号', labelWidth: 80, inputType: 'input'},

    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
]

export const formItems: FormItemInfo[] = [
    {prop: 'name', label: '姓名', labelWidth: 80, inputType: 'input'},
    {prop: 'phone', label: '电话', labelWidth: 80, inputType: 'input'},
    {prop: 'documentNumber', label: '证件号', labelWidth: 80, inputType: 'input'},
    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
    {
        prop: 'status',
        label: '状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'jyt_status',}
    },
]

export default {
    columns,
    searchFormItems,
    formItems
}
