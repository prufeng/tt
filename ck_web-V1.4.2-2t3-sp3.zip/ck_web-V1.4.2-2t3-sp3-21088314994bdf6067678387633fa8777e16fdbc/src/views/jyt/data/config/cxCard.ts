import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'jyt_status', width: 130, sortable: true},
    {prop: 'ajbh', label: '案件编号', width: 140, sortable: true},
    {prop: 'yhkh', label: '银行卡号', width: 140, sortable: true},
    {prop: 'xfrq', label: '下发日期', width: 190, sortable: true},
    {prop: 'sayy', label: '涉案原因', width: 400, sortable: true},
    {prop: 'lxbq', label: '类型标签', width: 80, dictFormatKey: 'lxbq', sortable: true},
    {prop: 'dataTime', label: '数据日期', width: 190, sortable: true},
    {prop: 'disposeBy', label: '处理人', width: 80, sortable: true},
    {prop: 'disposeTime', label: '处理日期', width: 190, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 230,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'jyt_status',}
    },
    {prop: 'ajbh', label: '案件编号', labelWidth: 80, inputType: 'input'},
    {prop: 'yhkh', label: '银行卡号', labelWidth: 80, inputType: 'input'},
    {prop: 'xfrq', label: '下发日期', labelWidth: 80, inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},},
    {prop: 'sayy', label: '涉案原因', labelWidth: 80, inputType: 'input'},
    {prop: 'lxbq', label: '类型标签', labelWidth: 80, inputType:  {tag: 'select', options: 'lxbq',}},
    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
]

export const formItems: FormItemInfo[] = [
    {prop: 'ajbh', label: '案件编号', labelWidth: 80, inputType: 'input'},
    {prop: 'yhkh', label: '银行卡号', labelWidth: 80, inputType: 'input'},
    {prop: 'xfrq', label: '下发日期', labelWidth: 80, inputType: 'input'},
    {prop: 'sayy', label: '涉案原因', labelWidth: 80, inputType: 'input'},
    {prop: 'lxbq', label: '类型标签', labelWidth: 80, inputType:  {tag: 'select', options: 'lxbq',}},
    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
    {
        prop: 'status',
        label: '状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'jyt_status',}
    },
]

export default {
    columns,
    searchFormItems,
    formItems
}
