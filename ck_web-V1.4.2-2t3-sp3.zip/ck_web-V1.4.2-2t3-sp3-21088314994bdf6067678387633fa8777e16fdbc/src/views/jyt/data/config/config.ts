import jytCxCardConfig from "./cxCard";
import jytCxFraudConfig from "./cxFraud";
import jytCxShareConfig from "./cxShare";
import {ButtonInfo} from "riking-ui";

const configs = {
    jytCxCardConfig,
    jytCxFraudConfig,
    jytCxShareConfig
}

export const getConfigs = (routeName) => {
    const config = configs[`${routeName}Config`];
    return config;
}

export const buttons: ButtonInfo[] = [
    {
        key: 'batchUpdate',
        label: '批量处理',
        tag: 'button',
        type: 'primary',
        labelWidth: 50,
        icon: 'icon_update',
        handler: async () => {
        }
    },
    {
        key: 'mock',
        label: '模拟接口',
        tag: 'button',
        type: 'primary',
        labelWidth: 50,
        icon: 'icon_add',
        handler: async () => {
        }
    }
]

export const rowButtons: ButtonInfo[] = [
    {
        key: 'view', label: '查看', tag: 'button', type: 'primary',
        handler: () => {
        }
    },
]

export const showMessage = (result) => {
    const {totalNum, succNum, failNum, msg} = result.data;
    const str = msg + "成功" + succNum + "条" + ", 失败" + failNum + "条！"
    if (failNum > 0) {
        ElMessage.error({ message: str+'失败原因：状态不匹配（只能批量处理待处理数据）', grouping: true, duration: 0, showClose: true })
    } else {
        ElMessage.success(str)
    }
}

export default configs;

