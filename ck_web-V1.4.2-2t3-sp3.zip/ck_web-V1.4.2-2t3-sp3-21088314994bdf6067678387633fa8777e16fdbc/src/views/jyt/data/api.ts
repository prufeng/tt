import {Pagination, RS} from 'riking-ui'
import service from '@/utils/request'
import {getCommonParams, getRequestClassificationCode, getSubSystem} from "@/utils/subSystem";

export function list(routeName: string, data = {}, paging: Pagination): Promise<RS> {
    return service({
        url: `/${routeName}/list`,
        method: 'POST',
        data,
        params: {currentPage: paging.currentPage, pageSize: paging.pageSize}
    })
}

export function updateByIds(routeName: string, ids = []): Promise<RS> {
    return service({
        url: `/${routeName}/updateByIds`,
        method: 'POST',
        data: ids,
    });
}

/**
 * 生成模拟数据
 */
export function getMockData(routeName: string): Promise<RS> {
    return service({
        url: `/${routeName}/getMockData`,
        method: 'POST',
        params: {apiName: routeName + 'Api'}
    });
}
/**
 * 导出
 */
export function exportExcel(routeName: string, ids:any,data = {},branchCodeStr: string): Promise<RS> {
    return service({
        url: `/${routeName}/exportExcel`,
        method: 'POST',
        data,
        params: {ids,branchCodeStr, ...getCommonParams()},
        responseType: 'blob'
    })
}
// export function listOne(reportCode: string, params = {}): Promise<RS> {
//     return service({
//         url: `/${reportCode}/listOne`,
//         method: 'GET',
//         params: {...params, ...getCommonParams()},
//     })
// }
//
// export function listFldm(reportCode: string): Promise<RS> {
//     return service({
//         url: `/dict/listFldmByRequestClassificationCode`,
//         method: 'GET',
//         params: {subSystem: getSubSystem() ,requestClassificationCode :reportCode}
//     })
// }
//

// export function exportExcel(reportCode: string, ids:any,data = {},branchCodeStr: string): Promise<RS> {
//     return service({
//         url: `/${reportCode}/exportExcel`,
//         method: 'POST',
//         data,
//         params: {ids,branchCodeStr, ...getCommonParams()},
//         responseType: 'blob'
//     })
// }
//
//
// export function impZip(reportCode: string, data = {}): Promise<RS> {
//     return service({
//         url: `/${reportCode}/imp`,
//         method: 'POST',
//         data,
//         params: getCommonParams(),
//         headers: {'Content-Type': 'multipart/form-data',}
//     })
// }
// export function checkData(reportCode: string,data = {}): Promise<RS> {
//     return service({
//         url: `/${reportCode}/checkData`,
//         method: 'POST',
//         data,
//         params: getCommonParams(),
//         headers: {'Content-Type': 'multipart/form-data',}
//     })
// }
// export function getPdf(reportCode: string, data = {}): Promise<RS> {
//     return service({
//         url: `/${reportCode}/getPdf`,
//         method: 'POST',
//         data,
//         params: {},
//     })
// }
// export function getImage(reportCode: string, data = {}): Promise<RS> {
//     return service({
//         url: `/${reportCode}/getImage`,
//         method: 'POST',
//         data,
//         params: {},
//     })
// }
// export function getXml(reportCode: string, data = {}): Promise<RS> {
//     return service({
//         url: `/${reportCode}/getXml`,
//         method: 'POST',
//         data,
//         params: {},
//     })
// }
// export function downloadZip(reportCode: string, ids:any): Promise<RS> {
//     return service({
//         url: `/${reportCode}/downloadZip`,
//         method: 'POST',
//         responseType : 'blob',
//         params: {ids},
//     })
// }
//
// export function del(reportCode: string, ids: any): Promise<RS> {
//     return service({
//         url: `/${reportCode}/del`,
//         method: 'POST',
//         params: {subSystem: getSubSystem(), ids},
//     })
// }
// export function update(reportCode: string,data:any): Promise<RS> {
//     return service({
//         url: `/${reportCode}/update`,
//         method: 'POST',
//         data,
//         params: {subSystem: getSubSystem()},
//     })
// }
// export function save(reportCode: string,data:any): Promise<RS> {
//     return service({
//         url: `/${reportCode}/save`,
//         method: 'POST',
//         data,
//         params: {subSystem: getSubSystem()},
//     })
// }
//
// export function upload(reportCode:string,qqdbs:string,rwlsh:string,data = {}): Promise<RS> {
//     return service({
//         url: `/${reportCode}/upload`,
//         method: 'POST',
//         data,
//         params: {qqdbs,rwlsh,subSystem:getSubSystem()},
//         headers: {'Content-Type': 'multipart/form-data',}
//     })
// }
