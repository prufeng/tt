<template>
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" @closed="closed" :close-on-click-modal="false"
             class="rk-dialog-default" destroy-on-close>
    <rk-detail-form ref="formRef" v-model="form" :form-items="formItems" :disabled="dialogData.formDisabled">

    </rk-detail-form>
    <template #footer>
               <span class="dialog-footer">
                 <el-button @click="save" v-if="showSaveBtn" type="primary">保存</el-button>
                 <el-button @click="closed"> 取消 </el-button>
               </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import {DialogForm, RkFormInstance, useDialogForm} from "riking-ui";
import {ElMessage} from "element-plus";

const dialogForm: DialogForm<RkFormInstance, any> = useDialogForm('formRef')
const {dialogData, open, close, closed, form, nameRef: formRef} = dialogForm

defineExpose({open})

const emit = defineEmits(['onClosed'])
const props = defineProps(['routeName', 'formItems', 'branchCode']);
const {routeName, formItems, branchCode} = props;

onMounted(() => {
  console.log("mountedDetail")
})

watch(()=> dialogData.visible, () => {
  if(dialogData.visible == false) {
    emit('onClosed')
  }
})


//子表所需代码
// const save = async () => {
//   const valid = await formRef.value?.asyncValidate();
//   if (!valid) {
//     return;
//   }
//   const data = toRaw(form.value);
//
//   // await subUpdateData(reportCode, data, reportCode);
//   close();
//   closed();
//   ElMessage.success("保存成功");
//   // handleClick(undefined);
//
// }


const showSaveBtn = computed(() => {
  return dialogData.title.includes('查看') ? false : true;
})

</script>

<style scoped>

</style>