import {FormItemInfo} from "riking-ui";


/*export const formItems: FormItemInfo[] = [
    {
        prop: 'appId',
        label: '产品服务ID',
        inputType: 'input',
        rules: [{max:32 , message: '产品服务ID长度不可超过32'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'appKey',
        label: '客户端私钥',
        inputType: 'input',
        rules: [{max:32 , message: '客户端私钥长度不可超过32'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'userId',
        label: '客户端调用者身份标识',
        inputType: 'input',
        rules: [{max:32 , message: '客户端调用者身份标识长度不可超过32'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'orgCusSendId',
        label: '流水号',
        inputType: 'input',
        rules: [{max: 32, message: '流水号长度不可超过32'}, {required: true, message: '流水号不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'aesKeyEncrypt',
        label: '加密报文密钥',
        inputType: 'input',
        rules: [{max:32 , message: '加密报文密钥长度不可超过32'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'aesKeyDecrypt',
        label: '解密报文密钥',
        inputType: 'input',
        rules: [{max: 32, message: '解密报文密钥长度不可超过32'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'urlCard',
        label: '获取涉案一级卡数据',
        inputType: 'input',
        rules: [{max:255 , message: '获取涉案一级卡数据长度不可超过255'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'paramUrlCard',
        label: '日期参数',
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'enableParamUrlCard',
        label: '是否启用日期参数',
        inputType: {tag: 'select',options: 'enableParamUrl'},
        rules: [{max:1 , message: '是否启用日期参数长度不可超过1'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'urlShare',
        label: '获取涉案卡开户名单共享信息',
        inputType: 'input',
        rules: [{max:255 , message: '获取涉案卡开户名单共享信息长度不可超过255'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'urlFraud',
        label: '获取涉诈收款卡数据',
        inputType: 'input',
        rules: [{max:255 , message: '获取涉诈收款卡数据长度不可超过255'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'paramUrlFraud',
        label: '日期参数',
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'enableParamUrlFraud',
        label: '是否启用日期参数',
        inputType: {tag: 'select',options: 'enableParamUrl'},
        rules: [{max:1 , message: '是否启用日期参数长度不可超过1'}, {required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'pageLimit',
        label: '请求行数（最大10万条）',
        inputType:  { tag: 'input-number', controlsPosition:"right",precision:"0"},
        rules: [{required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'page',
        label: '页码',
        inputType:  { tag: 'input-number', controlsPosition:"right",precision:"0"},
        rules: [{required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'startTime',
        label: '获取涉案卡开户名单共享信息开始时间',
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [{required: false, message: '不能为空'}],
        extra: {span: 12}
    },
    {
        prop: 'endTime',
        label: '获取涉案卡开户名单共享信息结束时间',
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [{required: false, message: '不能为空'}],
        extra: {span: 12}
    }
]*/

export default {
    // formItems
}
