import jytConfig from "./sysConfig";

const configs = {
    jytConfig,
}

export const getConfigs = (routeName) => {
    const config = configs[`${routeName}`];
    return config;
}

export default configs;

