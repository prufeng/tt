<template>
  <!--  <el-card>
      <rk-detail-form ref="configFormRef" v-model="configForm" :form-items="formItems"/>
      <div class="onSaveButton">
        <el-button type="warning"  @click="search">重置</el-button>
        <el-button type="primary"  @click="save">保存</el-button>
      </div>
    </el-card>-->
  <el-card>
    <el-form
        ref="configFormRef"
        :model="configForm"
        :label-position="labelPosition"
        label-width="auto"
    >
      <el-row>
        <el-col :span="12">
          <el-form-item label="产品服务ID" prop="appId"
                        :rules="[{max:32 , message: '产品服务ID长度不可超过32'}, {required: false, message: '产品服务ID不能为空'}]">
            <el-input v-model="configForm.appId"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="客户端私钥" prop="appKey"
                        :rules="[{max:32 , message: '客户端私钥长度不可超过32'}, {required: false, message: '客户端私钥不能为空'}]">
            <el-input v-model="configForm.appKey"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="客户端调用者身份标识" prop="userId"
                        :rules="[{max:32 , message: '客户端调用者身份标识长度不可超过32'}, {required: false, message: '客户端调用者身份标识不能为空'}]">
            <el-input v-model="configForm.userId"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="流水号" prop="orgCusSendId"
                        :rules="[{max:32 , message: '流水号长度不可超过32'}, {required: true, message: '流水号不能为空'}]">
            <el-input v-model="configForm.orgCusSendId"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="加密报文密钥" prop="aesKeyEncrypt"
                        :rules="[{max:32 , message: '加密报文密钥长度不可超过32'}, {required: false, message: '加密报文密钥不能为空'}]">
            <el-input v-model="configForm.aesKeyEncrypt"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="解密报文密钥" prop="aesKeyDecrypt"
                        :rules="[{max:32 , message: '解密报文密钥长度不可超过32'}, {required: false, message: '解密报文密钥不能为空'}]">
            <el-input v-model="configForm.aesKeyDecrypt"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="匹配卡号前六位，用逗号分隔" prop="yhkhSix"
                        :rules="[{required: false, message: '匹配卡号前六位不能为空'}]">
            <el-input v-model="configForm.yhkhSix" type="textarea"/>
          </el-form-item>
        </el-col>
      </el-row>
      <el-divider content-position="left">
        <div class="divider-label">获取涉案一级卡数据接口配置</div>
      </el-divider>
      <el-col :span="12">
        <el-form-item label="获取涉案一级卡数据" prop="urlCard"
                      :rules="[{max:255 , message: '获取涉案一级卡数据长度不可超过255'}, {required: false, message: '获取涉案一级卡数据不能为空'}]">
          <el-input v-model="configForm.urlCard"/>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="日期参数" prop="paramUrlCard" :rules="[{required: false, message: '日期参数不能为空'}]">
          <el-date-picker v-model="configForm.paramUrlCard" type="date" valueFormat="YYYY-MM-DD" style="width: 1000px"/>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="是否启用日期参数" prop="enableParamUrlCard"
                      :rules="[{max:1 , message: '是否启用日期参数长度不可超过1'}, {required: false, message: '是否启用日期参数不能为空'}]">
          <el-select v-model="configForm.enableParamUrlCard" style="width: 1000px">
            <el-option v-for="dict in dictData.enableParamUrl" :key="dict.value" :label="dict.label"
                       :value="dict.value"/>
          </el-select>
        </el-form-item>
      </el-col>
      <el-divider content-position="left">
        <div class="divider-label">获取涉案卡开户名单共享信息接口配置</div>
      </el-divider>
      <el-col :span="12">
        <el-form-item label="获取涉案卡开户名单共享信息" prop="urlShare"
                      :rules="[{max:255 , message: '获取涉案卡开户名单共享信息长度不可超过255'}, {required: false, message: '获取涉案卡开户名单共享信息不能为空'}]">
          <el-input v-model="configForm.urlShare"/>
        </el-form-item>
      </el-col>
      <el-row>
        <el-col :span="12">
          <el-form-item label="开始时间" prop="startTime"
                        :rules="[{required: true, message: '开始时间不能为空'}]">
            <el-date-picker v-model="configForm.startTime" type="datetime" valueFormat="YYYY-MM-DD HH:mm:ss" style="width: 1000px"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="结束时间" prop="endTime"
                        :rules="[{required: true, message: '结束时间不能为空'}]">
            <el-date-picker v-model="configForm.endTime" type="datetime" valueFormat="YYYY-MM-DD HH:mm:ss" style="width: 1000px"/>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <el-form-item label="请求行数（最大10万条）" prop="pageLimit"
                        :rules="[{required: false, message: '请求行数（最大10万条）不能为空'}]">
            <el-input-number v-model="configForm.pageLimit" class="mx-4" :min="0" :max="100000"
                             controls-position="right" style="width: 1000px"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="页码" prop="page" :rules="[{required: false, message: '页面不能为空'}]">
            <el-input-number v-model="configForm.page" class="mx-4" :min="0" controls-position="right"
                             style="width: 1000px"
            />
          </el-form-item>
        </el-col>
      </el-row>
      <el-divider content-position="left">
        <div class="divider-label">获取涉诈收款卡数据接口配置</div>
      </el-divider>
      <el-col :span="12">
        <el-form-item label="获取涉诈收款卡数据" prop="urlFraud"
                      :rules="[{max: 255, message: '获取涉诈收款卡数据长度不可超过255'}, {required: false, message: '获取涉诈收款卡数据不能为空'}]">
          <el-input v-model="configForm.urlFraud"/>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="日期参数" prop="paramUrlFraud" :rules="[{required: false, message: '日期参数不能为空'}]">
          <el-date-picker v-model="configForm.paramUrlFraud" type="date" valueFormat="YYYY-MM-DD" style="width: 1000px"/>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="是否启用日期参数" prop="enableParamUrlFraud"
                      :rules="[{required: false, message: '是否启用日期参数不能为空'}]">
          <el-select v-model="configForm.enableParamUrlFraud" style="width: 1000px">
            <el-option v-for="dict in dictData.enableParamUrl" :key="dict.value" :label="dict.label"
                       :value="dict.value"/>
          </el-select>
        </el-form-item>
      </el-col>
    </el-form>
    <div class="onSaveButton">
      <el-button type="warning" @click="search">重置</el-button>
      <el-button type="primary" @click="save(configFormRef)">保存</el-button>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import {ref} from "vue";
import {RkDetailForm} from "riking-ui";
import {getRouteName} from "@/utils/utils";
import {getConfigs} from './config/config';
import {list, updateById} from './api';
import dictData from '../../../hooks/useDicts'
import {useDict} from "riking-layout";
import {ElButton, ElMessage, FormInstance} from "element-plus";
import type {FormProps} from 'element-plus'

const route = useRoute();
const routeName = getRouteName(route);
// const {formItems} = getConfigs(routeName);
const labelPosition = ref<FormProps['labelPosition']>('right')
const configFormRef = ref()
let configForm = reactive({
  appId: '',
  appKey: '',
  userId: '',
  orgCusSendId: '',
  aesKeyEncrypt: '',
  aesKeyDecrypt: '',
  yhkhSix: '',
  urlCard: '',
  paramUrlCard: '',
  enableParamUrlCard: '',
  urlShare: '',
  urlFraud: '',
  paramUrlFraud: '',
  enableParamUrlFraud: '',
  pageLimit: '',
  page: '',
  startTime: '',
  endTime: '',
})

useDict([], [], {
  ...dictData
})

onMounted(() => search())

/**
 * 查询
 */
const search = async () => {
  const result = await list(routeName);
  Object.assign(configForm, result.data);
}

const save = async (formEl: FormInstance | undefined) => {
  if (!formEl) return
  await formEl.validate((valid) => {
    if (valid) {
      try {
        updateById(routeName, configForm);
      } finally {
        ElMessage.success('修改成功')
      }
    } else {
      console.log('error submit!')
      return false
    }
  })
}
/*const save = async () => {
  const valid = await configFormRef.value?.asyncValidate();
  if (!valid){
    return
  }
  try {
    await updateById(routeName,configForm.value);
  } finally {
    ElMessage.success('修改成功')
  }
}*/


</script>

<style scoped>
.onSaveButton {
  display: flex;
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中（若需要）*/
}

.divider-label {
  font-size: 12px;
}

</style>

