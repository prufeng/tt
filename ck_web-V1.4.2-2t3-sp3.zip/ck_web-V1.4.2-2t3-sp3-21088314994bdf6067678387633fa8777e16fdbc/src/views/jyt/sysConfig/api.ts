import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(routeName: string): Promise<RS> {
    return service({
        url: `/${routeName}/list`,
        method: 'POST',
    })
}

export function updateById(routeName: string, data={}): Promise<RS> {
    return service({
        url: `/${routeName}/updateById`,
        method: 'POST',
        data
    });
}

