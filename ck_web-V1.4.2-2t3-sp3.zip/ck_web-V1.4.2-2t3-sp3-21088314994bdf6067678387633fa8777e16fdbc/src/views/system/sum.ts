/**
 * 请求功能编号、反馈功能编号映射关系
 */
const reportCodeMap = new Map()
reportCodeMap.set('ps201', 'ps101')
reportCodeMap.set('ps202', 'ps102')
reportCodeMap.set('ps203', 'ps103')
reportCodeMap.set('ps204', 'ps104')
reportCodeMap.set('ps205', 'ps105')
reportCodeMap.set('ps206', 'ps106')
reportCodeMap.set('ps207', 'ps104')

/**
 * 路由 - 名称映射关系
 */
export const REPORT_NAME_MAPPING = new Map();
REPORT_NAME_MAPPING.set('ps201', '账户信息查询')
REPORT_NAME_MAPPING.set('ps203', '账户信息和交易明细综合查询反馈')
REPORT_NAME_MAPPING.set('ps204', '动态查询反馈')
REPORT_NAME_MAPPING.set('ps205', '冻结/续冻/解冻')
REPORT_NAME_MAPPING.set('ps206', '紧急止付/解除止付')
REPORT_NAME_MAPPING.set('ps207', '动态查询执行回执')
REPORT_NAME_MAPPING.set('psFkAccount', '账户信息')
REPORT_NAME_MAPPING.set('psFkMeasure', '强制措施')
REPORT_NAME_MAPPING.set('psFkPriority', '共有权/优先权')
REPORT_NAME_MAPPING.set('psFkSubAccount', '关联子账户')
REPORT_NAME_MAPPING.set('psFkTransaction', '交易明细')
REPORT_NAME_MAPPING.set('psFkFreezeDetail', '冻结/续冻/解冻明细')
REPORT_NAME_MAPPING.set('psFkPaymentDetail', '紧急止付/解除止付明细')
REPORT_NAME_MAPPING.set('psFkFinancial', '金融资产信息')
REPORT_NAME_MAPPING.set('psFkFinancialMeasure', '金融资产强制措施')
// REPORT_NAME_MAPPING.set('psFkDynamicReceipt', '动态查询请求回执')

export const getKey = (value: string) => {
    for (const [key, val] of REPORT_NAME_MAPPING) {
        if (value === val) {
            return key;
        }
    }
}

export const getValue = (key: string) => {
    return REPORT_NAME_MAPPING.get(key);
}

/**
 * 分类代码映射关系
 */
export const REPORT_NAME_FLDM = new Map();
REPORT_NAME_FLDM.set('SS01', '个人账户查询申请')
REPORT_NAME_FLDM.set('SS02', '对公账户查询申请')
REPORT_NAME_FLDM.set('SS03', '个人账户查询申请反馈')
REPORT_NAME_FLDM.set('SS04', '对公账户查询申请反馈')
REPORT_NAME_FLDM.set('SS06', '个人帐（卡）号查询申请')
REPORT_NAME_FLDM.set('SS05', '对公帐（卡）号查询申请')
REPORT_NAME_FLDM.set('SS07', '个人帐（卡）号查询申请反馈')
REPORT_NAME_FLDM.set('SS08', '对公帐（卡）号查询申请反馈')
REPORT_NAME_FLDM.set('SS09', '个人账户交易明细信息反馈')
REPORT_NAME_FLDM.set('SS10', '对公账户交易明细信息反馈')
REPORT_NAME_FLDM.set('SS11', '个人账户动态查询申请')
REPORT_NAME_FLDM.set('SS12', '对公账户动态查询申请')
REPORT_NAME_FLDM.set('SS13', '个人账户动态查询申请反馈')
REPORT_NAME_FLDM.set('SS14', '对公账户动态查询申请反馈')
REPORT_NAME_FLDM.set('SS15', '个人账户动态查询申请手机短信反馈')
REPORT_NAME_FLDM.set('SS16', '对公账户动态查询申请手机短信反馈')
REPORT_NAME_FLDM.set('SS17', '个人账户冻结/解冻/续冻/协助变更冻结 方式申请')
REPORT_NAME_FLDM.set('SS18', '对公账户冻结/解冻/续冻/协助变更冻结 方式申请')
REPORT_NAME_FLDM.set('SS19', '个人账户冻结/解冻/续冻/协助变更冻结 方式申请反馈')
REPORT_NAME_FLDM.set('SS20', '对公账户冻结/解冻/续冻/协助变更冻结 方式申请反馈')
REPORT_NAME_FLDM.set('SS21', '个人账户紧急止付申请')
REPORT_NAME_FLDM.set('SS22', '对公账户紧急止付申请')
REPORT_NAME_FLDM.set('SS23', '个人账户紧急止付申请反馈')
REPORT_NAME_FLDM.set('SS24', '对公账户紧急止付申请反馈')
REPORT_NAME_FLDM.set('LI25', '文书文件名称')
REPORT_NAME_FLDM.set('LI26', '申请人警官证')
REPORT_NAME_FLDM.set('LI27', '协查人警官证')
REPORT_NAME_FLDM.set('RR28', '请求接收回执信息文件')
REPORT_NAME_FLDM.set('RR29', '执行结束回执信息文件')

export default {
    reportCodeMap
}

export const setRequiredRule = (fields: [], required: boolean, formItems: []) => {
    const items = formItems.filter(item => fields.includes(item.prop));
    const rules = items.map(item => item.rules.find(item => item.required != undefined));
    rules.map(rule => {
        if(rule != undefined && rule.required != undefined) {
            rule.required = required
        }
    })
}

export const setRequiredRuleMessage = (fields: any[],ruleMessage: string, formItems: []) => {
    const items = formItems.filter(item => fields.includes(item.prop));
    const rules = items.map(item => item.rules.find(item => item.required != undefined));
    rules.map(rule => {
        if(rule != undefined && rule.required != undefined) {
            rule.message = ruleMessage
        }
    })
}
/**
 * 排除字段之外的其他字段都设置为false
 * @param excludeFields
 * @param formItems
 */
export const setRequiredRuleFalse = (excludeFields: [], formItems: []) => {
    // const items = formItems.filter(item => !excludeFields.includes(item.prop));
    // const rules = items.map(item => item.rules.find(item => item.required != undefined));
    // rules.map(rule => {
    //     if(rule != undefined && rule.required != undefined) {
    //         rule.required = false
    //     }
    // })

    formItems.map(item => {
        if(!excludeFields.includes(item.prop)) {
            item?.rules?.map(rule => {
                if(rule != undefined && rule.required != undefined) {
                    rule.required = false
                }
            })
        }
    });
}

export const isEmpty = (val) => {
    if(val === '' || val === null || val === undefined) {
        return true;
    }
    return false;
}

export const setDisabled = (field: string, disabled: boolean, formItems: []) => {
    const item = formItems.filter(item => field === item.prop);
    const inputType = item[0].inputType;
    if(inputType != undefined) {
        if (inputType.disabled != undefined) {
            inputType.disabled = disabled
        } else {
            inputType.disabled = disabled;
        }
    }
}