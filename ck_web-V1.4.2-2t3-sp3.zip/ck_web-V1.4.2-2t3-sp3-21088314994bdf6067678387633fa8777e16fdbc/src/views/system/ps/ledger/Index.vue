<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"
                    :form-items="searchFormItems" @search="search" :label-width="50"/>

<!--    <rk-page-table :columns="columns" :loading="loadingTable" :data="data" :pagination="page" @page-change="pageChange"-->
<!--                   @refresh="search"-->
<!--                   @selection-change="handleSelectionChange">-->

    <rk-page-table :columns="columns" :loading="loadingTable" :data="data"
                   @refresh="search" :pagination="page" @page-change="pageChange"
                   @selection-change="handleSelectionChange">
      <template #operations>
        <div style="display: flex; flex-direction: row">
<!--          <rk-button-group :buttons="getMainTableButtons()" :route-meta="$route.meta" max="8"/>-->
          <UpAndDown :exp="exp"/>
        </div>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link max="3"/>
      </template>

      <template #status="{ row }">
        <el-popover
            v-if="row.status === '6'"
            placement="bottom"
            title="审核不通过原因"
            :width="250"
            trigger="hover"
        >
          <p class="tipck">操作: 审核不通过</p>
          <p class="tipck">操作人: {{row.approveBy}}</p>
          <p class="tipck">操作时间: {{row.approveTime}}</p>
          <p class="tipck">备注: {{row.approveDesc}}</p>
          <template #reference>
            <el-button  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.status)
              }}</el-button>
          </template>
        </el-popover>
        <el-button v-else  link :type="getTagColor(row.status)"  >{{ dictFormatter(row.status, dictData.status) }}</el-button>
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed"
             :close-on-click-modal="false">
    <rk-detail-form ref="dialogFormRef" v-model="form" :disabled="dialogData.formDisabled" :form-items="formItems"/>

    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="审核" width="30%" draggable :append-to-body=true>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="auditPassData()">审核通过</el-button>
        <el-button type="danger" @click="()=>{msgDialog = true;msg =''}">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!--  </div>-->

  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog" title="不通过原因" width="30%" draggable :append-to-body=true>
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
      <el-button type="primary" @click="auditNoPassData()">提交</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage, ElFormItem} from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, RkIndexLayout, dictFormatter,
} from 'riking-ui'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'
import {useDict} from 'riking-layout'
import {checkData, pagination} from "@/utils/utils";
import {columns, searchFormItems, formItems} from './data';
import {list, getById, delByIds, saveOrUpdate, exportExcel, submit, auditPass, auditNoPass} from "./api";
import UpAndDown, {expLoading, impLoading} from "@/components/UpAndDown.vue";

const searchForm = ref({})
const loading = ref(false)
const loadingTable = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const auditDialog = ref(false);
const msgDialog = ref(false);
const msg = ref("");
let ids: string;

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  search()
})

const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}
const search = async () => {
  loadingTable.value = true
  let formData = checkData(searchForm.value);

  let params = {
    branchCodeList: formData.branchCodeList,
    startTime: formData.createTime,
    endTime: formData.endTime
  }

  let result = await list(params, page.value.currentPage, page.value.pageSize);

  let {current, total, records} = result.data;
  data.value = records;
  page.value.currentPage = current;
  page.value.total = total;
  loadingTable.value = false
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const exp = async () => {
  expLoading.value = true;
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    let params = checkData(searchForm.value)
    if (params.createTime) {
      params.startTime = params.createTime
      delete params.createTime
    }
    await exportExcel(params)
  } finally {
    expLoading.value = false;
  }
}


/**
 * 主表按钮
 */
const getMainTableButtons: () => ButtonInfo[] = () => {
  const buttons = [
    // {
    //   key: 'add',
    //   label: '新增',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_add',
    //   handler: () => {
    //     open({branchCode: dictData.branchCode[0].value}, false, "新增")
    //   }
    // },
    // {
    //   key: 'submit',
    //   label: '提交',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_submit',
    //   handler: async () => {
    //     if (ids == null || ids == undefined || ids == '') {
    //       ElMessage.warning("请选择需要提交的数据")
    //       return
    //     }
    //     await submit(ids);
    //     search();
    //     close();
    //     ElMessage.success('操作成功！（注：只能提交待补录数据）')
    //   },
    // },
    // {
    //   key: 'audit',
    //   label: '审核',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_check',
    //   handler: async () => {
    //     if (ids == null || ids == undefined || ids == '') {
    //       ElMessage.warning("请选择需要审核的数据")
    //       return
    //     }
    //     auditDialog.value=true
    //   },
    // },
    // {
    //   key: 'del',
    //   label: '删除',
    //   tag: 'button',
    //   type: 'danger',
    //   icon: 'icon_delete',
    //   handler: async () => {
    //     if (ids == null || ids == undefined || ids == '') {
    //       ElMessage.warning("请选择需要删除的数据")
    //       return
    //     }
    //     await delByIds(ids);
    //     ElMessage.success("操作成功！（注：待审核和审核通过数据不支持删除）");
    //     search();
    //   }
    // },
  ]
  return buttons;
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => {
        open(row, true, '查看')
        // openDialog(row)
      }
    },
  ]
  //状态是 待审核 审核通过不允许编辑 删除
  // if (row.status != '2' && row.status != '3') {
  //   buttons.splice(1, 0,
  //       {
  //         key: 'edit', label: '编辑', tag: 'button', type: 'primary',
  //         handler: () => {
  //           open(row, false, '编辑')
  //         }
  //       },
  //       {
  //         key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
  //         handler: () => deleteDialog(row)
  //       }
  //   );
  // }
  return buttons
}

const deleteDialog = async (row: any) => {
  await delByIds(row.id);
  search();
  ElMessage.success("删除成功");
}

const auditPassData = async () => {
  await auditPass(ids);
  search();
  auditDialog.value=false
  ElMessage.success('操作成功！（注：只能审核待审核数据）')
}

const auditNoPassData = async () => {
  await auditNoPass(ids, msg.value);
  search();
  msgDialog.value=false
  auditDialog.value=false
  ElMessage.success('操作成功！（注：只能审核待审核数据）')
}

const handleSave = async () => {
  //编辑
  dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate();
    if (valid) {
      await saveOrUpdate(form.value);
      search();
      close();
      ElMessage.success('操作成功')
    }
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}

const openDialog = async (row: any) => {
  const result = await getById({id: row.id});
  open(result.data, true, '查看');
}


const getTagColor = (status:string) => {
  return status == '6' ? 'danger' : 'primary';
}

const {dialogData, open, close, closed, form, nameRef: dialogFormRef}: DialogForm<RkFormInstance, any>
    = useDialogForm('dialogFormRef', {type: []})

</script>

<style scoped>

</style>
