import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

export const columns: TableColumnInfo[] = [
    // {key: 'id', type: 'selection'},
    {
        prop: 'module',
        label: '模块',
        minWidth: 200,
        sortable: true
    },
    {
        prop: 'fldm',
        label: '分类代码',
        minWidth: 100,
        sortable: true
    },
    {
        prop: 'qqdbs',
        label: '请求单标识',
        minWidth: 200,
        sortable: true
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        minWidth: 200,
        sortable: true
    },
    {
        prop: 'status',
        label: '状态',
        minWidth: 100,
        // dictFormatKey:'dataStatus',
        sortable: true
    },
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        minWidth: 100,
        // dictFormatKey: 'cxfkjg',
        sortable: true
    },
    // {
    //     prop: 'branchCode',
    //     label: '分行编号',
    //     minWidth: 200,
    //     sortable: true
    // },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        dictFormatKey:'branchCode',
        minWidth: 200,
        sortable: true
    },
    {
        prop: 'createTime',
        label: '创建时间',
        minWidth: 200,
        formatter: dateFormatter,
        sortable: true
    },
    {prop: 'submitBy', label: '提交人', minWidth: 120, sortable: true},
    {prop: 'submitTime', label: '提交时间', minWidth: 120, formatter: dateFormatter, sortable: true},
    {prop: 'approveBy', label: '审核人', minWidth: 120, sortable: true},
    {prop: 'approveTime', label: '审核时间', minWidth: 120, formatter: dateFormatter, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 100,
        minWidth: 140,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'createTime',
        label: '创建时间',
        labelWidth: 80,
        inputType: {
            tag: 'date-picker',
            type: 'daterange',
            style: 'width: 220px',
            rangeSeparator: '-',
            format: 'YYYY-MM-DD',
            valueFormat: 'YYYY-MM-DD',
        },
        // rules: [{ required: true, message: '查控日期不能为空' }],
    },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 100,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
            multiple: true,
            collapseTags: true,
            maxCollapseTags:1
        },
    },
]

export const formItems: FormItemInfo[] = [
    {
        prop: 'module',
        label: '模块',
        labelWidth: 120,
    },
    {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 120,
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 120,
        rules: [{required: true, message: '必填'}]
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 120
    },
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
        },
    },
    {
        prop: 'branchCode',
        label: '所属机构',
        labelWidth: 120,
        rules: [{required: true, message: '必填'}],
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
    },
    {
        prop: 'status',
        label: '状态',
        labelWidth: 120,
        // inputType: {
        //     tag: 'select',
        //     options: 'dataStatus',
        // },
        // scopedSlots: 'status'
    },
    // {
    // {
    //     prop: 'statusRemark',
    //     label: '备注',
    //     labelWidth: 120,
    //     inputType:{
    //         tag: 'input',
    //         type: 'textarea'
    //     },
    // },
    // {
    //     prop: 'createBy',
    //     label: '创建人',
    //     labelWidth: 170,
    //     inputType: {tag:'input',disabled: true},
    // },
    {
        prop: 'createTime',
        label: '创建时间',
        labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    },
    // {
    //     prop: 'updateBy',
    //     label: '更新人',
    //     labelWidth: 170,
    //     inputType: {tag:'input',disabled: true},
    // },
    // {
    //     prop: 'updateTime',
    //     label: '更新时间',
    //     labelWidth: 170,
    //     inputType: {tag:'input',disabled: true},
    // },
    {prop: 'submitBy', label: '提交人', labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    },
    {prop: 'submitTime', label: '提交时间', labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    },
    {prop: 'approveBy', label: '审核人', labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    },
    {prop: 'approveTime', label: '审核时间', labelWidth: 120,
        inputType: {tag:'input',disabled: true},
    },
]
