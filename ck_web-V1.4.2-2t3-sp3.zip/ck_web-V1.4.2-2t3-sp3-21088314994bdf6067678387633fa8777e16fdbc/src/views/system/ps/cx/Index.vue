<template>
  <rk-index-layout>
    <rk-dynamic-search-form
      v-model="searchForm"
      :form-items="recordSearchFormItems"
      :fields="advancedQueryItems"
      @search="search"
    ></rk-dynamic-search-form>

    <rk-page-table
      ref="mainTable"
      :data="data"
      :columns="recordColumns"
      :loading="loading"
      :pagination="page"
      :row-key="getRowKey"
      :expand-row-keys="expands"
      :id="getRowKey"
      @page-change="pageChange"
      @refresh="search"
      @selection-change="handleSelectionChange"
      @expand-change="clickRowHandle"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="tableButtons" :route-meta="$route.meta"></rk-button-group>
          <div style="margin: 0 4px"></div>
          <UpAndDown :imp="impExcel" :exp="() => exp(searchForm, reportCode)" />
        </div>
      </template>

      <template #expand="{ row }">
        <rk-page-table
          ref="treeTable"
          :loading="treeLoading"
          :data="treeData"
          :columns="columns"
          border="true"
          max-height="500"
          hiddenTableTools
          style="margin-left: 30px; width: 98%"
          :pagination="treePage"
          @page-change="(p: Pagination) =>treePageChange(p,row)"
          @refresh="treeSearch"
        >
          <template #actions="{ row: subRow }">
            <rk-button-group :buttons="genActButtons(subRow, row)" :route-meta="$route.meta" :max="3" link />
          </template>
        </rk-page-table>
      </template>

      <template #fileActions="{ row }">
        <rk-button-group
          v-if="row.importType !== '3'"
          :buttons="renderFileActButtons(row, reportCode)"
          :route-meta="$route.meta"
          link
        />
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!-- 查看、编辑 弹出层 -->
  <ComCxDialog ref="dialogRef" :form-items="isEdit ? editFormItems : ckformItems" @callback="save" />

  <!-- 线下请求单 弹出层 -->
  <ComCxDialog
    ref="offlineDialogRef"
    :form-items="formItems"
    @callback="saveOffline"
    :init-form-values="initFormValues"
  />

  <!-- 请求单页面反馈弹出框 -->
  <el-dialog title="反馈" v-model="feedbackDialog" width="90%" @closed="clearFeedbackForm()">
    <rk-collapse-form ref="bodyFormRef" v-model="bodyForm" :form-items="fkZtFormItems" :disabled="true">
    </rk-collapse-form>
    <div>
      <h4>反馈信息</h4>
    </div>
    <rk-detail-form ref="feedbackFormRef" v-model="feedbackForm" :form-items="feedbackFormItems">
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled="true" filterable style="width: 100%"> </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="reportCode === 'certificate'" type="primary" @click="uploadCertificate"
          >上传凭证图像文件</el-button
        >
        <el-button type="primary" @click="feedback">保存</el-button>
        <el-button @click="feedbackDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 指派机构表格弹出框 -->
  <el-dialog title="指派" v-model="assignmentDialog" width="70%">
    <rk-page-table
      ref="assignmentTable"
      :loading="assignmentLoading"
      :data="assignmentData"
      :columns="assignmentColumns"
      border="true"
      @selection-change="assignmentIdsHandleSelectionChange"
      @refresh="assignmentSearch"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <!-- 此处按钮无需做权限配置 -->
          <rk-button-group :buttons="assignmentButtons" :route-meta="[]"></rk-button-group>
        </div>
      </template>
    </rk-page-table>
  </el-dialog>

  <!-- 指派机构form弹出框 -->
  <el-dialog
    title="新增指派"
    v-model="assignmentFormDialog"
    width="70%"
    @closed="
      () => {
        assignmentFormRef.resetFields()
      }
    "
  >
    <rk-detail-form
      ref="assignmentFormRef"
      v-model="assignmentForm"
      :form-items="[
        {
          prop: 'qqdbs',
          label: '请求单标识',
          labelWidth: 150,
          inputType: 'input',
          scopedSlot: 'systemCode',
        },
        {
          prop: 'rwlsh',
          label: '任务流水号',
          labelWidth: 150,
          inputType: 'input',
          scopedSlot: 'systemCode',
        },
        {
          prop: 'branchCode',
          label: '业务操作机构',
          labelWidth: 150,
          inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
          },
          rules: [{ required: true, message: '业务操作机构不能为空' }],
        },
      ]"
    >
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled="true" filterable style="width: 100%"> </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="assignmentSave">保存</el-button>
        <el-button @click="assignmentFormDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>

  <!--xml文件列表-->
  <el-dialog v-model="fileDialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button
      v-for="name in xmlNames"
      :key="name"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="openXml(xmlList, name)"
    >
      {{ name }}
    </el-button>
  </el-dialog>

  <template>
    <div>
      <el-upload
        ref="uploadRef"
        :on-error="
          () => {
            ElMessage.error({ message: '上传失败', grouping: true, showClose: true, duration: 0 })
          }
        "
        :show-file-list="false"
        :http-request="IUploadFile"
      >
        >
        <el-button ref="uploadButton" id="uploadButton" type="primary">上传文件</el-button>
      </el-upload>
    </div>
  </template>

  <div class="img-viewer-box">
    <el-image-viewer
      v-if="viewerVisible"
      :url-list="urlList"
      @close="
        () => {
          viewerVisible = false
        }
      "
    />
  </div>
</template>

<script setup lang="ts">
import {onMounted, ref, watch} from 'vue'
import { ElDialog, ElButton, ElMessage } from 'element-plus'
import {
  assignmentDialog,
  assignmentLoading,
  assignmentData,
  assignmentColumns,
  assignmentSearch,
  assignmentButtons,
  assignmentQqdbs,
  assignmentRwlsh,
  assignmentIdsHandleSelectionChange,
  assignmentSave,
  assignmentFormDialog,
  assignmentFormRef,
  assignmentForm,
} from '@/utils/assignment'
import {
  RkPageTable,
  RkButtonGroup,
  RkDetailForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  FormItemInfo,
  TableColumnInfo,
  RkDynamicSearchForm,
} from 'riking-ui'

import { useDict } from 'riking-layout'

import { list, listOne, del, update, listFldm, treeList, upload, updateRequestStatus, offlineSave } from './api'
import {
  pagination,
  renderTableButtons,
  treePagination,
  formatDate,
  openXml,
  renderFileActButtons,
  viewerVisible,
  urlList,
  fileDialogVisible,
  xmlNames,
  xmlList,
  imp,
  exp,
  uploadCertificate,
  getFeedbackCode,
  handleSelectionChange,
  offlineDialogRef,
} from './data'
import { derivedPageElements, recordColumns, recordSearchFormItems, advancedQueryItems } from './page'
import { saveData } from '../fk/api'
import { derivedPageElements as feedbackDerivedPageElements } from '../fk/page'

import UpAndDown from '@/components/UpAndDown.vue'
import { getRequestClassificationCode, getSubSystem } from '@/utils/subSystem'

import { checkSpecialCharacters, copyProperties, specialChecks } from '@/utils/utils'
import ComCxDialog from '@/views/system/ps/cx/ComCxDialog.vue'
import {isEmpty, setDisabled, setRequiredRule, setRequiredRuleFalse} from '@/views/system/sum'

useDict([], [], {
  ...dictData,
  branchCode: async () => {
    const res = await dictsStore.loadDict()
    return res.data.branchCode
  },
  fldm: async () => {
    const path = useRoute().path
    reportCode.value = getRequestClassificationCode()
    const res = await listFldm(reportCode.value)
    return res.data
  },
  sqjgdm: async () => {
    return dictData['sqjgdm' + '.' + getSubSystem()]
  },
})

// 报文编号
const reportCode = ref('')
const loading = ref(false)
const data = ref<any[]>([])
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
let keyword: string
let columns: TableColumnInfo[] = [],
  formItems: FormItemInfo[] = [],
  ckformItems: FormItemInfo[] = ref([]),
  fkZtFormItems: FormItemInfo[] = ref([]),
  searchFormItems: FormItemInfo[] = []

/**
 * 反馈弹出框所需组件
 * */
let feelbackItem: FormItemInfo[] = []
let feelbackItem2: FormItemInfo[] = []
const feedbackDialog = ref(false)
const feedbackForm = ref({})
const fldm = ref('')
const feedbackFormRef = ref<RkFormInstance>()
const bodyForm = ref({})
const bodyFormRef = ref<RkFormInstance>()
const feedbackFormItems = ref([])

// 子组件实列
const dialogRef = ref()

// todo 测试多线程下动态表名的问
// const props = defineProps<{ requestClassificationCode: string | string[] }>();

const path = useRoute().path
reportCode.value = getRequestClassificationCode()
let pageElements = derivedPageElements()
columns = pageElements.columns
formItems = pageElements.formItems
ckformItems.value = JSON.parse(JSON.stringify(formItems))
fkZtFormItems.value = JSON.parse(
  JSON.stringify(
    formItems.filter((item) => {
      return (
        item.extra &&
        item.extra.collapse &&
        item.extra.collapse.name === 'body' &&
        item.extra.collapse.title === '主体信息'
      )
    }),
  ),
)

feelbackItem = feedbackDerivedPageElements(getFeedbackCode(reportCode.value), null).formItems
feelbackItem2 = feedbackDerivedPageElements(getFeedbackCode(reportCode.value), null).formItems2
searchFormItems = pageElements.searchFormItems

const initFormValues = ref({ qqrzjlx: '110031', xcrzjlx: '110031' })

let tableButtons = []
onMounted(() => {
  page.value = {...pagination}
  tableButtons = renderTableButtons(reportCode.value)
  search()
})

const search = async () => {
  loading.value = true
  try {
    let value = searchForm.value
    const newObject = { ...searchForm.value }
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null
        console.log('转化了空串')
      }
    }
    if (value.createTime != undefined) {
      newObject.endTime = formatDate(new Date(value.createTime[1]))
      newObject.createTime = formatDate(new Date(value.createTime[0]))
    }
    let result = await list(reportCode.value, newObject, page.value.currentPage, page.value.pageSize)
    let { current, total, records } = result.data
    data.value = records
    page.value.currentPage = current
    page.value.total = total

    if (expands.value.length != 0) {
      //如果存在展开行,清空expands.value数组,使它关闭
      expands.value.splice(0, expands.value.length)
      treeData.value = []
    }
  } finally {
    loading.value = false
  }
}

const impExcel = (data) => imp(data, search, reportCode.value)

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

let editFormItems = []
const isEdit = ref(false)
const openDialog = async (columnData: any, type: string) => {
  editFormItems = [
    {
      prop: 'qqdbs',
      label: '请求单标识',
      labelWidth: 150,
      inputType: { tag: 'input', disabled: true },
      extra: {
        collapse: { name: 'basic', title: '基础信息' },
      },
      rules: [
        { max: 30, message: '请求单标识长度不可超过30' },
        { required: true, message: '请求单标识不能为空' },
      ],
    },
    {
      prop: 'fldm',
      label: '分类代码',
      labelWidth: 150,
      inputType: {
        tag: 'select',
        options: 'fldm',
        multiple: false,
        disabled: true,
      },
      extra: {
        collapse: { name: 'body', title: '主体信息' },
      },
      rules: [{ required: true, message: '分类代码必填' }],
    },
    ...formItems.filter((item) => {
      return item.prop !== 'qqdbs' && item.prop !== 'fldm'
    }),
  ]

  const result = await listOne(reportCode.value, { id: columnData.id, qqdbs: columnData.qqdbs })
  if (type == '查看') {
    dialogRef.value.open(result.data, true, '查看')
  } else {
    isEdit.value = true // todo 关闭时设置为false
    dialogRef.value.open(result.data, false, '编辑')
  }
}

const save = async (formValue) => {
  try {
    expands.value.splice(0, expands.value.length)
    var rsPromise = await update(reportCode.value, formValue)
    ElMessage.success(rsPromise.data)
  } finally {
  }
}

const saveOffline = async (formValue) => {
  try {
    const data = formValue
    delete data.type
    await offlineSave(reportCode.value, data)
    await search()
    ElMessage.success('保存成功')
  } finally {
  }
}

const genActButtons: (subRow: any, row: any) => ButtonInfo[] = (subRow: any, row: any) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: () => {
        setRequiredRuleFalse([], ckformItems.value)
        openDialog(subRow, '查看')
      },
    },
    {
      key: 'assignment',
      label: '指派',
      tag: 'button',
      type: 'primary',
      handler: () => {
        if (subRow.status == '4' || subRow.status == '5') {
          ElMessage.warning('该条数据已经生成或上报报文,无法指派机构')
          return
        }
        assignmentDialog.value = true
        assignmentForm.value = {}
        const data = toRaw(assignmentForm.value)
        data.qqdbs = subRow.qqdbs
        data.rwlsh = subRow.rwlsh
        assignmentQqdbs.value = subRow.qqdbs
        assignmentRwlsh.value = subRow.rwlsh
        assignmentSearch()
      },
    },
  ]
  if (row.importType == '3') {
    buttons.splice(1, 0, {
      key: 'edit',
      label: '编辑',
      tag: 'button',
      type: 'primary',
      handler: () => {
        openDialog(subRow, '编辑')
      },
    })
    buttons.splice(2, 0, {
      key: 'del',
      label: '删除',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        try {
          const rsPromise = await del(reportCode.value, subRow.id)
          ElMessage.success(rsPromise.data)
        } finally {
          search()
        }
      },
    })
  }
  if (subRow.status == '1' || (reportCode.value == 'ps104' && subRow.status == '2')) {
    buttons.splice(1, 0, {
      key: 'feedback',
      label: '反馈',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        if (subRow.status == '4' || subRow.status == '5') {
          ElMessage.warning('该条数据已经生成或上报报文,无法新增反馈')
          return
        }
        setRequiredRuleFalse([], fkZtFormItems.value)
        feelbackItem = feedbackDerivedPageElements(getFeedbackCode(reportCode.value), subRow.djfs).formItems
        const result = await listOne(reportCode.value, { id: subRow.id, qqdbs: subRow.qqdbs })
        bodyForm.value = result.data
        let toRaw1 = toRaw(bodyForm.value)
        for (const key in result.data) {
          if (result.data.hasOwnProperty(key)) {
            toRaw1[key] = result.data[key]
          }
        }

        // let data = toRaw(feedbackForm.value);
        // data.qqdbs = subRow.qqdbs
        // data.rwlsh = subRow.rwlsh
        // fldm.value = subRow.fldm;
        // data = copyProperties(data, subRow, reportCode.value);

        fldm.value = subRow.fldm
        feedbackForm.value.qqdbs = subRow.qqdbs
        feedbackForm.value.rwlsh = subRow.rwlsh
        copyProperties(feedbackForm.value, subRow, reportCode.value)

        getFeedbackFormItems(fldm.value)
        feedbackDialog.value = true
      },
    })
  }

  return buttons
}

/**
 * 树状表所需组件和方法
 */
const treePage = ref<Pagination>(treePagination)
const treeData = ref<any[]>([])
const treeLoading = ref(false)
const qqdbs = ref('')
let expands = ref<any[]>([])

const treeSearch = async (row: any) => {
  treeLoading.value = true
  qqdbs.value = row.qqdbs
  const mbjgdm = row.bankCode
  try {
    var branchCodeList = Array.from(searchForm.value.branchCodeList).join('-|-')
    let result = await treeList(
      reportCode.value,
      qqdbs.value,
      row.fldm,
      [],
      treePage.value.currentPage,
      treePage.value.pageSize,
      branchCodeList,
      mbjgdm,
    )
    let { current, total, records } = result.data
    treeData.value = records
    treePage.value.currentPage = current
    treePage.value.total = total
  } finally {
    treeLoading.value = false
  }
}

const treePageChange = (p: Pagination, row: any) => {
  treePage.value = p
  treeSearch(row)
}

const getRowKey = (row: any) => {
  return row.id
}

const clickRowHandle = (row: any) => {
  treePage.value = treePagination
  if (expands.value.includes(row.id)) {
    expands.value = expands.value.filter((val) => val !== row.id)
  } else {
    //判断是否已经存在展开的行
    if (expands.value.length != 0) {
      //如果存在展开行,清空expands.value数组,使它关闭
      expands.value.splice(0, expands.value.length)
      //打开点击的行
      expands.value.push(row.id)
    } else {
      //如果不存在展开行,直接push打开点击的行
      expands.value.push(row.id)
    }
  }
  treeSearch(row)
}

const getFeedbackFormItems = (fldm: string) => {
  if (fldm == 'SS05' || fldm == 'SS06' || fldm == 'SS32' || fldm == 'SS33') {
    feedbackFormItems.value = [
      {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },
      {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },
      ...feelbackItem2[0].items,
    ]
  } else {
    feedbackFormItems.value = [
      {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },
      {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },
      ...feelbackItem[0].items,
    ]
  }
}

const feedback = async () => {
  const valid = await feedbackFormRef.value?.asyncValidate()
  const bodyFormData = toRaw(bodyForm.value)
  const data = toRaw(feedbackForm.value)
  data.djfs = bodyFormData.djfs
  const specialChecksReturn = specialChecks(data, getSubSystem(), getFeedbackCode(reportCode.value))
  if (specialChecksReturn.clear) {
    await feedbackFormRef.value?.clearValidate()
  }
  // 返回值 true是允许保存 , false是不允许保存
  if (!specialChecksReturn.result) {
    ElMessage.error({ message: specialChecksReturn.msg, grouping: true, showClose: true, duration: 0 })
    return
  }
  //校验是否存在特殊字符
  if (checkSpecialCharacters(data)) {
    await feedbackFormRef.value?.asyncValidate()
    ElMessage.error({ message: '存在特殊字符', grouping: true, showClose: true, duration: 0 })
    return
  }
  //校验必填项(仅当特殊校验通过时才进行)
  if (!valid && specialChecksReturn.continueToVerify) {
    await feedbackFormRef.value?.asyncValidate()
    ElMessage.error({ message: '存在必填项未填', grouping: true, showClose: true, duration: 0 })
    return
  }
  data.status = '1'
  data.deleted = '0'
  await updateRequestStatus(reportCode.value, data)
  await saveData(getFeedbackCode(reportCode.value), data, fldm.value)
  await search()
  feedbackDialog.value = false
  ElMessage.success('保存成功')
}

const IUploadFile = async (data = {}) => {
  if (!data.file.name.toLowerCase().endsWith('.pdf') && !data.file.name.toLowerCase().endsWith('.jpg')) {
    ElMessage.error({ message: '仅可上传PDF/JPG文件', grouping: true, showClose: true, duration: 0 })
    return
  }
  const rsPromise = await upload(reportCode.value, feedbackForm.value.qqdbs, feedbackForm.value.rwlsh, data)
  feedbackForm.value.pztxlx = rsPromise.data.pztxlx
  feedbackForm.value.pztxmc = rsPromise.data.pztxmc
  feedbackForm.value.pztxxh = parseInt(rsPromise.data.pztxxh, 10)
  feedbackForm.value.wjlj = rsPromise.data.wjlj
  ElMessage.success('上传成功')
}

function clearFeedbackForm() {
  // feedbackForm.value = {}
  // bodyForm.value = {}
  feedbackFormRef.value?.resetFields()
  bodyFormRef.value?.resetFields()
}


// let firstOpen = true
//
// watch(() =>  feedbackDialog.value, (newVal, oldVal) => {
//   if (!newVal) {
//     firstOpen = true
//   }
// })

/**
 * 手工反馈——冻结
 */
watch(
    () => feedbackForm.value,
  (newForm, oldForm) => {
    // 未启用部门编码，编辑页面隐藏
    if (dictData.departmentCodeRequired == undefined) {
      feedbackFormItems.value = feedbackFormItems.value.filter((item) => 'departmentCode' != item.prop)
    }

    if (reportCode.value == 'ps101' || reportCode.value == 'ps103') {
      // 若反馈结果是成功，客户编号-KHBH 必填
      setRequiredRule(['khbh'], newForm.cxfkjg == '01', feedbackFormItems.value)
      // 若反馈结果失败-02 只有查询反馈结果原因必填
      setRequiredRule(['gsnsh', 'khmc', 'branchCode', 'zzhm', 'zzlx'], newForm.cxfkjg == '01', feedbackFormItems.value)
      // setRequiredRule(['cxfkjgyy'], newForm.cxfkjg == '02', feedbackFormItems.value)

      // 反馈结果原因必填，反馈成功，反馈结果原因自动填入成功
      if (newForm.cxfkjgyy == '01' && feedbackForm.value.cxfkjgyy == '') {
        feedbackForm.value.cxfkjgyy = '成功'
      }

      // 对公或者是是反馈结果失败, 不必填
      if ('02' === bodyForm.value.ckztlb || '02' === newForm.cxfkjg) {
        setRequiredRule(['xb', 'mz', 'csrq'], false, feedbackFormItems.value)
      } else {
        setRequiredRule(['xb', 'csrq'], true, feedbackFormItems.value)
      }
      // 对公并且反馈结果成功，必填
      if ('02' === bodyForm.value.ckztlb && '01' === newForm.cxfkjg) {
        setRequiredRule(['gsnsh', 'tyshxydm'], true, feedbackFormItems.value)
      } else {
        setRequiredRule(['gsnsh', 'tyshxydm'], false, feedbackFormItems.value)
      }
    }

    // 动态查询表单项
    if (reportCode.value == 'ps104') {
      // 若请求查询对应的卡号 如果该账号无对应卡号，卡号-KH 可为空  todo 这里请求暂时取不到
      // setRequiredRule(['kh'], newForm.cxztlb != '01', formItems.value[0].items)
      // 若查询反馈结果是01-成功且交易类型是转账/汇款/ATM等网银转账业务时 交易对方帐卡号类型-JYDFZKHLX 对方账户币种-DFZHBZ  必填
      setRequiredRule(
        ['jydfzkhlx', 'dfzhbz'],
        '转账/汇款/ATM'.includes(newForm.jylx) && newForm.cxfkjg == '01',
        feedbackFormItems.value,
      )
      // 若交易类型是转账/汇款/ATM等网银转账业务时  对方账户名称-DFZHMC 交易对方账卡号-JYDFZKH  必填
      setRequiredRule(['dfzhmc', 'jydfzkh'], '转账/汇款/ATM'.includes(newForm.jylx), feedbackFormItems.value)
    }

    // 冻结/续冻/解冻表单项
    if (reportCode.value == 'ps105') {
      // 若执行结果为 1-执行失败时  未能冻结原因-WNDJYY  必填
      setRequiredRule(['wndjyy'], newForm.zxjg == '1', feedbackFormItems.value)

      // 若有在先冻结情况时  在先冻结机关-DJJG 在先冻结金额-DJJE 必填  todo 暂时取不到
      // setRequiredRule(['djjg','djje'], newForm.zxjg=='1', formItems.value[0].items)
      // 若执行结果失败-1 只有失败原因必填
      setRequiredRule(
        ['branchCode', 'ye', 'djjsrq', 'zhkyye', 'djzhhz', 'zzhm', 'zxqssj', 'wdjje', 'zzlxdm', 'sdje'],
        newForm.zxjg == '0',
        feedbackFormItems.value,
      )

      // 冻结 账户可用余额=账户余额-在先冻结金额-执行冻结金额
      // if (bodyForm.value.qqcslx == '05') {
      let ye = feedbackForm.value.ye
      // let zxdjje = feedbackForm.value.zxdjje
      let djje = feedbackForm.value.djje
      let sdje = feedbackForm.value.sdje

      if (!isEmpty(ye)) {
        const b1 = isEmpty(djje);
        djje = b1 ? 0 : djje;

        const b2 = isEmpty(sdje);
        sdje = b2 ? 0 : sdje;


      }

      // 限额冻结
      if (bodyForm.value.djfs == '01') {
        if (newForm.zxjg == '1') {
          feedbackForm.value.wdjje = ''
          setRequiredRule(['wdjje'], false, feedbackFormItems.value)
          setDisabled('wdjje', true, feedbackFormItems.value)
        } else {
          // if (!firstOpen) {
            if (isEmpty(feedbackForm.value.sdje)) {
              feedbackForm.value.wdjje = feedbackForm.value.sqdjxe
            } else {
              feedbackForm.value.wdjje = feedbackForm.value.sqdjxe - feedbackForm.value.sdje
            }
          // }
          // firstOpen = !firstOpen;
          setRequiredRule(['wdjje'], true, feedbackFormItems.value)
          setDisabled('wdjje', false, feedbackFormItems.value)
        }
        feedbackForm.value.zhkyye = ye - djje - sdje
      }

      // 只收不付，未能冻结金额取消必填
      if (bodyForm.value.djfs == '02') {
        feedbackForm.value.sqdjxe = 0.00
        feedbackForm.value.zhkyye = 0.00
        feedbackForm.value.sdje = 0.00
        feedbackForm.value.wdjje = ''
        setRequiredRule(['wdjje'], false, feedbackFormItems.value)
        setDisabled('wdjje', true, feedbackFormItems.value)
      }



      // }


      // // 限额内冻结时，且失败的，未冻结金额为空
      // if (newForm.zxjg == '1' && bodyForm.value.djfs == '01') {
      //
      // } else {
      //   if (feedbackForm.value.wdjje === '') {
      //     feedbackForm.value.wdjje = feedbackForm.value.sqdjxe - feedbackForm.value.sdje
      //   }
      // }
    }

    // 紧急止付/解除止付表单项
    if (reportCode.value == 'ps106') {
      // 若执行结果为 1-执行失败时  失败原因-SBYY 必填
      setRequiredRule(['sbyy'], newForm.zxjg == '1', feedbackFormItems.value)
      // 若执行结果为 0-执行成功时  执行起始时间-ZXQSSJ 必填
      setRequiredRule(['zxqssj'], newForm.zxjg == '0', feedbackFormItems.value)
      // 若执行结果失败-1 只有失败原因必填
      setRequiredRule(['zh', 'branchCode'], newForm.zxjg == '0', feedbackFormItems.value)
    }

    // 动态查询回执表单项
    if (reportCode.value == 'ps107') {
      // 若执行结果失败-1 只有失败原因必填
      setRequiredRule(
        ['branchCode', 'zxqssj', 'jssj', 'zh', 'fksjhm', 'zxsjqj'],
        newForm.zxjg == '0',
        feedbackFormItems.value,
      )
      setRequiredRule(['zxjgyy'], newForm.zxjg == '1', feedbackFormItems.value)
    }

    feedbackFormItems.value = [...feedbackFormItems.value]
  },
  { deep: true },
)
</script>

<script lang="ts">
import useDictsStore from '@/store/dictStore'
// TODO 启动时加载，不在页面里调用   子系统设置
const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<style scoped>
.el-table td.el-table__cell div {
  box-sizing: border-box;
  padding: 4px;
  height: auto;
  margin-left: 4px;
}

/*.parent :deep(.children) {样式内容}*/

.request-body :deep(.el-table__expanded-cell .table-header) {
  display: none;
}

.request-body :deep(.el-table__row) {
  background: gainsboro !important;
}

.request-body :deep(.el-table__expanded-cell .el-table__row) {
  background: transparent !important;
}

/*.test :deep(.el-table__cell) {*/
/*  background: gainsboro !important;*/
/*}*/

/*.test :deep(.el-table__expanded-cell .el-table__cell) {*/
/*  background: transparent !important;*/
/*}*/
</style>
