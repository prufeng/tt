import {TableColumnInfo} from "riking-ui";
import {dateFormatter} from "@/utils/utils";

// 请求页面  展开表 基础信息  用于下面列字段使用
export const basicColumns: TableColumnInfo[] = [
    {prop: 'qqcslx', label: '请求措施类型', width: 150, dictFormatKey: 'qqcslx', sortable: true},
    {prop: 'jjcd', label: '紧急程度', width: 150, dictFormatKey: 'jjcd', sortable: true},
    {prop: 'fssj', label: '发送时间', width: 150, sortable: true},
    {prop: 'sqjgdm', label: '申请机构', width: 150, dictFormatKey: 'sqjgdm', sortable: true},
    {prop: 'createBy', label: '创建人', minWidth: 200, sortable: true},
    // {prop: 'createTime', label: '数据日期', minWidth: 200, sortable: true},
    {prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 180,
        fixed: 'left',
    },
]

// 请求页面  展开表  账户信息查询  账户信息与交易明细查询 金融理财查询 列字段
export const publicAccountColumns: TableColumnInfo[] = [
    {prop: 'createTime', label: '数据日期', minWidth: 200, sortable: true},
    {prop: 'status', label: '请求处理状态', width: 150, dictFormatKey: 'reqProcessingStatus', sortable: true},
    {prop: 'rwlsh', label: '任务流水号', width: 230, sortable: true},
    {prop: 'cxzh', label: '查询账号', width: 170, sortable: true},
    {prop: 'zzhm', label: '证照号码', width: 150, sortable: true},
    {prop: 'ztmc', label: '主体名称', width: 150, sortable: true},
    {prop: 'cxnr', label: '查询内容', width: 170, dictFormatKey: 'cxnr', sortable: true},
    ...basicColumns,
    {prop: 'mxsdlx', label: '明细时段类型', width: 150, dictFormatKey: 'mxsdlx', sortable: true},
    {prop: 'mxqssj', label: '明细起始时间', width: 150, sortable: true},
    {prop: 'mxjzsj', label: '明细截至时间', width: 150, sortable: true},
]

// 请求页面  展开表   交易明细查询   列字段
export const publicTransactionColumns: TableColumnInfo[] = [
    {prop: 'createTime', label: '数据日期', minWidth: 200, sortable: true},
    {prop: 'status', label: '请求处理状态', width: 150, dictFormatKey: 'reqProcessingStatus', sortable: true},
    {prop: 'rwlsh', label: '任务流水号', width: 230, sortable: true},
    {prop: 'cxzh', label: '查询账卡号', width: 170, sortable: true},
    {prop: 'cxnr', label: '查询内容', width: 170, dictFormatKey: 'cxnr', sortable: true},
    ...basicColumns,
    {prop: 'mxsdlx', label: '明细时段类型', width: 150, dictFormatKey: 'mxsdlx', sortable: true},
    {prop: 'mxqssj', label: '明细起始时间', width: 150, sortable: true},
    {prop: 'mxjzsj', label: '明细截至时间', width: 150, sortable: true},
]

// 请求页面  展开表   动态查询  列字段
export const publicDynamicColumns: TableColumnInfo[] = [
    {prop: 'createTime', label: '数据日期', minWidth: 200, sortable: true},
    {prop: 'status', label: '请求处理状态', width: 150, dictFormatKey: 'reqProcessingStatus', sortable: true},
    {prop: 'rwlsh', label: '任务流水号', width: 230, sortable: true},
    {prop: 'yrwlsh', label: '原任务流水号', width: 230, sortable: true},
    {prop: 'zh', label: '账卡号', width: 170, sortable: true},
    ...basicColumns,
    {prop: 'kssj', label: '开始时间', width: 150, sortable: true},
    {prop: 'zxsjqj', label: '执行时间区间', width: 150, dictFormatKey: 'zxsjqj', sortable: true},
    {prop: 'jssj', label: '结束时间', width: 150, sortable: true},
]

// 请求页面  展开表   冻结/解冻/续冻  列字段
export const publicFreezeColumns: TableColumnInfo[] = [
    {prop: 'createTime', label: '数据日期', minWidth: 200, sortable: true},
    {prop: 'status', label: '请求处理状态', width: 150, dictFormatKey: 'reqProcessingStatus', sortable: true},
    {prop: 'rwlsh', label: '任务流水号', width: 230, sortable: true},
    {prop: 'yrwlsh', label: '原任务流水号', width: 230, sortable: true},
    {prop: 'djzhhz', label: '冻结账户户主', width: 150, sortable: true},
    {prop: 'zzlxdm', label: '证照类型', width: 150, dictFormatKey: 'license', sortable: true},
    {prop: 'zzhm', label: '证件号码', width: 150, sortable: true},
    {prop: 'zh', label: '冻结账卡号', width: 170, sortable: true},
    ...basicColumns,
    {prop: 'zhxh', label: '账户序号', width: 170, sortable: true},
    {prop: 'djfs', label: '冻结方式', width: 150, dictFormatKey: 'djfs', sortable: true},
    {prop: 'je', label: '金额', width: 150, sortable: true},
    {prop: 'bz', label: '币种', dictFormatKey: 'currency', sortable: true},
    {prop: 'kssj', label: '开始时间', width: 150, sortable: true},
    {prop: 'jssj', label: '结束时间', width: 150, sortable: true},
]

// 请求页面  展开表   紧急止付/解除止付  列字段
export const publicPaymentColumns: TableColumnInfo[] = [
    {prop: 'createTime', label: '数据日期', minWidth: 200, sortable: true},
    {prop: 'status', label: '请求处理状态', width: 150, dictFormatKey: 'reqProcessingStatus', sortable: true},
    {prop: 'rwlsh', label: '任务流水号', width: 230, sortable: true},
    {prop: 'yrwlsh', label: '原任务流水号', width: 230, sortable: true},
    {prop: 'zh', label: '账卡号', width: 170, sortable: true},
    ...basicColumns,
]

// 请求页面  展开表   调阅凭证图像  列字段
export const publicCertificateColumns: TableColumnInfo[] = [
    {prop: 'createTime', label: '数据日期', minWidth: 200, sortable: true},
    {prop: 'status', label: '请求处理状态', width: 150, dictFormatKey: 'reqProcessingStatus', sortable: true},
    {prop: 'rwlsh', label: '任务流水号', width: 230, sortable: true},
    {prop: 'cxzh', label: '查询账卡号', width: 170, sortable: true},
    {prop: 'cxzl', label: '查询种类', width: 150, sortable: true , dictFormatKey: 'cxzl'},
    {prop: 'jylsh', label: '交易流水号', width: 150, sortable: true},
    {prop: 'cxnr', label: '查询内容', width: 170, dictFormatKey: 'cxnr', sortable: true},
    ...basicColumns,
]
