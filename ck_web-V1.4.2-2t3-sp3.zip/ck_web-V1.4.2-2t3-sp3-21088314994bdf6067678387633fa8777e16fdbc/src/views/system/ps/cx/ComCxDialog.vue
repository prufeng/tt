<template>
  <el-dialog
    v-model="dialogData.visible"
    :title="dialogData.title"
    class="rk-dialog-default"
    @closed="closed"
    :close-on-click-modal="false"
    width="90%"
  >
    <rk-collapse-form
      v-if="reRender"
      ref="dialogFormRef"
      v-model="form"
      :collapse-model-value="activeCollapse"
      :disabled="dialogData.formDisabled"
      :form-items="formItemsDynamic"
    >
    </rk-collapse-form>

    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" v-if="btnVisible" @click="save" :loading="buttonLoading">保存</el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { ElButton, ElDialog } from 'element-plus'

import { RkFormInstance, useDialogForm } from 'riking-ui'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'

const reRender = ref(true)

const buttonLoading = ref(false)

const activeCollapse = ref([])

const formItemsDynamic = ref([])

const emits = defineEmits(['callback'])

const props = defineProps(['formItems', 'initFormValues'])

const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

defineExpose({ open, close })

onMounted(() => {
  formItemsDynamic.value = props.formItems
  form.value = props.initFormValues
})

const save = async () => {
  const valid = await dialogFormRef.value?.asyncValidate()
  if (!valid) {
    return
  }
  emits('callback', form.value)
  close()
}

/**
 *   t_ga_cx_general  当明细时段是03，明细起始日期和明细截至时间必填
 */
watch(
  () => form.value.mxsdlx,
  (val) => {
    const fields = ['mxqssj', 'mxjzsj']
    let temp = [...props.formItems]
    temp = temp.map((item) => {
      if (fields.includes(item.prop)) {
        item.rules[0].required = val === '03' ? true : false
        reRender.value = false
      }
      return item
    })
    formItemsDynamic.value = [...temp]
    nextTick(() => {
      reRender.value = true
    })
  },
  { deep: true },
)

//查看时证照类型代码、证照号码、主体名称必填
//查看时都不必填
// watch(
//   () => dialogData.title,
//   (newForm, oldForm) => {
//     if (newForm.includes('查看')) {
//       const fields = ['zzlx', 'ztmc', 'zzhm']
//       let temp = [...props.formItems]
//       temp = temp.map((item) => {
//         if (fields.includes(item.prop)) {
//           item.rules[0].required = true
//           reRender.value = false
//         }
//         return item
//       })
//       formItemsDynamic.value = [...temp]
//       nextTick(() => {
//         reRender.value = true
//       })
//     }
//   },
//   { deep: true },
// )
const btnVisible = computed(() => dialogData.title.includes('编辑') || dialogData.title.includes('新增'))
</script>

<style scoped></style>
