/**
 * 公安 请求页面 列字段与表单项配置
 */
import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {
    publicAccountColumns,
    publicCertificateColumns,
    publicDynamicColumns,
    publicFreezeColumns,
    publicPaymentColumns,
    publicTransactionColumns
} from "./publicColumns";
import {
    basicFormItems,
    personColumns,
    publicAccountFormItems,
    publicCertificateFormItems,
    publicDynamicFormItems,
    publicFreezeFormItems,
    publicPaymentFormItems,
    publicTransactionFormItems
} from "./publicForm";

/**
 * 公安 请求页面 列字段
 */
export const AccountColumns: TableColumnInfo[] = [
    ...publicAccountColumns.slice(0, 3), // 插入之前的项
    {prop: 'zzlx', label: '证照类型', width: 150, dictFormatKey: 'license', sortable: true}, // 要插入的项
    ...publicAccountColumns.slice(3), // 插入之后的项
];

export const TransactionColumns: TableColumnInfo[] = [
    ...publicTransactionColumns
];

export const DynamicColumns: TableColumnInfo[] = [
    ...publicDynamicColumns
];

export const FreezeColumns: TableColumnInfo[] = [
    ...publicFreezeColumns
];

export const PaymentColumns: TableColumnInfo[] = [
    ...publicPaymentColumns
];

export const CertificateColumns: TableColumnInfo[] = [
    ...publicCertificateColumns
];

/**
 * 公安 请求页面 表单项
 */
export const AccountFormItems: FormItemInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicAccountFormItems.slice(0, 2),
    {
        prop: 'zzlx',
        label: '证照类型代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{ required: false, message: '请选择证照类型', trigger: 'change' }],
    },
    ...publicAccountFormItems.slice(2),
    ...personColumns,
    {
        prop: 'qqrdwgzdh',
        label: '请求人单位工作电话',
        labelWidth: 150,
        // inputType: 'input',
        inputType: {tag: 'input', maxlength: '20' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人单位工作电话长度不可超过20'},{required: true, message: '请求人单位工作电话不能为空'}],
    },
    {
        prop: 'qqrdwzbdh',
        label: '请求人单位值班电话',
        labelWidth: 150,
        // inputType: 'input',
        inputType: {tag: 'input', maxlength: '20' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人单位值班电话长度不可超过20'},{required: true, message: '请求人单位值班电话不能为空'}],
    },
    {
        prop: 'qqrbadwmc',
        label: '请求人办案单位名称',
        labelWidth: 150,
        // inputType: 'input',
        inputType: {tag: 'input', maxlength: '50' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:50,message:'请求人办案单位名称长度不可超过50'},{required: true, message: '请求人办案单位名称不能为空'}],
    },
];

export const TransactionFormItems: FormItemInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicTransactionFormItems,
    ...personColumns
];

export const DynamicFormItems: FormItemInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicDynamicFormItems,
    ...personColumns,
    {
        prop: 'qqrdwgzdh',
        label: '请求人单位工作电话',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人单位工作电话长度不可超过20'},{required: true, message: '请求人单位工作电话不能为空'}],
    },
    {
        prop: 'qqrdwzbdh',
        label: '请求人单位值班电话',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人单位值班电话长度不可超过20'},{required: true, message: '请求人单位值班电话不能为空'}],
    },
    {
        prop: 'qqrbadwmc',
        label: '请求人办案单位名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:50,message:'请求人办案单位名称长度不可超过50'},{required: true, message: '请求人办案单位名称不能为空'}],
    },
];

export const FreezeFormItems: FormItemInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicFreezeFormItems,
    ...personColumns,
    {
        prop: 'qqrdwgzdh',
        label: '请求人单位工作电话',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人单位工作电话长度不可超过20'},{required: true, message: '请求人单位工作电话不能为空'}],
    },
    {
        prop: 'qqrdwzbdh',
        label: '请求人单位值班电话',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人单位值班电话长度不可超过20'},{required: true, message: '请求人单位值班电话不能为空'}],
    },
    {
        prop: 'qqrbadwmc',
        label: '请求人办案单位名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:50,message:'请求人办案单位名称长度不可超过50'},{required: true, message: '请求人办案单位名称不能为空'}],
    },
];

export const PaymentFormItems: FormItemInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicPaymentFormItems,
    ...personColumns,
    {
        prop: 'qqrdwgzdh',
        label: '请求人单位工作电话',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人单位工作电话长度不可超过20'},{required: true, message: '请求人单位工作电话不能为空'}],
    },
    {
        prop: 'qqrdwzbdh',
        label: '请求人单位值班电话',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人单位值班电话长度不可超过20'},{required: true, message: '请求人单位值班电话不能为空'}],
    },
    {
        prop: 'qqrbadwmc',
        label: '请求人办案单位名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:50,message:'请求人办案单位名称长度不可超过50'},{required: true, message: '请求人办案单位名称不能为空'}],
    },
];

export const CertificateFormItems: FormItemInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicCertificateFormItems,
    ...personColumns
];

