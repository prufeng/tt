import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
import {ElMessage} from "element-plus";
import {checkData, exportExcel, getImage, getPdf, getXml, impZip, downloadZip} from "@/views/system/ps/cx/api";
import {ref} from "vue";
import {expLoading} from "@/components/UpAndDown.vue";



// 线下请求单对话框组件实列引用
export const offlineDialogRef = ref();

let ids: string;
export const handleSelectionChange = async (val: any) => {
    ids = val.map((item: any) => item.id).join(",");
}

export const renderTableButtons = (reportCode) => {
    return [
        {
            key: 'download',
            label: '下载',
            tag: 'button',
            type: 'primary',
            icon: 'icon_download',
            handler: async () => {
                if (ids == undefined || ids.length == 0) {
                    ElMessage.warning('请先选择数据')
                    return
                }
                const result = await downloadZip(reportCode, ids);
                if (result.code == 500) {
                    ElMessage.error({message: result.data, grouping: true, showClose: true, duration: 0})
                }
            }
        },
        {
            key: 'add',
            label: '线下请求单',
            tag: 'button',
            type: 'primary',
            icon: 'icon_add',
            handler: async () => offlineDialogRef.value.open()
        },
    ]
}

export const formatDate = (date: Date) => {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

export const openXml = (xmlList, key: any) => {
    // 将base64字符串转换为Uint8Array对象
    console.log(xmlList[key])
    var xmlData = atob(xmlList[key]);
    var xmlArray = new Uint8Array(xmlData.length);
    for (var i = 0; i < xmlData.length; i++) {
        xmlArray[i] = xmlData.charCodeAt(i);
    }
    // 创建Blob对象
    var xmlBlob = new Blob([xmlArray], {type: 'text/xml'});
    // 将Blob对象转换为URL
    var xmlUrl = URL.createObjectURL(xmlBlob);
    let xmlWindow = window.open(xmlUrl, 'xml预览')
};

/**
 * 文件查看相关配置
 */
// 显示文件查看组件
export const viewerVisible = ref(false)
// 查询人证件url地址
export const urlList = ref([])
// 显示xml文件列表组件
export const fileDialogVisible = ref(false);
// xml文件
export const xmlList = ref({});
// xml文件名
export const xmlNames = ref({})
// 渲染行的文件操作按钮
export const renderFileActButtons: (row: any) => ButtonInfo[] = (row: any, reportCode: string) => [
    {
        key: 'viewPdf', label: '法律文书', tag: 'button', type: 'primary',
        handler: async () => {
            const result = await getPdf(reportCode, row);
            if (result.code == 500) {
                ElMessage.error({message: result.data, grouping: true, showClose: true, duration: 0})
                return
            }
            // let pdfWindow = window.open("", 'pdf预览');
            let pdfWindow = window.open("");
            // 将base64字符串转换为Uint8Array对象
            var pdfData = atob(result.data);
            var pdfArray = new Uint8Array(pdfData.length);
            for (var i = 0; i < pdfData.length; i++) {
                pdfArray[i] = pdfData.charCodeAt(i);
            }
            // 创建Blob对象
            var pdfBlob = new Blob([pdfArray], {type: 'application/pdf'});
            // 将Blob对象转换为URL
            var pdfUrl = URL.createObjectURL(pdfBlob);
            // 将URL作为iframe的src属性值
            pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>");
        }
    },
    {
        key: 'viewImage', label: '查询人证件', tag: 'button', type: 'primary',
        handler: async () => {
            const result = await getImage(reportCode, row);
            if (result.code == 500) {
                ElMessage.error({message: result.data, grouping: true, showClose: true, duration: 0})
                return
            }
            urlList.value = [];
            for (const image in result.data) {
                // 将base64字符串转换为Uint8Array对象
                var jpgData = atob(result.data[image]);
                var jpgArray = new Uint8Array(jpgData.length);
                for (var i = 0; i < jpgData.length; i++) {
                    jpgArray[i] = jpgData.charCodeAt(i);
                }
                // 创建Blob对象
                var jpgBlob = new Blob([jpgArray], {type: 'image/jpeg'});
                // 将Blob对象转换为URL
                var jpgUrl = URL.createObjectURL(jpgBlob);
                // 将URL作为iframe的src属性值
                viewerVisible.value = true;
                urlList.value = [...urlList.value, jpgUrl];
            }
        }
    },
    {
        key: 'viewXml', label: 'xml文件', tag: 'button', type: 'primary',
        handler: async () => {
            const result = await getXml(reportCode, row);
            xmlList.value = result.data;
            xmlNames.value = Object.keys(result.data);
            console.log(xmlNames.value);
            fileDialogVisible.value = true;
        }
    }
]

/**
 * 导入
 */
export const imp = async (data = {}, callback, reportCode: string) => {
    var needBeOverridden = await checkData(reportCode, data);
    if (needBeOverridden.data) {
        ElMessageBox.confirm(
            '检测到上传文件的请求单标识已存在,是否覆盖?',
            '提示',
            {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }
        )
            .then(async () => {
                await impZip(reportCode, data);
                ElMessage.success("覆盖成功");
                await callback;
            })
            .catch(() => {
                return
            })
    } else {
        await impZip(reportCode, data);
        ElMessage.success("导入成功");
        await callback;
    }
}

/**
 * 导出
 */
export const exp = async (searchFormValues, reportCode) => {
    expLoading.value = true;
    try {
        if (ids == undefined || ids.length == 0) {
            ids = ''
        }
        const newObject = {...searchFormValues};
        var branchCodeList = Array.from(searchFormValues.branchCodeList).join('-|-');
        await exportExcel(reportCode, ids, newObject, branchCodeList);
    } finally {
        expLoading.value = false;
    }
}

/**
 * 上传凭证图像
 */
export const uploadCertificate = () => {
    var elementById = document.getElementById("uploadButton");
    elementById.click();
}

/**
 * 根据请求报文的编号，获取反馈报文的编号
 */
export function getFeedbackCode(reportCode) {
    switch (reportCode) {
        case 'ps101':
            return 'ps201'
        case 'ps103':
            return 'ps203'
        case 'ps104':
            return 'ps204'
        case 'ps105':
            return 'ps205'
        case 'ps106':
            return 'ps206'
        case 'ps107':
            return 'ps207'
    }
}

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 50,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}
export const treePagination: Pagination = {
    currentPage: 1,
    pageSize: 8,
    pageSizes: [8, 16, 24, 32],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}