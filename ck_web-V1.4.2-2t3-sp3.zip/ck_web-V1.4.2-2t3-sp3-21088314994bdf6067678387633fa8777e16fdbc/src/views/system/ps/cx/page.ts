import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {getRequestClassificationCode, getSubSystem} from "@/utils/subSystem";

declare interface PageElements {
    columns: TableColumnInfo[]
    formItems: FormItemInfo[],
    searchFormItems: FormItemInfo[],
}

import * as pageConfigs from './ga';

export const derivedPageElements = () => {
    const requestClassificationCode = getRequestClassificationCode();
    const elements: PageElements = {formItems: [], searchFormItems: [], columns: []};

    switch (requestClassificationCode) {
        case 'ps101':
        case 'ps103':
            elements.columns = pageConfigs.AccountColumns;
            elements.formItems = pageConfigs.AccountFormItems;
            break;
        case 'ps104':
            elements.columns = pageConfigs.DynamicColumns;
            elements.formItems = pageConfigs.DynamicFormItems;
            break;
        case 'ps105':
            elements.columns = pageConfigs.FreezeColumns;
            elements.formItems = pageConfigs.FreezeFormItems;
            break;
        case 'ps106':
            elements.columns = pageConfigs.PaymentColumns;
            elements.formItems = pageConfigs.PaymentFormItems;
            break;
        default:
            break;
    }
    return elements
}

export const derivedCxPageElements = (reportCode: string) => {
    const elements: PageElements = {formItems: [], searchFormItems: [], columns: []};
    switch (reportCode) {
        case 'ps101':
        case 'ps103':
            elements.columns = pageConfigs.AccountColumns;
            elements.formItems = pageConfigs.AccountFormItems;
            break;
        case 'ps104':
            elements.columns = pageConfigs.DynamicColumns;
            elements.formItems = pageConfigs.DynamicFormItems;
            break;
        case 'ps105':
            elements.columns = pageConfigs.FreezeColumns;
            elements.formItems = pageConfigs.FreezeFormItems;
            break;
        case 'ps106':
            elements.columns = pageConfigs.PaymentColumns;
            elements.formItems = pageConfigs.PaymentFormItems;
            break;
        default:
            break;
    }
    return elements;
}

export const recordColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {key: 'id', type: 'expand', label: '展开', width: 50, minWidth: 50, scopedSlots: 'expand'},
    {prop: 'createTime', label: '数据日期', width: 150, sortable: true},
    {prop: 'fldm', label: '分类代码', width: 140, dictFormatKey: 'fldm', sortable: true},
    {prop: 'orgCode', label: '申请机构', width: 140, dictFormatKey: 'sqjgdm', sortable: true},
    {prop: 'qqdbs', label: '请求单标识', width: 190, sortable: true},
    {prop: 'importType', label: '导入方式', width: 80, dictFormatKey: 'importType', sortable: true},
    {prop: 'status', label: '文件处理状态', dictFormatKey: 'docProcessingStatus', width: 130, sortable: true},
    {prop: 'fileName', label: '文件名', width: 400, sortable: true},
    {prop: 'xmlFileName', label: 'XML文件名', width: 400, sortable: true},
    {prop: 'createBy', label: '创建人', sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'fileActions',
        minWidth: 230,
        fixed: 'right',
    },
]
export const recordSearchFormItems: FormItemInfo[] = [
    {prop: 'qqdbs', label: '请求单标识', labelWidth: 80, inputType: 'input'},
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'status',
        label: '文件处理状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'docProcessingStatus',}
    },
]

// 高级查询
export const advancedQueryItems = [
    {value: 'fldm', label: '分类代码', width: 140, sortable: true, inputType: {tag: 'select', options: 'fldm',}},
    {value: 'orgCode', label: '申请机构', width: 140, sortable: true, inputType: {tag: 'select', options: 'sqjgdm',}},
    {value: 'qqdbs', label: '请求单标识', width: 190, sortable: true},
    {
        value: 'importType',
        label: '导入方式',
        width: 80,
        sortable: true,
        inputType: {tag: 'select', options: 'importType'}
    },
    // {value: 'status', label: '文件处理状态', width: 130, sortable: true, inputType: {tag: 'select', options: 'docProcessingStatus',}},
    {value: 'fileName', label: '文件名', width: 400, sortable: true},
    {value: 'xmlFileName', label: 'XML文件名', width: 400, sortable: true},
    {value: 'createBy', label: '创建人', sortable: true},
    {
        value: 'createTime',
        label: '数据日期',
        labelWidth: 80,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ]
    },
]































