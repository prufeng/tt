/**
 * 公安 反馈页面 列字段与表单项配置
 */
import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {
    publicCertificateImageParentsColumns,
    publicCustomerParentsColumns,
    publicFkAccountColumns, publicFkFinancialColumns, publicFkFinancialMeasureColumns, publicFkFreezeColumns,
    publicFkFreezeDetailColumns,
    publicFkMeasureColumns,
    publicFkPaymentDetailColumns,
    publicFkPriorityColumns,
    publicFkSubAccountColumns,
    publicFkTransactionColumns,
    publicPaymentParentsColumns,
    publicTransactionParentsColumns,
    publicZhParentsColumns
} from "./publicColumns";
import {
    publicCertificateImageSearchItems,
    publicCustomerSearchItems, publicPaymentSearchItems,
    publicTransactionSearchItems, publicZhSearchItems,
} from "./publicSearchItems";
import {
    publicFkAccountFormItems,
    publicFkCertificateFormItems,
    publicFkCustomerFormItems,
    publicFkCustomerFormItems2,
    publicFkDynamicFormItems,
    publicFkDynamicReceiptFormItems,
    publicFkFinancialFormItems,
    publicFkFinancialMeasureFormItems,
    publicFkFreezeDetailFormItems,
    publicFkFreezeFormItems,
    publicFkMeasureFormItems,
    publicFkPaymentDetailFormItems,
    publicFkPaymentFormItems,
    publicFkPriorityFormItems,
    publicFkSubAccountFormItems,
    publicFkTransactionFormItems
} from "./publicForm";
import {dateFormatter} from "@/utils/utils";
import moment from "moment";


/**
 * 公安 反馈页面 列字段
 */

/*
 * 公安 反馈页面 列字段  主表部分
 */

// 账户信息页面  账户信息与交易明细页面
export const customerParentsColumns: TableColumnInfo[] = [
    ...publicCustomerParentsColumns,
    { prop: 'xb', label: '性别', minWidth: 210   ,dictFormatKey:'xbdm',  sortable: true},
    { prop: 'jg', label: '籍贯', minWidth: 210   ,sortable: true},
    { prop: 'mz', label: '民族', minWidth: 210   ,dictFormatKey:'mzdm',sortable: true},
    { prop: 'csrq', label: '出生日期', minWidth: 210 , formatter:(row: any) => row.csrq?moment(row.csrq).format('YYYY-MM-DD'):''  ,sortable: true},
    { prop: 'gj', label: '国籍', minWidth: 210   ,dictFormatKey:'gjdm',sortable: true},
    { prop: 'zy', label: '职业', minWidth: 210   ,sortable: true},
    { prop: 'dbrlxfs', label: '代办人联系方式', minWidth: 210   ,sortable: true},
];
// 交易明细页面
export const transactionParentsColumns: TableColumnInfo[] = [
    ...publicTransactionParentsColumns
];
//动态查询回执 动态查询
export const zhParentsColumns: TableColumnInfo[] = [
    ...publicZhParentsColumns
];
// 冻结页面
export const freezeColumns: TableColumnInfo[] = [
    ...publicFkFreezeColumns
];

//止付页面
export const paymentParentsColumns: TableColumnInfo[] = [
    ...publicPaymentParentsColumns
];
//调阅凭证页面
export const certificateImageParentsColumns: TableColumnInfo[] = [
    { prop: 'cxzh', label: '查询账号', width: 170 ,sortable: true},
    ...publicCertificateImageParentsColumns
];

/*
 * 公安 反馈页面 列字段  子表部分
 */
//账户信息 子表
export const fkAccountColumns: TableColumnInfo[] = [
    ...publicFkAccountColumns
]
export const fkAccountColumns2: TableColumnInfo[] = [
    ...publicFkAccountColumns.slice(0,9),
    ...publicFkAccountColumns.slice(10),
]
//强制措施信息 子表
export const fkMeasureColumns: TableColumnInfo[] = [
    ...publicFkMeasureColumns
]
// 金融资产信息 子表
export const fkFinancialColumns: TableColumnInfo[] = [
    ...publicFkFinancialColumns
]
// 金融资产强制措施 子表
export const fkFinancialMeasureColumns: TableColumnInfo[] = [
    ...publicFkFinancialMeasureColumns
]
//共享权\优先权信息 子表
export const fkPriorityColumns: TableColumnInfo[] = [
    ...publicFkPriorityColumns
]
//关联子账户 子表
export const fkSubAccountColumns: TableColumnInfo[] = [
    ...publicFkSubAccountColumns
]
//交易明细 子表
export const fkTransactionColumns: TableColumnInfo[] = [
    ...publicFkTransactionColumns
]
//冻结明细 子表
export const fkFreezeDetailColumns: TableColumnInfo[] = [
    ...publicFkFreezeDetailColumns
]
//止付明细 子表
export const fkPaymentDetailColumns: TableColumnInfo[] = [
    ...publicFkPaymentDetailColumns
]

/**
 * 公安 反馈页面 表单项
 */

/**反馈页面 Form配置 主表部分 */
// 账户信息页面  账户信息与交易明细页面
export const fkCustomerFormItems: FormItemInfo[] = [
    ...publicFkCustomerFormItems.slice(0,1),
    {
        prop: 'zzlx',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            // disabled:true
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '证件类型必填' }]
    },
    ...publicFkCustomerFormItems.slice(1)
]
// 账户信息页面  账户信息与交易明细页面2 SS05与SS06
export const fkCustomerFormItems2: FormItemInfo[] = [
    ...publicFkCustomerFormItems2.slice(0,1),
    {
        prop: 'zzlx',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            // disabled: true
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '证件类型必填' }]
    },
    ...publicFkCustomerFormItems2.slice(1)
]
// 交易明细页面
export const fkTransactionFormItems: FormItemInfo[] = [
    ...publicFkTransactionFormItems.slice(0,11),
    {
        prop: 'jydfzkh',
        label: '交易对方账卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 50, message: '交易对方账卡号最大长度为50' }],
    },
    {
        prop: 'jydfzkhlx',
        label: '交易对方帐卡号类型',
        labelWidth: 150,
        // inputType: {tag: 'input', maxlength: '10' },
        inputType: {
            tag: 'select',
            options: 'jydfzkhlx',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 10, message: '交易对方帐卡号类型最大长度为10' }],
    },
    ...publicFkTransactionFormItems.slice(11)
]
//动态查询执行回执
export const fkDynamicReceiptFormItems: FormItemInfo[] = [
    ...publicFkDynamicReceiptFormItems
]
//动态查询
export const fkDynamicFormItems: FormItemInfo[] = [
    ...publicFkDynamicFormItems.slice(0,13),
    {
        prop: 'jdbz',
        label: '借贷标志',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'jdbz',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 4, message: '借贷标志最大长度为4' },{ required: true, message: '借贷标志必填' }],
    },
    {
        prop: 'jydfzkh',
        label: '交易对方账卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 50, message: '交易对方账卡号最大长度为50' }],
    },{
        prop: 'jydfzkhlx',
        label: '交易对方账卡号类型',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '40' },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 40, message: '交易对方账卡号类型最大长度为40' }],
    },
    ...publicFkDynamicFormItems.slice(13)
]
//冻结解冻续冻
export const fkFreezeFormItems: FormItemInfo[] = [
    ...publicFkFreezeFormItems
]
//紧急止付\解除止付
export const fkPaymentFormItems: FormItemInfo[] = [
    ...publicFkPaymentFormItems.slice(0, 1),
    ...publicFkPaymentFormItems.slice(2, 6),
    {
        prop: 'zxqssj',
        label: '执行起始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {required: false,message:'必填'},
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
];
//调阅凭证图像
export const fkCertificateFormItems: FormItemInfo[] = [
    ...publicFkCertificateFormItems
]



/**反馈页面 Form配置 子表部分 */
//账户信息 子表
export const fkAccountFormItems: FormItemInfo[] = [
    ...publicFkAccountFormItems
]
export const fkAccountFormItems2: FormItemInfo[] = [
    ...publicFkAccountFormItems.slice(0,14),
    ...publicFkAccountFormItems.slice(15),
]
// 金融资产信息 子表
export const fkFinancialFormItems: FormItemInfo[] = [
    ...publicFkFinancialFormItems
]
// 金融资产强制措施 子表
export const fkFinancialMeasureFormItems: FormItemInfo[] = [
    ...publicFkFinancialMeasureFormItems
]
//强制措施信息 子表
export const fkMeasureFormItems: FormItemInfo[] = [
    ...publicFkMeasureFormItems
]
//共享权\优先权信息 子表
export const fkPriorityFormItems: FormItemInfo[] = [
    ...publicFkPriorityFormItems
]
//关联子账户 子表
export const fkSubAccountFormItems: FormItemInfo[] = [
    ...publicFkSubAccountFormItems
]
//交易明细 子表
//交易明细 子表和主表共用一个表单项


//冻结明细 子表
export const fkFreezeDetailFormItems: FormItemInfo[] = [
    ...publicFkFreezeDetailFormItems
]
//止付明细 子表
export const fkPaymentDetailFormItems: FormItemInfo[] = [
    ...publicFkPaymentDetailFormItems
]






/**
 * 公安 反馈页面 条件查询搜索框
 */

// 账户信息页面  账户信息与交易明细页面
export const customerSearchItems: FormItemInfo[] = [
    ...publicCustomerSearchItems
];
// 交易明细页面
export const transactionSearchItems: FormItemInfo[] = [
    ...publicTransactionSearchItems
];
//动态查询回执 动态查询 冻结页面
export const zhSearchItems: FormItemInfo[] = [
    ...publicZhSearchItems
];
//止付页面
export const paymentSearchItems: FormItemInfo[] = [
    ...publicPaymentSearchItems
];
//调阅凭证页面
export const certificateImageSearchItems: FormItemInfo[] = [
    ...publicCertificateImageSearchItems
];
