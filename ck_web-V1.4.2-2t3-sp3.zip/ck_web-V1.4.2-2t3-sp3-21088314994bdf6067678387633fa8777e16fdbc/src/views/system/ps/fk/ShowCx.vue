<template>
  <rk-collapse-form
      :form-items="formItems"
      :collapse-model-value="activeCollapse"
      v-model="form"
      disabled="true"
      ref="nameRef"
  >
  </rk-collapse-form>

  <div class="btnDiv">
    <rk-button-group :buttons="genFileActButtons(recordData)" :route-meta="[]"/>
  </div>

  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button v-for="xmlKey in xmlButtonKeys" :key="xmlKey" type="primary" link
               style=" margin-bottom: 10px;   display: flex;  flex-direction: column;" @click="openXml(xmlKey)">
      {{ xmlKey }}
    </el-button>
  </el-dialog>

  <div class="img-viewer-box">
    <el-image-viewer v-if="showImageViewer" :url-list="urlList" @close="() => {showImageViewer   = false}"/>
  </div>

</template>

<script lang="ts">
import {ref} from "vue";
import {ElButton, ElDialog, ElImageViewer, ElMessage} from "element-plus";

import {ButtonInfo} from "riking-ui";
import configs, { setRequiredRule, setRequiredRuleFalse, setRequiredRuleMessage } from '@/views/system/sum';
import {derivedCxPageElements} from "@/views/system/ps/cx/page";
import {getImage, getPdf, getXml, listOne} from "@/views/system/ps/cx/api";
import {listRecord} from "@/views/system/ps/fk/api";
</script>

<script setup lang="ts">


const activeCollapse = ref([])

const loading = ref(false)
const form = ref({})
const recordData = ref({})
const nameRef = ref()
const dialogVisible = ref(false);
const xmlButtonKeys = ref({});
const xmlDataList = ref({});
const showImageViewer = ref(false) //组件是否显示
const urlList = ref([]) //图片List
const emit = defineEmits(['djfsValueSent']);
const props = defineProps(['fkReportCode', 'visible', 'qqdbs', 'rwlsh']);

const reportCode = configs.reportCodeMap.get(props.fkReportCode)

const djfs = ref('');
defineExpose({djfs})

let pageElements = derivedCxPageElements(reportCode);
let formItems = pageElements.formItems;
//查看cx信息时，必填校改为空
setRequiredRuleFalse([], formItems)

formItems.map(item => {
  if (item.extra.collapse.title.includes('请求')) {
    return;
  }
  const title = '请求' + item.extra.collapse.title;
  item.extra.collapse.title = title;
})

onMounted(() => {
  activeCollapse.value = [];
  search();
})

watch(() => props.visible, (newVal) => {
  if (newVal) {
    clear();
    search();
  }
})

const search = async () => {
  loading.value = true;
  try {
    //查反馈数据对应的请求表数据
    const result = await listOne(reportCode, {'qqdbs': props.qqdbs, 'rwlsh': props.rwlsh});
    if(result.data.length==0){
      return
    }
    form.value = result.data;
    djfs.value = result.data.djfs;
    emit('djfsValueSent', result.data.djfs);
    //查这条反馈数据的附件表
    const record = await listRecord(reportCode, {'qqdbs': props.qqdbs,fldm:result.data.fldm});
    recordData.value =record.data
  } finally {
    loading.value = false
  }
}

const genFileActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'viewPdf', label: '法律文书', tag: 'button', type: 'primary',
    handler: async () => {
      const result = await getPdf(reportCode, row);
      if (result.code == 500) {
        ElMessage.error({message:result.data, grouping: true, showClose: true, duration: 0})
        return
      }
      // let pdfWindow = window.open("", 'pdf预览');
      let pdfWindow = window.open("");
      // 将base64字符串转换为Uint8Array对象
      var pdfData = atob(result.data);
      var pdfArray = new Uint8Array(pdfData.length);
      for (var i = 0; i < pdfData.length; i++) {
        pdfArray[i] = pdfData.charCodeAt(i);
      }
      // 创建Blob对象
      var pdfBlob = new Blob([pdfArray], {type: 'application/pdf'});
      // 将Blob对象转换为URL
      var pdfUrl = URL.createObjectURL(pdfBlob);
      // 将URL作为iframe的src属性值
      pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>");
    }
  },
  {
    key: 'viewImage', label: '查询人证件', tag: 'button', type: 'primary',
    handler: async () => {
      const result = await getImage(reportCode, row);
      if (result.code == 500) {
        ElMessage.error({message:result.data, grouping: true, showClose: true, duration: 0})
        return
      }
      urlList.value = [];
      for (const image in result.data) {
        // 将base64字符串转换为Uint8Array对象
        var jpgData = atob(result.data[image]);
        var jpgArray = new Uint8Array(jpgData.length);
        for (var i = 0; i < jpgData.length; i++) {
          jpgArray[i] = jpgData.charCodeAt(i);
        }
        // 创建Blob对象
        var jpgBlob = new Blob([jpgArray], {type: 'image/jpeg'});
        // 将Blob对象转换为URL
        var jpgUrl = URL.createObjectURL(jpgBlob);
        // 将URL作为iframe的src属性值
        showImageViewer.value = true;
        urlList.value = [...urlList.value,jpgUrl];
      }
    }
  },
  {
    key: 'viewXml', label: 'xml文件', tag: 'button', type: 'primary',
    handler: async () => {
      const result = await getXml(reportCode, row);
      const keys = Object.keys(result.data);
      xmlButtonKeys.value = keys;
      xmlDataList.value = result.data;
      console.log(keys);
      dialogVisible.value = true;
    }
  }
]

const openXml = (key: any) => {
  // 将base64字符串转换为Uint8Array对象
  console.log(xmlDataList.value[key])
  var xmlData = atob(xmlDataList.value[key]);
  var xmlArray = new Uint8Array(xmlData.length);
  for (var i = 0; i < xmlData.length; i++) {
    xmlArray[i] = xmlData.charCodeAt(i);
  }
  // 创建Blob对象
  var xmlBlob = new Blob([xmlArray], {type: 'text/xml'});
  // 将Blob对象转换为URL
  var xmlUrl = URL.createObjectURL(xmlBlob);
  let xmlWindow = window.open(xmlUrl, 'xml预览')
};

function clear() {
  nameRef.value?.clearValidate();
}

</script>


<style scoped>
.btnDiv {
  margin: 20px 0 20px 0;
  display: flex;
  flex-direction: row;
}
</style>
