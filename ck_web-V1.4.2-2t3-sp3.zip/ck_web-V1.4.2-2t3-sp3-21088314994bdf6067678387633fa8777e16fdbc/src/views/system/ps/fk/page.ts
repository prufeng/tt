import {FormItemInfo, TableColumnInfo} from "riking-ui";
import * as pageConfig from './ga';

declare interface PageElements {
    formItems: TableColumnInfo[],
    formItems2: TableColumnInfo[],
    columns: FormItemInfo[],
    subTables: TableColumnInfo[],
    subTables2: TableColumnInfo[],
    searchItems: FormItemInfo[],
}

declare interface PageParentsElements {
    cxParentsFormItems: FormItemInfo[],
    kzParentsFormItems: FormItemInfo[],
}

export const derivedPageElements = (key: string, djfs: string) => {
    const elements: PageElements = {
        formItems: [],
        formItems2: [],
        columns: [],
        subTables: [],
        subTables2: [],
        searchItems: []
    };
    switch (key) {
        case 'ps201':
            elements.columns = pageConfig.customerParentsColumns;
            elements.formItems = [{name: "客户信息", items: pageConfig.fkCustomerFormItems}];
            elements.formItems2 = [{name: "客户信息", items: pageConfig.fkCustomerFormItems2}];
            elements.subTables = [
                {
                    name: "账户信息",
                    items: pageConfig.fkAccountFormItems,
                    columns: pageConfig.fkAccountColumns,
                    listName: "psFkAccount"
                },
                {
                    name: "强制措施",
                    items: pageConfig.fkMeasureFormItems,
                    columns: pageConfig.fkMeasureColumns,
                    listName: "psFkMeasure"
                },
                {
                    name: "共有权/优先权",
                    items: pageConfig.fkPriorityFormItems,
                    columns: pageConfig.fkPriorityColumns,
                    listName: "psFkPriority"
                },
                {
                    name: "关联子账户",
                    items: pageConfig.fkSubAccountFormItems,
                    columns: pageConfig.fkSubAccountColumns,
                    listName: "psFkSubAccount"
                },
                {
                    name: "金融资产信息",
                    items: pageConfig.fkFinancialFormItems,
                    columns: pageConfig.fkFinancialColumns,
                    listName: "psFkFinancial"
                },
                {
                    name: "金融资产强制措施",
                    items: pageConfig.fkFinancialMeasureFormItems,
                    columns: pageConfig.fkFinancialMeasureColumns,
                    listName: "psFkFinancialMeasure"
                },
            ]
            elements.subTables2 = [
                {
                    name: "账户信息",
                    items: pageConfig.fkAccountFormItems2,
                    columns: pageConfig.fkAccountColumns2,
                    listName: "psFkAccount"
                },
            ]
            elements.searchItems = [...pageConfig.fkCustomerFormItems2
                .filter(item => item.label !== '业务操作机构' && item.label !== '部门编码')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType == 'input' ? 'input' : {
                            ...item.inputType,
                            disabled: false
                        },
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems]
            break;
        case 'ps203':
            elements.columns = pageConfig.customerParentsColumns;
            elements.formItems = [{name: "客户信息", items: pageConfig.fkCustomerFormItems}];
            elements.formItems2 = [{name: "客户信息", items: pageConfig.fkCustomerFormItems2}];
            elements.subTables = [
                {
                    name: "账户信息",
                    items: pageConfig.fkAccountFormItems,
                    columns: pageConfig.fkAccountColumns,
                    listName: "psFkAccount"
                },
                {
                    name: "强制措施",
                    items: pageConfig.fkMeasureFormItems,
                    columns: pageConfig.fkMeasureColumns,
                    listName: "psFkMeasure"
                },
                {
                    name: "共有权/优先权",
                    items: pageConfig.fkPriorityFormItems,
                    columns: pageConfig.fkPriorityColumns,
                    listName: "psFkPriority"
                },
                {
                    name: "关联子账户",
                    items: pageConfig.fkSubAccountFormItems,
                    columns: pageConfig.fkSubAccountColumns,
                    listName: "psFkSubAccount"
                },
                {
                    name: "交易明细",
                    items: pageConfig.fkTransactionFormItems,
                    columns: pageConfig.fkTransactionColumns,
                    listName: "psFkTransaction"
                },
                {
                    name: "金融资产信息",
                    items: pageConfig.fkFinancialFormItems,
                    columns: pageConfig.fkFinancialColumns,
                    listName: "psFkFinancial"
                },
                {
                    name: "金融资产强制措施",
                    items: pageConfig.fkFinancialMeasureFormItems,
                    columns: pageConfig.fkFinancialMeasureColumns,
                    listName: "psFkFinancialMeasure"
                },
            ];
            elements.subTables2 = [
                {
                    name: "账户信息",
                    items: pageConfig.fkAccountFormItems2,
                    columns: pageConfig.fkAccountColumns2,
                    listName: "psFkAccount"
                },
                {
                    name: "交易明细",
                    items: pageConfig.fkTransactionFormItems,
                    columns: pageConfig.fkTransactionColumns,
                    listName: "psFkTransaction"
                }
            ];
            elements.searchItems = [...pageConfig.fkCustomerFormItems
                .filter(item => item.label !== '业务操作机构' && item.label !== '部门编码')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType == 'input' ? 'input' : {
                            ...item.inputType,
                            disabled: false
                        },
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems];
            break;
        case 'ps204':
            elements.columns = pageConfig.zhParentsColumns;
            elements.formItems = [{name: "动态查询", items: pageConfig.fkDynamicFormItems}];
            elements.subTables = [];
            elements.searchItems = [...pageConfig.fkDynamicFormItems
                .filter(item => item.label !== '业务操作机构' && item.label !== '部门编码')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType == 'input' ? 'input' : {
                            ...item.inputType,
                            disabled: false
                        },
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems];
            break;
        case 'ps205':
            elements.columns = pageConfig.freezeColumns;
            var fkFreezeFormItemList = pageConfig.fkFreezeFormItems;
            // if (djfs == '02') {
            //     fkFreezeFormItemList.forEach((item: any) => {
            //         if (item.label == '执行冻结金额' || item.label == '未冻结金额') {
            //             item.inputType.disabled = true;
            //         }
            //     });
            // } else {
            //     fkFreezeFormItemList.forEach((item: any) => {
            //         if (item.label == '执行冻结金额' || item.label == '未冻结金额') {
            //             item.inputType.disabled = false;
            //         }
            //     });
            // }
            elements.formItems = [{name: "冻结/续冻/解冻", items: pageConfig.fkFreezeFormItems}];
            elements.subTables = [{
                name: "冻结/续冻/解冻明细",
                items: pageConfig.fkFreezeDetailFormItems,
                columns: pageConfig.fkFreezeDetailColumns,
                listName: "psFkFreezeDetail"
            }];
            elements.searchItems = [...pageConfig.fkFreezeFormItems
                .filter(item => item.label !== '业务操作机构' && item.label !== '部门编码')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType == 'input' ? 'input' : {
                            ...item.inputType,
                            disabled: false
                        },
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems];
            break;
        case 'ps206':
            elements.columns = pageConfig.paymentParentsColumns;
            elements.formItems = [{name: "紧急止付/解除止付", items: pageConfig.fkPaymentFormItems}];
            elements.subTables = [
                {
                    name: "紧急止付/解除止付明细",
                    items: pageConfig.fkPaymentDetailFormItems,
                    columns: pageConfig.fkPaymentDetailColumns,
                    listName: "psFkPaymentDetail"
                }
            ];
            elements.searchItems = [...pageConfig.fkPaymentFormItems
                .filter(item => item.label !== '业务操作机构' && item.label !== '部门编码')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType == 'input' ? 'input' : {
                            ...item.inputType,
                            disabled: false
                        },
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems];
            break;
        case 'ps207':
            elements.columns = pageConfig.zhParentsColumns;
            elements.formItems = [{name: "动态查询执行回执", items: pageConfig.fkDynamicReceiptFormItems}];
            elements.subTables = [];
            elements.searchItems = [...pageConfig.fkDynamicReceiptFormItems
                .filter(item => item.label !== '业务操作机构' && item.label !== '部门编码')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType == 'input' ? 'input' : {
                            ...item.inputType,
                            disabled: false
                        },
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems];
            break;
    }
    return elements;
}
export const derivedPageParentsElements = (key: string) => {
    const parentsElements: PageParentsElements = {cxParentsFormItems: [], kzParentsFormItems: []};
    switch (key) {
        case 'ps201':
            parentsElements.cxParentsFormItems = cxParentsFormItems;
            break;
        case 'ps203':
            parentsElements.cxParentsFormItems = cxParentsFormItems;
            break;
        case 'ps204':
            parentsElements.kzParentsFormItems = kzParentsFormItems;
            break;
        case 'ps205':
            parentsElements.kzParentsFormItems = kzParentsFormItems;
            break;
        case 'ps206':
            parentsElements.kzParentsFormItems = kzParentsFormItems;
            break;
        case 'ps207':
            parentsElements.kzParentsFormItems = kzParentsFormItems;
            break;
    }
    return parentsElements;
}

export const cxParentsFormItems: FormItemInfo[] = [
    {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
        },

    },
    {
        prop: 'sqjgdm',
        label: '申请机构',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'sqjgdm',
        },
    },
    {
        prop: 'mbjgdm',
        label: '目标机构代码',
        labelWidth: 100,
        inputType: "input",
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
    },
]
export const kzParentsFormItems: FormItemInfo[] = [
    {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
        },

    },
    {
        prop: 'sqjgdm',
        label: '申请机构',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'sqjgdm',
        },
    },
    {
        prop: 'mbjgdm',
        label: '目标机构代码',
        labelWidth: 100,
        inputType: "input",
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
    },
    {
        prop: 'qqcslx',
        label: '措施类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'qqcslx',
            multiple: false,
        },
    },
    {
        prop: 'yrwlsh',
        label: '原任务流水号',
        labelWidth: 100,
        inputType: "input",
    },
]
export const recordSearchFormItems: FormItemInfo[] = [
    {prop: 'qqdbs', label: '请求单标识', labelWidth: 80, inputType: 'input'},
    {prop: 'rwlsh', label: '任务流水号', labelWidth: 80, inputType: 'input'},
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 80,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'status',
        label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
            // multiple: true,
            // collapseTags: true
        },
        labelWidth: 80,
    },
    {
        prop: 'onlyQuerySucceeded',
        label: '匹配成功',
        labelWidth: 80,
        inputType: {tag:'checkbox'},
        // inputType: {tag: 'checkbox', checked: "checked"},
    }
]

const publicAdvancedQueryItems = [
    {value: 'qqdbs', label: '请求单标识', labelWidth: 80, inputType: 'input'},
    {value: 'status', label: '状态', width: 140, sortable: true, inputType: {tag: 'select', options: 'dataStatus',}},
    {value: 'fldm', label: '分类代码', width: 140, sortable: true, inputType: {tag: 'select', options: 'fldm',}},
    {value: 'rwlsh', label: '任务流水号', labelWidth: 80, inputType: 'input'},
    {value: 'department_code', label: '部门编码', labelWidth: 80, inputType: 'input'},

    {value: 'deleteState', label: '删除状态', inputType: {tag: 'select', options: 'deleteStatusList'}, labelWidth: 100},
    {value: 'create_by', label: '创建人', labelWidth: 80, inputType: 'input'},
    {
        value: 'create_time',
        label: '数据日期',
        labelWidth: 80,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ]
    },
    {value: 'update_by', label: '修改人', labelWidth: 80, inputType: 'input'},
    {
        value: 'update_time',
        label: '修改时间',
        labelWidth: 80,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ]
    },
    {value: 'submit_by', label: '提交人', labelWidth: 80, inputType: 'input'},
    {
        value: 'submit_time',
        label: '提交时间',
        labelWidth: 80,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ]
    },
    {value: 'approve_by', label: '审核人', labelWidth: 80, inputType: 'input'},
    {
        value: 'approve_time',
        label: '审核时间',
        labelWidth: 80,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
        ]
    },
]
export const isExpPathArray = ref<any[]>([])
export const isExpSubSystemArray = ref<any[]>([])
