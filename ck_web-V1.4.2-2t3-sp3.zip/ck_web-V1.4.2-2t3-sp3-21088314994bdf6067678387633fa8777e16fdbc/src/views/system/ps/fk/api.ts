import {RS} from 'riking-ui'
import service from '@/utils/request'
import {getRequestClassificationCode, getSubSystem} from "@/utils/subSystem";

function getCommonParams() {
    const subSystem: string = getSubSystem();
    const requestClassificationCode: string | string[] = getRequestClassificationCode();
    const commonParams = {subSystem, requestClassificationCode};
    return commonParams;
}

function getCommonParams1(name : string) {
    const subSystem: string = getSubSystem();
    const requestClassificationCode: string | string[] = name;
    const commonParams = {subSystem, requestClassificationCode};
    return commonParams;
}


export function listBusinessLine(): Promise<RS> {
    return service({
        url: `/dict/listBusinessLine`,
        method: 'GET',
        params: {subSystem: getSubSystem()}
    })
}

export function list(reportCode: string, data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/${reportCode}/list`,
        method: 'POST',
        data,
        params: {current, size, ...getCommonParams()}
    })
}

export function listSub(reportCode: string, data = {}, current: number, size: number, rwlsh:string, khbh:string,branchCode:string): Promise<RS> {
    return service({
        url: `/${reportCode}/listSub`,
        method: 'POST',
        data,
        params: {current, size, rwlsh ,khbh,branchCode,  ...getCommonParams1("")}
    })
}
export function listRecord(reportCode: string, data = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/listRecord`,
        method: 'POST',
        data,
    })
}

export function saveData(reportCode: string, data = {},fldm:string): Promise<RS> {
    return service({
        url: `/${reportCode}/save`,
        method: 'POST',
        data,
        params: {...getCommonParams(),fldm}
    })
}
export function subSaveData(reportCode: string, data = {}, name:string): Promise<RS> {
    return service({
        url: `/${name}/save`,
        method: 'POST',
        data,
        params: getCommonParams1(name)
    })
}
export function updateData(reportCode: string, data = {}): Promise<RS> {
    const dataCopy = JSON.parse(JSON.stringify(data));
    if('beiz' in dataCopy && dataCopy.beiz !== null) {
        dataCopy.beiz = dataCopy.beiz.replace('>', '&gt;')
        dataCopy.beiz = dataCopy.beiz.replace('<', '&lt;')
    }

    return service({
        url: `/${reportCode}/update`,
        method: 'POST',
        data: dataCopy,
        params: getCommonParams()
    })
}
export function subUpdateData(reportCode: string, data = {}, name:string): Promise<RS> {
    const dataCopy = JSON.parse(JSON.stringify(data));
    if('beiz' in dataCopy && dataCopy.beiz !== null) {
        dataCopy.beiz = dataCopy.beiz.replace('>', '&gt;')
        dataCopy.beiz = dataCopy.beiz.replace('<', '&lt;')
    }
    if('jyzy' in dataCopy) {
        dataCopy.jyzy = dataCopy.jyzy.replace('>', '&gt;')
        dataCopy.jyzy = dataCopy.jyzy.replace('<', '&lt;')
    }

    return service({
        url: `/${name}/update`,
        method: 'POST',
        data: dataCopy,
        params: getCommonParams1(name)
    })
}

export function submitBatch(data:any,reportCode: string, ids:any): Promise<RS> {
    const dataCopy = JSON.parse(JSON.stringify(data));
    if('beiz' in dataCopy && dataCopy.beiz !== null) {
        dataCopy.beiz = dataCopy.beiz.replace('>', '&gt;')
        dataCopy.beiz = dataCopy.beiz.replace('<', '&lt;')
    }

    return service({
        url: `/${reportCode}/submit`,
        method: 'POST',
        data: dataCopy,
        params: {ids, ...getCommonParams()},
    })
}

export function subSubmitBatch(reportCode: string, ids:any,name:string): Promise<RS> {
    return service({
        url: `/${name}/submit`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}

export function auditBatch(reportCode: string, ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/audit`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}

export function auditNotPassBatch(reportCode: string, ids: any,msg:any): Promise<RS> {
    return service({
        url: `/${reportCode}/auditNotPass`,
        method: 'POST',
        params: {ids,msg, ...getCommonParams()},
    })
}

export function subAuditBatch(reportCode: string, ids: any,name:string): Promise<RS> {
    return service({
        url: `/${name}/audit`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}

export function subAuditNotPassBatch(reportCode: string, ids: any,name:string,msg:any): Promise<RS> {
    return service({
        url: `/${name}/auditNotPass`,
        method: 'POST',
        params: {ids, msg,...getCommonParams1(name)},
    })
}

export function resetBatch(reportCode: string, ids: any,msg:string): Promise<RS> {
    return service({
        url: `/${reportCode}/reset`,
        method: 'POST',
        params: {ids, ...getCommonParams(),msg},
    })
}

export function subResetBatch(reportCode: string, ids: any ,name:string,msg:string): Promise<RS> {
    return service({
        url: `/${name}/reset`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name),msg},
    })
}

export function recallBatch(reportCode: string, ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/recall`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}

export function subRecallBatch(reportCode: string, ids: any ,name:string): Promise<RS> {
    return service({
        url: `/${name}/recall`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}

export function delBatch(reportCode: string, ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/del`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}
export function delBatchAudit(reportCode: string,ids: any): Promise<RS> {
    return service({
        url: `/${reportCode}/delAudit`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}
export function delAuditNotPass(reportCode: string, ids: any, msg:string): Promise<RS> {
    return service({
        url: `/${reportCode}/delAuditNotPass`,
        method: 'POST',
        params: {ids, msg, ...getCommonParams()},
    })
}

export function subDelBatch(reportCode: string, ids: any, name:string): Promise<RS> {
    return service({
        url: `/${name}/del`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}
export function subDelBatchAudit(reportCode: string, ids: any, name:string): Promise<RS> {
    return service({
        url: `/${name}/delAudit`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}
export function subDelBatchAuditNotPass(reportCode: string, ids: any, msg:string, name:string): Promise<RS> {
    return service({
        url: `/${name}/delAuditNotPass`,
        method: 'POST',
        params: {ids,msg, ...getCommonParams1(name)},
    })
}

export function importExcel(reportCode: string,data:any,qqdbs: string,rwlsh: string,businessLine:string,khbh:string,is417report:boolean): Promise<RS> {
    return service({
        url: `/${reportCode}/importExcel`,
        method: 'POST',
        data,
        // params: {qqdbs,rwlsh,businessLine,khbh,is417report, ...getCommonParams()},
        params: {qqdbs,rwlsh,businessLine,khbh,is417report, subSystem:getSubSystem(), requestClassificationCode: reportCode},
        headers: {'Content-Type': 'multipart/form-data'},
    })
}

export function exportExcel(reportCode: string, ids:any,data = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/exportExcel`,
        method: 'POST',
        data,
        params: {ids, ...getCommonParams()},
        responseType: 'blob'
    })
}
export function upload(qqdbs:string,rwlsh:string,id:string,data = {},imageType:string): Promise<RS> {
    return service({
        url: '/fkCertificateImage/upload',
        method: 'POST',
        data,
        params: {imageType,qqdbs,rwlsh,id,subSystem:getSubSystem(),requestClassificationCode:getRequestClassificationCode()},
        headers: {'Content-Type': 'multipart/form-data',}
    })
}
export function checkExcelData(reportCode: string,data = {}): Promise<RS> {
    return service({
        url: `/${reportCode}/checkExcelData`,
        method: 'POST',
        data,
        params: getCommonParams(),
        headers: {'Content-Type': 'multipart/form-data',}
    })
}
export function checkFileExist(id:string): Promise<RS> {
    return service({
        url: '/fkCertificateImage/checkFileExist',
        method: 'POST',
        params: {id,subSystem:getSubSystem(),requestClassificationCode:getRequestClassificationCode()},
    })
}

export function previewUploadFile(id:string): Promise<RS> {
    return service({
        url: '/fkCertificateImage/previewUploadFile',
        method: 'POST',
        params: {id,subSystem:getSubSystem(),requestClassificationCode:getRequestClassificationCode()},
    })
}

export function auditAllBatch(reportCode: string, data = {},rwlsh:string,khbh:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: `/${reportCode}/auditAllBatch`,
        method: 'POST',
        data,
        params: {subSystem: getSubSystem(),reportCode,rwlsh,khbh,isSubTable},
    })
}
export function submitAllBatch(reportCode: string, data = {},rwlsh:string,khbh:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: `/${reportCode}/submitAllBatch`,
        method: 'POST',
        data,
        params: {subSystem: getSubSystem(),reportCode,rwlsh,khbh,isSubTable},
    })
}
export function auditNotPassAllBatch(reportCode: string, data = {},rwlsh:string,khbh:string,isSubTable:boolean,msg:string): Promise<RS> {
    return service({
        url: `/${reportCode}/auditNotPassAllBatch`,
        method: 'POST',
        data,
        params: {subSystem: getSubSystem(),reportCode,rwlsh,khbh,isSubTable,msg},
    })
}

export function delAllBatch(reportCode: string, data = {},rwlsh:string,khbh:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: `/${reportCode}/delAllBatch`,
        method: 'POST',
        data,
        params: {subSystem: getSubSystem(), reportCode, rwlsh, khbh, isSubTable},
    })
}
export function auditDelAllBatch(reportCode: string, data = {},rwlsh:string,khbh:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: `/${reportCode}/auditDelAllBatch`,
        method: 'POST',
        data,
        params: {subSystem: getSubSystem(), reportCode, rwlsh, khbh, isSubTable},
    })
}
export function auditDelNotPassAllBatch(reportCode: string, data = {},rwlsh:string,khbh:string,isSubTable:boolean,msg:string): Promise<RS> {
    return service({
        url: `/${reportCode}/auditDelNotPassAllBatch`,
        method: 'POST',
        data,
        params: {subSystem: getSubSystem(), reportCode, rwlsh, khbh, isSubTable, msg},
    })
}

export function listFldm(reportCode: string): Promise<RS> {
    return service({
        url: `/dict/listFldmByRequestClassificationCode`,
        method: 'GET',
        params: {subSystem: getSubSystem() ,requestClassificationCode :reportCode}
    })
}
