import {FormItemInfo} from "riking-ui";

//反馈页面 Form配置 主表部分
// 账户信息页面  账户信息与交易明细页面
export const publicFkCustomerFormItems: FormItemInfo[] = [
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 2,
            message: '查询反馈结果最大长度为2,成功或失败'
        }, {required: true, message: '查询反馈结果必填'}],
    },
    {
        prop: 'cxfkjgyy',
        label: '查询反馈结果原因',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {
            max: 1000,
            message: '查询反馈结果原因最大长度为1000'
        }],
    },
    {
        prop: 'zzhm',
        label: '证照号码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '证照号码必填'}, {
            max: 30,
            message: '证照号码最大长度为30'
        }],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '50' },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '客户编号必填'},
            {max: 50, message: '客户编号最大长度为50'}
        ],
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '部门编码必填'},
            {max: 50, message: '部门编码最大长度为50'}
        ],
    },
    {
        prop: 'khmc',
        label: '客户名称',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '150' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '客户名称必填'}, {
            max: 150,
            message: '客户名称最大长度为150'
        }],
    },
    {
        prop: 'lxdh',
        label: '联系电话',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '联系电话最大长度为20'}],
    },
    {
        prop: 'lxsj',
        label: '联系手机',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '联系手机最大长度为20'}],
    },

    {
        prop: 'dbrxm',
        label: '代办人姓名',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '代办人姓名最大长度为100'}],
    },
    {
        prop: 'dbrzjlx',
        label: '代办人证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 15, message: '代办人证件类型最大长度为15'}],
    },
    {
        prop: 'dbrzjhm',
        label: '代办人证件号码',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '代办人证件号码最大长度为30'}],
    },
    {
        prop: 'dbrlxfs',
        label: '代办人联系方式',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '30' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 30,
            message: '代办人联系方式最大长度为30'
        }],
    },
    {
        prop: 'zzdz',
        label: '住宅地址',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '住宅地址最大长度为100'}],
    },
    {
        prop: 'zzdh',
        label: '住宅电话',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '住宅电话最大长度为20'}],
    },
    {
        prop: 'gzdw',
        label: '工作单位',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '工作单位最大长度为100'}],
    },
    {
        prop: 'dwdz',
        label: '单位地址',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '150' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 150, message: '单位地址最大长度为150'}],
    },
    {
        prop: 'dwdh',
        label: '单位电话',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '单位电话最大长度为20'}],
    },
    {
        prop: 'yxdz',
        label: '邮箱地址',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '60' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 60, message: '邮箱地址最大长度为60'}],
    },
    {
        prop: 'frdb',
        label: '法人代表',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '60' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 60, message: '法人代表最大长度为60'}],
    },
    {
        prop: 'frdbzjlx',
        label: '法人代表证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 15, message: '法人代表证件类型最大长度为15'}],
    },
    {
        prop: 'frdbzjhm',
        label: '法人代表证件号码',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '法人代表证件号码最大长度为30'}],
    },
    {
        prop: 'khgszzhm',
        label: '客户工商执照号码',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '18' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 18, message: '客户工商执照号码最大长度为18'}],
    },
    {
        prop: 'gsnsh',
        label: '国税纳税号',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '50' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 50,
            message: '国税纳税号最大长度为50'
        }],
    },
    {
        prop: 'dsnsh',
        label: '地税纳税号',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '地税纳税号最大长度为50'}],
    },
    {
        prop: 'xb',
        label: '性别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'xbdm',
        },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 10,
            message: '性别最大长度为10'
        }],
    },
    {
        prop: 'jg',
        label: '籍贯',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '性别最大长度为100'
        }],
    },
    {
        prop: 'mz',
        label: '民族',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'mzdm',
        },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '民族最大长度为10'
        }],
    },
    {
        prop: 'csrq',
        label: '出生日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$', message: '格式应为年-月-日'}],
    },
    {
        prop: 'gj',
        label: '国籍',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'gjdm',
        },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '国籍最大长度为100'
        }],
    },
    {
        prop: 'zy',
        label: '职业',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '职业最大长度为100'
        }],
    },
    {
        prop: 'tyshxydm',
        label: '统一社会信用码',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '18' },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {max: 18, message: '统一社会信用码最大长度为18'},
            {required: true, message: '必填'}
        ],
    },
]
// 账户信息页面  账户信息与交易明细页面2
export const publicFkCustomerFormItems2: FormItemInfo[] = [
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 2,
            message: '查询反馈结果最大长度为2,成功或失败'
        }, {required: true, message: '查询反馈结果必填'}],
    },
    {
        prop: 'cxfkjgyy',
        label: '查询反馈结果原因',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [{required: false, message: '必填'}, {required: false, message: '必填'}, {
            pattern: '^[^<>&]*$',
            message: '存在特殊字符'
        }, {
            max: 1000,
            message: '查询反馈结果原因最大长度为1000'
        }],
    },
    {
        prop: 'zzhm',
        label: '证照号码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '证照号码必填'}, {
            max: 30,
            message: '证照号码最大长度为30'
        }],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '客户编号必填'}, {
            max: 50,
            message: '客户编号最大长度为50'
        }],
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '部门编码必填'},
            {max: 50, message: '部门编码最大长度为50'}
        ],
    },
    {
        prop: 'khmc',
        label: '客户名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '150'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '客户名称必填'}, {
            max: 150,
            message: '客户名称最大长度为150'
        }],
    },
    {
        prop: 'lxdh',
        label: '联系电话',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '联系电话最大长度为20'}],
    },
    {
        prop: 'lxsj',
        label: '联系手机',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '联系手机最大长度为20'}],
    },

    {
        prop: 'dbrxm',
        label: '代办人姓名',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '代办人姓名最大长度为100'}],
    },
    {
        prop: 'dbrzjlx',
        label: '代办人证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 15, message: '代办人证件类型最大长度为15'}],
    },
    {
        prop: 'dbrzjhm',
        label: '代办人证件号码',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '代办人证件号码最大长度为30'}],
    },
    {
        prop: 'dbrlxfs',
        label: '代办人联系方式',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '30' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 30,
            message: '代办人联系方式最大长度为30'
        }],
    },
    {
        prop: 'zzdz',
        label: '住宅地址',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '住宅地址最大长度为100'}],
    },
    {
        prop: 'zzdh',
        label: '住宅电话',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '住宅电话最大长度为20'}],
    },
    {
        prop: 'gzdw',
        label: '工作单位',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '工作单位最大长度为100'}],
    },
    {
        prop: 'dwdz',
        label: '单位地址',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '150' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 150, message: '单位地址最大长度为150'}],
    },
    {
        prop: 'dwdh',
        label: '单位电话',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '单位电话最大长度为20'}],
    },
    {
        prop: 'yxdz',
        label: '邮箱地址',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '60' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 60, message: '邮箱地址最大长度为60'}],
    },
    {
        prop: 'frdb',
        label: '法人代表',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '60' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 60, message: '法人代表最大长度为60'}],
    },
    {
        prop: 'frdbzjlx',
        label: '法人代表证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 15, message: '法人代表证件类型最大长度为15'}],
    },
    {
        prop: 'frdbzjhm',
        label: '法人代表证件号码',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '法人代表证件号码最大长度为30'}],
    },
    {
        prop: 'khgszzhm',
        label: '客户工商执照号码',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '18' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 18, message: '客户工商执照号码最大长度为18'}],
    },
    {
        prop: 'gsnsh',
        label: '国税纳税号',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '50' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 50,
            message: '国税纳税号最大长度为50'
        }],
    },
    {
        prop: 'dsnsh',
        label: '地税纳税号',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '地税纳税号最大长度为50'}],
    },
    {
        prop: 'xb',
        label: '性别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'xbdm',
        },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 10,
            message: '性别最大长度为10'
        }],
    },
    {
        prop: 'jg',
        label: '籍贯',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '性别最大长度为100'
        }],
    },
    {
        prop: 'mz',
        label: '民族',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'mzdm',
        },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '性别最大长度为10'
        }],
    },
    {
        prop: 'csrq',
        label: '出生日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$', message: '格式应为年-月-日'}],
    },
    {
        prop: 'gj',
        label: '国籍',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'gjdm',
        },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '国籍最大长度为100'
        }],
    },
    {
        prop: 'zy',
        label: '职业',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '100' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '职业最大长度为100'
        }],
    },
    {
        prop: 'tyshxydm',
        label: '统一社会信用码',
        labelWidth: 150,
        inputType: {tag: 'input',maxlength: '18' },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {max: 18, message: '统一社会信用码最大长度为18'},
            {required: true, message: '必填'}
        ],
    },
]
// 交易明细页面
export const publicFkTransactionFormItems: FormItemInfo[] = [
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 2,
            message: '查询反馈结果最大长度为2,成功或失败'
        }, {required: true, message: '查询反馈结果必填'}],
    },
    {
        prop: 'cxfkjgyy',
        label: '查询反馈结果原因',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 1000,
            message: '查询反馈结果原因最大长度为1000'
        }, {required: true, message: '查询反馈结果原因必填'}],
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '部门编码必填'},
            {max: 50, message: '部门编码最大长度为50'}
        ],
    },
    {
        prop: 'cxzh',
        label: '查询帐号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '查询帐号最大长度为50'}],
    },
    {
        prop: 'cxkh',
        label: '查询卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '查询卡号最大长度为50'}],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '客户编号必填'}, {
            max: 50,
            message: '客户编号最大长度为50'
        }],
    },
    {
        prop: 'jylx',
        label: '交易类型',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '交易类型最大长度为50'}],
    },
    {
        prop: 'jdbz',
        label: '借贷标志',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'jdbz',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 4,
            message: '借贷标志最大长度为4'
        }, {required: true, message: '借贷标志必填'}],
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {max: 10, message: '币种最大长度为10'},
            {required: true, message: '币种标志必填'}
        ],
    },
    {
        prop: 'je',
        label: '交易金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '交易金额必填'}],
    },
    {
        prop: 'ye',
        label: '交易余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '交易余额必填'}],
    },
    {
        prop: 'jysj',
        label: '交易时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '交易时间必填'},
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            }],
    },
    {
        prop: 'jylsh',
        label: '交易流水号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 50,
            message: '交易流水号最大长度为50'
        }, {required: true, message: '交易流水号必填'}],
    },
    {
        prop: 'jydfxm',
        label: '交易对方名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '500' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 500, message: '交易对方名称最大长度为500'}],
    },
    {
        prop: 'jydfzjhm',
        label: '交易对方证件号码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '交易对方证件号码最大长度为30'}],
    },
    {
        prop: 'jydsye',
        label: '交易对手余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: []
    },
    {
        prop: 'jydfzhkhh',
        label: '交易对方账号开户行',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '交易对方账号开户行最大长度为100'
        }],
    },
    {
        prop: 'jyzy',
        label: '交易摘要',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '200' },
        rules: [{required: true, message: '必填'}, {max: 200, message: '交易摘要最大长度为200'}],
    },
    {
        prop: 'jywdmc',
        label: '交易网点名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '交易网点名称最大长度为100'
        }, {required: true, message: '交易网点名称必填'}],
    },
    {
        prop: 'jywddm',
        label: '交易网点代码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 20,
            message: '交易网点代码最大长度为20'
        }, {required: true, message: '交易网点代码必填'}],
    },
    {
        prop: 'rzh',
        label: '日志号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '日志号最大长度为30'}],
    },
    {
        prop: 'cph',
        label: '传票号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '传票号最大长度为30'}],
    },
    {
        prop: 'pzzl',
        label: '凭证种类',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '凭证种类最大长度为50'}],
    },
    {
        prop: 'pzh',
        label: '凭证号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '凭证号最大长度为30'}],
    },
    {
        prop: 'xjbz',
        label: '现金标志',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'xjbz',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 2,
            message: '现金标志最大长度为2'
        }, {required: true, message: '现金标志必填'}],
    },
    {
        prop: 'zdh',
        label: '终端号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 30, message: '终端号最大长度为30'}],
    },
    {
        prop: 'jysfcg',
        label: '交易是否成功',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'jysfcg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '·'}, {max: 2, message: '交易是否成功最大长度为2'}, {
            required: true,
            message: '交易是否成功必填'
        }],
    },
    {
        prop: 'jyfsd',
        label: '交易发生地',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '交易发生地最大长度为100'}],
    },
    {
        prop: 'shmc',
        label: '商户名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '商户名称最大长度为50'}],
    },
    {
        prop: 'shh',
        label: '商户号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '商户号最大长度为50'}],
    },
    {
        prop: 'ip',
        label: 'IP地址',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '40' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 40, message: 'IP地址最大长度为40'}],
    },
    {
        prop: 'mac',
        label: 'MAC地址',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: 'MAC地址最大长度为50'}],
    },
    {
        prop: 'jygyh',
        label: '交易柜员号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '交易柜员号最大长度为20'}],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '200' },
        // rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 200, message: '交易柜员号最大长度为200' }],
        rules: [{max: 200, message: '备注最大长度为200'}],
    },

    {
        prop: 'jydfzjlxdm',
        label: '交易对方证件类型代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [
            {required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {max: 10, message: '最大长度为10'}
        ],
    },
    {
        prop: 'jyfmc',
        label: '交易方名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '最大长度为100'
        }],
    },
    {
        prop: 'jyfzjhm',
        label: '交易方证件号码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 30,
            message: '最大长度为30'
        }],
    },
    {
        prop: 'jyfzjlxdm',
        label: '交易方证件类型代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [
            {required: true, message: '必填'},
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {max: 10, message: '最大长度为10'}
        ],
    },
    {
        prop: 'atmjbh',
        label: 'ATM机编号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '最大长度为50'}],
    },
    {
        prop: 'dkh',
        label: '端口号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '10' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '最大长度为10'}],
    },
]
//动态查询执行回执
export const publicFkDynamicReceiptFormItems: FormItemInfo[] = [
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '部门编码必填'},
            {max: 50, message: '部门编码最大长度为50'}
        ],
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 50,
            message: '账号最大长度为50'
        }, {required: true, message: '账号必填'}],
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {max: 50, message: '卡号最大长度为50'},
            {required: false, message: '卡号必填'}
        ],
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 2,
            message: '执行结果最大长度为2'
        }, {required: true, message: '执行结果必填'}],
    },
    {
        prop: 'sbyy',
        label: '失败原因',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '200' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 200,
            message: '失败原因最大长度为200'
        }],
    },
    {
        prop: 'fksjhm',
        label: '反馈手机号码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '11' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 11,
            message: '反馈手机号码最大长度为11'
        }, {required: true, message: '反馈手机号码必填'}],
    },
    {
        prop: 'zxqssj',
        label: '执行起始时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: true, message: '执行起始时间必填'},
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            }],
    },
    {
        prop: 'zxsjqj',
        label: '执行时间区间',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxsjqj',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '执行时间区间必填'}],
    },
    {
        prop: 'jssj',
        label: '结束时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '结束时间必填'}],
    },
]
//动态查询
export const publicFkDynamicFormItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 50,
            message: '账号最大长度为50'
        }, {required: true, message: '账号必填'}],
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 40,
            message: '卡号最大长度为50'
        }, {required: true, message: '卡号必填'}],
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '部门编码必填'},
            {max: 50, message: '部门编码最大长度为50'}
        ],
    },
    {
        prop: 'zhmc',
        label: '账户名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '60' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 60,
            message: '账户名称最大长度为60'
        }, {required: true, message: '账户名称必填'}],
    },
    {
        prop: 'zhbz',
        label: '账户币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '账户币种最大长度为10'}],
    },
    {
        prop: 'zhdykh',
        label: '账户对应卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '账户对应卡号最大长度为50'}],
    },
    {
        prop: 'jycz',
        label: '交易操作',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '交易操作最大长度为100'
        }, {required: true, message: '交易操作必填'}],
    },
    {
        prop: 'czsj',
        label: '操作时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '操作时间必填'},
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            }],
    },
    {
        prop: 'jydd',
        label: '交易地点',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '交易地点最大长度为100'
        }, {required: true, message: '交易地点必填'}],
    },
    {
        prop: 'ajlx',
        label: '案件类型',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '200' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 200,
            message: '案件类型最大长度为200'
        }, {required: true, message: '案件类型必填'}],
    },
    {
        prop: 'jyje',
        label: '交易金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '交易金额必填'}],
    },
    {
        prop: 'jybz',
        label: '交易币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '交易币种最大长度为10'}],
    },
    {
        prop: 'zhxyed',
        label: '账户信用额度',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
    },
    {
        prop: 'khzjlx',
        label: '客户证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '客户证件类型最大长度为10'}],
    },
    {
        prop: 'khzjhm',
        label: '客户证件号码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '客户证件号码最大长度为20'}],
    },
    {
        prop: 'dfzhmc',
        label: '对方账户名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '60' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 60, message: '对方账户名称最大长度为60'}],
    },
    {
        prop: 'dfzhbz',
        label: '对方账户币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '对方账户币种最大长度为10'}],
    },
    {
        prop: 'pzzl',
        label: '凭证种类',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '凭证种类最大长度为50'}],
    },
    {
        prop: 'pzh',
        label: '凭证号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '凭证号最大长度为20'}],
    },
    {
        prop: 'xjbz',
        label: '现金标志',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '10' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '现金标志最大长度为10'}],
    },
    {
        prop: 'fwjm',
        label: '服务界面',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '服务界面最大长度为50'}],
    },
    {
        prop: 'zdh',
        label: '终端号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '终端号最大长度为20'}],
    },
    {
        prop: 'kyxq',
        label: '卡有效期',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '10' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '卡有效期最大长度为10'}],
    },
    {
        prop: 'jylxyhk',
        label: '交易类型（银行卡）',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '交易类型（银行卡）最大长度为20'}],
    },
    {
        prop: 'jylxgjk',
        label: '交易类型（个金、国际卡）',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'jylxgjk',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 20,
            message: '交易类型（个金、国际卡）最大长度为20'
        }],
    },
    {
        prop: 'shh',
        label: '商户号（银行卡）',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '商户号（银行卡）最大长度为50'}],
    },
    {
        prop: 'shmc',
        label: '商户名（银行卡）',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '商户名（银行卡）最大长度为100'}],
    },
    {
        prop: 'wdms',
        label: '网点描述',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '网点描述最大长度为50'}],
    },
    {
        prop: 'wddz',
        label: '网点地址',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '网点地址最大长度为100'}],
    },
    {
        prop: 'wddh',
        label: '网点电话',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '网点电话最大长度为20'}],
    },
    {
        prop: 'gyh',
        label: '柜员号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '柜员号最大长度为20'}],
    },
    {
        prop: 'sqgyh',
        label: '授权柜员号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '授权柜员号最大长度为20'}],
    },
    {
        prop: 'jydm',
        label: '交易代码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '交易代码最大长度为20'}],
    },
    {
        prop: 'fjybz',
        label: '反交易标志',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '10' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '反交易标志最大长度为10'}],
    },
    {
        prop: 'czjybs',
        label: '冲正交易标识',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '10' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 10, message: '冲正交易标识最大长度为10'}],
    },
]
//冻结解冻续冻
export const publicFkFreezeFormItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 50,
            message: '账号最大长度为50'
        }],
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '卡号最大长度为50'}],
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '部门编码必填'},
            {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 2,
            message: '执行结果最大长度为2'
        }, {required: true, message: '执行结果必填'}],
    },
    {
        prop: 'sqdjxe',
        label: '申请冻结限额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2", disabled: true},
        rules: [],
    },
    {
        prop: 'sdje',
        label: '执行冻结金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2", disabled: false},
        rules: [{required: true, message: '执行冻结金额'}],
    },
    {
        prop: 'ye',
        label: '账户余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '账户余额必填'}],
    },
    {
        prop: 'zxqssj',
        label: '执行起始时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '执行起始时间必填'},
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            }],
    },
    {
        prop: 'djjsrq',
        label: '执行结束时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '执行结束时间必填'},
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            }],
    },
    {
        prop: 'wndjyy',
        label: '未能冻结原因',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {max: 1000, message: '未能冻结原因最大长度为1000'},
            {required: true, message: '必填'}
        ],
    },
    {
        prop: 'djjg',
        label: '在先冻结机关',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '在先冻结机关最大长度为50'}],
    },
    {
        prop: 'djje',
        label: '在先冻结金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
    },
    {
        prop: 'djjzrq',
        label: '在先冻结到期日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},

    },
    {
        prop: 'wdjje',
        label: '未冻结金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2", disabled: false},
        rules: [{required: true, message: '未冻结金额必填'}],
    },
    {
        prop: 'zhkyye',
        label: '账户可用余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '账户可用余额必填'}],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [{max: 1000, message: '备注最大长度为1000'}],
    },
    {
        prop: 'djzhhz',
        label: '冻结账户户主',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{required: true, message: '必填'}, {max: 100, message: '冻结账户户主最大长度为100'}],
    },
    {
        prop: 'zzlxdm',
        label: '证件类型代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{required: true, message: '必填'}, {max: 15, message: '证件类型代码最大长度为15'}],
    },
    {
        prop: 'zzhm',
        label: '证件号码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{required: true, message: '必填'}, {max: 30, message: '证件号码最大长度为30'}],
    }
]
//紧急止付\解除止付
export const publicFkPaymentFormItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '账号必填'}, {
            max: 50,
            message: '最大长度为50'
        }],
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '卡号必填'}, {
            max: 50,
            message: '最大长度为50'
        }],
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '执行结果必填'}],
    },
    {
        prop: 'sbyy',
        label: '失败原因',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '200' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 200,
            message: '失败原因最大长度为200'
        }],
    },
    {
        prop: 'zxqssj',
        label: '执行起始时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '执行起始时间必填'},
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            }],
    },

]
//调阅凭证图像
export const publicFkCertificateFormItems: FormItemInfo[] = [
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
        },
    },
    {
        prop: 'cxfkjgyy',
        label: '查询反馈结果原因',
        labelWidth: 150,
        inputType: 'input',
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '查询反馈结果原因最大长度为100'
        }],
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'cxzh',
        label: '查询帐号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 40, message: '查询帐号最大长度为40'}],
    },
    {
        prop: 'cxzl',
        label: '查询种类',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxzl',
        },
    },
    {
        prop: 'pztxlx',
        label: '凭证图像类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'pztxlx',
            disabled: true
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '凭证图像类型必填'}, {
            max: 6,
            message: '凭证图像类型最大长度为6'
        }],
    },
    {
        prop: 'pztxxh',
        label: '凭证图像序号',
        labelWidth: 150,
        inputType: {tag: 'input-number', disabled: true},
        rules: [{required: true, message: '凭证图像序号必填'}, {type: 'integer', message: '凭证图像序号必须为整数'}],
    },
    {
        prop: 'pztxmc',
        label: '凭证图像名称',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: true,
            message: '凭证图像名称必填'
        }, {max: 60, message: '凭证图像名称最大长度为60'}],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 200, message: '备注最大长度为200'}],
    }

]
//调阅凭证图像 国安特有
export const publicNsaFkCertificateFormItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '账号最大长度为50'}],
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 40, message: '帐号最大长度为40'}],
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '业务操作机构必填'}]
    },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'jylsh',
        label: '交易流水号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '交易流水号最大长度为50'}],
    },
    {
        prop: 'pztxlx',
        label: '凭证图像类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'pztxlx-nsa',
            disabled: true
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '凭证图像类型必填'}, {
            max: 2,
            message: '凭证图像类型最大长度为2'
        }],
    },
    {
        prop: 'txwjm',
        label: '图像文件名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 500, message: '图像文件名最大长度为500'}],
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '执行结果必填'}],
    },
    {
        prop: 'sbyy',
        label: '失败原因',
        labelWidth: 150,
        inputType: 'input',
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 200,
            message: '失败原因最大长度为200'
        }],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 30, message: '备注最大长度为30'}],
    }

]


//反馈页面 Form配置 子表部分
//账户信息 子表
export const publicFkAccountFormItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '部门编码必填'},
            {max: 50, message: '部门编码最大长度为50'}
        ],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true},
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '客户编号必填'},
            {max: 50, message: '客户编号最大长度为50'}
        ],
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 50,
            message: '卡号最大长度为50'
        }],
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '账号最大长度为50'}],
    },
    {
        prop: 'zhlb',
        label: '账户类别',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 50,
            message: '账户类别最大长度为50'
        }],
    },
    {
        prop: 'zhzt',
        label: '账户状态',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 20,
            message: '账户状态最大长度为20'
        }],
    },
    {
        prop: 'khwd',
        label: '开户网点',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '200' },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 200,
            message: '开户网点最大长度为200'
        }],
    },
    {
        prop: 'khwddm',
        label: '开户网点代码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 20,
            message: '住宅地址最大长度为100'
        }],
    },
    {
        prop: 'khrq',
        label: '开户日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{required: true, message: '必填'},]
    },
    {
        prop: 'xhrq',
        label: '销户日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{required: false, message: '必填'},]
    },
    {
        prop: 'xhwd',
        label: '销户网点',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 100,
            message: '销户网点最大长度为100'
        }],
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [{required: true, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 20,
            message: '币种最大长度为20'
        }],
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        // inputType: {tag: 'input', maxlength: '20' },
        inputType: {
            tag: 'select',
            options: 'chbz',
        },
        rules: [{required: false, message: '必填'}, {pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 20,
            message: '钞汇标志最大长度为20'
        }],
    },
    {
        prop: 'zhye',
        label: '账户余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '必填'},]

    },
    {
        prop: 'kyye',
        label: '可用余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '必填'},]

    },
    {
        prop: 'zhjysj',
        label: '最后交易时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {
                pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$',
                message: '格式应为年-月-日 时:分:秒'
            },
            {required: true, message: '最后交易时间必填'}
        ],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '200' },
        rules: [{max: 200, message: '备注最大长度为200'}],
    },
    // {
    //     prop: 'cxfkjgyy',
    //     label: '查询反馈结果原因',
    //     labelWidth: 150,
    //     inputType: 'input',
    //     rules: [{required: true, message: '必填'}, {max: 1000, message: '最大长度为1000'}],
    // },
    // {
    //     prop: 'khmc',
    //     label: '客户名称',
    //     labelWidth: 150,
    //     inputType: 'input',
    //     rules: [{required: true, message: '必填'}, {max: 150, message: '最大长度为150'}],
    // },
    {
        prop: 'khsfdm',
        label: '开户省份代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'areaCode',
        },
        rules: [{required: true, message: '必填'}, {max: 6, message: '最大长度为6'}],
    },
    {
        prop: 'khcsdm',
        label: '开户城市代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'areaCode',
        },
        rules: [{required: true, message: '必填'}, {max: 6, message: '最大长度为6'}],
    },
    {
        prop: 'zdr',
        label: '账单日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'},
            {pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$', message: '格式应为年-月-日'}],
    },
    {
        prop: 'yxqjzrq',
        label: '有效期截止日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '必填'},
            {pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$', message: '格式应为年-月-日'}],
    },
    {
        prop: 'ed',
        label: '额度',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: false, message: '必填'}],
    },

]
//强制措施信息 子表
export const publicFkMeasureFormItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true, maxlength: '50'},
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '客户编号必填'},
            {max: 50, message: '客户编号最大长度为50'}
        ],
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '账号最大长度为50'}],
    },
    {
        prop: 'csxh',
        label: '措施序号',
        labelWidth: 150,
        inputType: 'input-number',
        rules: [{type: 'integer', message: '措施序号必须为整数'}],
    },
    {
        prop: 'djksrq',
        label: '冻结开始日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'djjzrq',
        label: '冻结截止日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'djjgmc',
        label: '冻结机关名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 1000, message: '冻结机关名称最大长度为1000'}],
    },
    {
        prop: 'djje',
        label: '冻结金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000'},
        rules: [{max: 1000, message: '备注最大长度为1000'}],
    },
    {
        prop: 'djcslx',
        label: '冻结措施类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'djcslx',
        },
    },
    {
        prop: 'zzhxh',
        label: '子账户序号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
    },
]
//共享权\优先权信息 子表
export const publicFkPriorityFormItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true,maxlength: '50'},
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '客户编号必填'},
            {max: 50, message: '客户编号最大长度为50'}
        ],
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '账号最大长度为50'}],
    },
    {
        prop: 'xh',
        label: '权利序号',
        labelWidth: 150,
        inputType: 'input-number',
        rules: [{type: 'integer', message: '权利序号必须为整数'}],
    },
    {
        prop: 'qllx',
        label: '权利类型',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '权利类型最大长度为50'}],
    },
    {
        prop: 'zzlxdm',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '证件类型必填'}]
    },
    {
        prop: 'zzhm',
        label: '证件号码',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            max: 30,
            message: '证件号码最大长度为30'
        }, {required: true, message: '证件号码必填'}],
    },
    {
        prop: 'qlrxm',
        label: '权利人姓名',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '60'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 60, message: '权利人姓名最大长度为60'}],
    },
    {
        prop: 'qlje',
        label: '权利金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
    },
    {
        prop: 'qlrdz',
        label: '权利人通讯地址',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 100, message: '权利人通讯地址最大长度为100'}],
    },
    {
        prop: 'qlrlxfs',
        label: '权利人联系方式',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '权利人联系方式最大长度为50'}],
    },
    {
        prop: 'jrcpxh',
        label: '金融产品序号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '最大长度为20'}],
    },
    {
        prop: 'jrcpbh',
        label: '金融产品编号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{required: false, message: '金融产品编号必填'},{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '最大长度为50'}],
    },
    {
        prop: 'zzhxh',
        label: '子账户序号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '最大长度为50'}],
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '最大长度为20'}],
    },

]
//关联子账户 子表
export const publicFkSubAccountFormItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true, maxlength: '50'},
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '客户编号必填'},
            {max: 50, message: '客户编号最大长度为50'}
        ],
    },
    {
        prop: 'zh',
        label: '账卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '账卡号最大长度为50'}],
    },
    {
        prop: 'zzhxh',
        label: '子账户序号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '子账户序号最大长度为50'}],
    },
    {
        prop: 'zzhlb',
        label: '子账户类别',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '子账户类别最大长度为50'}],
    },
    {
        prop: 'zzhzh',
        label: '子账户账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 50, message: '子账户账号最大长度为50'}],
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        // inputType: {tag: 'input', maxlength: '20'},
        inputType: {
            tag: 'select',
            options: 'chbz',
        },
        rules: [{required: false, message: '钞汇标志必填'},{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '钞汇标志最大长度为20'}],
    },
    {
        prop: 'zhye',
        label: '账户余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
    },
    {
        prop: 'zhzt',
        label: '账户状态',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20'},
    },
    {
        prop: 'kyye',
        label: '可用余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
    }
]
//交易明细 子表
//交易明细 子表和主表共用一个表单项


//冻结明细 子表
export const publicFkFreezeDetailFormItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '账号必填'}, {
            max: 50,
            message: '账号最大长度为50'
        }],
    },
    {
        prop: 'zhzzh',
        label: '账号子账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '账号子账号必填'}, {
            max: 50,
            message: '账号子账号最大长度为50'
        }],
    },
    {
        prop: 'zzhxh',
        label: '子账号序号',
        labelWidth: 150,
        // inputType: 'input-number',
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{required: true, message: '子账号序号必填'}],
    },
    {
        prop: 'zzhye',
        label: '子账号余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '子账号余额必填'}],
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '执行结果必填'}],
    },
    {
        prop: 'zxjgyy',
        label: '执行失败原因',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '500' },
        rules: [{required: false, message: '执行失败原因必填'}]
    },
    {
        prop: 'djjg',
        label: '在先冻结机关',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 1000, message: '在先冻结机关最大长度为1000'}],
    },
    {
        prop: 'zxdjje',
        label: '在先冻结金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
    },
    {
        prop: 'djjzrq',
        label: '在先冻结到期日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},

    },
    {
        prop: 'djje',
        label: '冻结金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '冻结金额必填'}],
    },
    {
        prop: 'djkssj',
        label: '冻结开始时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '冻结开始时间必填'}],
    },
    {
        prop: 'djjssj',
        label: '冻结结束时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '冻结结束时间必填'}],
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '币种必填'}],
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        // inputType: {tag: 'input', maxlength: '20' },
        inputType: {
            tag: 'select',
            options: 'chbz',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '钞汇标志必填'}],
    },
    {
        prop: 'wdjje',
        label: '未冻结金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
    },
]

//止付明细 子表
export const publicFkPaymentDetailFormItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '账号必填'}],
    },
    {
        prop: 'zhzzh',
        label: '账号子账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '账号子账号必填'}],
    },
    {
        prop: 'zzhxh',
        label: '子账号序号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '子账号序号必填'}],
    },
    {
        prop: 'zzhye',
        label: '子账号余额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: true, message: '子账号余额必填'}],
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '执行结果必填'}],
    },
    {
        prop: 'zxjgyy',
        label: '执行失败原因',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '500' },
        rules: [{required: false, message: '执行失败原因必填'}]
    },
    {
        prop: 'zfkssj',
        label: '止付开始时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '止付开始时间必填'}],
    },
    {
        prop: 'zfjssj',
        label: '止付结束时间',
        labelWidth: 150,
        inputType: {
            tag: 'date-input',
            type: 'datetime',
            format: "YYYY-MM-DD HH:mm:ss",
            valueFormat: 'YYYY-MM-DD HH:mm:ss'
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '止付结束时间必填'}],
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '币种必填'}],
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        // inputType: {tag: 'input', maxlength: '20' },
        inputType: {
            tag: 'select',
            options: 'chbz',
        },
        rules: [{required: false, message: '钞汇标志必填'},{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {max: 20, message: '钞汇标志最大长度为20'}],
    },
]

// 金融资产信息 子表
export const publicFkFinancialFormItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true},
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '客户编号必填'},
            {max: 255, message: '客户编号最大长度为255'}
        ],
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '账号必填'}, {
            max: 50,
            message: '账号最大长度为50'
        }],
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '卡号必填'}, {
            max: 50,
            message: '卡号最大长度为50'
        }],
    },
    {
        prop: 'jrzcxh',
        label: '金融资产序号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '金融资产序号'}, {
            max: 50,
            message: '金融资产序号最大长度为50'
        }],
    },
    {
        prop: 'jrzcmc',
        label: '金融资产名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: true,
            message: '金融资产名称必填'
        }, {max: 100, message: '金融资产名称最大长度为100'}],
    },
    {
        prop: 'jrzclx',
        label: '金融资产类型',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '100' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: true,
            message: '金融资产类型必填'
        }, {max: 100, message: '金融资产类型最大长度为100'}],
    },
    {
        prop: 'cpxszl',
        label: '产品销售种类',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: false,
            message: '产品销售种类必填'
        }, {max: 20, message: '产品销售种类最大长度为20'}],
    },
    {
        prop: 'dqh',
        label: '地区号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '30' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '地区号必填'}, {
            max: 30,
            message: '地区号最大长度为30'
        }],
    },
    {
        prop: 'jrcpbh',
        label: '金融产品编号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: true,
            message: '金融产品编号必填'
        }, {max: 50, message: '金融产品编号最大长度为50'}],
    },
    {
        prop: 'lczh',
        label: '理财账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '理财账号必填'}, {
            max: 50,
            message: '理财账号最大长度为50'
        }],
    },
    {
        prop: 'zjhkzh',
        label: '资金回款账户',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: true,
            message: '资金回款账户必填'
        }, {max: 50, message: '资金回款账户最大长度为50'}],
    },
    {
        prop: 'zcglr',
        label: '资产管理人',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '资产管理人必填'}, {
            max: 50,
            message: '资产管理人最大长度为50'
        }],
    },
    {
        prop: 'zckftgyhjy',
        label: '资产可否通过银行交易',
        labelWidth: 150,
        // inputType: {tag: 'input', maxlength: '2' },
        inputType: {
            tag: 'select',
            options: 'ZCKFTGYHJY',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: false,
            message: '资产可否通过银行交易必填'
        }, {max: 2, message: '资产可否通过银行交易最大长度为2'}],
    },
    {
        prop: 'zcjyxzlx',
        label: '资产交易限制类型',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: false,
            message: '资产交易限制类型必填'
        }, {max: 50, message: '资产交易限制类型最大长度为50'}],
    },
    {
        prop: 'zcjyxzsj',
        label: '资产交易限制时间',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {
            required: true,
            message: '资产交易限制时间必填'
        }, {max: 50, message: '资产交易限制时间最大长度为50'}],
    },
    {
        prop: 'zyqr',
        label: '质押权人',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '质押权人必填'}, {
            max: 50,
            message: '质押权人最大长度为50'
        }],
    },
    {
        prop: 'tgr',
        label: '托管人',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '托管人必填'}, {
            max: 50,
            message: '托管人最大长度为50'
        }],
    },
    {
        prop: 'syr',
        label: '受益人',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '受益人必填'}, {
            max: 50,
            message: '受益人最大长度为50'
        }],
    },
    {
        prop: 'clr',
        label: '成立日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '交易时间必填'},
            {pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$', message: '格式应为年-月-日'}],
    },
    {
        prop: 'shrDate',
        label: '赎回日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '交易时间必填'},
            {pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$', message: '格式应为年-月-日'}],
    },
    {
        prop: 'tgzh',
        label: '托管账号',
        labelWidth: 150,
        inputType: {tag: 'input'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '托管账号必填'}, {
            max: 50,
            message: '托管账号最大长度为50'
        }],
    },
    {
        prop: 'jldw',
        label: '计量单位',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '计量单位必填'}, {
            max: 20,
            message: '计量单位最大长度为20'
        }],
    },
    {
        prop: 'jjbz',
        label: '计价币种',
        labelWidth: 150,
        // inputType: {tag: 'input', maxlength: '20' },
        inputType: {
            tag: 'select',
            options: 'currency',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '计价币种必填'}, {
            max: 20,
            message: '计价币种最大长度为20'
        }],
    },
    {
        prop: 'zcdwjg',
        label: '资产单位价格',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: false, message: '资产单位价格必填'}],
    },
    {
        prop: 'sl',
        label: '数量/份额/金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "3"},
        rules: [{required: true, message: '数量/份额/金额必填'}],
    },
    {
        prop: 'kksl',
        label: '可控数量/份数/金额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: false, message: '可控数量/份数/金额必填'}],
    },
    {
        prop: 'zczse',
        label: '资产总数额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: false, message: '资产总数额必填'}],
    },
    {
        prop: 'bz',
        label: '备注',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '200' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '备注必填'}, {
            max: 200,
            message: '备注最大长度为200'
        }],
    },
]
// 金融资产强制措施 子表
export const publicFkFinancialMeasureFormItems: FormItemInfo[] = [
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '部门编码必填'}, {
            max: 50,
            message: '部门编码最大长度为50'
        }],
    },
    {
        prop: 'khbh',
        label: '客户编号',
        labelWidth: 150,
        inputType: {tag: 'input', disabled: true},
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '客户编号必填'},
            {max: 255, message: '客户编号最大长度为255'}
        ],
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '账号必填'}, {
            max: 50,
            message: '账号最大长度为50'
        }],
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '卡号必填'}, {
            max: 50,
            message: '卡号最大长度为50'
        }],
    },
    {
        prop: 'jrcpxh',
        label: '金融产品序号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '20' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '金融产品序号'}, {
            max: 20,
            message: '金融产品序号最大长度为20'
        }],
    },
    {
        prop: 'jrcpbh',
        label: '金融产品编号',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '50' },
        rules: [
            {pattern: '^[^<>&]*$', message: '存在特殊字符'},
            {required: false, message: '金融产品编号'},
            {max: 50, message: '金融产品编号最大长度为50'}
        ],
    },
    {
        prop: 'djksrq',
        label: '冻结开始日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '冻结开始日必填'},
            {pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$', message: '格式应为年-月-日'}],
    },
    {
        prop: 'djjzrq',
        label: '冻结截止日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '冻结截止日必填'},
            {pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$', message: '格式应为年-月-日'}],
    },
    {
        prop: 'djjgmc',
        label: '冻结机关名称',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: true, message: '冻结机关名称'}, {
            max: 1000,
            message: '冻结机关名称最大长度为1000'
        }],
    },
    {
        prop: 'djje',
        label: '冻结金额/数额',
        labelWidth: 150,
        inputType: {tag: 'input-number', controlsPosition: "right", precision: "2"},
        rules: [{required: false, message: '数量/份额/金额必填'}],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: {tag: 'input', maxlength: '1000' },
        rules: [{pattern: '^[^<>&]*$', message: '存在特殊字符'}, {required: false, message: '备注'}, {
            max: 1000,
            message: '备注最大长度为1000'
        }],
    },
]
