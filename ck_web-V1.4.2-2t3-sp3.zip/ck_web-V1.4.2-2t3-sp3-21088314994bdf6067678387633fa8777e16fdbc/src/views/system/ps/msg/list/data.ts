import { FormItemInfo, Pagination, TableColumnInfo } from "riking-ui";
export const columns: TableColumnInfo[] = [
  {
    key: 'id',
    type: 'selection',

  },
  {
    prop: 'reportName',
    label: '报表名称',
  },
  {
    prop: 'reportCode',
    label: '报表编号',
    sortable: true
  },
  {
    prop: 'qqdbs',
    label: '请求单标识',
    sortable: true,
  },
  {
    prop: 'reportZipName',
    label: '报文包名称',
    sortable: true
  },
  {
    prop: 'connectionType',
    label: '报送方式',
    dictFormatKey: 'connectionType',
    sortable: true
  },
  {
    prop: 'isUpload',
    label: '是否报送成功',
    dictFormatKey: 'isUpload',
    sortable: true
  },
  {
    prop: 'createTime',
    label: '生成日期',
    sortable: true
  },
  {
    key: 'actions',
    label: '操作',
    scopedSlots: 'actions',
    fixedWidth: 220,
    fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'reportCode',
    label: '报表名称',
    // inputType: {  
    //   tag: 'select',
    // },
    scopedSlot: 'reportCode',
  },
  {
    prop: 'qqdbs',
    label: '请求单标识',
    labelWidth: 80,
  },
  {
    prop: 'createTimeArr',
    label: '生成日期',
    inputType: { tag: 'date-picker', type: 'daterange', valueFormat: 'YYYY-MM-DD' }
  },
  // {
  //   prop: 'branchCodeList', label: '业务操作机构', labelWidth: 100,
  //   inputType: {
  //     tag: 'tree-select',
  //     options: 'branchCode',
  //     multiple: true,
  //     showCheckbox: true,
  //     checkStrictly: true,
  //   }
  // },
  // {
  //   prop: 'businessLine', label: '业务线', labelWidth: 100,
  //   inputType: {
  //     tag: 'select',
  //     options: 'businessLine',
  //   }
  // },
];

export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}
