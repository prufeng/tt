
import { RS } from 'riking-ui'
import service from '@/utils/request';
enum Api {
  list = '/sysReportZipRecord/list',
  getFkReportCode = "/sysReportCode/getFkReportCode",
  upload = '/psMessage/upload',
  getXmlUrl = '/psMessage/getXml',
  getPdfUrl = '/psMessage/getPdf',
  resetById = '/psMessage/resetById'
}

export const getQuartzList = (data: any, pageNo: number, pageSize: number, sort: {}): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: { pageNo, pageSize, ...sort }
  })
};

export function getFkReportCode(data: any) {
  return service({
    url: Api.getFkReportCode,
    method: 'get',
    params: data,
  })

}

export function upload(params: any) {
  return service({
    url: Api.upload,
    method: 'POST',
    params: params
  })

}

export function getXml(data = {}): Promise<RS> {
  return service({
    url: Api.getXmlUrl,
    method: 'POST',
    data,
    params: {},
  })
}

export function getPdf(data = {}): Promise<RS> {
  return service({
    url: Api.getPdfUrl,
    method: 'POST',
    data,
    params: {},
  })
}

export function checkFileIsExists(id: any): Promise<RS> {
  return service({
    url: '/sysReportZipRecord/checkFileIsExists',
    method: 'get',
    params: { id },
  })
}

export function downloadZip(id: any): Promise<RS> {
  return service({
    url: '/sysReportZipRecord/downloadZip',
    method: 'get',
    params: { id },
  })
}

export const resetById = (id): Promise<RS> => {
  return service({
    url: Api.resetById,
    method: 'POST',
    params: {id}
  })
};
