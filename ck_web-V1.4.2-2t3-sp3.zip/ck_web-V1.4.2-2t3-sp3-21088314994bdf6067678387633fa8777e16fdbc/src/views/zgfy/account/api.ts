import {RS} from 'riking-ui'
import service from '@/utils/request'
import {getCommonParams, getRequestClassificationCode} from "@/utils/subSystem";

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: '/zgfyCx/list',
        method: 'POST',
        data,
        params: {current, size, ...getCommonParams()}
    })
}
export function treeList(qqdbs:string,data = {}, current: number, size: number,branchCodeList:string): Promise<RS> {
    return service({
        url: '/zgfyCx/treeList',
        method: 'POST',
        data,
        params: {current, size, qqdbs,branchCodeList,requestClassificationCode:getRequestClassificationCode()}
    })
}
export function subList(bdhm:string,data = {}, current: number, size: number,requestClassificationCode:string): Promise<RS> {
    return service({
        url: '/zgfyCx/subList',
        method: 'POST',
        data,
        params: {current, size, bdhm,requestClassificationCode}
    })
}
export function cxSearchList(data = {}): Promise<RS> {
    return service({
        url: '/zgfyCx/list',
        method: 'POST',
        data,
        params: {current:1, size:10, ...getCommonParams()}
    })
}
export function getOne(params = {}): Promise<RS> {
    return service({
        url: '/zgfyCx/getOne',
        method: 'GET',
        params: {...params, ...getCommonParams()},
    })
}
//
// export function basic(params = {}): Promise<RS> {
//     return service({
//         url: '/query/basic',
//         method: 'GET',
//         params: {...params, ...getCommonParams()},
//     })
// }
//
// export function person(params = {}): Promise<RS> {
//     return service({
//         url: '/query/person',
//         method: 'GET',
//         params: {...params, ...getCommonParams()},
//     })
// }

export function updateRequestStatus(reportCode: string,data = {}): Promise<RS> {
    return service({
        url: `/zgfyCx/updateRequestStatus`,
        method: 'POST',
        data,
        params: {requestClassificationCode:reportCode},
    });
}
export function isSameKhzh(reportCode: string,data = {}): Promise<RS> {
    return service({
        url: `/zgfyFk/isSameKhzh`,
        method: 'POST',
        data,
        params: {requestClassificationCode:reportCode},
    });
}

export function impZip(data = {}): Promise<RS> {
    return service({
        url: '/zgfyCx/imp',
        method: 'POST',
        data,
        params: getCommonParams(),
        headers: {'Content-Type': 'multipart/form-data',}
    })
}
export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: `/zgfyCx/exportExcel`,
        method: 'POST',
        data,
        params: {ids, ...getCommonParams()},
        responseType: 'blob'
    })
}
export function checkData(data = {}): Promise<RS> {
    return service({
        url: '/zgfyCx/checkData',
        method: 'POST',
        data,
        params: getCommonParams(),
        headers: {'Content-Type': 'multipart/form-data',}
    })
}
export function getPdf(data = {}): Promise<RS> {
    return service({
        url: '/zgfyCx/getPdf',
        method: 'POST',
        data,
        params: {requestClassificationCode:getRequestClassificationCode()},
    })
}
export function getImage(data = {}): Promise<RS> {
    return service({
        url: '/zgfyCx/getImage',
        method: 'POST',
        data,
        params: {requestClassificationCode:getRequestClassificationCode()},
    })
}
export function getXml( data = {}): Promise<RS> {
    return service({
        url: `/zgfyCx/getXml`,
        method: 'POST',
        data,
        params: {requestClassificationCode:getRequestClassificationCode()},
    })
}
export function downloadZip(ids:any): Promise<RS> {
    return service({
        url: '/zgfyCx/downloadZip',
        method: 'POST',
        responseType : 'blob',
        params: {ids},
    })
}


