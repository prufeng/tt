import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
import {ElMessage} from "element-plus";

export const buttons: ButtonInfo[] = [
    {
        key: 'import',
        label: '导入',
        tag: 'button',
        type: 'primary',
        icon: 'icon_add',
        handler: () => ElMessage.warning('导入'),
    },
    {
      key: 'export',
      label: '导出',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: () => ElMessage.warning('导出'),
    },

]

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 50,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}
export const subPagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}
export const treePagination: Pagination = {
    currentPage: 1,
    pageSize: 8,
    pageSizes: [8, 16, 24, 32],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}