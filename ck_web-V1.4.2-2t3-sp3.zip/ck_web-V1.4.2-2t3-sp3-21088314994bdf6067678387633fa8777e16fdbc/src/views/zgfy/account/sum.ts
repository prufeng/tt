

const reportCodeMap = new Map()
reportCodeMap.set('fkCxqq', '1001')
reportCodeMap.set('fkKzqq', '1003')
reportCodeMap.set('fkReturnFail', '1005')


export default {
    reportCodeMap
}

