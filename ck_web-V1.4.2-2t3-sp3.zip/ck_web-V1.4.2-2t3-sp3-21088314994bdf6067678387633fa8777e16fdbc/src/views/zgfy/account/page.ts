import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
import {ElMessage} from "element-plus";
import {dateFormatter} from "@/utils/utils";
import {getRequestClassificationCode, getSubSystem} from "@/utils/subSystem";

declare interface PageElements {
    columns: TableColumnInfo[]
    formItems: FormItemInfo[],
    kzqqDetailFormItems: FormItemInfo[],
    searchFormItems: FormItemInfo[],
    subColumns: TableColumnInfo[],
    subFormItems: FormItemInfo[],
    subTableName: string;
}

export const derivedPageElements = () => {
    const requestClassificationCode = getRequestClassificationCode();
    let elements: PageElements = {formItems: [], searchFormItems: [], columns: [],subColumns:[],subFormItems:[],subTableName:''};
    switch (requestClassificationCode) {
        case '1001':
            elements.columns = cxqqColumns;
            elements.formItems = cxqqFormItems;
            break;
        case '1003':
            elements.columns = kzqqColumns;
            elements.formItems = kzqqFormItems;
            elements.subColumns = controlAccountColumns;
            elements.subFormItems = controlAccountFormItems;
            elements.subTableName = "controlAccount"
            break;
        case '1005':
            elements.columns = returnFailColumns;
            elements.formItems = returnFailFormItems;
            break;
        default:
            break;
    }
    return elements;
}
export const derivedCxPageElements = (requestClassificationCode:string) => {
    let elements: PageElements = {formItems: [], kzqqDetailFormItems:[],searchFormItems: [], columns: [],subColumns:[],subFormItems:[],subTableName:''};
    switch (requestClassificationCode) {
        case '1001':
            elements.columns = cxqqColumns;
            elements.formItems = cxqqFormItems;
            break;
        case '1003':
            elements.columns = kzqqColumns;
            elements.formItems = kzqqFormItems;
            elements.kzqqDetailFormItems = controlAccountFormItems
            elements.subColumns = controlAccountColumns;
            elements.subFormItems = controlAccountFormItems;
            elements.subTableName = "controlAccount"
            break;
        case '1005':
            elements.columns = returnFailColumns;
            elements.formItems = returnFailFormItems;
            break;
        default:
            break;
    }
    return elements;
}

const sqjgdm = 'sqjgdm' + "." + getSubSystem();

export const recordColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {key: 'id', type: 'expand', label: '展开', fixedWidth: 60,scopedSlots: 'expand'},
    {prop: 'createTime', label: '数据日期', width: 150, formatter:dateFormatter,sortable: true},
    // {prop: 'orgCode', label: '申请机构', width: 140, dictFormatKey: sqjgdm},
    // {prop: 'bankCode', label: '银行名称', width: 100, dictFormatKey: 'mbjgdm',sortable: true},
    {prop: 'qqdbs', label: '请求批次号', width: 190,sortable: true},
    {prop: 'importType', label: '导入方式',width:80, dictFormatKey: 'importType'},
    {prop: 'status', label: '文件处理状态', dictFormatKey: 'docProcessingStatus',width:130},
    {prop: 'fileName', label: '文件名', width: 400,sortable: true},
    {prop: 'createBy', label: '创建人',sortable: true},
]

export const recordSearchFormItems: FormItemInfo[] = [
    {prop: 'qqdbs', label: '请求批次号', labelWidth: 80, inputType: 'input'},
    {
        prop: 'branchCodeList', label: '业务操作机构', labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
]
export const htRecordSearchFormItems: FormItemInfo[] = [
    {prop: 'qqdbs', label: '请求批次号', labelWidth: 80, inputType: 'input'},
]

// 查询请求
export const cxqqColumns: TableColumnInfo[] = [
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 200,
        fixed: 'left',
    },
    {prop: 'createTime', label: '数据日期' , minWidth:200, formatter: dateFormatter,sortable: true},
    { prop: 'status', label: '请求处理状态', width: 150, dictFormatKey: 'reqProcessingStatus'},
    { prop: 'bdhm', label: '查询请求单号', width: 150,sortable: true },
    { prop: 'lb', label: '类别', width: 150 ,dictFormatKey:'zgfy_lb',sortable: true},
    { prop: 'xz', label: '性质', width: 150,dictFormatKey:'zgfy_xz' ,sortable: true},
    { prop: 'xm', label: '被查询人姓名', width: 150,sortable: true },
    { prop: 'zjlx', label: '证件类型', width: 150, dictFormatKey:'zgfy_zjlx' ,sortable: true },
    // { prop: 'fydm', label: '执行法院代码', width: 150 },
    { prop: 'dsrzjhm', label: '被查询人证件/组织机构号码', width: 150,sortable: true },
    { prop: 'fymc', label: '执行法院名称', width: 150,sortable: true },
    { prop: 'cbr', label: '承办法官', width: 150,sortable: true },
    { prop: 'yhdh', label: '承办法官联系电话', width: 150 ,sortable: true},
    { prop: 'ah', label: '执行案号', width: 150 ,sortable: true},
    { prop: 'gzzbh', label: '承办法官工作证编号', width: 150,sortable: true },
    { prop: 'gwzbh', label: '承办法官公务证编号', width: 150 ,sortable: true},
    { prop: 'ckh', label: '查询法律文书名称', width: 150,sortable: true },
    { prop: 'ckkssj', label: '账户资金往来交易信息查询开始时间', width: 150,sortable: true },
    // {prop: 'branchCode', label: '业务操作机构' , minWidth:200, dictFormatKey: 'branchTree'},
    { prop: 'ckjssj', label: '账户资金往来交易信息查询结束时间', width: 150 ,sortable: true},
    { prop: 'wsbh', label: '文书编号', width: 150 ,sortable: true},
    {prop: 'createBy', label: '创建人' , minWidth:200,sortable: true},
    {prop: 'updateBy', label: '修改人' , minWidth:200,sortable: true},
    {prop: 'updateTime', label: '修改时间' , minWidth:200, formatter: dateFormatter,sortable: true},
]
// 控制请求
export const kzqqColumns: TableColumnInfo[] = [
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 200,
        fixed: 'left',
    },
    {prop: 'createTime', label: '数据日期' , minWidth:200, formatter: dateFormatter,sortable: true},
    { prop: 'status', label: '请求处理状态', width: 150, dictFormatKey: 'reqProcessingStatus'},
    { prop: "bdhm", label: "控制请求单号", width: 150 ,sortable: true},
    { prop: "lb", label: "类别", width: 150 ,dictFormatKey:'zgfy_lb',sortable: true},
    { prop: "xz", label: "性质", width: 150,dictFormatKey:'zgfy_xz' ,sortable: true},
    { prop: "xm", label: "被查询人姓名", width: 150,
        scopedSlots: {
            default: 'subTable',
        },sortable: true},
    { prop: "zjlx", label: "证件类型", width: 150 , dictFormatKey:'zgfy_zjlx' ,sortable: true},
    // { prop: "fydm", label: "执行法院代码", width: 150 },
    { prop: "dsrzjhm", label: "被查询人证件/组织机构号码", width: 150 ,sortable: true},
    { prop: "fymc", label: "执行法院名称", width: 150 ,sortable: true},
    { prop: "cbr", label: "承办法官", width: 150 ,sortable: true},
    { prop: "yhdh", label: "承办法官联系电话", width: 150 ,sortable: true},
    { prop: "ah", label: "执行案号", width: 150 ,sortable: true},
    { prop: "gzzbh", label: "承办法官工作证编号", width: 150 ,sortable: true},
    { prop: "gwzbh", label: "承办法官公务证编号", width: 150 ,sortable: true},
    { prop: "ckh", label: "控制通知书名称", width: 150 ,sortable: true},
    // {prop: 'branchCode', label: '业务操作机构' , minWidth:200, dictFormatKey: 'branchTree'},
    { prop: "lxfs", label: "承办人联系地址", width: 150 ,sortable: true},
    { prop: "beiz", label: "备注", width: 150 ,sortable: true},
    {prop: 'createBy', label: '创建人' , minWidth:200,sortable: true},
    {prop: 'updateBy', label: '修改人' , minWidth:200,sortable: true},
    {prop: 'updateTime', label: '修改时间' , minWidth:200, formatter: dateFormatter,sortable: true},
]
// 控制请求子表 被执行人账户信息
export const controlAccountColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    { prop: "ccxh", label: "序号", minWidth: 200 ,sortable: true},
    { prop: "kzlx", label: "控制类型", minWidth: 200 , dictFormatKey: 'zgfy_kzlx',sortable: true },
    { prop: "kzcs", label: "控制措施", minWidth: 200 , dictFormatKey: 'zgfy_kzcs',sortable: true},
    { prop: "khzh", label: "开户账号", minWidth: 200 ,sortable: true},
    { prop: "glzhhm", label: "开户账号子账号", minWidth: 200 ,sortable: true},
    { prop: "cclb", label: "账户类别", minWidth: 200 ,sortable: true},
    { prop: "khwd", label: "开户网点", minWidth: 200 ,sortable: true},
    { prop: "khwddm", label: "开户网点代码", minWidth: 200,sortable: true },
    { prop: "zcmc", label: "金融资产名称", minWidth: 200,sortable: true },
    { prop: "zclx", label: "金融资产类型", minWidth: 200 ,sortable: true},
    { prop: "jldw", label: "计量单位", minWidth: 200,sortable: true },
    { prop: "kznr", label: "申请控制内容", minWidth: 200 , dictFormatKey: 'zgfy_kznr' ,sortable: true},
    { prop: "ksrq", label: "申请控制开始时间", minWidth: 200 ,sortable: true},
    { prop: "jsrq", label: "申请控制结束时间", minWidth: 200 ,sortable: true},
    { prop: "bz", label: "申请控制金额币种", minWidth: 200 , dictFormatKey: 'zgfy_bz',sortable: true},
    { prop: "je", label: "申请控制金额（数额）", minWidth: 200,sortable: true },
    { prop: "sfjh", label: "是否结汇", minWidth: 200 ,sortable: true},
    { prop: "ckwh", label: "裁定书文号", minWidth: 200 ,sortable: true},
    { prop: "zxkzhhm", label: "执行款专户户名", minWidth: 200 ,sortable: true},
    { prop: "zxkzhkhh", label: "执行款专户开户行", minWidth: 200 ,sortable: true},
    { prop: "zxkzhkhhhh", label: "执行款专户开户行行号", minWidth: 200 ,sortable: true},
    { prop: "zxkzzh", label: "执行款专户账号", minWidth: 200 ,sortable: true},
    { prop: "zxkzhlx", label: "执行款专户类型", minWidth: 200 ,sortable: true},
    { prop: "ydjah", label: "原冻结案号", minWidth: 200 ,sortable: true},
    { prop: "ydjdh", label: "原冻结请求单号（任务流水号）", minWidth: 200 ,sortable: true},
    // {prop: 'branchCode', label: '业务操作机构' , minWidth:200, dictFormatKey: 'branchTree'},

    { prop: "cpxszl", label: "产品销售种类", minWidth: 200 ,sortable: true},
    { prop: "dqh",    label: "地区号", minWidth: 200 ,sortable: true},
    { prop: "jrcpbh", label: "金融产品编号", minWidth: 200 ,sortable: true},
    { prop: "lczh",   label: "理财账号", minWidth: 200 ,sortable: true},
    { prop: "zjhkzh", label: "资金回款账户", minWidth: 200 ,sortable: true},
    { prop: "se",     label: "申请控制数量/份额/金额", minWidth: 200 ,sortable: true},

    {prop: 'createBy', label: '创建人' , minWidth:200,sortable: true},
    {prop: 'createTime', label: '数据日期' , minWidth:200, formatter: dateFormatter,sortable: true},
    {prop: 'updateBy', label: '修改人' , minWidth:200,sortable: true},
    {prop: 'updateTime', label: '修改时间' , minWidth:200, formatter: dateFormatter,sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 200,
        fixed: 'right',
    },
]
// 法院回退失败反馈
export const returnFailColumns: TableColumnInfo[] = [
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 200,
        fixed: 'left',
    },
    {prop: 'status', label: '回退处理状态', width: 150, dictFormatKey: 'zgfy_clzt',sortable: true},
    {prop: 'returnType', label: '回退类型', width: 150, dictFormatKey: 'zgfy_qqlx',sortable: true},
    { prop: "bdhm", label: "查询请求单号", width: 150 ,sortable: true},
    { prop: "xchtyy", label: "回退原因", width: 150, dictFormatKey: 'zgfy_htyy' ,sortable: true},
    { prop: "xchtbz", label: "回退原因备注", width: 150 ,sortable: true},
    { prop: "xchtr", label: "回退联系人", width: 150 ,sortable: true},
    { prop: "xchtdh", label: "回退联系人电话", width: 150 ,sortable: true},
]
// 查询请求
export const cxqqFormItems: FormItemInfo[] = [
    { prop: "bdhm", label: "查询请求单号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "lb", label: "类别", labelWidth: 150,inputType: {
        tag: 'select',
        options: 'zgfy_lb',
    }, extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "xz", label: "性质", labelWidth: 150,inputType: {
        tag: 'select',
        options: 'zgfy_xz',
    }, extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "xm", label: "被查询人姓名", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "zjlx", label: "证件类型", labelWidth: 150,        inputType: {
        tag: 'select',
        options: 'zgfy_zjlx',
    }, extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "dsrzjhm", label: "被查询人证件/组织机构号码", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "fymc", label: "执行法院名称", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "fydm", label: "执行法院代码", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "cbr", label: "承办法官", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "yhdh", label: "承办法官联系电话", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "ah", label: "执行案号", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "gzzbh", label: "承办法官工作证编号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "gwzbh", label: "承办法官公务证编号", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "ckh", label: "查询法律文书名称", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "ckkssj", label: "账户资金往来交易信息查询开始时间", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "ckjssj", label: "账户资金往来交易信息查询结束时间", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "wsbh", label: "文书编号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}}
]
// 控制请求
export const kzqqFormItems: FormItemInfo[] = [
    { prop: "bdhm", label: "控制请求单号", labelWidth: 150, inputType: "input" },
    { prop: "lb", label: "类别", labelWidth: 150,inputType: {
        tag: 'select',
        options: 'zgfy_lb',
    },},
    { prop: "xz", label: "性质", labelWidth: 150,inputType: {
        tag: 'select',
        options: 'zgfy_xz',
    },},
    { prop: "xm", label: "被查询人姓名", labelWidth: 150, inputType: "input" },
    { prop: "zjlx", label: "证件类型", labelWidth: 150,         inputType: {
        tag: 'select',
        options: 'zgfy_zjlx',
    }, },
    { prop: "dsrzjhm", label: "被查询人证件/组织机构号码", labelWidth: 150, inputType: "input" },
    { prop: "fymc", label: "执行法院名称", labelWidth: 150, inputType: "input" },
    { prop: "fydm", label: "执行法院代码", labelWidth: 150, inputType: "input" },
    { prop: "cbr", label: "承办法官", labelWidth: 150, inputType: "input" },
    { prop: "yhdh", label: "承办法官联系电话", labelWidth: 150, inputType: "input" },
    { prop: "ah", label: "执行案号", labelWidth: 150, inputType: "input" },
    { prop: "gzzbh", label: "承办法官工作证编号", labelWidth: 150, inputType: "input" },
    { prop: "gwzbh", label: "承办法官公务证编号", labelWidth: 150, inputType: "input" },
    { prop: "ckh", label: "控制通知书名称", labelWidth: 150, inputType: "input" },
    { prop: "lxfs", label: "承办人联系地址", labelWidth: 150, inputType: "input" },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: "input" }
]
// 控制请求子表 被执行人账户信息
export const controlAccountFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "序号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "kzlx", label: "控制类型", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_kzlx',
        }, extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "kzcs", label: "控制措施", labelWidth: 150 ,inputType: {
            tag: 'select',
            options: 'zgfy_kzcs',
    }, extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "khzh", label: "开户账号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "glzhhm", label: "开户账号子账号", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "cclb", label: "账户类别", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "khwd", label: "开户网点", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "khwddm", label: "开户网点代码", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "zcmc", label: "金融资产名称", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "zclx", label: "金融资产类型", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "jldw", label: "计量单位", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "kznr", label: "申请控制内容", labelWidth: 150,  inputType: {
        tag: 'select',
        options: 'zgfy_kznr',
        // // multiple: true,
    }, extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "ksrq", label: "申请控制开始时间", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "jsrq", label: "申请控制结束时间", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "bz", label: "申请控制金额币种", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_bz',
            // // multiple: true,
        }, extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "je", label: "申请控制金额（数额）", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "sfjh", label: "是否结汇", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "ckwh", label: "裁定书文号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "zxkzhhm", label: "执行款专户户名", labelWidth: 150, inputType: "input", extra: {collapse: {name: 'body', title: '主体信息'}} },
    { prop: "zxkzhkhh", label: "执行款专户开户行", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "zxkzhkhhhh", label: "执行款专户开户行行号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "zxkzzh", label: "执行款专户账号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "zxkzhlx", label: "执行款专户类型", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "ydjah", label: "原冻结案号", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "ydjdh", label: "原冻结请求单号（任务流水号）", labelWidth: 150, inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "cpxszl", label: "产品销售种类", labelWidth: 150,inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}  },
    { prop: "dqh",label: "地区号", labelWidth: 150,inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}    },
    { prop: "jrcpbh",label: "金融产品编号", labelWidth: 150,inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
    { prop: "lczh",label: "理财账号", labelWidth: 150,inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}    },
    { prop: "zjhkzh",label: "资金回款账户", labelWidth: 150,inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}  },
    { prop: "se",label: "申请控制数量/份额/金额", labelWidth: 150,inputType: "input" , extra: {collapse: {name: 'body', title: '主体信息'}}},
]
// 法院回退失败反馈
export const returnFailFormItems: FormItemInfo[] = [
    { prop: "bdhm", label: "查询请求单号", labelWidth: 150, inputType: "input" },
    { prop: "xchtyy", label: "回退原因", labelWidth: 150,inputType: {
        tag: 'select',
        options: 'zgfy_htyy',
        // // multiple: true,
    }, },
    { prop: "xchtbz", label: "回退原因备注", labelWidth: 150, inputType: "input" },
    { prop: "xchtr", label: "回退联系人", labelWidth: 150, inputType: "input" },
    { prop: "xchtdh", label: "回退联系人电话", labelWidth: 150, inputType: "input" }

]


// 高级查询
export const advancedQueryItems = [
    { value: 'file_name', label: '文件名', inputType: { tag: 'input' } },
    // { value: 'bank_code', label: '银行名称', inputType: { tag: 'input' } },
    { value: 'create_by', label: '创建人', labelWidth: 80, inputType: 'input'},
    { value: 'import_type', label: '导入方式', labelWidth: 80, inputType: {
            tag: 'select',
            options: 'importType',
        }},
    { value: 'status', label: '文件处理状态', labelWidth: 80,inputType: {
            tag: 'select',
            options: 'docProcessingStatus',
        }},
    { value: 'create_time', label: '数据日期', labelWidth: 80, inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]},
]
































