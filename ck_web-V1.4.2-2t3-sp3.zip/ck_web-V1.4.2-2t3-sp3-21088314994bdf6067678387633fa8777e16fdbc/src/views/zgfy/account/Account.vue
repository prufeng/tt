<template>
  <rk-index-layout>
    <rk-dynamic-search-form
      ref="searchFormRef"
      v-model="searchForm"
      :loading="loading"
      @keyup.enter="search"
      :form-items="getRequestClassificationCode() != 1005 ? recordSearchFormItems : htRecordSearchFormItems"
      :fields="advancedQueryItems"
      @search="search"
      :label-width="50"
    ></rk-dynamic-search-form>
    <rk-page-table
      :loading="state.loading"
      :columns="recordColumns"
      :data="data"
      :pagination="page"
      :row-key="getRowKey"
      :expand-row-keys="expands"
      @page-change="pageChange"
      @refresh="search"
      @selection-change="handleSelectionChange"
      @expand-change="clickRowHandle"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
          <div style="margin: 0 4px"></div>
          <UpAndDown :imp="imp" :exp="exp" />
        </div>
      </template>

      <template #expand="{ row }">
        <rk-page-table
          :loading="treeLoading"
          :data="treeData"
          :columns="columns"
          border="true"
          max-height="500"
          hiddenTableTools
          style="margin-left: 30px; width: 98%"
          :pagination="treePage"
          @page-change="(p: Pagination) => treePageChange(p, row)"
          @refresh="treeSearch"
        >
          <template #actions="{ row: subRow }">
            <rk-button-group :buttons="genActButtons(subRow, row)" :route-meta="$route.meta" :max="3" link />
          </template>
          <template #subTable="{ row }">
            <el-button type="primary" :underline="false" link @click="openSubTable(row.bdhm, row.status)">{{
              row.xm
            }}</el-button>
          </template>
        </rk-page-table>
      </template>
    </rk-page-table>
  </rk-index-layout>

  <!-- 弹出层 -->
  <el-dialog
    v-model="dialogData.visible"
    :title="dialogData.title"
    class="rk-dialog-default"
    @closed="closed"
    :close-on-click-modal="false"
  >
    <rk-detail-form ref="dialogFormRef" v-model="form" :form-items="formItems" :disabled="dialogData.formDisabled" />

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 子表弹出层 -->
  <el-dialog v-model="subTableVisible" title="详细信息" class="rk-dialog-default">
    <rk-page-table
      :loading="subLoading"
      :columns="subColumns"
      :data="subData"
      :pagination="subPage"
      @page-change="subPageChange"
      @refresh="subSearch"
      @selection-change="handleSelectionChange"
    >
      <template #actions="{ row }">
        <rk-button-group :buttons="genSubActButtons(row)" :route-meta="$route.meta" link />
      </template>
    </rk-page-table>
  </el-dialog>
  <!-- 子表form弹出层 -->
  <el-dialog v-model="subDialogData.visible" :title="subDialogData.title" class="rk-dialog-default" @closed="subClosed">
    <rk-detail-form
      ref="subDialogFormRef"
      v-model="subForm"
      :form-items="subFormItems"
      :disabled="subDialogData.formDisabled"
    />
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="subClose"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 请求单页面反馈弹出框 -->
  <el-dialog title="反馈" v-model="feedbackDialog" width="90%" @closed="clearFeedbackForm()">
    <rk-collapse-form
      v-if="getRequestClassificationCode() === '1001'"
      ref="bodyFormRef"
      v-model="bodyForm"
      :form-items="
        formItems.filter((item) => {
          return (
            item.extra &&
            item.extra.collapse &&
            item.extra.collapse.name === 'body' &&
            item.extra.collapse.title === '主体信息'
          )
        })
      "
      :disabled="true"
    />
    <rk-collapse-form
      v-else
      ref="subBodyFormRef"
      v-model="subBodyForm"
      :form-items="
        subFormItems.filter((item) => {
          return (
            item.extra &&
            item.extra.collapse &&
            item.extra.collapse.name === 'body' &&
            item.extra.collapse.title === '主体信息'
          )
        })
      "
      :disabled="true"
    />
    <div>
      <h4>反馈信息</h4>
    </div>
    <!-- <rk-detail-form ref="feedbackFormRef" v-model="feedbackForm" :form-items="[
      {
        prop: 'qqdbs',
        label: '请求批次号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      }, {
        prop: 'bdhm',
        label: '请求单号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      }, ...getFeelbackItem(feelbackItem[0].items)]">
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled=true filterable style="width: 100%">
        </el-input>
      </template>
    </rk-detail-form> -->
    <rk-detail-form ref="feedbackFormRef" v-model="feedbackForm" :form-items="cxFkFormItems">
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled="true" filterable style="width: 100%"> </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="feedback">保存</el-button>
        <el-button @click="feedbackDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 指派机构表格弹出框 -->
  <el-dialog title="指派" v-model="assignmentDialog" width="70%">
    <rk-page-table
      ref="assignmentTable"
      :loading="assignmentLoading"
      :data="assignmentData"
      :columns="assignmentColumns"
      border="true"
      @selection-change="assignmentIdsHandleSelectionChange"
      @refresh="assignmentSearch"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <!-- 此处按钮无需做权限配置 即:route-meta="[]"即可-->
          <rk-button-group :buttons="assignmentButtons" :route-meta="[]"></rk-button-group>
        </div>
      </template>
    </rk-page-table>
  </el-dialog>
  <!-- 指派机构form弹出框 -->
  <el-dialog
    title="新增指派"
    v-model="assignmentFormDialog"
    width="70%"
    @closed="
      () => {
        assignmentFormRef.resetFields()
      }
    "
  >
    <rk-detail-form
      ref="assignmentFormRef"
      v-model="assignmentForm"
      :form-items="[
        {
          prop: 'qqdbs',
          label: '请求批次号',
          labelWidth: 150,
          inputType: 'input',
          scopedSlot: 'systemCode',
        },
        {
          prop: 'rwlsh',
          label: '请求单号',
          labelWidth: 150,
          inputType: 'input',
          scopedSlot: 'systemCode',
        },
        {
          prop: 'branchCode',
          label: '业务操作机构',
          labelWidth: 150,
          inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
          },
          rules: [{ required: true, message: '业务操作机构不能为空' }],
        },
      ]"
    >
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled="true" filterable style="width: 100%"> </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="assignmentSave">保存</el-button>
        <el-button @click="assignmentFormDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button
      v-for="xmlKey in xmlButtonKeys"
      :key="xmlKey"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="openXml(xmlKey)"
    >
      {{ xmlKey }}
    </el-button>
  </el-dialog>

  <div class="img-viewer-box">
    <el-image-viewer
      v-if="showImageViewer"
      :url-list="urlList"
      @close="
        () => {
          showImageViewer = false
        }
      "
    />
  </div>

  <el-dialog v-model="docDialogVisible" title="法律文书列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button
      v-for="key in docKeys"
      :key="key"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="openPdf(key)"
    >
      {{ key }}
    </el-button>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage, ElImageViewer } from 'element-plus'
import {
  assignmentDialog,
  assignmentLoading,
  assignmentData,
  assignmentColumns,
  // assignmentPage,
  // assignmentPageChange,
  assignmentSearch,
  assignmentButtons,
  assignmentQqdbs,
  assignmentRwlsh,
  assignmentIdsHandleSelectionChange,
  assignmentSave,
  assignmentFormDialog,
  assignmentFormRef,
  assignmentForm,
} from '@/utils/assignment'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  RkDetailForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  FormItemInfo,
  TableColumnInfo,
  dictFormatter,
} from 'riking-ui'
import { pagination, subPagination, treePagination } from '@/views/zgfy/account/data'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'
import { useDict } from 'riking-layout'
import {
  derivedPageElements,
  recordColumns,
  recordSearchFormItems,
  advancedQueryItems,
  htRecordSearchFormItems,
} from '@/views/zgfy/account/page'
import {
  list,
  impZip,
  getOne,
  cxSearchList,
  getPdf,
  getImage,
  downloadZip,
  subList,
  treeList,
  checkData,
  getXml,
  updateRequestStatus,
  exportExcel,
  isSameKhzh,
} from '@/views/zgfy/account/api'
import UpAndDown, { expLoading } from '@/components/UpAndDown.vue'
import { feedbackSaveData } from '@/views/zgfy/feedback/api'
import { getRequestClassificationCode } from '@/utils/subSystem'
import { copyProperties } from '@/utils/utils'
import { derivedPageElements as feedbackDerivedPageElements } from '@/views/zgfy/feedback/page'
import { setRequiredRule } from '@/views/system/sum'

const loading = ref(false)
const data = ref<any[]>([])
const page = ref<Pagination>(pagination)
const dialogVisible = ref(false)
const xmlButtonKeys = ref({})
const xmlDataList = ref({})

const docDialogVisible = ref(false)
const docKeys = ref({})
const docs = ref({})

const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const showImageViewer = ref(false) //组件是否显示
const urlList = ref([]) //图片List

const { state, init } = useState(cxSearchList)
let keyword: string
let columns: TableColumnInfo[] = [],
  formItems: FormItemInfo[] = [],
  searchFormItems: FormItemInfo[] = []
const cxFkFormItems = ref([])
// todo 测试多线程下动态表名的问题，多几次程序调用
// const props = defineProps<{ requestClassificationCode: string | string[] }>();

useDict([], [], dictData)

onMounted(() => {
  page.value = { ...pagination }
  let pageElements = derivedPageElements()
  columns = pageElements.columns
  formItems = pageElements.formItems
  feelbackItem = feedbackDerivedPageElements(getFeedbackCode(getRequestClassificationCode())).formItems
  searchFormItems = pageElements.searchFormItems
  subColumns = pageElements.subColumns
  subFormItems = pageElements.subFormItems
  subTableName = pageElements.subTableName
  let tempItems = [
    {
      prop: 'qqdbs',
      label: '请求批次号',
      labelWidth: 150,
      inputType: 'input',
      scopedSlot: 'systemCode',
    },
    {
      prop: 'bdhm',
      label: '请求单号',
      labelWidth: 150,
      inputType: 'input',
      scopedSlot: 'systemCode',
    },
    ...getFeelbackItem(feelbackItem[0].items),
  ]
  cxFkFormItems.value = JSON.parse(JSON.stringify(tempItems))
  search()
})
let ids: string
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(',')
}
function getFeelbackItem(formInfo) {
  // 找到目标项的索引
  const targetIndex = formInfo.findIndex((item) => item.prop === 'branchCode')
  // 如果找到了目标项，则进行修改
  if (targetIndex !== -1) {
    // 在目标项中添加 rules 属性
    formInfo[targetIndex].rules = [{ required: true, message: `必填` }]
  } else {
    // 如果找不到目标项，可以进行相应的处理，比如输出错误信息
    console.error("未找到目标项 'branchCode'")
  }
  return formInfo
}
const search = async () => {
  init()
  let value = searchForm.value
  const newObject = { ...searchForm.value }
  for (const key in newObject) {
    if (newObject[key] === '') {
      newObject[key] = null
      console.log('转化了空串')
    }
  }
  if (value.createTime != undefined) {
    newObject.endTime = formatDate(new Date(value.createTime[1]))
    newObject.createTime = formatDate(new Date(value.createTime[0]))
  }
  let result = await list(newObject, page.value.currentPage, page.value.pageSize)
  let { current, total, records } = result.data
  data.value = records
  page.value.currentPage = current
  page.value.total = total
  if (expands.value.length != 0) {
    //如果存在展开行,清空expands.value数组,使它关闭
    expands.value.splice(0, expands.value.length)
    treeData.value = []
  }
}

const imp = async (data = {}) => {
  var needBeOverridden = await checkData(data)
  if (needBeOverridden.data) {
    ElMessageBox.confirm('检测到上传文件的请求批次号已存在,是否覆盖?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    })
      .then(async () => {
        await impZip(data)
        ElMessage.success('覆盖成功')
        await search()
      })
      .catch(() => {
        // ElMessage.warning("取消导入");
        return
      })
  } else {
    await impZip(data)
    ElMessage.success('导入成功')
    await search()
  }
}

const exp = async () => {
  expLoading.value = true
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    const newObject = { ...searchForm.value }
    await exportExcel(ids, newObject)
  } finally {
    expLoading.value = false
  }
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

// const basicForm = ref({});
// const personForm = ref({});
// const basicFormRef = ref<RkFormInstance>();
// const personFormRef = ref<RkFormInstance>();
// const collapseFormRef = ref<RkFormInstance>()
// const collapseForm = ref({})

const genActButtons: (subRow: any, row: any) => ButtonInfo[] = (subRow: any, row: any) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: () => {
        open(subRow, true, '查看')
      },
    },
    {
      key: 'viewXml',
      label: 'XML',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        const result = await getXml(row)
        const keys = Object.keys(result.data)
        xmlButtonKeys.value = keys
        xmlDataList.value = result.data
        dialogVisible.value = true
      },
    },
  ]
  if (getRequestClassificationCode() != '1005') {
    buttons.splice(2, 0, {
      key: 'viewPdf',
      label: '法律文书',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        const result = await getPdf(subRow)
        if (result.code == 500) {
          ElMessage.error({ message: result.data, grouping: true, showClose: true, duration: 0 })
          return
        }

        // docKeys.value = Object.keys(result.data)
        // docs.value = result.data
        // docDialogVisible.value = true

        // let pdfWindow = window.open("", 'pdf预览');
        let pdfWindow = window.open('')
        // 将base64字符串转换为Uint8Array对象
        var pdfData = atob(result.data)
        var pdfArray = new Uint8Array(pdfData.length)
        for (var i = 0; i < pdfData.length; i++) {
          pdfArray[i] = pdfData.charCodeAt(i)
        }
        // 创建Blob对象
        var pdfBlob = new Blob([pdfArray], { type: 'application/pdf' })
        // 将Blob对象转换为URL
        var pdfUrl = URL.createObjectURL(pdfBlob)
        // 将URL作为iframe的src属性值
        pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>")
      },
    })
    buttons.splice(3, 0, {
      key: 'viewImage',
      label: '法官证件',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        const result = await getImage(subRow)
        if (result.code == 500) {
          ElMessage.error({ message: result.data, grouping: true, showClose: true, duration: 0 })
          return
        }
        urlList.value = []
        for (const image in result.data) {
          // 将base64字符串转换为Uint8Array对象
          const jpgData = atob(result.data[image])
          const jpgArray = new Uint8Array(jpgData.length)
          for (let i = 0; i < jpgData.length; i++) {
            jpgArray[i] = jpgData.charCodeAt(i)
          }
          // 创建Blob对象
          const jpgBlob = new Blob([jpgArray], { type: 'image/jpeg' })
          // 将Blob对象转换为URL
          const jpgUrl = URL.createObjectURL(jpgBlob)
          // 将URL作为iframe的src属性值
          urlList.value = [...urlList.value, jpgUrl]
        }
        showImageViewer.value = true
      },
    })
    buttons.splice(1, 0, {
      key: 'assignment',
      label: '指派',
      tag: 'button',
      type: 'primary',
      handler: () => {
        if (subRow.status == '4' || subRow.status == '5') {
          ElMessage.warning('该条数据已经生成或上报报文,无法指派机构')
          return
        }
        assignmentDialog.value = true
        assignmentForm.value = {}
        const data = toRaw(assignmentForm.value)
        data.qqdbs = subRow.qqdbs
        data.rwlsh = subRow.bdhm
        assignmentQqdbs.value = subRow.qqdbs
        assignmentRwlsh.value = subRow.bdhm
        assignmentSearch()
      },
    })
  }
  if (getRequestClassificationCode() != '1005' && getRequestClassificationCode() != '1003') {
    buttons.splice(1, 0, {
      key: 'feedback',
      label: '反馈',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        if (subRow.status == '4' || subRow.status == '5') {
          ElMessage.warning('该条数据已经生成或上报报文,无法新增反馈')
          return
        }

        let toRaw1 = toRaw(bodyForm.value)
        for (const key in subRow) {
          if (subRow.hasOwnProperty(key)) {
            toRaw1[key] = subRow[key]
          }
        }

        let data = toRaw(feedbackForm.value)
        data.qqdbs = subRow.qqdbs
        data.bdhm = subRow.bdhm
        data = copyProperties(data, subRow, getRequestClassificationCode())

        feedbackDialog.value = true
      },
    })
  }
  return buttons
}
const openXml = (key: any) => {
  // 将base64字符串转换为Uint8Array对象
  console.log(xmlDataList.value[key])
  var xmlData = atob(xmlDataList.value[key])
  var xmlArray = new Uint8Array(xmlData.length)
  for (var i = 0; i < xmlData.length; i++) {
    xmlArray[i] = xmlData.charCodeAt(i)
  }
  // 创建Blob对象
  var xmlBlob = new Blob([xmlArray], { type: 'text/xml' })
  // 将Blob对象转换为URL
  var xmlUrl = URL.createObjectURL(xmlBlob)
  let xmlWindow = window.open(xmlUrl, 'xml预览')
}

const openPdf = (key: any) => {
  // let pdfWindow = window.open("", 'pdf预览');
  let pdfWindow = window.open('')
  // 将base64字符串转换为Uint8Array对象
  const pdfData = atob(docs.value[key])
  const pdfArray = new Uint8Array(pdfData.length)
  for (let i = 0; i < pdfData.length; i++) {
    pdfArray[i] = pdfData.charCodeAt(i)
  }
  // 创建Blob对象
  const pdfBlob = new Blob([pdfArray], { type: 'application/pdf' })
  // 将Blob对象转换为URL
  const pdfUrl = URL.createObjectURL(pdfBlob)
  // 将URL作为iframe的src属性值
  pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>")
}

const buttons: ButtonInfo[] = [
  {
    key: 'download',
    label: '下载',
    tag: 'button',
    type: 'primary',
    icon: 'icon_download',
    handler: async () => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
      }
      const result = await downloadZip(ids)
      if (result.code == 500) {
        ElMessage.error({ message: result.data, grouping: true, showClose: true, duration: 0 })
      }
    },
  },
]
const activeCollapse = ref(['basic', 'body', 'person'])
function formatDate(date: Date) {
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  const seconds = date.getSeconds().toString().padStart(2, '0')

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
}
/**
 * 树状表所需组件和方法
 * */
const {
  dialogData: treeDialogData,
  open: treeOpen,
  close: treeClose,
  closed: treeClosed,
  form: treeForm,
  nameRef: treeDialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('treeDialogFormRef', { type: [] })
const treePage = ref<Pagination>(treePagination)
const treeData = ref<any[]>([])
const treeLoading = ref(false)
const qqdbs = ref('')
let expands = ref<any[]>([])
const treeSearch = async (row: any) => {
  treeLoading.value = true
  qqdbs.value = row.qqdbs
  try {
    var branchCodeList
    if (searchForm.value.branchCodeList == null) {
      branchCodeList = null
    } else {
      branchCodeList = Array.from(searchForm.value.branchCodeList).join('-|-')
    }
    let result = await treeList(qqdbs.value, [], treePage.value.currentPage, treePage.value.pageSize, branchCodeList)
    let { current, total, records } = result.data
    treeData.value = records
    treePage.value.currentPage = current
    treePage.value.total = total
  } finally {
    treeLoading.value = false
  }
}
const treePageChange = (p: Pagination, row: any) => {
  treePage.value = p
  treeSearch(row)
}
const getRowKey = (row: any) => {
  return row.id
}
const clickRowHandle = (row: any) => {
  treePage.value = treePagination
  if (expands.value.includes(row.id)) {
    expands.value = expands.value.filter((val) => val !== row.id)
  } else {
    //判断是否已经存在展开的行
    if (expands.value.length != 0) {
      //如果存在展开行,清空expands.value数组,使它关闭
      expands.value.splice(0, expands.value.length)
      //打开点击的行
      expands.value.push(row.id)
    } else {
      //如果不存在展开行,直接push打开点击的行
      expands.value.push(row.id)
    }
  }
  treeSearch(row)
}
/**
 * 子表所需组件和方法
 * */
const subPage = ref<Pagination>(subPagination)
const subData = ref<any[]>([])
const subTableVisible = ref(false)
let subColumns = []
let subFormItems = []
let subTableName = ''
const subLoading = ref(false)
const bdhm = ref('')
const {
  dialogData: subDialogData,
  open: subOpen,
  close: subClose,
  closed: subClosed,
  form: subForm,
  nameRef: subDialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('subDialogFormRef', { type: [] })

const genSubActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  let buttons: ButtonInfo[] = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: () => {
        subOpen(row, true, '查看')
      },
    },
  ]
  //row.status == '已反馈'不显示反馈按钮
  if (!(row.status == '已反馈')) {
    buttons.push({
      key: 'feedback',
      label: '反馈',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        if (mainTableStatus.value == '4' || mainTableStatus.value == '5') {
          ElMessage.warning('该条数据已经生成或上报报文,无法新增反馈')
          return
        }
        // if (getRequestClassificationCode() == '1003') {
        //   //控制类型不为2：非存款类金融资产,实际控制可用金额必填
        //   setRequiredRule(['skje'], row.kzlx != '2', cxFkFormItems.value)
        // }
        let toRaw1 = toRaw(subBodyForm.value)
        for (const key in row) {
          if (row.hasOwnProperty(key)) {
            toRaw1[key] = row[key]
          }
        }

        // let data = toRaw(feedbackForm.value)
        let data = feedbackForm.value
        data.qqdbs = row.qqdbs
        data.bdhm = row.bdhm
        data = copyProperties(data, row, getRequestClassificationCode())

        feedbackDialog.value = true
      },
    })
  }
  return buttons
}

const subSearch = async () => {
  subLoading.value = true
  try {
    let result = await subList(bdhm.value, [], subPage.value.currentPage, subPage.value.pageSize, subTableName)
    let { current, total, records } = result.data
    subData.value = records
    subPage.value.currentPage = current
    subPage.value.total = total
  } finally {
    subLoading.value = false
  }
}
const subPageChange = (p: Pagination) => {
  subPage.value = p
  subSearch()
}
const openSubTable = (BDHM: string, status: string) => {
  bdhm.value = BDHM
  mainTableStatus.value = status
  subTableVisible.value = true
  subPageChange(subPagination)
}
/**
 * 反馈弹出框所需组件
 * */
const mainTableStatus = ref('')
let feelbackItem: FormItemInfo[] = []
const feedbackDialog = ref(false)
const feedbackForm = ref({})
const feedbackFormRef = ref<RkFormInstance>()
const bodyForm = ref({})
const bodyFormRef = ref<RkFormInstance>()
const subBodyForm = ref({})
const subBodyFormRef = ref<RkFormInstance>()
const feedback = async () => {
  const valid = await feedbackFormRef.value?.asyncValidate()
  if (!valid) {
    return
  }
  const data = toRaw(feedbackForm.value)
  data.status = '1'
  data.deleted = '0'
  const res = await isSameKhzh(getRequestClassificationCode(), data)
  if (res.code == 200) {
    await updateRequestStatus(getRequestClassificationCode(), data)
    await feedbackSaveData(data, getFeedbackCode(getRequestClassificationCode()))
    await search()
    const code = getRequestClassificationCode()
    if ('1003' === code) {
      await subSearch()
    }
    feedbackDialog.value = false
    ElMessage.success('保存成功')
  } else {
    ElMessage.error({ message: res.msg, grouping: true, duration: 0, showClose: true })
  }
}
function getFeedbackCode(reportCode: string) {
  switch (reportCode) {
    case '1001':
      return 'fkCxqq'
    case '1003':
      return 'fkKzqq'
  }
}
function clearFeedbackForm() {
  feedbackForm.value = {}
  bodyForm.value = {}
  subBodyForm.value = {}
  feedbackFormRef.value?.resetFields()
  bodyFormRef.value?.resetFields()
  subBodyFormRef.value?.resetFields()
}

watch(
  () => [feedbackForm.value, cxFkFormItems.value],
  (newVal) => {
    setRequiredRule(['ccxh'], feedbackForm.value?.ccxh, cxFkFormItems.value)
    //控制请求反馈  根据控制结果控制未控原因是否必填
    if (feedbackForm?.value?.kzzt) {
      setRequiredRule(['skje'], subBodyForm.value.kzlx != '2' && feedbackForm.value.kzzt == '1', cxFkFormItems.value)
      setRequiredRule(['wnkzyy'], feedbackForm.value.kzzt == '2', cxFkFormItems.value)
      setRequiredRule(
        ['kznr', 'ye', 'kyye', 'csksrq', 'csjsrq', 'djxe', 'khmc', 'khbh', 'branchCode'],
        feedbackForm.value.kzzt == '1',
        cxFkFormItems.value,
      )
    } else {
      //查询请求反馈
      // 开户账号:查无开户信息 以下必填不要
      setRequiredRule(
        ['cclb', 'zhzt', 'khwd', 'khwddm', 'khrq', 'bz', 'khmc', 'khbh', 'branchCode'],
        feedbackForm.value.khzh != '查无开户信息',
        cxFkFormItems.value,
      )
    }
  },
  {
    deep: true,
  },
)
</script>

<style scoped>
/*.parent :deep(.children) {样式内容}*/

.request-body :deep(.el-table__expanded-cell .table-header) {
  display: none;
}

.request-body :deep(.el-table__row) {
  background: gainsboro !important;
}

.request-body :deep(.el-table__expanded-cell .el-table__row) {
  background: transparent !important;
}

/*.test :deep(.el-table__cell) {*/
/*  background: gainsboro !important;*/
/*}*/

/*.test :deep(.el-table__expanded-cell .el-table__cell) {*/
/*  background: transparent !important;*/
/*}*/
</style>
