import {RS} from 'riking-ui'
import service from '@/utils/request'

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: `/zgfyLedger/list`,
        method: 'POST',
        data,
        params: {current, size}
    })
}

export function getById(params = {}): Promise<RS> {
    return service({
        url: `/zgfyLedger/getById`,
        method: 'GET',
        params,
    })
}

export function saveOrUpdate(data = {}): Promise<RS> {
    return service({
        url: `/zgfyLedger/saveOrUpdate`,
        method: 'POST',
        data,
    })
}
export function submit(ids:string): Promise<RS> {
    return service({
        url: `/zgfyLedger/submit`,
        method: 'POST',
        params:{ids},
    })
}
export function auditPass(ids:string): Promise<RS> {
    return service({
        url: `/zgfyLedger/auditPass`,
        method: 'POST',
        params:{ids},
    })
}
export function auditNoPass(ids:string, msg: string): Promise<RS> {
    return service({
        url: `/zgfyLedger/auditNoPass`,
        method: 'POST',
        params:{ids, msg},
    })
}

export function delByIds(ids: string): Promise<RS> {
    return service({
        url: `/zgfyLedger/delByIds`,
        method: 'POST',
        params: {ids: ids},
    })
}

export function exportExcel(data = {}): Promise<RS> {
    return service({
        url: `/zgfyLedger/exportExcel`,
        method: 'POST',
        data,
        // params: {ids},
        responseType: 'blob'
    })
}
