<template>
  <rk-collapse-form
    :form-items="formItems"
    v-model="form"
    disabled="true"
    ref="nameRef"
    :collapse-model-value="activeCollapse"
  >
  </rk-collapse-form>
  <rk-collapse-form
    :form-items="kzqqDetailFormItems"
    v-model="formDetail"
    disabled="true"
    ref="nameDetailRef"
    :collapse-model-value="activeCollapse"
  >
  </rk-collapse-form>
  <div class="btnDiv">
    <rk-button-group
      :buttons="genActButtons({ wsbh: wsbh, gzzbh: gzzbh, gwzbh: gwzbh, qqdbs: qqdbs, bdhm: bdhm }, recordData)"
      :route-meta="[]"
      max="10"
    />
  </div>

  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button
      v-for="xmlKey in xmlButtonKeys"
      :key="xmlKey"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="openXml(xmlKey)"
      >{{ xmlKey }}
    </el-button>
  </el-dialog>
  <div class="img-viewer-box">
    <el-image-viewer
      v-if="showImageViewer"
      :url-list="urlList"
      @close="
        () => {
          showImageViewer = false
        }
      "
    />
  </div>

  <el-dialog v-model="docDialogVisible" title="法律文书列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button
      v-for="key in docKeys"
      :key="key"
      type="primary"
      link
      style="margin-bottom: 10px; display: flex; flex-direction: column"
      @click="openPdf(key)"
    >
      {{ key }}
    </el-button>
  </el-dialog>
</template>

<script setup lang="ts">
import { ButtonInfo, RkButtonGroup, RkCollapseForm } from 'riking-ui'
import configs from '@/views/zgfy/account/sum'
import { ref, defineProps, defineEmits } from 'vue'
import { derivedCxPageElements } from '@/views/zgfy/account/page'
import { getImage, getPdf, getXml } from '@/views/zgfy/feedback/api'
import { subList } from '@/views/zgfy/account/api'
import { listSysFileImportRecord } from '@/views/zgfy/feedback/api'
import { ElButton, ElDialog, ElImageViewer, ElMessage } from 'element-plus'

const activeCollapse = ref([])

const loading = ref(false)
const form = ref({})
const formDetail = ref({})
const nameRef = ref()
const nameDetailRef = ref()
const recordData = ref()
const wsbh = ref()
const gzzbh = ref()
const gwzbh = ref()
const showImageViewer = ref(false) //组件是否显示
const urlList = ref([]) //图片List
const dialogVisible = ref(false)
const xmlButtonKeys = ref({})
const xmlDataList = ref({})

const props = defineProps(['fkReportCode', 'visible', 'bdhm', 'qqdbs', 'rowValue'])
const emit = defineEmits(['getCxDetail'])
const reportCode = configs.reportCodeMap.get(props.fkReportCode)
let pageElements = derivedCxPageElements(reportCode)
let formItems = pageElements.formItems
let kzqqDetailFormItems = pageElements.kzqqDetailFormItems

const docDialogVisible = ref(false)
const docKeys = ref({})
const docs = ref({})

formItems = formItems.map((item) => {
  let newObj = {
    ...item,
    extra: {
      collapse: { name: 'cx', title: '请求数据项' },
    },
  }
  return newObj
})
kzqqDetailFormItems = kzqqDetailFormItems.map((item) => {
  let newObj = {
    ...item,
    extra: {
      collapse: { name: 'cx', title: '请求详细信息' },
    },
  }
  return newObj
})
onMounted(() => {
  activeCollapse.value = []
  search()
})

watch(
  () => props.visible,
  (newVal) => {
    if (newVal) {
      clear()
      search()
    }
  },
)

const search = async () => {
  loading.value = true
  try {
    //查反馈数据对应的请求表数据
    let result = await subList(props.bdhm, [], null, null, reportCode)
    if (result.data.records.length == 0) {
      return
    }
    let res = await subList(props.bdhm, [], 1, 10, 'controlAccount')
    if (res.data.records.length > 0) {
      const detailsVal = res.data.records.filter((item) => item.ccxh == props.rowValue.ccxh)[0]
      formDetail.value = detailsVal
      //将请求详细信息传到父组件
      emit('getCxDetail', detailsVal)
    }
    form.value = result.data.records[0]
    wsbh.value = result.data.records[0]?.wsbh
    gzzbh.value = result.data.records[0]?.gzzbh
    gwzbh.value = result.data.records[0]?.gwzbh
    //查这条反馈数据的附件表
    let record = await listSysFileImportRecord({ qqdbs: props.qqdbs })
    recordData.value = record.data
  } finally {
    loading.value = false
  }
}
const openXml = (key: any) => {
  // 将base64字符串转换为Uint8Array对象
  console.log(xmlDataList.value[key])
  var xmlData = atob(xmlDataList.value[key])
  var xmlArray = new Uint8Array(xmlData.length)
  for (var i = 0; i < xmlData.length; i++) {
    xmlArray[i] = xmlData.charCodeAt(i)
  }
  // 创建Blob对象
  var xmlBlob = new Blob([xmlArray], { type: 'text/xml' })
  // 将Blob对象转换为URL
  var xmlUrl = URL.createObjectURL(xmlBlob)
  let xmlWindow = window.open(xmlUrl, 'xml预览')
}

const openPdf = (key: any) => {
  // let pdfWindow = window.open("", 'pdf预览');
  let pdfWindow = window.open('')
  // 将base64字符串转换为Uint8Array对象
  const pdfData = atob(docs.value[key])
  const pdfArray = new Uint8Array(pdfData.length)
  for (let i = 0; i < pdfData.length; i++) {
    pdfArray[i] = pdfData.charCodeAt(i)
  }
  // 创建Blob对象
  const pdfBlob = new Blob([pdfArray], { type: 'application/pdf' })
  // 将Blob对象转换为URL
  const pdfUrl = URL.createObjectURL(pdfBlob)
  // 将URL作为iframe的src属性值
  pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>")
}

const genActButtons: (subRow: any, row: any) => ButtonInfo[] = (subRow: any, row: any) => {
  const buttons = [
    {
      key: 'viewXml',
      label: 'XML',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        const result = await getXml(row, reportCode)
        const keys = Object.keys(result.data)
        xmlButtonKeys.value = keys
        xmlDataList.value = result.data
        dialogVisible.value = true
      },
    },
  ]
  if (reportCode != '1005') {
    buttons.splice(2, 0, {
      key: 'viewPdf',
      label: '法律文书',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        const result = await getPdf(subRow, reportCode)
        if (result.code == 500) {
          ElMessage.error({ message: result.data, grouping: true, showClose: true, duration: 0 })
          return
        }

        // docKeys.value = Object.keys(result.data)
        // docs.value = result.data;
        // docDialogVisible.value = true;

        // let pdfWindow = window.open("", 'pdf预览');
        let pdfWindow = window.open('')
        // 将base64字符串转换为Uint8Array对象
        var pdfData = atob(result.data)
        var pdfArray = new Uint8Array(pdfData.length)
        for (var i = 0; i < pdfData.length; i++) {
          pdfArray[i] = pdfData.charCodeAt(i)
        }
        // 创建Blob对象
        var pdfBlob = new Blob([pdfArray], { type: 'application/pdf' })
        // 将Blob对象转换为URL
        var pdfUrl = URL.createObjectURL(pdfBlob)
        // 将URL作为iframe的src属性值
        pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>")
      },
    })
    buttons.splice(3, 0, {
      key: 'viewImage',
      label: '法官证件',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        const result = await getImage(subRow, reportCode)
        if (result.code == 500) {
          ElMessage.error({ message: result.data, grouping: true, showClose: true, duration: 0 })
          return
        }
        urlList.value = []
        for (const image in result.data) {
          // 将base64字符串转换为Uint8Array对象
          const jpgData = atob(result.data[image])
          const jpgArray = new Uint8Array(jpgData.length)
          for (let i = 0; i < jpgData.length; i++) {
            jpgArray[i] = jpgData.charCodeAt(i)
          }
          // 创建Blob对象
          const jpgBlob = new Blob([jpgArray], { type: 'image/jpeg' })
          // 将Blob对象转换为URL
          const jpgUrl = URL.createObjectURL(jpgBlob)
          // 将URL作为iframe的src属性值
          showImageViewer.value = true
          urlList.value = [...urlList.value, jpgUrl]
        }
      },
    })
  }
  return buttons
}

function clear() {
  nameRef.value?.clearValidate()
  nameDetailRef.value?.clearValidate()
}
</script>

<style scoped>
.btnDiv {
  margin: 20px 0 20px 0;
  display: flex;
  flex-direction: row;
}
</style>
