// import { ButtonInfo, FormItemInfo, Pagination, TableColumnInfo, SearchFormField } from "riking-ui";
import { ButtonInfo, FormItemInfo, Pagination, TableColumnInfo } from "riking-ui";
import { dateFormatter } from "@/utils/utils";

declare interface PageElements {
    formItems: TableColumnInfo[],
    columns: FormItemInfo[],
    subTables: TableColumnInfo[],
    searchItems: FormItemInfo[],
    // advancedQueryItems: SearchFormField[],
}
export const derivedPageElements = (key: string) => {
    // const elements: PageElements = { formItems: [], columns: [], subTables: [], searchItems: [], advancedQueryItems: [] };
    const elements: PageElements = { formItems: [], columns: [], subTables: [], searchItems: [] };
    switch (key) {
        case 'fkCxqq':
            elements.columns = cxqqColumns;
            elements.formItems = [{ name: "账户信息", items: fkAccountFormItems }];
            elements.subTables = [
                // {name:"账户信息",items:fkAccountFormItems, columns:fkAccountColumns,listName:"fkAccount"},
                { name: "金融资产信息", items: fkFinancialFormItems, columns: fkFinancialColumns, listName: "zgfyFkFinancial" },
                { name: "司法强制措施信息", items: fkMeasureFormItems, columns: fkMeasureColumns, listName: "zgfyFkMeasure" },
                { name: "资金往来信息", items: fkTransferFormItems, columns: fkTransferColumns, listName: "zgfyFkTransfer" },
                { name: "共有权/优先权信息", items: fkPriorityFormItems, columns: fkPriorityColumns, listName: "zgfyFkPriority" },
                { name: "关联子账户信息", items: fkSubAccountFormItems, columns: fkSubAccountColumns, listName: "zgfyFkSubAccount" },
            ]
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            elements.searchItems = [...fkAccountFormItems
                .filter(item => item.label !== '业务操作机构')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType,
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems];
            break;
        case 'fkKzqq':
            elements.columns = kzqqColumns;
            elements.formItems = [{ name: "控制结果", items: fkControlFormItems }];
            elements.subTables = [
                // {name:"控制结果",items:fkControlFormItems, columns:fkControlColumns,listName:"fkControl"},
                { name: "在先冻结信息", items: fkControlFreezeFormItems, columns: fkControlFreezeColumns, listName: "fkControlFreeze" },
                { name: "优先权信息", items: fkControlPriorityFormItems, columns: fkControlPriorityColumns, listName: "fkControlPriority" },
            ];
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            elements.searchItems = [...fkControlFormItems
                .filter(item => item.label !== '业务操作机构')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType,
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems];
            break;
        case 'fkReturnFail':
            elements.columns = returnFailColumns;
            elements.formItems = [{ name: "回退信息", items: returnFailFormItems }];
            elements.subTables = [];
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            elements.searchItems = [...returnFailFormItems
                .filter(item => item.label !== '业务操作机构')
                .map(item => {
                    return {
                        value: item.prop,
                        label: item.label,
                        inputType: item.inputType,
                        labelWidth: item.labelWidth,
                    };
                }), ...publicAdvancedQueryItems];
            break;
    }
    return elements;
}
export const parentsColumns: TableColumnInfo[] = [
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: 'qqdbs', label: '请求批次号', minWidth: 200, sortable: true },
    { prop: 'bdhm', label: '请求单号', minWidth: 210, sortable: true },
    // {prop: 'sqjgdm', label: '申请机构' , minWidth:200 , dictFormatKey:sqjgdm},
    // {prop: 'mbjgdm', label: '目标机构' , minWidth:200 , dictFormatKey:'mbjgdm'},
    // {prop: 'branchCode', label: '业务操作机构' , minWidth:200, dictFormatKey: 'branchTree'},
    { prop: 'branchCode', label: '业务操作机构', minWidth: 200, dictFormatKey: 'branchTree', sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    // { prop: 'createTime', label: '数据日期', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'departmentCode', label: '部门编码', dictFormatKey: 'departmentCode' },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 180,
        fixed: 'right',
        // type:'expand',
    },
]

export const parentsFormItems: FormItemInfo[] = [
    {
        prop: 'qqdbs',
        label: '请求批次号',
        labelWidth: 100,
        inputType: 'input',
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }, { required: true, message: `必填` }]
    },
    {
        prop: 'bdhm',
        label: '请求单号',
        labelWidth: 100,
        inputType: 'input',
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }, { required: true, message: `必填` }]
    }
]

export const searchItems: FormItemInfo[] = [
    // {
    //     prop: 'qqdbs',
    //     label: '请求批次号',
    //     inputType: 'input',
    //     labelWidth:100
    // },
    // {   prop: 'khzh',
    //     label: '开户账号',
    //     inputType: 'input',
    //     labelWidth:100},
    {
        prop: 'bdhm',
        label: '请求单号',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'branchCode', label: '业务操作机构', labelWidth: 100,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
];

/**
 * 查询请求反馈
 **/
// 查询请求反馈 主表 Columns
export const cxqqColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'createTime', label: '数据日期', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'khzh', label: '开户账号', width: 170, sortable: true },
    { prop: "khmc", label: "客户名称", minWidth: 200, sortable: true },
    { prop: "khbh", label: "客户编号", minWidth: 200, sortable: true },
    ...parentsColumns,
]
// 查询请求反馈 账户信息 Columns (子表)
export const fkAccountColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "khzh", label: "开户账号", minWidth: 210, sortable: true },
    { prop: "cclb", label: "账户类别", minWidth: 200, sortable: true },
    { prop: "zhzt", label: "账户状态", minWidth: 200, sortable: true },
    { prop: "khwd", label: "开户网点", minWidth: 200, sortable: true },
    { prop: "khwddm", label: "开户网点代码", minWidth: 200, sortable: true },
    { prop: "khrq", label: "开户日期", minWidth: 200, sortable: true },
    { prop: "xhrq", label: "销户日期", minWidth: 200, sortable: true },
    { prop: "bz", label: "计价币种", minWidth: 200, dictFormatKey: 'zgfy_bz', sortable: true },
    { prop: "ye", label: "资产数额", minWidth: 200, sortable: true },
    { prop: "kyye", label: "可用资产数额", minWidth: 200, sortable: true },
    { prop: "glzjzh", label: "关联资金账户", minWidth: 200, sortable: true },
    { prop: "fksj", label: "反馈结果时间", minWidth: 200, sortable: true },
    { prop: "txdz", label: "通讯地址", minWidth: 200, sortable: true },
    { prop: "yzbm", label: "邮政编码", minWidth: 200, sortable: true },
    { prop: "lxdh", label: "联系电话", minWidth: 200, sortable: true },
    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 账户信息 FormItems (子表)
export const fkAccountFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "khmc", label: "客户名称", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` },{ required: true, message: `必填` }] },
    { prop: "khbh", label: "客户编号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` },{ required: true, message: `必填` }] },
    { prop: "khzh", label: "开户账号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }, { required: true, message: `必填,若无则反馈“查无开户信息”` }] },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{ required: true, message: `必填` }]
    },
    { prop: "cclb", label: "账户类别", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }, { required: true, message: `必填` }] },
    { prop: "zhzt", label: "账户状态", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }, { required: true, message: `必填` }] },
    { prop: "khwd", label: "开户网点", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` }, { required: true, message: `必填` }] },
    { prop: "khwddm", label: "开户网点代码", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }, { required: true, message: `必填` }] },
    { prop: "khrq", label: "开户日期", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }, { required: true, message: `必填` }] },
    { prop: "xhrq", label: "销户日期", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }] },
    {
        prop: "bz", label: "计价币种", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_bz',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: `必填` }]
    },
    { prop: "ye", label: "资产数额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填,若无则反馈0.00` }] },
    { prop: "kyye", label: "可用资产数额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填,若无则反馈0.00` }] },
    { prop: "glzjzh", label: "关联资金账户", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }] },
    { prop: "fksj", label: "反馈结果时间", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }, { required: true, message: `必填` }] },
    { prop: "txdz", label: "通讯地址", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` }] },
    { prop: "yzbm", label: "邮政编码", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }] },
    { prop: "lxdh", label: "联系电话", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }] },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]
// 查询请求反馈 金融资产 Columns (子表)
export const fkFinancialColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "ccxh", label: "账户序号", minWidth: 100, sortable: true },
    { prop: "zcxh", label: "金融资产序号", minWidth: 100, sortable: true },
    { prop: "zcmc", label: "金融资产名称", minWidth: 200, sortable: true },
    { prop: "zclx", label: "金融资产类型", minWidth: 200, sortable: true },
    { prop: "zcglr", label: "资产管理人", minWidth: 200, sortable: true },
    { prop: "zckfjy", label: "资产可否通过银行交易", minWidth: 200, sortable: true,dictFormatKey: 'ZCKFTGYHJY' },
    { prop: "zcjyxz", label: "资产交易限制类型", minWidth: 200, sortable: true },
    { prop: "xzxcrq", label: "资产交易限制消除时间", minWidth: 200, sortable: true },
    { prop: "jldw", label: "计量单位", minWidth: 200, sortable: true },
    { prop: "bz", label: "计价币种", minWidth: 200, dictFormatKey: 'zgfy_bz', sortable: true },
    { prop: "zcdwjg", label: "资产单位价格", minWidth: 200, sortable: true },
    { prop: "se", label: "数量/份额/金额", minWidth: 200, sortable: true },
    { prop: "kyse", label: "可控数量/份额/金额", minWidth: 200, sortable: true },

    { prop: "cpxszl", label: "产品销售种类", minWidth: 200, sortable: true },
    { prop: "dqh", label: "地区号", minWidth: 200, sortable: true },
    { prop: "jrcpbh", label: "金融产品编号", minWidth: 200, sortable: true },
    { prop: "lczh", label: "理财账号", minWidth: 200, sortable: true },
    { prop: "zjhkzh", label: "资金回款账户", minWidth: 200, sortable: true },
    { prop: "zyqr", label: "质押权人", minWidth: 200, sortable: true },
    { prop: "tgr", label: "托管人", minWidth: 200, sortable: true },
    { prop: "syr", label: "受益人", minWidth: 200, sortable: true },
    { prop: "clr", label: "成立日", minWidth: 200, sortable: true },
    { prop: "shrDate", label: "赎回日", minWidth: 200, sortable: true },
    { prop: "tgzh", label: "托管账号", minWidth: 200, sortable: true },
    { prop: "zczje", label: "资产总数额", minWidth: 200, sortable: true },
    { prop: 'departmentCode', label: '部门编码', dictFormatKey: 'departmentCode' },
    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 金融资产 FormItems (子表)
export const fkFinancialFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "zcxh", label: "金融资产序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: false }, rules: [{ type: "integer", message: "金融资产序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "zcmc", label: "金融资产名称", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` }, { required: true, message: `必填` }] },
    { prop: "zclx", label: "金融资产类型", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }, { required: true, message: `必填` }] },
    { prop: "zcglr", label: "资产管理人", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "zckfjy", label: "资产可否通过银行交易", labelWidth: 150, inputType: {tag: 'select', options: 'ZCKFTGYHJY'}, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1, message: `长度不可超过1,填入是/否` }] },
    { prop: "zcjyxz", label: "资产交易限制类型", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "xzxcrq", label: "资产交易限制消除时间", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }] },
    { prop: "jldw", label: "计量单位", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }, { required: true, message: `必填` }] },
    {
        prop: "bz", label: "计价币种", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_bz',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: `必填` }]
    },
    { prop: "zcdwjg", label: "资产单位价格", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [] },
    { prop: "se", label: "数量/份额/金额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填,若无则反馈0.00` }] },
    { prop: "kyse", label: "可控数量/份额/金额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填,若无则反馈0.00` }] },

    { prop: "cpxszl", label: "产品销售种类", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }] },
    { prop: "dqh", label: "地区号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }] },
    { prop: "jrcpbh", label: "金融产品编号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "lczh", label: "理财账号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "zjhkzh", label: "资金回款账户", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "zyqr", label: "质押权人", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "tgr", label: "托管人", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "syr", label: "受益人", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "clr", label: "成立日", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }] },
    { prop: "shrDate", label: "赎回日", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }] },
    { prop: "tgzh", label: "托管账号", labelWidth: 150, inputType: 'input', rules: [{ max: 50, message: `长度不可超过50` }] },
    { prop: "zczje", label: "资产总数额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "4" } },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]
// 查询请求反馈 强制措施 Columns (子表)
export const fkMeasureColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "ccxh", label: "账户序号", minWidth: 100, sortable: true },
    { prop: "csxh", label: "措施序号", minWidth: 100, sortable: true },
    { prop: "djjzrq", label: "冻结截止日", minWidth: 200, sortable: true },
    { prop: "djjg", label: "冻结机关", minWidth: 200, sortable: true },
    { prop: "djwh", label: "冻结文号", minWidth: 200, sortable: true },
    { prop: "djje", label: "冻结金额/数额", minWidth: 200, sortable: true },

    { prop: "zcxh", label: "金融资产序号", minWidth: 200, sortable: true },
    { prop: "jrcpbh", label: "金融产品编号", minWidth: 200, sortable: true },
    { prop: 'departmentCode', label: '部门编码', dictFormatKey: 'departmentCode' },
    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 强制措施 FormItems (子表)
export const fkMeasureFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "csxh", label: "措施序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: false }, rules: [{ type: "integer", message: "措施序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "djjzrq", label: "冻结截止日", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }] },
    { prop: "djjg", label: "冻结机关", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }, { required: true, message: `必填` }] },
    { prop: "djwh", label: "冻结文号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }, { required: true, message: `必填` }] },
    { prop: "djje", label: "冻结金额/数额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填` }] },

    { prop: "zcxh", label: "金融资产序号", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "0" } },
    { prop: "jrcpbh", label: "金融产品编号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]
// 查询请求反馈 资金往来 Columns (子表)
export const fkTransferColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "ccxh", label: "账户序号", minWidth: 100, sortable: true },
    { prop: "wlxh", label: "资金往来序号", minWidth: 100, sortable: true },
    { prop: "jyzl", label: "交易种类", minWidth: 200, sortable: true },
    { prop: "zjlx", label: "借贷方向(资金流向)", minWidth: 200, sortable: true },
    { prop: "bz", label: "交易币种", minWidth: 200, dictFormatKey: 'zgfy_bz', sortable: true },
    { prop: "je", label: "交易金额", minWidth: 200, sortable: true },
    { prop: "jysj", label: "交易日期", minWidth: 200, sortable: true },
    { prop: "jylsh", label: "交易流水号", minWidth: 200, sortable: true },
    { prop: "zckzxm", label: "交易对方姓名/名称", minWidth: 200, sortable: true },
    { prop: "zckzh", label: "交易对方账号", minWidth: 200, sortable: true },
    { prop: "zckzhkhh", label: "交易对方账号开户行", minWidth: 200, sortable: true },
    { prop: "jydsyhhh", label: "交易对方账号开户行行号", minWidth: 200, sortable: true },
    { prop: "jydszjlx", label: "交易对方开户证件类型", minWidth: 200, sortable: true },
    { prop: "jydszjhm", label: "交易对方开户证件号码", minWidth: 200, sortable: true },
    { prop: "jydstxdz", label: "交易对方通讯地址", minWidth: 200, sortable: true },
    { prop: "jydsyzbm", label: "交易对方邮政编码", minWidth: 200, sortable: true },
    { prop: "jydslxdh", label: "交易对方联系电话", minWidth: 200, sortable: true },
    { prop: 'departmentCode', label: '部门编码', dictFormatKey: 'departmentCode' },
    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 资金往来 FormItems (子表)
export const fkTransferFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "wlxh", label: "资金往来序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: false }, rules: [{ type: "integer", message: "资金往来序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "jyzl", label: "交易种类", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }, { required: true, message: `必填` }] },
    { prop: "zjlx", label: "借贷方向(资金流向)", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }, { required: true, message: `必填` }] },
    {
        prop: "bz", label: "交易币种", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_bz',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: `必填` }]
    },
    { prop: "je", label: "交易金额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填` }] },
    { prop: "jysj", label: "交易日期", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }, { required: true, message: `必填` }] },
    { prop: "jylsh", label: "交易流水号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }, { required: true, message: `必填` }] },
    { prop: "zckzxm", label: "交易对方姓名/名称", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 60, message: `长度不可超过60` }] },
    { prop: "zckzh", label: "交易对方账号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }] },
    { prop: "zckzhkhh", label: "交易对方账号开户行", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` }] },
    { prop: "jydsyhhh", label: "交易对方账号开户行行号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }] },
    {
        prop: "jydszjlx", label: "交易对方开户证件类型", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_zjlx',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }]
    },
    { prop: "jydszjhm", label: "交易对方开户证件号码", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    { prop: "jydstxdz", label: "交易对方通讯地址", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` }] },
    { prop: "jydsyzbm", label: "交易对方邮政编码", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }] },
    { prop: "jydslxdh", label: "交易对方联系电话", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }] },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]
// 查询请求反馈 共有权/优先权 Columns (子表)
export const fkPriorityColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "ccxh", label: "账户序号", minWidth: 100, sortable: true },
    { prop: "xh", label: "序号", minWidth: 100, sortable: true },
    { prop: "qllx", label: "权利类型", minWidth: 200, sortable: true },
    { prop: "qlr", label: "权利人", minWidth: 200, sortable: true },
    { prop: "qlje", label: "权利金额/数额", minWidth: 200, sortable: true },
    { prop: "qlrdz", label: "权利人通讯地址", minWidth: 200, sortable: true },
    { prop: "qlrlxfs", label: "权利人联系方式", minWidth: 200, sortable: true },

    { prop: "zcxh", label: "金融资产序号", minWidth: 200, sortable: true },
    { prop: "jrcpbh", label: "金融产品编号", minWidth: 200, sortable: true },
    { prop: 'departmentCode', label: '部门编码', dictFormatKey: 'departmentCode' },
    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 共有权/优先权 FormItems (子表)
export const fkPriorityFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "xh", label: "序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: false }, rules: [{ type: "integer", message: "序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "qllx", label: "权利类型", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }, { required: true, message: `必填` }] },
    { prop: "qlr", label: "权利人", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 60, message: `长度不可超过60` }, { required: true, message: `必填` }] },
    { prop: "qlje", label: "权利金额/数额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填` }] },
    { prop: "qlrdz", label: "权利人通讯地址", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` }] },
    { prop: "qlrlxfs", label: "权利人联系方式", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },

    { prop: "zcxh", label: "金融资产序号", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "0" } },
    { prop: "jrcpbh", label: "金融产品编号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]
// 查询请求反馈 关联子类账户 Columns (子表)
export const fkSubAccountColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "ccxh", label: "账户序号", minWidth: 100, sortable: true },
    { prop: "glxh", label: "子账户序号", minWidth: 100, sortable: true },
    { prop: "zkhzh", label: "主账户账号", minWidth: 200, sortable: true },
    { prop: "glzhlb", label: "子账户类别", minWidth: 200, sortable: true },
    { prop: "glzhhm", label: "子账户账号", minWidth: 200, sortable: true },
    { prop: "bz", label: "计价币种", minWidth: 200, dictFormatKey: 'zgfy_bz', sortable: true },
    { prop: "ye", label: "资产数额", minWidth: 200, sortable: true },
    { prop: "kyye", label: "可用资产数额", minWidth: 200, sortable: true },
    { prop: 'departmentCode', label: '部门编码', dictFormatKey: 'departmentCode' },
    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 关联子类账户 FormItems (子表)
export const fkSubAccountFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "glxh", label: "子账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: false }, rules: [{ type: "integer", message: "子账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "zkhzh", label: "主账户账号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }, { required: true, message: `必填` }] },
    { prop: "glzhlb", label: "子账户类别", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 20, message: `长度不可超过20` }, { required: true, message: `必填` }] },
    { prop: "glzhhm", label: "子账户账号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }, { required: true, message: `必填` }] },
    {
        prop: "bz", label: "计价币种", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_bz',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: `必填` }]
    },
    { prop: "ye", label: "资产数额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填,若无则反馈0.00` }] },
    { prop: "kyye", label: "可用资产数额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填,若无则反馈0.00` }] },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]

/**
 * 控制请求反馈
 **/
// 控制请求反馈 主表 Columns
export const kzqqColumns: TableColumnInfo[] = [

    { key: 'id', type: 'selection' },
    { prop: 'createTime', label: '数据日期', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'khzh', label: '开户账号', width: 170, sortable: true },
    { prop: "khmc", label: "客户名称", minWidth: 200, sortable: true },
    { prop: "khbh", label: "客户编号", minWidth: 200, sortable: true },
    ...parentsColumns,
]

// 查询请求反馈 控制结果 Columns (子表)
export const fkControlColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    // { prop: "ccxh", label: "序号", minWidth: 200 },
    { prop: "khzh", label: "开户账号", minWidth: 200, sortable: true },
    { prop: "kznr", label: "控制内容", minWidth: 200, dictFormatKey: 'zgfy_kznr', sortable: true },
    { prop: "kzzt", label: "控制结果", minWidth: 200, dictFormatKey: 'zgfy_kzzt', sortable: true },
    { prop: "ye", label: "账户余额", minWidth: 200, sortable: true },
    { prop: "kyye", label: "可用余额", minWidth: 200, sortable: true },
    { prop: "csksrq", label: "措施始期", minWidth: 200, sortable: true },
    { prop: "csjsrq", label: "措施终期", minWidth: 200, sortable: true },
    { prop: "djxe", label: "冻结限额", minWidth: 200, sortable: true },
    { prop: "skje", label: "实际控制可用金额", minWidth: 200, sortable: true },
    { prop: "ceskje", label: "超额控制金额", minWidth: 200, sortable: true },
    { prop: "wnkzyy", label: "未能控制原因", minWidth: 200, sortable: true },

    { prop: "jrcpbh", label: "金融产品编号", minWidth: 200, sortable: true },
    { prop: "lczh", label: "理财账号", minWidth: 200, sortable: true },
    { prop: "skse", label: "实控数量/份额/金额", minWidth: 200, sortable: true },

    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 控制结果 FormItems (子表)
export const fkControlFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "khmc", label: "客户名称", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` },{ required: true, message: `必填` }] },
    { prop: "khbh", label: "客户编号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` },{ required: true, message: `必填` }] },
    { prop: "khzh", label: "开户账号", labelWidth: 150, inputType: {tag: 'input', disabled: true}, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 30, message: `长度不可超过30` }, { required: true, message: `必填,若无反馈“查无开户信息”` }] },
    {
        prop: "kznr", label: "控制内容", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_kznr',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: `必填` }]
    },
    {
        prop: "kzzt", label: "控制结果", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_kzzt',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: `必填` }]
    },
    {
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{ required: true, message: `必填` }]
    },
    { prop: "ye", label: "账户余额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填,若无反馈0.00` }] },
    { prop: "kyye", label: "可用余额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填,若无反馈0.00` }] },
    { prop: "csksrq", label: "措施始期", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }, { required: true, message: `必填` }] },
    { prop: "csjsrq", label: "措施终期", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日时分秒" }, { required: true, message: `必填` }] },
    { prop: "djxe", label: "冻结限额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填` }] },
    { prop: "skje", label: "实际控制可用金额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" },rules: [{ required: false, message: `必填` }] },
    { prop: "ceskje", label: "超额控制金额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" } },
    { prop: "wnkzyy", label: "未能控制原因", labelWidth: 150, inputType: 'input', rules: [{ required: false, message: `未能控制原因必填` },{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] },

    { prop: "jrcpbh", label: "金融产品编号", labelWidth: 150, inputType: 'input',rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 30, message: `长度不可超过30` }] },
    { prop: "lczh", label: "理财账号", labelWidth: 150, inputType: 'input' ,rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 50, message: `长度不可超过50` }] },
    { prop: "skse", label: "实控数量/份额/金额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "4" } },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]
// 查询请求反馈 在先冻结信息 Columns (子表)
export const fkControlFreezeColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    //{ prop: "ccxh", label: "控制序号", minWidth: 200 },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "csxh", label: "措施序号", minWidth: 100 },
    { prop: "djjg", label: "在先冻结机关", minWidth: 200, sortable: true },
    { prop: "djwh", label: "在先冻结文号", minWidth: 200, sortable: true },
    { prop: "djje", label: "在先冻结金额", minWidth: 200, sortable: true },
    { prop: "djjzrq", label: "在先冻结到期日", minWidth: 200, sortable: true },

    { prop: "jrcpbh", label: "金融产品编号", minWidth: 200, sortable: true },
    { prop: 'departmentCode', label: '部门编码', dictFormatKey: 'departmentCode' },
    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 在先冻结信息 FormItems (子表)
export const fkControlFreezeFormItems: FormItemInfo[] = [{ prop: "ccxh", label: "控制序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" },{ required: true, message: `必填` }] },
    { prop: "csxh", label: "措施序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "措施序号必须为整数" }, { required: false, message: `必填` }] },
    { prop: "djjg", label: "在先冻结机关", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }, { required: true, message: `必填` }] },
    { prop: "djwh", label: "在先冻结文号", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }, { required: true, message: `必填` }] },
    { prop: "djje", label: "在先冻结金额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [] },
    { prop: "djjzrq", label: "在先冻结到期日", labelWidth: 150, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD' }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { type: "date", message: "必须为年月日" }] },

    { prop: "jrcpbh", label: "金融产品编号", labelWidth: 150, inputType: 'input',rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]
// 查询请求反馈 优先权信息 Columns (子表)
export const fkControlPriorityColumns: TableColumnInfo[] = [
    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', dictFormatKey: 'dataStatus', sortable: true, scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "xh", label: "序号", minWidth: 200 },
    { prop: "qllx", label: "权利类型", minWidth: 200, sortable: true },
    { prop: "qlr", label: "权利人", minWidth: 200, sortable: true },
    { prop: "qlje", label: "权利金额/数额", minWidth: 200, sortable: true },
    { prop: "qlrdz", label: "权利人通讯地址", minWidth: 200, sortable: true },
    { prop: "qlrlxfs", label: "权利人联系方式", minWidth: 200, sortable: true },

    { prop: "jrcpbh", label: "金融产品编号", minWidth: 200, sortable: true },
    { prop: 'departmentCode', label: '部门编码', dictFormatKey: 'departmentCode' },
    { prop: "beiz", label: "备注", minWidth: 200, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
// 查询请求反馈 优先权信息 FormItems (子表)
export const fkControlPriorityFormItems: FormItemInfo[] = [
    { prop: "ccxh", label: "账户序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: true }, rules: [{ type: "integer", message: "账户序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "xh", label: "序号", labelWidth: 150, inputType: { tag: 'input-number', disabled: false }, rules: [{ type: "integer", message: "权利序号必须为整数" }, { required: true, message: `必填` }] },
    { prop: "qllx", label: "权利类型", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }, { required: true, message: `必填` }] },
    { prop: "qlr", label: "权利人", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 60, message: `长度不可超过60` }, { required: true, message: `必填` }] },
    { prop: "qlje", label: "权利金额/数额", labelWidth: 150, inputType: { tag: 'input-number', controlsPosition: "right", precision: "2" }, rules: [{ required: true, message: `必填` }] },
    { prop: "qlrdz", label: "权利人通讯地址", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 100, message: `长度不可超过100` }] },
    { prop: "qlrlxfs", label: "权利人联系方式", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },

    { prop: "jrcpbh", label: "金融产品编号", labelWidth: 150, inputType: 'input',rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 50, message: `长度不可超过50` }] },
    {
        prop: 'departmentCode',
        label: '部门编码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'departmentCode',
        },
        rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: false, message: '部门编码必填' }, { max: 50, message: '部门编码最大长度为50' }],
    },
    { prop: "beiz", label: "备注", labelWidth: 150, inputType: 'input', rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }] }
]

/**
 * 回退失败请求
 **/
// 回退失败请求 Columns
export const returnFailColumns: TableColumnInfo[] = [

    { key: 'id', type: 'selection' },
    { prop: 'status', label: '状态', width: 150, dictFormatKey: 'dataStatus', scopedSlots: 'status' },
    { prop: 'deleteState', label: '删除状态', dictFormatKey: 'deleteStatusList', scopedSlots: 'deleteState', sortable: true },
    { prop: "qqdbs", label: "请求批次号", width: 150, sortable: true },
    { prop: "bdhm", label: "查询请求单号", width: 150, sortable: true },
    { prop: "xchtyy", label: "回退原因", width: 150, dictFormatKey: 'zgfy_htyy', sortable: true },
    { prop: "xchtbz", label: "回退原因备注", width: 150, sortable: true },
    { prop: "xchtr", label: "回退联系人", width: 150, sortable: true },
    { prop: "xchtdh", label: "回退联系人电话", width: 150, sortable: true },
    { prop: 'createBy', label: '创建人', minWidth: 200, sortable: true },
    { prop: 'createTime', label: '创建时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'updateBy', label: '修改人', minWidth: 200, sortable: true },
    { prop: 'updateTime', label: '修改时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'submitBy', label: '提交人', minWidth: 200, sortable: true },
    { prop: 'submitTime', label: '提交时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    { prop: 'approveBy', label: '审核人', minWidth: 200, sortable: true },
    { prop: 'approveTime', label: '审核时间', minWidth: 200, formatter: dateFormatter, sortable: true },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 160,
        fixed: 'right',
    },
]
// 回退失败请求 FormItems
export const returnFailFormItems: FormItemInfo[] = [
    { prop: "qqdbs", label: "请求批次号", labelWidth: 150, inputType: "input" , rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message:`必填` }]},
    { prop: "bdhm", label: "查询请求单号", labelWidth: 150, inputType: "input" , rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message:`必填` }] },
    {
        prop: "xchtyy", label: "回退原因", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_htyy',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: `必填` }]
    },
    {
        prop: "returnType", label: "回退请求类型", labelWidth: 150, inputType: {
            tag: 'select',
            options: 'zgfy_qqlx',
        }, rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { required: true, message: `必填` }]
    },
    { prop: "xchtbz", label: "回退原因备注", labelWidth: 150, inputType: "input", rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }, { max: 1000, message: `长度不可超过1000` }, { required: true, message: `必填` }] },
    { prop: "xchtr", label: "回退联系人", labelWidth: 150, inputType: "input", rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }] },
    { prop: "xchtdh", label: "回退联系人电话", labelWidth: 150, inputType: "input", rules: [{ pattern: '^[^<>&]*$', message: '存在特殊字符' }] }
]
// 回退失败请求 SearchItems
export const returnFailSearchItems: FormItemInfo[] = [
    { prop: "bdhm", label: "查询请求单号", labelWidth: 150, inputType: "input" },
    { prop: "xchtr", label: "回退联系人", labelWidth: 150, inputType: "input" },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
]

// // 高级查询
// export const advancedQueryItems1: SearchFormField[] = [
//     { value: 'qqdbs', label: '请求单标识号', inputType: { tag: 'input' } },
//     { value: 'khmc', label: '客户名称', inputType: { tag: 'input' } },
//     { value: 'khzh', label: '开户账号', inputType: { tag: 'input' } },
//     { value: 'status', label: '状态', inputType: { tag: 'select', options: 'dataStatus' } },
// ]
//
// // 高级查询
// export const advancedQueryItems2: SearchFormField[] = [
//     // { value: 'xchtyy', label: '回退原因', inputType: { tag: 'input' } },
//     { value: 'xchtbz', label: '回退原因备注', inputType: { tag: 'input' } },
//     { value: 'xchtdh', label: '回退联系人电话', inputType: { tag: 'input' } },
// ]

export const recordSearchKZFormItems: FormItemInfo[] = [
    { prop: 'qqdbs', label: '请求批次号', labelWidth: 80, inputType: 'input' },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 80,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'onlyQuerySucceeded',
        label: '匹配成功',
        labelWidth: 50,
        inputType: { tag: 'checkbox' },
        // inputType: {tag:'checkbox',   checked:"checked"},
    }
]

export const recordSearchFormItems: FormItemInfo[] = [
    { prop: 'qqdbs', label: '请求批次号', labelWidth: 80, inputType: 'input' },
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 80,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'onlyQuerySucceeded',
        label: '匹配成功',
        labelWidth: 50,
        inputType: { tag: 'checkbox' },
        // inputType: {tag:'checkbox',   checked:"checked"},
    }
]
export const htRecordSearchFormItems: FormItemInfo[] = [
    { prop: 'qqdbs', label: '请求批次号', labelWidth: 80, inputType: 'input' },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 80,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },

]

const publicAdvancedQueryItems = [
    { value: 'bdhm', label: '请求单号', labelWidth: 80, inputType: 'input' },
    {
        value: 'status',
        label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
        },
        labelWidth: 80
    },
    { value: 'deleteState', label: '删除状态', inputType: { tag: 'select', options: 'deleteStatusList' }, labelWidth: 100 },
    { value: 'create_by', label: '创建人', labelWidth: 80, inputType: 'input' },
    {
        value: 'create_time', label: '数据日期', labelWidth: 80, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' },
        rules: [
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒' },
        ]
    },
    { value: 'update_by', label: '修改人', labelWidth: 80, inputType: 'input' },
    {
        value: 'update_time', label: '修改时间', labelWidth: 80, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' },
        rules: [
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒' },
        ]
    },
    { value: 'submit_by', label: '提交人', labelWidth: 80, inputType: 'input' },
    {
        value: 'submit_time', label: '提交时间', labelWidth: 80, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' },
        rules: [
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒' },
        ]
    },
    { value: 'approve_by', label: '审核人', labelWidth: 80, inputType: 'input' },
    {
        value: 'approve_time', label: '审核时间', labelWidth: 80, inputType: { tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss' },
        rules: [
            { pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒' },
        ]
    },
]
