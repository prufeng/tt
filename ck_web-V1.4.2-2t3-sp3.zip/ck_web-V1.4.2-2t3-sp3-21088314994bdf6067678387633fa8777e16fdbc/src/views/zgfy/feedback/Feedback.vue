<template>
  <rk-index-layout>
    <rk-dynamic-search-form
      v-model="searchForm"
      :form-items="
        getRequestClassificationCode() == 'fkReturnFail'
          ? htRecordSearchFormItems
          : getRequestClassificationCode() == 'fkKzqq'
          ? recordSearchKZFormItems
          : recordSearchFormItems
      "
      :fields="advancedQueryItems"
      @search="search"
    >
      <template #onlyQuerySucceeded>
        <el-checkbox :checked="dictData.matching != undefined ? true : false" />
      </template>
    </rk-dynamic-search-form>

    <rk-page-table
      :loading="loading"
      :columns="columns"
      :data="data"
      :pagination="page"
      @refresh="search"
      @page-change="pageChange"
      @selection-change="handleSelectionChange"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group
            :buttons="getRequestClassificationCode() == 'fkReturnFail' ? Buttons_yhthsb : Buttons"
            :route-meta="$route.meta"
            :max="9"
          />
          <div style="margin: 0 4px"></div>
          <UpAndDown :imp="imp" :exp="exp" />
        </div>
      </template>

      <template #status="{ row }">
        <el-popover v-if="row.status === '6'" placement="bottom" title="审核不通过原因" :width="250" trigger="hover">
          <p class="tipck">操作: 审核不通过</p>
          <p class="tipck">操作人: {{ row.approveBy }}</p>
          <p class="tipck">操作时间: {{ row.approveTime }}</p>
          <p class="tipck">备注: {{ row.approveDesc }}</p>
          <template #reference>
            <el-button link :type="getTagColor(row.status)"
              >{{ dictFormatter(row.status, dictData.dataStatus) }}
            </el-button>
          </template>
        </el-popover>
        <el-popover
          v-else-if="row.status === '0' && row.resetBy !== null && row.resetBy !== ''"
          placement="bottom"
          title="重置原因"
          :width="250"
          trigger="hover"
        >
          <p class="tipck">操作: 重置</p>
          <p class="tipck">操作人: {{ row.resetBy }}</p>
          <p class="tipck">操作时间: {{ row.resetTime }}</p>
          <p class="tipck">备注: {{ row.resetDesc }}</p>
          <template #reference>
            <el-button link :type="getTagColor(row.status)"
              >{{ dictFormatter(row.status, dictData.dataStatus) }}
            </el-button>
          </template>
        </el-popover>
        <el-button v-else link :type="getTagColor(row.status)"
          >{{ dictFormatter(row.status, dictData.dataStatus) }}
        </el-button>
      </template>

      <template #deleteState="{ row }">
        <el-popover
          v-if="row.deleteState === '4'"
          placement="bottom"
          title="删除审核不通过原因"
          :width="250"
          trigger="hover"
        >
          <p class="tipck">操作: 删除审核不通过</p>
          <p class="tipck">操作人: {{ row.approveBy }}</p>
          <p class="tipck">操作时间: {{ row.approveTime }}</p>
          <p class="tipck">备注: {{ row.deleteComments }}</p>
          <template #reference>
            <el-button link :type="getDelTagColor(row.deleteState)">
              {{ dictFormatter(row.deleteState, dictData.deleteStatusList) }}
            </el-button>
          </template>
        </el-popover>
        <el-button v-else link :type="getDelTagColor(row.deleteState)">
          {{ dictFormatter(row.deleteState, dictData.deleteStatusList) }}
        </el-button>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" :max="2" link />
      </template>
    </rk-page-table>
  </rk-index-layout>
  <!-- 弹出层 -->
  <el-dialog
    v-model="dialogData.visible"
    :title="dialogData.title"
    class="rk-dialog-default"
    @closed="closed"
    :close-on-click-modal="false"
  >
    <!-- 请求页面信息   -->
    <ShowCx
      :fkReportCode="reportCode"
      :visible="dialogData.visible"
      :bdhm="bdhm"
      :qqdbs="qqdbs"
      :rowValue="form"
      @getCxDetail="getCxDetail"
    ></ShowCx>
    <!-- 弹出层头信息 -->
    <!--    <rk-detail-form ref="dialogHeadFormRef" v-model="form" :form-items="parentsFormItems"-->
    <!--                    :disabled="dialogData.formDisabled">-->
    <!--      &lt;!&ndash;                    :disabled="isAddByZgfy.value=='add'?false:true">&ndash;&gt;-->

    <!--    </rk-detail-form>-->
    <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
      <!-- 标签页-主信息 -->
      <el-tab-pane :key="1" :label="formItems[0].name" :name="1">
        <div style="display: flex; flex-direction: row">
          <el-space wrap :size="10">
            <rk-button-group
              :buttons="
                dialogData.title === getTitleName() + '编辑' || dialogData.title === getTitleName() + '新增'
                  ? parentsButtons()
                  : []
              "
              :route-meta="$route.meta"
              :max="9"
            ></rk-button-group>
            <el-text class="mx-1" size="small">状态 :</el-text>
            <el-tag size="large">{{ status }}</el-tag>
          </el-space>
        </div>
        <br />
        <rk-detail-form
          ref="dialogFormRef"
          v-model="form"
          :form-items="formItems[0].items"
          :disabled="dialogData.formDisabled"
        >
        </rk-detail-form>
      </el-tab-pane>
      <!-- 标签页-从表信息 -->
      <el-tab-pane
        v-for="(subTable, index) in subTables"
        :key="'sub' + (index + 1)"
        :label="subTable.name"
        :name="'sub' + (index + 1)"
      >
        <rk-page-table
          :loading="subLoading"
          :columns="subTable.columns"
          :data="subData"
          :pagination="subPage"
          @page-change="subPageChange"
          @selection-change="subHandleSelectionChange"
          @refresh="handleClick(undefined)"
        >
          <template #operations>
            <div style="display: flex; flex-direction: row">
              <rk-button-group
                v-if="dialogData.title === getTitleName() + '编辑'"
                :buttons="subButtons(subTable.listName, subTable.items)"
                :route-meta="$route.meta"
                :max="9"
              ></rk-button-group>
              <!-- 417report入口-->
              <el-upload ref="upload417ReportRef" :show-file-list="false" :http-request="IUpload417ReportFile">
                <el-button ref="upload417ReportButton" id="upload417ReportButton" type="primary" style="display: none">
                  导入417report
                </el-button>
              </el-upload>
            </div>
          </template>
          <template #status="{ row }">
            <el-popover
              v-if="row.status === '6'"
              placement="bottom"
              title="审核不通过原因"
              :width="250"
              trigger="hover"
            >
              <p class="tipck">操作: 审核不通过</p>
              <p class="tipck">操作人: {{ row.approveBy }}</p>
              <p class="tipck">操作时间: {{ row.approveTime }}</p>
              <p class="tipck">备注: {{ row.approveDesc }}</p>
              <template #reference>
                <el-button link :type="getTagColor(row.status)"
                  >{{ dictFormatter(row.status, dictData.dataStatus) }}
                </el-button>
              </template>
            </el-popover>
            <el-popover
              v-else-if="row.status === '0' && row.resetBy !== null && row.resetBy !== ''"
              placement="bottom"
              title="重置原因"
              :width="250"
              trigger="hover"
            >
              <p class="tipck">操作: 重置</p>
              <p class="tipck">操作人: {{ row.resetBy }}</p>
              <p class="tipck">操作时间: {{ row.resetTime }}</p>
              <p class="tipck">备注: {{ row.resetDesc }}</p>
              <template #reference>
                <el-button link :type="getTagColor(row.status)"
                  >{{ dictFormatter(row.status, dictData.dataStatus) }}
                </el-button>
              </template>
            </el-popover>
            <el-button v-else link :type="getTagColor(row.status)"
              >{{ dictFormatter(row.status, dictData.dataStatus) }}
            </el-button>
          </template>

          <template #deleteState="{ row }">
            <el-popover
              v-if="row.deleteState === '4'"
              placement="bottom"
              title="删除审核不通过原因"
              :width="250"
              trigger="hover"
            >
              <p class="tipck">操作: 删除审核不通过</p>
              <p class="tipck">操作人: {{ row.approveBy }}</p>
              <p class="tipck">操作时间: {{ row.approveTime }}</p>
              <p class="tipck">备注: {{ row.deleteComments }}</p>
              <template #reference>
                <el-button link :type="getDelTagColor(row.deleteState)">
                  {{ dictFormatter(row.deleteState, dictData.deleteStatusList) }}
                </el-button>
              </template>
            </el-popover>
            <el-button v-else link :type="getDelTagColor(row.deleteState)">
              {{ dictFormatter(row.deleteState, dictData.deleteStatusList) }}
            </el-button>
          </template>

          <template #actions="{ row }">
            <rk-button-group
              :buttons="
                dialogData.title === getTitleName() + '编辑'
                  ? subGenActButtons(row, subTable.listName, subTable.items)
                  : subGenActButtons2(row, subTable.listName, subTable.items)
              "
              :route-meta="$route.meta"
              :max="2"
              link
            />
          </template>
        </rk-page-table>
      </el-tab-pane>
    </el-tabs>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-model="subDialogData.visible" :title="subDialogData.title" class="rk-dialog-default" @closed="subClosed">
    <rk-detail-form
      ref="subDialogFormRef"
      v-model="subForm"
      :form-items="subFormItems"
      :disabled="subDialogData.formDisabled"
    >
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button
          type="primary"
          v-if="subDialogData.title.includes('编辑') || subDialogData.title.includes('新增')"
          :loading="buttonLoading"
          @click="save1(null, listName)"
          >保存</el-button
        >
        <el-button @click="subClose"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="审核" width="30%" draggable :append-to-body="true">
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids)">审核通过</el-button>
        <el-button
          type="danger"
          @click="
            () => {
              msgDialog = true
              msg = ''
            }
          "
        >
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 子表审核弹窗 -->
  <el-dialog v-model="subAuditDialog" title="审核" width="30%" draggable :append-to-body="true">
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="subAudit(subIds, listName)">审核通过</el-button>
        <el-button
          type="danger"
          @click="
            () => {
              subMsgDialog = true
              msg = ''
            }
          "
        >
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog" title="不通过原因" width="30%" draggable :append-to-body="true">
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="auditNotPass(ids)">提交</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 主表删除审核弹窗 -->
  <el-dialog v-model="auditDelDialog" title="删除审核" width="30%" draggable :append-to-body="true">
    <!-- <span>是否删除审核通过,审核不通过请输入原因?</span>-->
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入删除审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="delAudit(ids, '1')">审核通过</el-button>
        <el-button type="danger" @click="delAudit(ids, '2')">审核不通过</el-button>
        <el-button
          type="default"
          @click="
            () => {
              auditDelDialog = false
            }
          "
          >取消</el-button
        >
      </span>
    </template>
  </el-dialog>
  <!-- 子表删除审核弹窗 -->
  <el-dialog v-model="auditDelDialogSub" title="删除审核" width="30%" draggable :append-to-body="true">
    <!-- <span>是否删除审核通过,审核不通过请输入原因?</span>-->
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入删除审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="delAuditSub(subIds, '1', listName)">审核通过</el-button>
        <el-button type="danger" @click="delAuditSub(subIds, '2', listName)">审核不通过</el-button>
        <el-button
          type="default"
          @click="
            () => {
              auditDelDialogSub = false
            }
          "
          >取消</el-button
        >
      </span>
    </template>
  </el-dialog>

  <!-- 子表审核不通过原因输入弹窗 -->
  <el-dialog v-model="subMsgDialog" title="不通过原因" width="30%" draggable :append-to-body="true">
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="subAuditNotPass(subIds, listName)">提交</el-button>
      </span>
    </template>
  </el-dialog>

  <template>
    <div>
      <el-upload
        ref="uploadRef"
        :on-error="
          () => {
            ElMessage.error({ message: '上传失败', grouping: true, showClose: true, duration: 0 })
          }
        "
        :show-file-list="false"
        :http-request="IUploadFile"
      >
        >
        <el-button ref="uploadButton" id="uploadButton" type="primary">上传文件</el-button>
      </el-upload>
    </div>
  </template>
  <!-- 批量提交/审核结果弹窗 -->
  <el-dialog
    v-model="submitAllVisible"
    title="提示"
    :close-on-click-modal="false"
    :destroy-on-close="true"
    :append-to-body="true"
  >
    <el-collapse v-model="activeNames">
      <el-collapse-item name="1">
        <template #title>
          <div class="message-text">
            {{ submitOrAudit }} 成功 <span style="margin: 0 5px; color: #67c23a">{{ successNum }}</span> 条数据, 失败
            <span style="margin: 0 5px; color: #f56c6c">{{ failNum }}</span> 条数据
          </div>
        </template>
        <div style="box-sizing: border-box">{{ returnMassage }}</div>
      </el-collapse-item>
    </el-collapse>
  </el-dialog>

  <ShowConfirm :visible="confirmVisible.visible" @callback="confirmCallback"></ShowConfirm>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'
import { setRequiredRule } from '@/views/system/sum'
// TODO 启动时加载，不在页面里调用   子系统设置
const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
//主表所需代码
import { onMounted, ref } from 'vue'
import {
  ElDialog,
  ElButton,
  ElCollapse,
  ElCollapseItem,
  ElMessage,
  ElPopover,
  ElForm,
  ElFormItem,
  ElCheckbox,
  ElUpload,
  ElInput,
  ElTabs,
  ElTabPane,
  ElText,
  ElTag,
  ElSpace,
  UploadInstance,
  Action,
} from 'element-plus'
import {
  RkIndexLayout,
  RkDynamicSearchForm,
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  RkDetailForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  dictFormatter,
} from 'riking-ui'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'
import { useDict } from 'riking-layout'
import { pagination, subPagination } from '@/views/zgfy/feedback/data'
import {
  derivedPageElements,
  fkAccountFormItems,
  searchItems,
  recordSearchFormItems,
  htRecordSearchFormItems,
  recordSearchKZFormItems,
} from '@/views/zgfy/feedback/page'
import {
  list,
  exportExcel,
  saveData,
  submitBatch,
  auditBatch,
  delBatch,
  resetBatch,
  listByBdhm,
  subSaveData,
  subSubmitBatch,
  subResetBatch,
  subAuditBatch,
  subDelBatch,
  updateData,
  subUpdateData,
  auditNotPassBatch,
  subAuditNotPassBatch,
  checkFileExist,
  upload,
  previewUploadFile,
  importExcel,
  recallBatch,
  subRecallBatch,
  submitAllBatch,
  auditAllBatch,
  auditNotPassAllBatch,
  checkExcelData,
  delBatchAudit,
  delAuditNotPass,
  listZgfyCxGeneral,
  delAllBatch,
  auditDelAllBatch,
  auditDelNotPassAllBatch,
} from '@/views/zgfy/feedback/api'
import UpAndDown, { expLoading, impLoading } from '@/components/UpAndDown.vue'
import { parentsFormItems } from '@/views/zgfy/feedback/page'
import { getRequestClassificationCode, getSubSystem } from '@/utils/subSystem'
import { listBusinessLine } from '@/views/query/feedback/api'
import { checkSpecialCharacters, specialChecks } from '@/utils/utils'
import useRouteParamsStore from '@/store/routeParamsStore'
import ShowCx from '@/views/zgfy/feedback/ShowCx.vue'
import { validateSwitchDict } from '@/views/taf/fk/commonFk'
import ShowConfirm from '@/views/taf/fk/ShowConfirm.vue'

const activeNames = ref(['1'])
const activeName = ref(1)
const buttonLoading = ref(false)
const loading = ref(false)
const subLoading = ref(false)
const data = ref<any[]>([])
const subData = ref<any[]>([])
const page = ref<Pagination>(pagination)
const subPage = ref<Pagination>(subPagination)
const khbh = ref('')
const ccxh = ref('')
const branchCode = ref('')
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({ businessLine: '' })
const reportCode = getRequestClassificationCode()
const cxDetailValue = ref({});

const getCxDetail = (values) => {
  //控制类型不为2：非存款类金融资产,实际控制可用金额必填
  if (activeName.value == 1 && formItems.value[0].name == '控制结果') {
    cxDetailValue.value = values
    // setRequiredRule(['skje'], values.kzlx != '2', formItems.value[0].items)
  }
}
/**
 * 代办汇总跳转到反馈页面
 */
const setRouteParams = () => {
  const store = useRouteParamsStore()
  const routeParams = store.getParams()

  if (routeParams != undefined && Object.keys(routeParams).length > 0) {
    const filters = [
      { key: 1, field: 'create_time', operator: 'ge', value: routeParams['searchTime'][0] },
      { key: 2, field: 'create_time', operator: 'le', value: routeParams['searchTime'][1] },
    ]

    const params = {
      filters,
      businessLine: routeParams['businessLine'],
      branchCodeList: routeParams['branchCode'],
      status: routeParams['status'],
    }
    searchForm.value = params
  }
  store.setParams({})
}

async function getBusinessLine() {
  try {
    const res = await listBusinessLine()
    const data1 = res.data

    if (data1.length === 0) {
      ElMessage.error({ message: '用户未配置业务线,无法查询数据', grouping: true, showClose: true, duration: 0 })
      searchForm.value.businessLine = ''
    } else {
      searchForm.value.businessLine = data1[0].value
    }
  } catch (error) {
    console.error('Error fetching business line:', error)
  } finally {
    setRouteParams()
    search()
  }
}

const visible = ref(false)
const isSubImpLoading = ref(false)
const bdhm = ref('')
const qqdbs = ref('')
let listName = ''
const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

const {
  dialogData: subDialogData,
  open: subOpen,
  close: subClose,
  closed: subClosed,
  form: subForm,
  nameRef: subDialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('subDialogFormRef', { type: [] })
let status = ref('')
let columns: any[] = [],
  advancedQueryItems: any[] = [],
  subTables: any[] = []
let requestClassificationCode: string
let isAddByZgfy = ref('edit')
const formItems = ref([])
const subFormItems = ref([])

useDict([], [], {
  ...dictData,
  branchCode: async () => {
    const res = await dictsStore.loadDict()
    return res.data.branchCode
  },
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data
  },
})

onMounted(() => {
  page.value = {...pagination}
  let router = useRouter()
  let path = router.currentRoute.value.path
  requestClassificationCode = getRequestClassificationCode()
  let pageElements = derivedPageElements(requestClassificationCode)
  columns = pageElements.columns
  formItems.value = pageElements.formItems
  subTables = pageElements.subTables
  advancedQueryItems = pageElements.searchItems
  getBusinessLine()

  if (dictData.matching != undefined) {
    // @ts-ignore
    searchForm.value.onlyQuerySucceeded = true
  }
})

const confirmVisible = reactive({ visible: false })

const callSave = () => {
  if (subDialogData.visible) {
    save1(null, listName)
  } else {
    save()
  }
}

const showConfirm = () => {
  let flag = validateSwitchDict(dictData, 'SaveReminder')
  if (flag) {
    confirmVisible.visible = true
  } else {
    callSave()
  }
}

const confirmCallback = (flag: boolean) => {
  confirmVisible.visible = false
  if (flag) {
    callSave()
  }
}

/**
 * 代办汇总跳转到反馈页面
 */
const routeQuery = () => {
  const store = useRouteParamsStore()
  const routeParams = store.getParams()

  if (routeParams != undefined && Object.keys(routeParams).length > 0) {
    const filters = [
      { key: 1, field: 'create_time', operator: 'ge', value: routeParams['searchTime'][0] },
      { key: 2, field: 'create_time', operator: 'le', value: routeParams['searchTime'][1] },
    ]

    const params = {
      filters,
      businessLine: routeParams['businessLine'],
      branchCodeList: routeParams['branchCode'],
      status: routeParams['status'],
    }
    searchForm.value = params
  }
}

const search = async () => {
  loading.value = true
  try {
    const newObject = { ...searchForm.value }
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null
        console.log('转化了空串')
      }
    }
    let result = await list(newObject, page.value.currentPage, page.value.pageSize)
    let { current, total, records } = result.data
    data.value = records
    page.value.currentPage = current
    page.value.total = total
  } finally {
    loading.value = false
  }
}
const getTagColor = (status: string) => {
  if (status == '6') {
    return 'danger'
  } else {
    return 'primary'
  }
}
const getDelTagColor = (status: string) => {
  if (status == '4') {
    return 'danger'
  } else {
    return 'primary'
  }
}
const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const subPageChange = (p: Pagination) => {
  subPage.value = p
  handleClick(undefined)
}

let ids: string
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(',')
}
let subIds: string
const subHandleSelectionChange = async (val: any) => {
  subIds = val.map((item: any) => item.id).join(',')
}
const save = async () => {
  const valid = await dialogFormRef.value?.asyncValidate()
  const data = toRaw(form.value)
  const specialChecksReturn = specialChecks(data, getSubSystem(), requestClassificationCode)
  if (!valid) {
    return
  }
  if (specialChecksReturn.clear) {
    await dialogFormRef.value?.clearValidate()
  }
  // 返回值 true是允许保存 , false是不允许保存
  if (!specialChecksReturn.result) {
    ElMessage.error({ message: specialChecksReturn.msg, grouping: true, showClose: true, duration: 0 })
    return
  }
  //校验是否存在特殊字符
  if (checkSpecialCharacters(data)) {
    await dialogFormRef.value?.asyncValidate()
    ElMessage.error({ message: '存在特殊字符', grouping: true, showClose: true, duration: 0 })
    return
  }
  //校验必填项(仅当特殊校验通过时才进行)
  if (!valid && specialChecksReturn.continueToVerify) {
    await dialogFormRef.value?.asyncValidate()
    ElMessage.error({ message: '存在必填项未填', grouping: true, showClose: true, duration: 0 })
    return
  }
  if (getRequestClassificationCode() == 'fkReturnFail' && isAddByZgfy.value == 'add') {
    console.log('请求批次号: ' + data.qqdbs)
    console.log('请求单号: ' + data.bdhm)
    if (data.qqdbs == null || data.qqdbs == '') {
      ElMessage.error({ message: '请求批次号必填!', grouping: true, showClose: true, duration: 0 })
      return
    }
    if (data.bdhm == null || data.bdhm == '') {
      ElMessage.error({ message: '请求单号必填!', grouping: true, showClose: true, duration: 0 })
      return
    }
    // 查询请求: 1; 控制请求: 2
  }
  buttonLoading.value = true
  try {
    const data = toRaw(form.value)
    data.status = '1'
    data.deleted = '0'
    delete data.type
    if (data.id == undefined) {
      await saveData(data)
    } else {
      await updateData(data)
    }
    if (dialogData.title === getTitleName() + '新增') {
      close()
    }
    await search()
    status.value = status.value = dictFormatter('1', dictData.dataStatus)
    ElMessage.success('保存成功')
  } finally {
    buttonLoading.value = false
  }
}

const submit = async (ids: string) => {
  try {
    const rs = await submitBatch({}, ids)

    status.value = status.value = dictFormatter('2', dictData.dataStatus)
    console.log('待审核')
    // close();
    ElMessage.success(rs.data)
  } finally {
    await search()
  }
}

const submitAndSave = async (data: any, ids: string) => {
  try {
    const valid = await dialogFormRef.value?.asyncValidate()
    const data = toRaw(form.value)
    const specialChecksReturn = specialChecks(data, getSubSystem(), requestClassificationCode)
    if (!valid) {
      return
    }
    if (specialChecksReturn.clear) {
      await dialogFormRef.value?.clearValidate()
    }
    // 返回值 true是允许保存 , false是不允许保存
    if (!specialChecksReturn.result) {
      ElMessage.error({ message: specialChecksReturn.msg, grouping: true, showClose: true, duration: 0 })
      return
    }
    //校验是否存在特殊字符
    if (checkSpecialCharacters(data)) {
      await dialogFormRef.value?.asyncValidate()
      ElMessage.error({ message: '存在特殊字符', grouping: true, showClose: true, duration: 0 })
      return
    }
    //校验必填项(仅当特殊校验通过时才进行)
    if (!valid && specialChecksReturn.continueToVerify) {
      await dialogFormRef.value?.asyncValidate()
      ElMessage.error({ message: '存在必填项未填', grouping: true, showClose: true, duration: 0 })
      return
    }
    const rs = await submitBatch(data, ids)
    status.value = status.value = dictFormatter('2', dictData.dataStatus)
    console.log('待审核')
    // close();
    ElMessage.success(rs.data)
  } finally {
    await search()
  }
}
const auditDialog = ref(false)
const audit = async (ids: any) => {
  try {
    const rs = await auditBatch(ids)
    status.value = status.value = dictFormatter('3', dictData.dataStatus)
    ElMessage.success(rs.data)
    close()
  } finally {
    auditDialog.value = false
    await search()
  }
}
const auditNotPass = async (ids: any) => {
  try {
    const rs = await auditNotPassBatch(ids, msg.value)
    status.value = status.value = dictFormatter('6', dictData.dataStatus)
    ElMessage.success(rs.data)
    close()
  } finally {
    msgDialog.value = false
    auditDialog.value = false
    await search()
  }
}

const reset = async (ids: string) => {
  ElMessageBox.prompt('重置原因', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    inputType: 'textarea',
  })
    .then(async ({ value }) => {
      try {
        const rs = await resetBatch(ids, value)
        status.value = status.value = dictFormatter('0', dictData.dataStatus)
        // close();
        ElMessage.success(rs.data)
      } finally {
        await search()
      }
    })
    .catch(() => {
      return
    })
}

const recall = async (ids: string) => {
  try {
    const rs = await recallBatch(ids)
    status.value = status.value = dictFormatter('0', dictData.dataStatus)
    // close();
    ElMessage.success(rs.data)
  } finally {
    await search()
  }
}
// 全量删除
const delAll = async () => {
  ElMessageBox.confirm('是否批量删除所有待补录/待提交数据?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      const newObject = { ...searchForm.value }
      for (const key in newObject) {
        if (newObject[key] === '') {
          newObject[key] = null
        }
      }
      var rs = await delAllBatch(getRequestClassificationCode(), newObject, null, null, null, false)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '删除'
      submitAllVisible.value = true
      search()
    })
    .catch(() => {
      return
    })
}
//主表批量删除方法
const del = async (ids: string) => {
  ElMessageBox.confirm('您确定删除所选中的待提交或待补录的数据吗?', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        const rs = await delBatch(ids, getRequestClassificationCode())
        ElMessage.success(rs.data)
      } finally {
        await search()
      }
    })
    .catch(() => {
      return
    })
}
const auditDelDialog = ref(false)
// 全量删除审核
const auditDelAll = async () => {
  ElMessageBox.confirm('是否批量删除审核所有删除待审核数据?', '警告', {
    confirmButtonText: '审核通过',
    cancelButtonText: '审核不通过',
    type: 'warning',
    distinguishCancelAndClose: true,
    confirmButtonClass: 'auditButton',
    cancelButtonClass: 'auditNotPassButton',
  })
    .then(async () => {
      const newObject = { ...searchForm.value }
      for (const key in newObject) {
        if (newObject[key] === '') {
          newObject[key] = null
        }
      }
      const rs = await auditDelAllBatch(getRequestClassificationCode(), newObject, null, null, null, false)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '删除审核'
      submitAllVisible.value = true
      search()
    })
    .catch((action: Action) => {
      if (action === 'cancel') {
        ElMessageBox.prompt('删除审核不通过理由', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputType: 'textarea',
        })
          .then(async ({ value }) => {
            if (value == null || value == '') {
              ElMessage.warning('删除审核不通过原因必填！')
              return
            }
            const newObject = { ...searchForm.value }
            for (const key in newObject) {
              if (newObject[key] === '') {
                newObject[key] = null
              }
            }
            const rs = await auditDelNotPassAllBatch(
              getRequestClassificationCode(),
              newObject,
              null,
              null,
              null,
              false,
              value,
            )
            successNum.value = rs.data.successNum
            failNum.value = rs.data.failNum
            returnMassage.value = rs.data.returnMassage
            submitOrAudit.value = '删除审核不通过'
            submitAllVisible.value = true
            search()
          })
          .catch(() => {
            return
          })
      }
    })
}
const delAudit = async (ids: string, type: string) => {
  if ((msg.value == null || msg.value == '') && type == '2') {
    ElMessage.warning('删除审核不通过原因必填！')
    return
  }
  try {
    let rs
    if (type == '1') {
      rs = await delBatchAudit(ids, getRequestClassificationCode())
    } else {
      rs = await delAuditNotPass(ids, msg.value, getRequestClassificationCode())
    }
    ElMessage.success(rs.data)
  } finally {
    await search()
    auditDelDialog.value = false
  }
}

const auditDelDialogSub = ref(false)
const delAuditSub = async (ids: string, type: string, name: string) => {
  if ((msg.value == null || msg.value == '') && type == '2') {
    ElMessage.warning('删除审核不通过原因必填！')
    return
  }
  try {
    let rs
    if (type == '1') {
      rs = await delBatchAudit(ids, name)
    } else {
      rs = await delAuditNotPass(ids, msg.value, name)
    }
    ElMessage.success(rs.data)
  } finally {
    await handleClick(undefined)
    await search()
    auditDelDialogSub.value = false
  }
}

const subSubmit = async (ids: string, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      subSubmitAll(name)
      return
    }
    const rs = await subSubmitBatch(ids, name)
    ElMessage.success(rs.data)
  } finally {
    await handleClick(undefined)
    await search() // 刷新最外层页面
  }
}

const subAuditDialog = ref(false)
const msgDialog = ref(false)
const subMsgDialog = ref(false)
const msg = ref('')
const subAudit = async (ids: any, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      subAuditAll(name)
      return
    }
    await subAuditBatch(ids, name)
    ElMessage.success('审核成功')
  } finally {
    subAuditDialog.value = false
    await handleClick(undefined)
  }
}
const subAuditNotPass = async (ids: any, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    await subAuditNotPassBatch(ids, name, msg.value)
    ElMessage.success('审核不通过成功')
  } finally {
    subMsgDialog.value = false
    subAuditDialog.value = false
    await handleClick(undefined)
  }
}

const subReset = async (ids: string, name: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  ElMessageBox.prompt('重置原因', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    inputType: 'textarea',
  })
    .then(async ({ value }) => {
      try {
        const rs = await subResetBatch(ids, name, value)
        ElMessage.success(rs.data)
      } finally {
        await handleClick(undefined)
        await search() // 刷新最外层页面
      }
    })
    .catch(() => {
      return
    })
}

const subRecall = async (ids: string, name: string) => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  try {
    const rs = await subRecallBatch(ids, name)
    ElMessage.success(rs.data)
  } finally {
    await handleClick(undefined)
    await search() // 刷新最外层页面
  }
}

const subDelAll = async (name: string) => {
  ElMessageBox.confirm('是否批量删除所有待补录/待提交数据?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      var rs = await delAllBatch(name, {}, bdhm.value, khbh.value, ccxh.value, true)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '删除'
      submitAllVisible.value = true
      await handleClick(undefined)
    })
    .catch(() => {
      return
    })
}
const subDelAuditAll = async (name: string) => {
  ElMessageBox.confirm('是否批量审核所有待审核数据?', '警告', {
    confirmButtonText: '审核通过',
    cancelButtonText: '审核不通过',
    type: 'warning',
    distinguishCancelAndClose: true,
    confirmButtonClass: 'auditButton',
    cancelButtonClass: 'auditNotPassButton',
  })
    .then(async () => {
      var rs = await auditDelAllBatch(name, {}, bdhm.value, khbh.value, ccxh.value, true)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '删除审核'
      submitAllVisible.value = true
      await handleClick(undefined)
    })
    .catch((action: Action) => {
      if (action === 'cancel') {
        ElMessageBox.prompt('删除审核不通过理由', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputType: 'textarea',
        })
          .then(async ({ value }) => {
            if (value == null || value == '') {
              ElMessage.warning('删除审核不通过原因必填！')
              return
            }
            var rs = await auditDelNotPassAllBatch(name, {}, bdhm.value, khbh.value, ccxh.value, true, value)
            successNum.value = rs.data.successNum
            failNum.value = rs.data.failNum
            returnMassage.value = rs.data.returnMassage
            submitAllVisible.value = true
            submitOrAudit.value = '删除审核不通过'
            await handleClick(undefined)
          })
          .catch(() => {
            return
          })
      }
    })
}

const subDel = async (ids: string, name: string) => {
  // if (ids == undefined || ids.length == 0) {
  //   ElMessage.warning('请先选择数据')
  //   return
  // }
  if (ids == undefined || ids.length == 0) {
    subDelAll(name)
    return
  }
  ElMessageBox.confirm('您确定删除所选中的待提交或待补录的数据吗?', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        const rs = await subDelBatch(ids, name)
        ElMessage.success(rs.data)
      } finally {
        await handleClick(undefined)
        await search() // 刷新最外层页面
      }
    })
    .catch(() => {
      return
    })
}

const imp = async (data = {}) => {
  impLoading.value = true
  try {
    var name = data.name
    if (name == null) {
      name = data[0].name
    }
    if (!name.toLowerCase().endsWith('.xlsx') && !name.toLowerCase().endsWith('.xls')) {
      ElMessage.error({ message: '仅可上传Excel文件', grouping: true, showClose: true, duration: 0 })
      return
    }
    var needBeOverridden = await checkExcelData(data)
    if (needBeOverridden.data) {
      ElMessageBox.confirm('检测到上传文件中的数据已存在,是否覆盖?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(async () => {
          try {
            const rs = await importExcel(data, false, null, null, null, null)
            // ElMessage.success(rs.data);
            await ElMessageBox.alert(rs.data, '导入结果', {
              customClass: 'customMessageBox',
              dangerouslyUseHTMLString: true,
            })
            await search()
          } finally {
            impLoading.value = false
          }
        })
        .catch(() => {
          // ElMessage.warning("取消导入");
          impLoading.value = false
          return
        })
    } else {
      const rs = await importExcel(data, false, null, null, null, null)
      // ElMessage.success(rs.data);
      await ElMessageBox.alert(rs.data, '导入结果', {
        customClass: 'customMessageBox',
        dangerouslyUseHTMLString: true,
      })
      await search()
    }
  } finally {
    impLoading.value = false
  }
}

const exp = async () => {
  expLoading.value = true
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    let value = searchForm.value
    const newObject = { ...searchForm.value }
    await exportExcel(ids, newObject)
  } finally {
    expLoading.value = false
  }
}

const parentsButtons: () => ButtonInfo[] = () => {
  const buttons = [
    {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      icon: 'icon_check',
      handler: () => {
        ids = form.value.id
        auditDialog.value = true
      },
    },
    {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      icon: 'icon_recall',
      handler: () => recall(form.value.id),
    },
    // {
    //   key: 'reset',
    //   label: '重置',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_reset',
    //   handler: () => reset(form.value.id),
    // },
  ]
  if (status.value == '待提交' || status.value == '待补录' || status.value == '待补录(审核未通过)') {
    buttons.splice(0, 0, {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => submitAndSave(toRaw(form.value), form.value.id),
    })
    buttons.splice(4, 0, {
      key: 'save',
      label: '保存',
      tag: 'button',
      type: 'primary',
      icon: 'icon_update',
      handler: () => {
        showConfirm()
      },
    })
  }
  if (getRequestClassificationCode() == 'fkReturnFail' && isAddByZgfy.value == 'add') {
    return [
      {
        key: 'save',
        label: '保存',
        tag: 'button',
        type: 'primary',
        icon: 'icon_update',
        handler: () => {
          showConfirm()
        },
      },
    ]
  } else {
    return buttons
  }
}
const parentsButtons2: ButtonInfo[] = [
  {
    key: 'submit',
    label: '提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => submit(form.value.id),
  },
  {
    key: 'audit',
    label: '审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => {
      ids = form.value.id
      auditDialog.value = true
    },
  },
  {
    key: 'recall',
    label: '撤回',
    tag: 'button',
    type: 'primary',
    icon: 'icon_recall',
    handler: () => recall(form.value.id),
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => reset(form.value.id),
  },
]

const dictDataList = [
  { label: '1', value: '待提交' },
  { label: '2', value: '待审核' },
  {
    label: '3',
    value: '已审核',
  },
  { label: '4', value: '已生成' },
]

const route = useRoute()
const uploadRef = ref<UploadInstance>()
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        //法院查询反馈页面，要判断请求中账户资金往来交易信息查询开始时间 和 账户资金往来交易信息查询结束时间，如果没值，则资金往来TAB不需要显示    ---根据反馈页面的请求单号 请求批次号 查general表
        let result = await listZgfyCxGeneral(row)
        let record = result.data[0]
        if (record != undefined && record['ckkssj'] == null && record['ckjssj'] == null) {
          // 移除 资金往来TAB
          subTables = derivedPageElements(requestClassificationCode).subTables.filter((f) => f.name != '资金往来信息')
        } else {
          subTables = derivedPageElements(requestClassificationCode).subTables
        }
        isAddByZgfy.value = 'edit'
        bdhm.value = row.bdhm
        qqdbs.value = row.qqdbs
        activeName.value = 1
        khbh.value = row.khbh
        ccxh.value = row.ccxh
        branchCode.value = row.branchCode
        status.value = dictFormatter(row.status, dictData.dataStatus)
        open(row, true, getTitleName() + '查看')
      },
    },
    // {
    //   key: 'upload', label: '上传回执文书', tag: 'button', type: 'primary',
    //   handler: () => {
    //     if (row.status!=1) {
    //       ElMessage.error("仅在待提交状态可上传回执文书")
    //       return;
    //     }
    //     var elementById = document.getElementById("uploadButton");
    //     elementById.click();
    //     bdhm.value = row.bdhm;
    //     qqdbs.value = row.qqdbs;
    //   }
    // },
    // {
    //   key: 'preview', label: '查看已上传回执文书', tag: 'button', type: 'primary',
    //   handler: async () => {
    //     bdhm.value = row.bdhm;
    //     var rsPromise = await previewUploadFile(bdhm.value);
    //     let pdfWindow = window.open("", 'pdf预览');
    //     // 将base64字符串转换为Uint8Array对象
    //     const pdfData = atob(rsPromise.data);
    //     const pdfArray = new Uint8Array(pdfData.length);
    //     for (let i = 0; i < pdfData.length; i++) {
    //       pdfArray[i] = pdfData.charCodeAt(i);
    //     }
    //     // 创建Blob对象
    //     const pdfBlob = new Blob([pdfArray], {type: 'application/pdf'});
    //     // 将Blob对象转换为URL
    //     const pdfUrl = URL.createObjectURL(pdfBlob);
    //     // 将URL作为iframe的src属性值
    //     pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>");
    //   }
    // }
  ]
  if ((row.status <= 2 || row.status == 6) && (row.deleteState == '1' || row.deleteState == '4')) {
    buttons.splice(1, 0, {
      key: 'edit',
      label: '编辑',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        //法院查询反馈页面，要判断请求中账户资金往来交易信息查询开始时间 和 账户资金往来交易信息查询结束时间，如果没值，则资金往来TAB不需要显示    ---根据反馈页面的请求单号 请求批次号 查general表
        let result = await listZgfyCxGeneral(row)
        let record = result.data[0]
        if (record != undefined && record['ckkssj'] == null && record['ckjssj'] == null) {
          // 移除 资金往来TAB
          subTables = derivedPageElements(requestClassificationCode).subTables.filter((f) => f.name != '资金往来信息')
        } else {
          subTables = derivedPageElements(requestClassificationCode).subTables
        }
        isAddByZgfy.value = 'edit'
        bdhm.value = row.bdhm
        qqdbs.value = row.qqdbs
        activeName.value = 1
        khbh.value = row.khbh
        ccxh.value = row.ccxh
        branchCode.value = row.branchCode
        status.value = dictFormatter(row.status, dictData.dataStatus)
        if (row.status > 2 && row.status != 6) {
          open(row, true, getTitleName())
        } else {
          let disabled = false
          if (row.status == 2) {
            disabled = true
          }
          open(row, disabled, getTitleName() + '编辑')
        }
      },
    })
  }
  return buttons
}

const IUploadFile = async (data = {}) => {
  if (!data.file.name.toLowerCase().endsWith('.pdf')) {
    ElMessage.error({ message: '仅可上传PDF文件', grouping: true, showClose: true, duration: 0 })
    return
  }
  var isNotExist = await checkFileExist(bdhm.value)
  if (!isNotExist.data) {
    ElMessageBox.confirm('检测到该数据已经上传过回执文书,是否覆盖?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    })
      .then(async () => {
        const rsPromise = await upload(qqdbs.value, bdhm.value, data)
        ElMessage.success(rsPromise.data)
      })
      .catch(() => {
        ElMessage.warning('取消上传')
        return
      })
  } else {
    const rsPromise = await upload(qqdbs.value, bdhm.value, data)
    ElMessage.success(rsPromise.data)
  }
}
//子表所需代码
const save1 = async (data: any, name: string) => {
  const valid = await subDialogFormRef.value?.asyncValidate()
  if (!valid) {
    return
  }
  buttonLoading.value = true
  try {
    data = toRaw(subForm.value)
    data.status = '1'
    data.deleted = '0'
    data.bdhm = bdhm.value
    if (khbh.value != '' && khbh.value != undefined) {
      data.khbh = khbh.value
    }
    if (ccxh.value != '' && ccxh.value != undefined) {
      data.ccxh = ccxh.value
    }
    if (branchCode.value != '' && branchCode.value != undefined) {
      data.branchCode = branchCode.value
    }
    data.qqdbs = qqdbs.value
    if (data.id == undefined) {
      await subSaveData(data, name)
    } else {
      await subUpdateData(data, name)
    }
    subClose()
    subClosed()
    ElMessage.success('保存成功')
    handleClick(undefined)
  } finally {
    buttonLoading.value = false
  }
}

const subButtons: (name: string, items: any) => ButtonInfo[] = (name: string, items: any) => {
  const buttons = [
    {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => subSubmit(subIds, name),
    },
    {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      icon: 'icon_check',
      handler: () => {
        listName = name
        if (subIds == null || subIds.length == 0) {
          subAuditAll(name)
          return
        }
        subAuditDialog.value = true
      },
    },
    {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      icon: 'icon_recall',
      handler: () => subRecall(subIds, name),
    },
    {
      key: 'reset',
      label: '重置',
      tag: 'button',
      type: 'primary',
      icon: 'icon_reset',
      handler: () => subReset(subIds, name),
    },
    // {
    //   key: 'del',
    //   label: '批量删除',
    //   tag: 'button',
    //   type: 'danger',
    //   icon: 'icon_delete',
    //   handler: () => subDel(subIds, name),
    // },
    {
      key: 'delete',
      label: '删除',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      handler: () => subDel(subIds, name),
    },
    {
      key: 'delverify',
      label: '删除审核',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      handler: () => {
        listName = name
        msg.value = null
        if (subIds == undefined || subIds.length == 0) {
          // ElMessage.warning('请先选择数据')
          subDelAuditAll(name)
          return
        }
        auditDelDialogSub.value = true
      },
    },
  ]
  if (status.value == '待提交' || status.value == '待补录' || status.value == '待补录(审核未通过)') {
    buttons.splice(0, 0, {
      key: 'add',
      label: '新增',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: () => {
        listName = name
        subFormItems.value = items
        if (name == 'zgfyFkFinancial') {
          setRequiredRule(['zcxh'], false, subFormItems.value)
        } else if (name == 'zgfyFkSubAccount') {
          setRequiredRule(['glxh'], false, subFormItems.value)
        } else if (name == 'fkControlFreeze' || name == 'zgfyFkMeasure') {
          setRequiredRule(['csxh'], false, subFormItems.value)
        } else if (name == 'fkControlPriority' || name == 'zgfyFkPriority') {
          setRequiredRule(['xh'], false, subFormItems.value)
        } else if (name == 'zgfyFkTransfer') {
          setRequiredRule(['wlxh'], false, subFormItems.value)
        } else {
          console.log('其他')
        }
        subOpen({ ccxh: ccxh.value }, false, getSubTitleName(name) + '新增')
      },
    })
  }

  if (
    getSubSystem() === 'zgfy' &&
    getRequestClassificationCode() === 'fkCxqq' &&
    getSubTitleName(name) === '资金往来信息' &&
    dialogData.title === getTitleName() + '编辑'
  ) {
    buttons.push({
      key: 'imp417report',
      label: '导入417report',
      tag: 'button',
      type: 'primary',
      loading: isSubImpLoading.value,
      icon: 'icon_upload',
      handler: () => {
        var elementById = document.getElementById('upload417ReportButton')
        elementById.click()
      },
    })
  }
  return buttons
}
const getTitleName = () => {
  switch (getRequestClassificationCode()) {
    case 'fkCxqq':
      return '查询请求反馈'
    case 'fkKzqq':
      return '控制请求反馈'
    case 'fkReturnFail':
      return '账户信息和交易明细综合查询反馈'
  }
}

const getSubTitleName = (name: string) => {
  switch (name) {
    case 'fkAccount':
      return '账户信息'
    case 'zgfyFkFinancial':
      return '金融资产信息'
    case 'zgfyFkMeasure':
      return '司法强制措施信息'
    case 'zgfyFkPriority':
      return '共有权/优先权信息'
    case 'zgfyFkSubAccount':
      return '关联子账户信息'
    case 'zgfyFkTransfer':
      return '资金往来信息'
    case 'fkControl':
      return '控制结果'
    case 'fkControlFreeze':
      return '在先冻结信息'
    case 'fkControlPriority':
      return '优先权信息'
  }
}
const subGenActButtons2: (row: any, name: string, items: any) => ButtonInfo[] = (
  row: any,
  name: string,
  items: any,
) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: () => {
        subFormItems.value = items
        subOpen(row, true, getSubTitleName(name) + '查看')
      },
    },
  ]
  return buttons
}
const subGenActButtons: (row: any, name: string, items: any) => ButtonInfo[] = (row: any, name: string, items: any) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: () => {
        subFormItems.value = items
        subOpen(row, true, getSubTitleName(name) + '查看')
      },
    },
  ]
  /*if (row.status <2||row.status==6) {
    buttons.splice(1, 0,
        {
          key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
          handler: () => subDel(row.id, name)
        });
  }*/
  if (row.status == 2) {
    buttons.splice(1, 0, {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      handler: () => subRecall(row.id, name),
    })
  }
  if (row.status == 3) {
    buttons.splice(1, 0, {
      key: 'reset',
      label: '重置',
      tag: 'button',
      type: 'primary',
      handler: () => subReset(row.id, name),
    })
  }
  if (row.status == 2) {
    buttons.splice(1, 0, {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      handler: () => {
        listName = name
        subIds = row.id
        subAuditDialog.value = true
      },
    })
  }
  if (row.status == 1 && (row.deleteState == '1' || row.deleteState == '4')) {
    buttons.splice(1, 0, {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      handler: () => subSubmit(row.id, name),
    })
  }
  if ((row.status < 2 || row.status == 6) && (row.deleteState == '1' || row.deleteState == '4')) {
    buttons.splice(1, 0, {
      key: 'edit',
      label: '编辑',
      tag: 'button',
      type: 'primary',
      handler: () => {
        listName = name
        subFormItems.value = items
        if (name == 'zgfyFkFinancial') {
          setRequiredRule(['zcxh'], true, subFormItems.value)
        } else if (name == 'zgfyFkSubAccount') {
          setRequiredRule(['glxh'], true, subFormItems.value)
        } else if (name == 'fkControlFreeze' || name == 'zgfyFkMeasure') {
          setRequiredRule(['csxh'], true, subFormItems.value)
        } else if (name == 'fkControlPriority' || name == 'zgfyFkPriority') {
          setRequiredRule(['xh'], true, subFormItems.value)
        } else if (name == 'zgfyFkTransfer') {
          setRequiredRule(['wlxh'], true, subFormItems.value)
        } else {
          console.log('其他')
        }
        if (row.status > 2 && row.status != 6) {
          subOpen(row, true, getSubTitleName(name))
        } else {
          subOpen(row, false, getSubTitleName(name) + '编辑')
        }
      },
    })
  }

  return buttons
}

const fkAccountSearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'fkAccount',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}
const fkFinancialSearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'zgfyFkFinancial',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}

const fkMeasureSearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'zgfyFkMeasure',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}

const fkPrioritySearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'zgfyFkPriority',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}

const fkSubAccountSearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'zgfyFkSubAccount',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}
const fkTransferSearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'zgfyFkTransfer',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}
const fkControlSearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'fkControl',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}
const fkControlFreezeSearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'fkControlFreeze',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}
const fkControlPrioritySearch = async () => {
  let result = await listByBdhm(
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    'fkControlPriority',
    bdhm.value,
    khbh.value,
    ccxh.value,
  )
  subSearch(result)
}

const subSearch = (result: any) => {
  let { current, total, records } = result.data
  subData.value = records
  subPage.value.currentPage = current
  subPage.value.total = total
}

let tabName = ''
const handleClick = async (tab: any) => {
  subLoading.value = true
  try {
    if (tab == undefined) {
      switch (tabName) {
        // case "账户信息" :
        //   await fkAccountSearch();
        //   break;
        case '金融资产信息':
          await fkFinancialSearch()
          break
        case '司法强制措施信息':
          await fkMeasureSearch()
          break
        case '共有权/优先权信息':
          await fkPrioritySearch()
          break
        case '关联子账户信息':
          await fkSubAccountSearch()
          break
        case '资金往来信息':
          await fkTransferSearch()
          break
        // case "控制结果" :
        //   await fkControlSearch();
        //   break;
        case '在先冻结信息':
          await fkControlFreezeSearch()
          break
        case '优先权信息':
          await fkControlPrioritySearch()
          break
        default:
          break
      }
    } else {
      subPage.value.currentPage = 1
      tabName = tab.props.label
      switch (tab.props.label) {
        // case "账户信息" :
        //   await fkAccountSearch();
        //   break;
        case '金融资产信息':
          await fkFinancialSearch()
          break
        case '司法强制措施信息':
          await fkMeasureSearch()
          break
        case '共有权/优先权信息':
          await fkPrioritySearch()
          break
        case '关联子账户信息':
          await fkSubAccountSearch()
          break
        case '资金往来信息':
          await fkTransferSearch()
          break
        // case "控制结果" :
        //   await fkControlSearch();
        //   break;
        case '在先冻结信息':
          await fkControlFreezeSearch()
          break
        case '优先权信息':
          await fkControlPrioritySearch()
          break
      }
    }
  } finally {
    subLoading.value = false
  }
}
//主表按钮组件
const Buttons_yhthsb: ButtonInfo[] = [
  {
    key: 'save',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => {
      status.value = '新增'
      isAddByZgfy.value = 'add'
      open(null, false, getTitleName() + '新增')
    },
  },
  {
    key: 'submit',
    label: '提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        submitAll()
        return
      }
      submit(ids)
    },
  },
  {
    key: 'audit',
    label: '审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        auditAll()
        return
      }
      auditDialog.value = true
    },
  },
  {
    key: 'recall',
    label: '撤回',
    tag: 'button',
    type: 'primary',
    icon: 'icon_recall',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
      }
      recall(ids)
    },
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
      }
      reset(ids)
    },
  },
  {
    key: 'delete',
    label: '删除',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        // ElMessage.warning('请先选择数据')
        delAll()
        return
      }
      del(ids)
    },
  },
  {
    key: 'delverify',
    label: '删除审核',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => {
      msg.value = null
      if (ids == undefined || ids.length == 0) {
        // ElMessage.warning('请先选择数据')
        auditDelAll()
        return
      }
      auditDelDialog.value = true
    },
  },
]
//主表按钮组件
const Buttons: ButtonInfo[] = [
  {
    key: 'submit',
    label: '提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        submitAll()
        return
      }
      submit(ids)
    },
  },
  {
    key: 'audit',
    label: '审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        auditAll()
        return
      }
      auditDialog.value = true
    },
  },
  {
    key: 'recall',
    label: '撤回',
    tag: 'button',
    type: 'primary',
    icon: 'icon_recall',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
      }
      recall(ids)
    },
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
      }
      reset(ids)
    },
  },
  {
    key: 'delete',
    label: '删除',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        // ElMessage.warning('请先选择数据')
        delAll()
        return
      }
      del(ids)
    },
  },
  {
    key: 'delverify',
    label: '删除审核',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => {
      msg.value = null
      if (ids == undefined || ids.length == 0) {
        // ElMessage.warning('请先选择数据')
        auditDelAll()
        return
      }
      auditDelDialog.value = true
    },
  },
]
const submitAllVisible = ref(false)
const successNum = ref(0)
const failNum = ref(0)
const returnMassage = ref('')
const submitOrAudit = ref('')
const submitAll = async () => {
  ElMessageBox.confirm('是否批量提交所有待提交/待补录数据?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      const newObject = { ...searchForm.value }
      for (const key in newObject) {
        if (newObject[key] === '') {
          newObject[key] = null
          console.log('转化了空串')
        }
      }
      var rs = await submitAllBatch(getRequestClassificationCode(), newObject, null, null, null, false)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '提交'
      submitAllVisible.value = true
      search()
    })
    .catch(() => {
      return
    })
}
const auditAll = async () => {
  ElMessageBox.confirm('是否批量审核所有待审核数据?', '警告', {
    confirmButtonText: '审核通过',
    cancelButtonText: '审核不通过',
    type: 'warning',
    distinguishCancelAndClose: true,
    confirmButtonClass: 'auditButton',
    cancelButtonClass: 'auditNotPassButton',
  })
    .then(async () => {
      const newObject = { ...searchForm.value }
      for (const key in newObject) {
        if (newObject[key] === '') {
          newObject[key] = null
          console.log('转化了空串')
        }
      }
      var rs = await auditAllBatch(getRequestClassificationCode(), newObject, null, null, null, false)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '审核'
      submitAllVisible.value = true
      search()
    })
    .catch((action: Action) => {
      if (action === 'cancel') {
        ElMessageBox.prompt('审核不通过理由', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputType: 'textarea',
        })
          .then(async ({ value }) => {
            const newObject = { ...searchForm.value }
            for (const key in newObject) {
              if (newObject[key] === '') {
                newObject[key] = null
                console.log('转化了空串')
              }
            }
            var rs = await auditNotPassAllBatch(
              getRequestClassificationCode(),
              newObject,
              null,
              null,
              null,
              false,
              value,
            )
            successNum.value = rs.data.successNum
            failNum.value = rs.data.failNum
            returnMassage.value = rs.data.returnMassage
            submitOrAudit.value = '审核不通过'
            submitAllVisible.value = true
            search()
          })
          .catch(() => {
            return
          })
      }
    })
}
const subSubmitAll = async (name: string) => {
  ElMessageBox.confirm('是否批量提交所有待提交/待补录数据?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      var rs = await submitAllBatch(name, {}, bdhm.value, khbh.value, ccxh.value, true)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '提交'
      submitAllVisible.value = true
      await handleClick(undefined)
    })
    .catch(() => {
      return
    })
}
const subAuditAll = async (name: string) => {
  ElMessageBox.confirm('是否批量审核所有待审核数据?', '警告', {
    confirmButtonText: '审核通过',
    cancelButtonText: '审核不通过',
    type: 'warning',
    distinguishCancelAndClose: true,
    confirmButtonClass: 'auditButton',
    cancelButtonClass: 'auditNotPassButton',
  })
    .then(async () => {
      var rs = await auditAllBatch(name, {}, bdhm.value, khbh.value, ccxh.value, true)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '审核'
      submitAllVisible.value = true
      await handleClick(undefined)
    })
    .catch((action: Action) => {
      if (action === 'cancel') {
        ElMessageBox.prompt('审核不通过理由', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputType: 'textarea',
        })
          .then(async ({ value }) => {
            var rs = await auditNotPassAllBatch(name, {}, bdhm.value, khbh.value, ccxh.value, true, value)
            successNum.value = rs.data.successNum
            failNum.value = rs.data.failNum
            returnMassage.value = rs.data.returnMassage
            submitAllVisible.value = true
            submitOrAudit.value = '审核不通过'
            await handleClick(undefined)
          })
          .catch(() => {
            return
          })
      }
    })
}

/**
 *   这里监听主表单 控制反馈主表单条件非空 调整传参
 */
watch(
  () => [form.value,cxDetailValue.value],
  (newForm, oldForm) => {
    // 未启用部门编码，编辑页面隐藏
    if (dictData.departmentCodeRequired == undefined) {
      formItems.value[0].items = formItems.value[0].items.filter((item) => 'departmentCode' != item.prop)
    }
    if (activeName.value == '1' && formItems.value[0].name == '控制结果') {
      if(cxDetailValue?.value?.kzlx && form.value.kzzt){
        setRequiredRule(['skje'], cxDetailValue?.value?.kzlx != '2' && form.value.kzzt == '1', formItems.value[0].items)
      }
      setRequiredRule(['wnkzyy'], form.value.kzzt == '2', formItems.value[0].items)
      setRequiredRule(
        ['kznr', 'ye', 'kyye', 'csksrq', 'csjsrq', 'djxe', 'khmc', 'khbh', 'branchCode'],
        form.value.kzzt == '1',
        formItems.value[0].items,
      )
    } else if (activeName.value == '1' && formItems.value[0].name == '账户信息') {
      // 开户账号:查无开户信息 以下必填不要
      setRequiredRule(
        ['cclb', 'zhzt', 'khwd', 'khwddm', 'khrq', 'bz', 'khmc', 'khbh', 'branchCode'],
        form.value.khzh != '查无开户信息',
        formItems.value[0].items,
      )
    }
    formItems.value = [...formItems.value]
  },
  { deep: true },
)

/**
 *   这里监听子表单 控制反馈子表单条件非空
 */
watch(
  () => subForm.value,
  (newForm, oldForm) => {
    // 未启用部门编码，编辑页面隐藏
    if (dictData.departmentCodeRequired == undefined) {
      subFormItems.value = subFormItems.value.filter((item) => 'departmentCode' != item.prop)
    }

    subFormItems.value = [...subFormItems.value]
  },
  { deep: true },
)

const IUpload417ReportFile = async (data = {}, dd: any) => {
  try {
    isSubImpLoading.value = true
    var name = data.file.name
    if (name == null) {
      name = data[0].name
    }
    if (!name.toLowerCase().endsWith('.xlsx') && !name.toLowerCase().endsWith('.xls')) {
      ElMessage.error({ message: '仅可上传Excel文件', grouping: true, showClose: true, duration: 0 })
      return
    }
    const rs = await importExcel(data, true, qqdbs.value, bdhm.value, searchForm.value.businessLine, ccxh.value)
    // ElMessage.success(rs.data);
    await ElMessageBox.alert(`<div style="max-height: 500px; overflow-y: auto;">${rs.data}</div>`, '导入结果', {
      customClass: 'customMessageBox',
      dangerouslyUseHTMLString: true,
    })
    await search()
  } finally {
    isSubImpLoading.value = false
    // await search();
    await handleClick(undefined)
  }
}
</script>

<style scoped>
.auditNotPassButton {
  background: #f56c6cff;
  border-color: #f56c6cff;
  color: #fff;
}

.auditNotPassButton:hover {
  background: #e08282; /* 鼠标悬停时的背景色 */
  border-color: #e08282; /* 鼠标悬停时的边框颜色 */
  color: #fff; /* 鼠标悬停时的文字颜色 */
}

/*.auditButton{*/
/*  background: var(--el-color-success);*/
/*  border-color: var(--el-color-success);*/
/*  color: #fff;*/
/*}*/
</style>
