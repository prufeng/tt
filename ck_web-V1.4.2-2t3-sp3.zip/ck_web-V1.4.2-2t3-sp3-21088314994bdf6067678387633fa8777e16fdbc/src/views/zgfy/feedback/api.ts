import {RS} from 'riking-ui'
import service from '@/utils/request'
import {getCommonParams, getRequestClassificationCode, getSubSystem} from "@/utils/subSystem";

export function list(data = {}, current: number, size: number): Promise<RS> {
    return service({
        url: '/zgfyFk/list',
        method: 'POST',
        data,
        params: {current, size, requestClassificationCode:getRequestClassificationCode()}
    })
}

export function listZgfyCxGeneral(data = {}): Promise<RS> {
    return service({
        url: '/zgfyCx/listZgfyCxGeneral',
        method: 'POST',
        data,
    })
}

export function listSysFileImportRecord( data = {}): Promise<RS> {
    return service({
        url: `/zgfyCx/listSysFileImportRecord`,
        method: 'POST',
        data,
    })
}

export function getPdf(data = {},cxCode:string): Promise<RS> {
    return service({
        url: '/zgfyCx/getPdf',
        method: 'POST',
        data,
        params: {requestClassificationCode:cxCode},
    })
}
export function getImage(data = {},cxCode:string): Promise<RS> {
    return service({
        url: '/zgfyCx/getImage',
        method: 'POST',
        data,
        params: {requestClassificationCode:cxCode},
    })
}
export function getXml( data = {},cxCode:string): Promise<RS> {
    return service({
        url: `/zgfyCx/getXml`,
        method: 'POST',
        data,
        params: {requestClassificationCode:cxCode},
    })
}

export function listByBdhm(data = {}, current: number, size: number,name:string, bdhm:string,khbh:string,ccxh:string): Promise<RS> {
    if (khbh==undefined) {
        khbh = '';
    }
    if (ccxh==undefined || null) {
        ccxh = '';
    }
    return service({
        url: '/zgfyFk/listByBdhm',
        method: 'POST',
        data,
        params: {current, size, bdhm , khbh,requestClassificationCode:name,ccxh}
    });
}

export function saveData(data = {}): Promise<RS> {
    return service({
        url: '/zgfyFk/save',
        method: 'POST',
        data,
        params: {requestClassificationCode:getRequestClassificationCode()}
    })
}
export function feedbackSaveData(data = {},requestClassificationCode:string): Promise<RS> {
    return service({
        url: '/zgfyFk/save',
        method: 'POST',
        data,
        params: {requestClassificationCode}
    })
}
export function updateData(data = {}): Promise<RS> {
    return service({
        url: '/zgfyFk/update',
        method: 'POST',
        data,
        params: {requestClassificationCode:getRequestClassificationCode()}
    })
}
export function subSaveData(data = {}, name:string): Promise<RS> {
    return service({
        url: '/zgfyFk/save',
        method: 'POST',
        data,
        params: {requestClassificationCode:name}
    })
}
export function subUpdateData(data = {}, name:string): Promise<RS> {
    return service({
        url: '/zgfyFk/update',
        method: 'POST',
        data,
        params: {requestClassificationCode:name}
    })
}

export function submitBatch(data:any,ids:any): Promise<RS> {
    return service({
        url: '/zgfyFk/submit',
        method: 'POST',
        data,
        params: {ids, requestClassificationCode:getRequestClassificationCode()},
    })
}

export function subSubmitBatch(ids:any,name:string): Promise<RS> {
    return service({
        url: '/zgfyFk/submit',
        method: 'POST',
        params: {ids, requestClassificationCode:name},
    })
}

export function auditBatch(ids: any): Promise<RS> {
    return service({
        url: '/zgfyFk/audit',
        method: 'POST',
        params: {ids, requestClassificationCode:getRequestClassificationCode()},
    })
}
export function auditNotPassBatch(ids: any,msg:any): Promise<RS> {
    return service({
        url: '/zgfyFk/auditNotPass',
        method: 'POST',
        params: {ids,msg, requestClassificationCode:getRequestClassificationCode()},
    })
}

export function subAuditBatch(ids: any,name:string): Promise<RS> {
    return service({
        url: '/zgfyFk/audit',
        method: 'POST',
        params: {ids, requestClassificationCode:name},
    })
}
export function subAuditNotPassBatch(ids: any,name:string,msg:any): Promise<RS> {
    return service({
        url: '/zgfyFk/auditNotPass',
        method: 'POST',
        params: {ids, msg,requestClassificationCode:name},
    })
}
export function resetBatch(ids: any,msg:string): Promise<RS> {
    return service({
        url: '/zgfyFk/reset',
        method: 'POST',
        params: {ids, requestClassificationCode:getRequestClassificationCode(),msg},
    })
}

export function subResetBatch(ids: any ,name:string,msg:string): Promise<RS> {
    return service({
        url: '/zgfyFk/reset',
        method: 'POST',
        params: {ids, requestClassificationCode:name,msg},
    })
}

export function recallBatch(ids: any): Promise<RS> {
    return service({
        url: '/zgfyFk/recall',
        method: 'POST',
        params: {ids, requestClassificationCode:getRequestClassificationCode()},
    })
}

export function subRecallBatch(ids: any ,name:string): Promise<RS> {
    return service({
        url: '/zgfyFk/recall',
        method: 'POST',
        params: {ids, requestClassificationCode:name},
    })
}

export function delBatch(ids: any, name: string): Promise<RS> {
    return service({
        url: '/zgfyFk/del',
        method: 'POST',
        params: {ids,requestClassificationCode:name},
    })
}

export function delBatchAudit(ids: any, name: string): Promise<RS> {
    return service({
        url: '/zgfyFk/delAudit',
        method: 'POST',
        params: {ids,requestClassificationCode:name},
    })
}
export function delAuditNotPass(ids: any, msg:string, name: string): Promise<RS> {
    return service({
        url: '/zgfyFk/delAuditNotPass',
        method: 'POST',
        params: {ids,msg,requestClassificationCode:name},
    })
}


export function subDelBatch(ids: any,name:string): Promise<RS> {
    return service({
        url: '/zgfyFk/del',
        method: 'POST',
        params: {ids, requestClassificationCode:name},
    })
}

export function checkExcelData(data:any): Promise<RS> {
    return service({
        url: `/zgfyFk/checkExcelData`,
        method: 'POST',
        data,
        params: {requestClassificationCode:getRequestClassificationCode()},
        headers: {'Content-Type': 'multipart/form-data',}
    })
}
export function importExcel(data:any,is417report:boolean,qqdbs:string,bdhm:string,businessLine:string,ccxh:string): Promise<RS> {
    return service({
        url: '/zgfyFk/importExcel',
        method: 'POST',
        data,
        params: {is417report,qqdbs,bdhm,businessLine,ccxh,requestClassificationCode:getRequestClassificationCode()},
        headers: {'Content-Type': 'multipart/form-data'},
    })
}

export function exportExcel(ids:any,data = {}): Promise<RS> {
    return service({
        url: '/zgfyFk/exportExcel',
        method: 'POST',
        data,
        params: {ids, requestClassificationCode:getRequestClassificationCode()},
        responseType: 'blob'
    })
}
export function upload(qqdbs:string,bdhm:string,data = {}): Promise<RS> {
    return service({
        url: '/zgfyFk/upload',
        method: 'POST',
        data,
        params: {qqdbs,bdhm,requestClassificationCode:getRequestClassificationCode()},
        headers: {'Content-Type': 'multipart/form-data',}
    })
}

export function checkFileExist(bdhm:string): Promise<RS> {
    return service({
        url: '/zgfyFk/checkFileExist',
        method: 'POST',
        params: {bdhm,requestClassificationCode:getRequestClassificationCode()},
    })
}

export function previewUploadFile(bdhm:string): Promise<RS> {
    return service({
        url: '/zgfyFk/previewUploadFile',
        method: 'POST',
        params: {bdhm,requestClassificationCode:getRequestClassificationCode()},
    })
}

export function auditAllBatch(name: string,data = {},bdhm:string,khbh:string,ccxh:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: '/zgfyFk/auditAllBatch',
        method: 'POST',
        data,
        params: {requestClassificationCode:name,bdhm,khbh,ccxh,isSubTable},
    })
}
export function submitAllBatch(name: string,data = {},bdhm:string,khbh:string,ccxh:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: '/zgfyFk/submitAllBatch',
        method: 'POST',
        data,
        params: {requestClassificationCode:name,bdhm,khbh,ccxh,isSubTable},
    })
}
export function auditNotPassAllBatch(name: string,data = {},bdhm:string,khbh:string,ccxh:string,isSubTable:boolean,msg:string): Promise<RS> {
    return service({
        url: '/zgfyFk/auditNotPassAllBatch',
        method: 'POST',
        data,
        params: {requestClassificationCode:name,bdhm,khbh,ccxh,isSubTable,msg},
    })
}

export function delAllBatch(name: string,data = {},bdhm:string,khbh:string,ccxh:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: '/zgfyFk/delAllBatch',
        method: 'POST',
        data,
        params: {requestClassificationCode:name,bdhm,khbh,ccxh,isSubTable},
    })
}
export function auditDelAllBatch(name: string,data = {},bdhm:string,khbh:string,ccxh:string,isSubTable:boolean): Promise<RS> {
    return service({
        url: '/zgfyFk/auditDelAllBatch',
        method: 'POST',
        data,
        params: {requestClassificationCode:name,bdhm,khbh,ccxh,isSubTable},
    })
}
export function auditDelNotPassAllBatch(name: string,data = {},bdhm:string,khbh:string,ccxh:string,isSubTable:boolean,msg:string): Promise<RS> {
    return service({
        url: '/zgfyFk/auditDelNotPassAllBatch',
        method: 'POST',
        data,
        params: {requestClassificationCode:name,bdhm,khbh,ccxh,isSubTable,msg},
    })
}
