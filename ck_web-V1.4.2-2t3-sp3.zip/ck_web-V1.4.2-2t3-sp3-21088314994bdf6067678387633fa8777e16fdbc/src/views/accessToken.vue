<template>
  <div v-loading.fullscreen.lock="loading" element-loading-text="跳转中..."></div>
</template>

<script lang="ts">
export default {
  name: 'AccessTokenView',
}
</script>
<script setup lang="ts">
import useUserStore from '@/store/user'
import {removeToken, removeRefreshToken, setToken, setSectok, getSectok} from '@/utils/token'
import {setModId, setSubSystem, setSubSystemName} from "@/utils/subSystem";
import {getJumpUrl} from "@/utils/utils";
import {isEmpty} from "@/views/system/sum";
// import { judgmentRedirect } from '@/apis/oauth'

const userStore = useUserStore()

const route = useRoute()
const router = useRouter()

const loading = ref(false)

const checkUrl = async (redirect: string | any) => {
  if (redirect) {
    // subSysHasRedirect 代表系统内存在 但是当前用户没有该权限
    // userHasRedirect 代表当前账号具备权限直接跳转
    // nothing  代表url错误直接404
    // const { data } = await judgmentRedirect({ redirect })
    /*if (data === 'userHasRedirect') {
      router.push({ path: (redirect as string) || '/' }).catch((r) => console.error(r))
    } else */{
      router.push({ path: '/' }).catch((r) => console.error(r))
    }
  } else {
    router.push({ path: '/' }).catch((r) => console.error(r))
  }
}

onMounted(async () => {
  loading.value = true
  try {
    const { sectok, redirect, sectok3 ,subSystem,modId } = route.query
    let copySectok=null;
    let copyIsSectok3=null;
    console.log("开始跳转...  跳转参数subSystem "+subSystem+" modId "+modId+" sectok3 "+sectok3+" sectok "+sectok+" redirect "+redirect)
    if (subSystem){

      //let arr=getJumpUrl(subSystem as string)
      const regex = /'([^']*)\|([^']*)'/;
      const matches = (subSystem as string).match(regex);

      setSubSystem(matches[1])
      setSubSystemName(matches[2])
      userStore.subSystem=matches[1];

      console.log("成功解析subSystem 解析到的子系统编码 "+matches[1]+" 子系统名称 "+matches[2])

      // if (arr!=null){
      //   setSubSystem(arr[0])
      //   setSubSystemName(arr[1])
      //   setModId(arr[2])
      //   userStore.subSystem=arr[0];
      //   copySectok=arr[3];
      //   copyIsSectok3=arr[4];
      // }
    }
    if(modId){
      setModId(modId)
    }

    /**
     * 每次在业务系统顶部下拉框切换系统都要调用access_token方法。
     * 星展分包发布添加 2025/02/19
     *
     * 问题描述：
     *    星展分包发布问题，从权限系统第一次跳转到子系统会调用access_token方法，并在后端缓存token认证的相关信息，
     *    当切换到其他子系统时，不再调用access_token方法，由于分包发布，要跳转的子系统对应后端程序并未缓存token认证相关信息，导致认证失败。
     */
    let sectokTemp = sectok;
    if (isEmpty(sectokTemp)) {
      sectokTemp = getSectok();
      console.log("跳转系统, cookie保存的sectok: ", sectokTemp)
    }
    await userStore.accessToken(sectokTemp)
    setSectok(sectokTemp)
    checkUrl(redirect)

    // if (copyIsSectok3||sectok3) {
    //   setToken(sectok3==undefined?copySectok:sectok3)
    //   checkUrl(redirect)
    // } else {
    //   await userStore.accessToken(sectok==undefined?copySectok:sectok)
    //   checkUrl(redirect)
    // }
  } finally {
    setTimeout(() => (loading.value = false), 500)
  }
})
</script>
