<template>
  <div class="app-container">
    <rk-search-form ref="searchFormRef" v-model="searchForm" @keyup.enter="search" :form-items="searchItems"
                    @search="search" :label-width="50"/>

    <rk-page-table :data="data" :columns="columns" :loading="loading" @refresh="search" hidden-table-tools>
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <UpAndDown :exp="exp"/>
        </div>
      </template>
    </rk-page-table>
  </div>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict

</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {RkPageTable, RkSearchForm, RkFormInstance, RS,} from 'riking-ui'
import {useDict} from 'riking-layout'
import {getSubSystem} from "@/utils/subSystem";
import moment from "moment";
import useChangeTab from '@/hooks/useChangeTab'
import {listBusinessLine} from "@/views/query/feedback/api";
import {expLoading} from "@/components/UpAndDown.vue";
import {expExcelReqSt, listSt} from "@/views/report/api";

interface ISearch {
  searchTime: [] | any,
  subSystem: string | undefined
}

const subSystem = getSubSystem();

const defaultDateRangeValue = [moment().add(-9, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')] // 默认日期范围

const defaultSystemValue = (getSubSystem() === 'ybjh') ? undefined : getSubSystem() // 默认选择系统

const searchForm = ref<ISearch>({
  searchTime: defaultDateRangeValue,
  subSystem: defaultSystemValue,
})

const searchFormRef = ref<RkFormInstance>()

const data = ref<any []>([]);
const loading = ref(false) // 加载状态

const { handleTabClick  } = useChangeTab()

useDict([], [], {
  ...dictData,
  branchCode: async () => {
    const res = await dictsStore.loadDict()
    return res.data.branchCode
  },
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data;
  },
}) // 往页面加载数据集

onMounted(() => {
  search();
})

const search = async () => {
  loading.value = true;
  try{
    const value = searchForm.value;

    const params: any = {};

    params.subSystem = value?.subSystem;
    if(params.subSystem == undefined) {
      params.subSystem = "ybjh";
    }

    const searchTime = value.searchTime;
    if (searchTime) {
      params.startDate = searchTime[0];
      params.endDate = searchTime[1];
    }

    let result = await listSt(params);
    data.value = result.data;
    console.log(result);
  } finally {
    loading.value = false;
  }
}

const exp = async () => {
  expLoading.value = true;
  try {
    let searchTime = searchForm.value.searchTime;
    let subSystem = searchForm.value?.subSystem;
    if(subSystem == undefined) {
      subSystem = "ybjh";
    }
    await expExcelReqSt(searchTime[0], searchTime[1], subSystem);
  } finally {
    expLoading.value = false;
  }
}

let columns = [
  {prop: 'subSystem', label: '系统', labelWidth: 150, sortable: true},
  {prop: 'reqNum', label: '请求单数量', labelWidth: 150, sortable: true},
  {prop: 'taskNum', label: '查询明细数量（任务数量）', labelWidth: 150, sortable: true},
  {prop: 'cxFeedbackSuccNum', label: '查询反馈成功数量', labelWidth: 150, sortable: true},
  {prop: 'cxFeedbackFailNum', label: '查询反馈失败数量', labelWidth: 150, sortable: true},
  {prop: 'kzFeedbackSuccNum', label: '控制反馈成功数量 ', labelWidth: 150, sortable: true},
  {prop: 'kzFeedbackFailNum', label: '控制反馈失败数量', labelWidth: 150, sortable: true},
  {prop: 'unFeedbackNum', label: '未反馈数量', labelWidth: 150, sortable: true},
  // {key: 'actions', label: '操作', labelWidth: 150, fixed: 'right''}
]

const searchItems=[
  {
    prop: 'searchTime',
    label: '数据日期',
    labelWidth: 80,
    inputType: {
      tag: 'date-picker',
      type: 'daterange',
      style:"width: 220px",
      rangeSeparator: '-',
      format: "YYYY-MM-DD",
      valueFormat: 'YYYY-MM-DD'
    },
    rules: [{required: true, message: '数据日期不能为空'}]
  },
  {
    prop: 'subSystem',
    label: '系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
      disabled: defaultSystemValue ? true : false
    }
  },
]

</script>

<style scoped>
.card {
  /*background-color: #409eff;*/
  background-color: white;
  border-radius: 0.5rem;
  color: black;
  padding: 10px 15px;
  box-shadow: 0 0 0.25rem 0 rgba(0, 0, 0, 0.2);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card:hover {
  background-color: white;
}

.no_zero {
  color: #5c51e3;
  font-weight: bold;
  font-size: 14px;
}

.card-title {
  text-align: left;
  font-size: 14px;
  color: #333333;
  margin-top: 0;
  margin-bottom: 0;
}

.card-content {
  text-align: left;
  font-weight: bold;
  font-size: 24px;
  color: #5c51e3;
  margin-top: 8px;
  margin-bottom: 0;
}

.card-image {
  width: 42px; /* 设置图片宽度为 42 像素 */
  height: 42px; /* 设置图片高度为 42 像素 */
}

.card-image2 {
  width: 14px; /* 设置图片宽度为 42 像素 */
  height: 14px; /* 设置图片高度为 42 像素 */
}

.divider-title {
  flex-grow: 0;
  flex-shrink: 0;
  flex-basis: auto;
  font-weight: bold;
  font-size: 14px;
  color: #5c51e3;
  font-weight: bold;
}

.divider {
  flex: 1;
  margin-left: 0.5rem;
}

</style>
