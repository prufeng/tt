<template>
  <div class="rk-login-body">
    <div class="login-header">
      <div class="wrapper">
        <img src="@/assets/images/logo01.png" class="h_logo" />
      </div>
    </div>
    <div class="login-mian-content">
      <div class="wrapper">
        <div class="login_cont">
          <div class="login_form_box">
            <h2>欢迎登录</h2>
            <el-form ref="loginFormRef" :model="loginForm" :rules="loginRules" @keyup.enter="submitForm(loginFormRef)">
              <el-form-item prop="username">
                <span class="svg-cont">
                  <i class="iconfont icon_personal"></i>
                </span>

                <el-input v-model="loginForm.username" placeholder="用户名" autocomplete="on" :validate-event="false" />
              </el-form-item>
              <el-form-item prop="password">
                <span class="svg-cont">
                  <i class="iconfont icon_unlock"></i>
                </span>
                <el-input
                  ref="passwordRef"
                  v-model="loginForm.password"
                  :type="passwordType"
                  placeholder="密码"
                  autocomplete="on"
                  :validate-event="false"
                />
                <span class="show-pwd" @click="showPwd">
                  <i :class="['iconfont', passwordType === 'password' ? 'icon_eye' : 'icon_eye-open']" />
                </span>
              </el-form-item>
              <el-form-item v-show="tenantOptions.length > 1" prop="tenant">
                <span class="svg-cont">
                  <i class="iconfont icon_tenant"></i>
                </span>
                <el-Select v-model="loginForm.tenant" placeholder="" :validate-event="false">
                  <el-option v-for="item in tenantOptions" :key="item.value" :label="item.label" :value="item.value" />
                </el-Select>
              </el-form-item>
              <el-form-item>
                <el-button
                  type="primary"
                  class="submitBtn"
                  style="width: 100%"
                  :loading="loading"
                  @click="submitForm(loginFormRef)"
                >
                  登录
                </el-button>
              </el-form-item>
            </el-form>

            <div class="rk-info-bt"><p>无法登录请联系管理员</p></div>
          </div>
        </div>
      </div>
    </div>
    <div class="login-footer">版权所有 © 悦锦软件系统（上海）有限公司</div>
    <div class="circle-bg">
      <div class="circle circle1"></div>
      <div class="circle circle2"></div>
      <div class="circle circle3"></div>
      <div class="circle circle4"></div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { FormInstance } from 'element-plus'
import { findAllTenantList } from '@/apis/oauth'
import useUserStore from '@/store/user'
import useDictsStore from '@/store/dictStore';
import {useDict} from "riking-layout";

const dictsStore = useDictsStore();
const userStore = useUserStore()
const tenantOptions = ref<any[]>([])
const loading = ref<boolean>(false)
onMounted(async () => {
  loadTenantData()
})

const loginFormRef = ref<FormInstance>()
const passwordRef = ref()
const passwordType = ref('password')

const loginForm = reactive({
  username: '',
  password: '',
  tenant: '',
})

// 加载租户
const loadTenantData = async () => {
  let res = await findAllTenantList()
  tenantOptions.value = res.data
  loginForm.tenant = res.data[0].value
}

const loginRules = reactive({
  username: [{ required: true, message: '用户名不能为空' }],
  password: [{ required: true, message: '密码不能为空' }],
  tenant: [{ required: true, message: '租户不能为空' }],
})

function showPwd() {
  if (passwordType.value === 'password') {
    passwordType.value = ''
  } else {
    passwordType.value = 'password'
  }
  nextTick(() => {
    passwordRef.value.blur()
  })
}
const submitForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.validate(async (valid) => {
    if (valid) {
      loading.value = true
      try {
        await userStore.login(loginForm)
        await userStore.loadUserSystems();
        await dictsStore.loadDict();
        router.push({ path: (route.query?.redirect as string) || '/' }).catch((r) => console.error(r))
        ElMessage.success('登录成功！')
      } finally {
        setTimeout(() => {
          loading.value = false
        }, 500)
      }
    } else {
      if (!loginForm.tenant) {
        ElMessage.warning('租户不能为空')
      }
      return false
    }
  })
}

const router = useRouter()
const route = useRoute()
</script>




<style lang="scss">
/* reset element-ui css */
.rk-login-body {
  .el-input__wrapper {
    width: 100%;
  }
  .el-input {
    display: block;
    height: 40px;
    width: 100%;

    input {
      background-color: transparent;
      border-radius: 3px;
      padding: 12px 5px 12px 30px;
      height: 40px;
      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px rgb(255, 255, 255) inset !important;
        -webkit-text-fill-color: #333 !important;
      }
    }
  }
  .el-select {
    display: block;
    height: 40px;
    width: 100%;
  }

  .el-form-item {
    border-radius: 5px;
    color: #454545;
  }
}
</style>
<style lang="scss" scoped>
.rk-login-body {
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  min-width: 1000px;
  background: url(@/assets/images/loginBg.png) no-repeat;
  background-size: cover;
  overflow: hidden;
  .login-header {
    width: 100%;
    height: 100px;
    .h_logo {
      margin-left: 10px;
      margin-top: 30px;
    }
    .line {
      display: inline-block;
      vertical-align: bottom;
      margin-left: 8px;
      margin-bottom: 3px;
      color: #666;
    }
    .title {
      display: inline-block;
      font-size: 16px;
      color: #333333;
      font-weight: 700;
      vertical-align: bottom;
      margin-left: 8px;
      margin-bottom: 2px;
    }
  }
  .login-mian-content {
    position: absolute;
    left: 0;
    top: 80px;
    bottom: 60px;
    height: auto;
    width: 100%;
    background-size: cover;
    overflow: hidden;
  }
  .wrapper {
    position: relative;
    max-width: 1200px;
    min-width: 1000px;
    height: 100%;
    margin: 0 auto;
  }
  .login_cont {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 1000px;
    height: 500px;
    margin-top: -250px;
    margin-left: -500px;
    box-shadow: 1px 1px 50px #00000014;
    background: url(@/assets/images/lbox_bg.png) no-repeat;
    .login_form_box {
      position: relative;
      float: right;
      width: 500px;
      height: 100%;
      padding: 70px;
      margin: 0 auto;
    }
    h2 {
      position: relative;
      margin: 10px 0 30px 0;
      font-size: 28px;
      color: var(--el-color-primary);
      font-weight: 700;
      line-height: 24px;
      text-align: left;
    }
    .login-form {
      width: 100%;
    }
    .rk-info-bt {
      margin: 20px 0 0;
      p {
        font-size: 12px;
        color: #333;
        letter-spacing: 1px;
        text-align: center;
      }
    }
  }
  .svg-cont {
    position: absolute;
    left: 10px;
    top: 50%;
    margin-top: -8px;
    line-height: 18px;
    color: #000;
    z-index: 999;
  }
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 0;
    line-height: 40px;
    font-size: 16px;
    color: #666;
    cursor: pointer;
    user-select: none;
  }
  .submitBtn {
    position: relative;
    height: 45px;
    width: 360px;
    color: #fff;
    background-image: #5c51e3;;
    border-radius: 5px;
    font-size: 16px;
    background-size: 300%;
    border: none;
    cursor: pointer;
    z-index: 1;
    &:hover {
      animation: sun 15s infinite;
      z-index: 1;
    }
  }

  @keyframes sun {
    100% {
      background-position: -400% 0;
    }
  }
}
.login-footer {
  position: fixed;
  width: 100%;
  height: 60px;
  line-height: 60px;
  bottom: 0;
  font-size: 14px;
  color: #fff;
  text-align: center;
}
.verifyword {
  width: 250px;
}
/*--背景愿动画---*/
.circle-bg .circle {
  position: absolute;
  -webkit-animation: movingCircle 10s ease-in-out infinite alternate;
  -moz-animation: movingCircle 10s ease-in-out infinite alternate;
  animation: movingCircle 10s ease-in-out infinite alternate;
  pointer-events: none;
  display: none\9;
}
.circle-bg .circle.circle1 {
  left: 50px;
  top: 50px;
  width: 250px;
  height: 250px;
  background: url(@/assets/images/circle1.png) no-repeat;
}
.circle-bg .circle.circle2 {
  right: 100px;
  top: 50px;
  width: 231px;
  height: 231px;
  background: url(@/assets/images/circle2.png) no-repeat;
  -webkit-animation: movingCircle 25s ease-in-out infinite alternate;
  -moz-animation: movingCircle 25s ease-in-out infinite alternate;
  animation: movingCircle 25s ease-in-out infinite alternate;
}
.circle-bg .circle.circle3 {
  right: 150px;
  bottom: 50px;
  width: 129px;
  height: 129px;
  background: url(@/assets/images/circle3.png) no-repeat;
  -webkit-animation: movingCircle 20s ease-in-out infinite alternate;
  -moz-animation: movingCircle 20s ease-in-out infinite alternate;
  animation: movingCircle 20s ease-in-out infinite alternate;
}
.circle-bg .circle.circle4 {
  left: 100px;
  bottom: 100px;
  width: 180px;
  height: 182px;
  background: url(@/assets/images/circle4.png) no-repeat;
  -webkit-animation: movingCircle 15s ease-in-out infinite alternate;
  -moz-animation: movingCircle 15s ease-in-out infinite alternate;
  animation: movingCircle 15s ease-in-out infinite alternate;
}
@-webkit-keyframes movingCircle {
  0% {
    -webkit-transform: rotate(0) translate(0, 0);
    transform: rotate(0) translate(0, 0);
  }

  50% {
    -webkit-transform: rotate(180deg) translate(160px, 90px);
    transform: rotate(180deg) translate(160px, 90px);
  }

  100% {
    -webkit-transform: rotate(360deg) translate(-20px, -40px);
    transform: rotate(360deg) translate(-20px, -40px);
  }
}

@-moz-keyframes movingCircle {
  0% {
    -moz-transform: rotate(0) translate(0, 0);
    transform: rotate(0) translate(0, 0);
  }

  50% {
    -moz-transform: rotate(180deg) translate(160px, 90px);
    transform: rotate(180deg) translate(160px, 90px);
  }

  100% {
    -moz-transform: rotate(360deg) translate(-20px, -40px);
    transform: rotate(360deg) translate(-20px, -40px);
  }
}

@keyframes movingCircle {
  0% {
    -webkit-transform: rotate(0) translate(0, 0);
    -moz-transform: rotate(0) translate(0, 0);
    transform: rotate(0) translate(0, 0);
  }

  50% {
    -webkit-transform: rotate(180deg) translate(160px, 90px);
    -moz-transform: rotate(180deg) translate(160px, 90px);
    transform: rotate(180deg) translate(160px, 90px);
  }

  100% {
    -webkit-transform: rotate(360deg) translate(-20px, -40px);
    -moz-transform: rotate(360deg) translate(-20px, -40px);
    transform: rotate(360deg) translate(-20px, -40px);
  }
}
</style>
