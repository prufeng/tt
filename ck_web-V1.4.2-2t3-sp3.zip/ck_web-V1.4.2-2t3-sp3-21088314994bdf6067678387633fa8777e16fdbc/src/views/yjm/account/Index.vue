<template>
  <rk-index-layout>
    <rk-search-form v-model="form" :form-items="searchFormItems" :label-width="50" @search="search"></rk-search-form>

    <rk-page-table ref="tableRef" :data="data" @refresh="search" @page-change="pageChange"
                   @selection-change="selectionChange" :columns="columns" :loading="loading" :pagination="paging">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="setButtons()" :route-meta="$route.meta"></rk-button-group>
          <div style="margin: 0 4px;"></div>
          <UpAndDown :exp="exp"/>
        </div>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="setRowButtons(row)" :route-meta="$route.meta" link/>
      </template>
    </rk-page-table>
  </rk-index-layout>

  <Edit ref="detailRef" :form-items="formItems" :route-name="routeName" @onClosed="search"></Edit>
</template>

<script setup lang="ts">
import Edit from '@/views/yjm/components/Edit.vue';
import {ref} from "vue";
import {ButtonInfo, Pagination} from "riking-ui";
import {getRouteName, pagination} from "@/utils/utils";
import {getConfigs, showMessage, buttons} from './config/config';
import {list, updateByIds, getMockData} from './api';
import dictData from '../../../hooks/useDicts'
import {useDict} from "riking-layout";
import {exportExcel} from "@/views/query/account/api";
import {expLoading} from "@/components/UpAndDown.vue";
import {submitAllBatch} from "@/views/query/feedback/api";


const data = ref();
const form = ref({})
const tableRef = ref()
const detailRef = ref();
const paging = ref<Pagination>(pagination)
const loading = ref(false)

const route = useRoute();
const routeName = getRouteName(route);
const {columns, formItems, searchFormItems} = getConfigs(routeName);

useDict([], [], {
  ...dictData
})

onMounted(() => search())

watch(paging, () => search())

/**
 * 查询
 */
const search = async () => {
  loading.value = true;
  try {
    const newObject = {...form.value};
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null;
        console.log("转化了空串")
      }
    }
    const result = await list(routeName, newObject, paging.value);
    const {records, current, total} = result.data;
    data.value = records;
    paging.value.currentPage = current;
    paging.value.total = total;
  } finally {
    loading.value = false;
  }
}

/**
 * 查看
 */
const view = async (row) => {
  detailRef.value.open(row, true, '查看')
}

/**
 * 批量更新
 */
const batchUpdate = async () => {
  if (ids == undefined || ids.length == 0) {
    ElMessage.warning({message:"请勾选要处理的数据！", grouping: true})
  }else {
    const result = await updateByIds(routeName, ids);
    console.log(result);
    showMessage(result)
    await search();
  }
}

const mockData = async () => {
  await getMockData(routeName);
  await search();
}

// 选择事件
let ids = [];
const selectionChange = (newSelection: any[]) => {
  ids = newSelection.map(item => item.id)
}

// 分页事件
const pageChange = (p: Pagination) => {
  paging.value = p
}

/**
 * 设置行按钮
 */
const setRowButtons = (row) => {
  const buttons: ButtonInfo[] = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => view(row)
    },
  ]
  return buttons;
}

/**
 * 设置表头按钮
 */
const setButtons = () => {
  // 按钮和方法的映射关系， 按钮的key属性作为mapping的键，值为需要绑定的方法
  const buttonMethodMapping = {
    /*'batchUpdate': batchUpdate,
    'mock': mockData,*/
  }
  // 为表头按钮绑定对应的方法
  buttons.forEach(item => {
    item.handler = () => buttonMethodMapping[item.key]();
  })
  return buttons;
}


const exp = async () => {
  expLoading.value = true;
  try {
    let copyIds='';
    if (!(ids == undefined || ids.length == 0)) {
      copyIds = ids.toString()
    }
    console.log('导出',copyIds)
    const newObject = {...form.value};
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null;
        console.log("转化了空串")
      }
    }
    // var branchCodeList = Array.from(form.value.branchCodeList).join('-|-');
    await exportExcel(routeName, copyIds, newObject);
  } finally {
    expLoading.value = false;
  }
}


// const _setRowButtons = (row) => {
//   const _row = row
//   return () => {
//     rowButtons.forEach(item => {
//       if (item.key === 'view') {
//         item.handler = () => view(_row)
//       }
//     })
//     return rowButtons;
//   }
// }
//
//
// const setRowButtons =(row)=> {
//   rowButtons.forEach((item, index) => {
//     (function(){
//       const j = index
//       setTimeout(function() {
//         if (item.key === 'view') {
//           item.handler = () =>view(row)
//         }
//       }, j*1000)
//     })()
//   })
//   return rowButtons;
// }


</script>

<style scoped>

</style>

