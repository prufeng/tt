import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: "id", type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'yjm_cx_status', width: 130, sortable: true},
    {prop: 'pushid', label: '对应推送信息id', width: 140, sortable: true},
    {prop: 'victimName', label: '潜在受害人姓名', width: 140, sortable: true},
    {prop: 'victimIdcard', label: '证件号码', width: 140, sortable: true},
    {prop: 'level', label: '原预警等级', width: 190, sortable: true},
    {prop: 'measures', label: '需要解除管控措施', width: 190, sortable: true},
    {prop: 'policeName', label: '办案民警姓名', width: 190, sortable: true},
    {prop: 'policeMobile', label: '联系电话', width: 190, sortable: true},
    {prop: 'createTime', label: '信息创建时间', width: 190, sortable: true},
    {prop: 'remark', label: '备注', width: 190, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 230,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'yjm_cx_status',}
    },
    {prop: 'victimIdcard', label: '证件号码', labelWidth: 80, inputType: 'input'},
    {prop: 'policeName', label: '办案民警姓名', labelWidth: 80, inputType: 'input'},

    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
]

export const formItems: FormItemInfo[] = [
    {prop: 'pushid', label: '对应推送信息id', labelWidth: 140, inputType:'input'},
    {prop: 'victimName', label: '潜在受害人姓名', labelWidth: 140, inputType:'input'},
    {prop: 'victimIdcard', label: '证件号码', labelWidth: 140, inputType:'input'},
    {prop: 'level', label: '原预警等级', labelWidth: 140, inputType:'input'},
    {prop: 'measures', label: '需要解除管控措施', labelWidth: 140, inputType:'input'},
    {prop: 'policeName', label: '办案民警姓名', labelWidth: 140, inputType:'input'},
    {prop: 'policeMobile', label: '联系电话', labelWidth: 140, inputType:'input'},
    {prop: 'createTime', label: '信息创建时间', labelWidth: 140, inputType:'input'},
    {prop: 'remark', label: '备注', labelWidth: 140, inputType:'input'},
    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
    {
        prop: 'status',
        label: '状态',
        labelWidth: 140,
        inputType: {tag: 'select', options: 'yjm_cx_status',}
    },
]

export default {
    columns,
    searchFormItems,
    formItems
}
