<template>
  <el-card>
    <el-form
        ref="configFormRef"
        :model="configForm"
        :label-position="labelPosition"
        label-width="auto"
    >
      <el-row gutter="15">
        <el-col :span="12">
          <el-form-item label="账号" prop="accountConsumer"
                        :rules="[{max:255 , message: '账号长度不可超过255'}, {required: false, message: '账号不能为空'}]">
            <el-input v-model="configForm.accountConsumer"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="密码" prop="passwordConsumer"
                        :rules="[{max:255 , message: '密码长度不可超过255'}, {required: false, message: '密码不能为空'}]">
            <el-input v-model="configForm.passwordConsumer"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="拉取任务消费组" prop="groupId"
                        :rules="[{max:32 , message: '拉取任务消费组长度不可超过32'}, {required: false, message: '拉取任务消费组不能为空'}]">
            <el-input v-model="configForm.groupId"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="人行推送消息队列" prop="pushMessageGroup"
                        :rules="[{max:255 , message: '人行推送消息队列长度不可超过255'}, {required: false, message: '人行推送消息队列不能为空'}]">
            <el-input v-model="configForm.pushMessageGroup"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="机构反馈信息队列" prop="feedbackMessageGroup"
                        :rules="[{max:255 , message: '机构反馈信息队列长度不可超过255'}, {required: false, message: '机构反馈信息队列不能为空'}]">
            <el-input v-model="configForm.feedbackMessageGroup"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="金融机构端签发公钥" prop="bankPublicKey"
                        :rules="[{max:255 , message: '金融机构端签发公钥长度不可超过255'}, {required: false, message: '金融机构端签发公钥不能为空'}]">
            <el-input v-model="configForm.bankPublicKey" type="textarea"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="金融机构端签发私钥" prop="bankPrivateKey"
                        :rules="[{max:255 , message: '金融机构端签发私钥长度不可超过255'}, {required: false, message: '金融机构端签发私钥不能为空'}]">
            <el-input v-model="configForm.bankPrivateKey" type="textarea"/>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="人行端签发公钥" prop="publicKey"
                        :rules="[{max:255 , message: '人行端签发公钥长度不可超过255'}, {required: false, message: '人行端签发公钥不能为空'}]">
            <el-input v-model="configForm.publicKey" type="textarea"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="onSaveButton">
      <el-button type="warning" @click="search">重置</el-button>
      <el-button type="primary" @click="save(configFormRef)">保存</el-button>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import {ref} from "vue";
import {getRouteName} from "@/utils/utils";
import {list, updateById} from './api';
import dictData from '../../../hooks/useDicts'
import {useDict} from "riking-layout";
import {ElButton, ElMessage, FormInstance} from "element-plus";
import type {FormProps} from 'element-plus'

const route = useRoute();
const routeName = getRouteName(route);
const labelPosition = ref<FormProps['labelPosition']>('right')
const configFormRef = ref()
let configForm = reactive({
  accountConsumer: '',
  passwordConsumer: '',
  groupId: '',
  pushMessageGroup: '',
  feedbackMessageGroup: '',
  bankPublicKey: '',
  bankPrivateKey: '',
  publicKey: '',
})

useDict([], [], {
  ...dictData
})

onMounted(() => search())

/**
 * 查询
 */
const search = async () => {
  const result = await list(routeName);
  Object.assign(configForm, result.data);
}

const save = async (formEl: FormInstance | undefined) => {
  if (!formEl) return
  await formEl.validate((valid) => {
    if (valid) {
      try {
        updateById(routeName, configForm);
      } finally {
        ElMessage.success('修改成功')
      }
    } else {
      console.log('error submit!')
      return false
    }
  })
}

</script>

<style scoped>
.onSaveButton {
  display: flex;
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中（若需要）*/
}

</style>

