import {FormItemInfo, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    {key: "id", type: 'selection'},
    {prop: 'status', label: '状态', dictFormatKey: 'yjm_fk_status', width: 130, sortable: true},
    {prop: 'pushid', label: '对应推送信息id', width: 140, sortable: true},
    {prop: 'handleTime', label: '处理完成时间', width: 140, sortable: true},
    {prop: 'isControl', label: '是否已经解除对应保护措施', width: 190, sortable: true},
    {prop: 'actualAccountNum', label: '实际处理账户数', width: 400, sortable: true},
    {prop: 'feedbackInfo', label: '反馈详情', width: 190, sortable: true},
    {prop: 'remark', label: '备注', width: 80, sortable: true},
    {prop: 'dataTime', label: '数据日期', width: 190, sortable: true},
    {prop: 'submitBy', label: '提交人', width: 190, sortable: true},
    {prop: 'submitTime', label: '提交时间', width: 190, sortable: true},
    {prop: 'approveBy', label: '审核人', width: 190, sortable: true},
    {prop: 'approveTime', label: '审核时间', width: 190, sortable: true},
    {prop: 'resetBy', label: '重置人', width: 190, sortable: true},
    {prop: 'resetTime', label: '重置时间', width: 190, sortable: true},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        minWidth: 230,
        fixed: 'right',
    },
]

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '状态',
        labelWidth: 80,
        inputType: {tag: 'select', options: 'jyt_status',}
    },
    {prop: 'pushid', label: '对应推送信息id', labelWidth: 80, inputType: 'input'},
    {prop: 'handleTime', label: '处理完成时间', labelWidth: 80, inputType: 'input'},
    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
]

export const formItems: FormItemInfo[] = [
    {prop: 'pushid', label: '对应推送信息id', labelWidth: 140, inputType:'input'},
    {prop: 'handleTime', label: '处理完成时间', labelWidth: 140, inputType:'input'},
    {prop: 'isControl', label: '是否已经解除对应保护措施', labelWidth: 140, inputType:'input'},
    {prop: 'actualAccountNum', label: '实际处理账户数', labelWidth: 140, inputType:'input'},
    {prop: 'feedbackInfo', label: '反馈详情', labelWidth: 140, inputType:'input'},
    {prop: 'remark', label: '备注', labelWidth: 140, inputType:'input'},
    /*{
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },*/
    {
        prop: 'status',
        label: '状态',
        labelWidth: 140,
        inputType: {tag: 'select', options: 'yjm_fk_status',}
    },
]

export default {
    columns,
    searchFormItems,
    formItems
}
