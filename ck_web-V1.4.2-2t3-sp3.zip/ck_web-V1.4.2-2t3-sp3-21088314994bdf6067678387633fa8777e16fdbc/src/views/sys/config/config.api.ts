import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";

enum Api {
  save = '/Configuration/save',
  edit = '/Configuration/edit',
  list = '/Configuration/list',
  delete = '/Configuration/delete',
  getById = '/Configuration/getById',
  test = '/sftp/connectionTest',
  refresh = '/Configuration/refresh'
}

/**
 * 保存或者更新任务
 * @param params
 */
export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
  console.log(data);
  let url = isUpdate ? Api.edit : Api.save;
  return service({
    url: url,
    method: 'POST',
    data,
  })
};

/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize,...getCommonParams()}
})
};

/**
 * 查询详情
 * @param params
 */
export const getOne = (id: string): Promise<RS> => {
  return service({
    url: Api.getById,
    method: 'GET',
    params: {id}
})
};

//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: {...getCommonParams()}
  })
}

export const deleteOne = (id: string) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    params: {id}
})
}
  /**
   * 连接测试
   * @param params
   */
  export const shareTest = (subSystem: string): Promise<RS> => {
    return service({
      url: Api.test,
      method: 'POST',
      params: {subSystem}
    })
};


export const refresh = (): Promise<RS> => {
  return service({
    url: Api.refresh,
    method: 'GET',
  })
};