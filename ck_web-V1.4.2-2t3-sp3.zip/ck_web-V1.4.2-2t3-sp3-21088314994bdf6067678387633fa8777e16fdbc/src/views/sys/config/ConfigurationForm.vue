<!-- <template>
  <el-card class="custom-card" shadow="never">
    <rk-detail-form v-model="config" :form-items="formItems">
      <template #passwordSlot>
        <el-input v-model="config.password" type="password" show-password />
      </template>
      <template #portSlot>
        <el-form-item label="端口" v-show="config.connectionType == '2'" style="margin-left: -70px;">
          <el-input ref="editor" v-model="config.port" style="width:200px;" />
        </el-form-item>
      </template>
    </rk-detail-form>

    <span class="dialog-footer" style="margin-left: -2%">
      <el-button type="primary" @click="ceshi">
        <i class="iconfont icon_binding"></i> 前置机连通性测试</el-button>
      <el-button type="primary" @click="save">
        <i class="iconfont icon_update"></i> 保存</el-button>
      <el-button @click="reset">
        <i class="iconfont icon_reset"></i>重置</el-button>
    </span>
  </el-card>
</template> -->

<template>
  <el-card class="custom-card" shadow="never">
    <el-form ref="configForm" :model="config" label-width="70px">

      <el-row>
        <el-col :span="12">
          <el-form-item label="结构化下载目录" :label-width="100" prop="jdownloadDirectory">
            <el-input v-model="config.jdownloadDirectory" />
          </el-form-item>
        </el-col>

        <el-col :span="12" v-show="config.systemCode == 'szmz'">
          <el-form-item label="非结构化下载目录" :label-width="100" prop="fdownloadDirectory">
            <el-input v-model="config.fdownloadDirectory" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="结构化上传目录" :label-width="100" prop="juploadDirectory">
            <el-input v-model="config.juploadDirectory" />
          </el-form-item>
        </el-col>

        <el-col :span="12" v-show="config.systemCode == 'szmz'">
          <el-form-item label="非结构化上传目录" :label-width="100" prop="fuploadDirectory">
            <el-input v-model="config.fuploadDirectory" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="连接方式" :label-width="100" prop="connectionType">
            <el-select v-model="config.connectionType" placeholder="请选择连接方式">
              <el-option v-for="dict in dictData.connectionType" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="地址" :label-width="100" prop="address">
            <el-input v-model="config.address" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="用户名" :label-width="100" prop="userName">
            <el-input v-model="config.userName" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="密码:" :label-width="100" prop="password">
            <!-- <el-input v-model="config.password" type="password" show-password /> -->
            <el-input v-model="config.password"/>
          </el-form-item>
        </el-col>

        <el-col :span="12" v-show="config.connectionType == '2'">
          <el-form-item label="端口号" :label-width="100" prop="port">
            <el-input v-model="config.port" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="所属系统" :label-width="100" prop="systemCode">
            <el-select v-model="config.systemCode" :disabled="true">
              <el-option v-for="dict in dictData.systemCode" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item :label="config.systemCode == 'szmz'?'平台公钥地址':'平台签名证书'" :label-width="100" prop="publicKey1">
            <el-input v-model="config.publicKey1" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item :label="config.systemCode == 'szmz'?'平台私钥地址':'平台加密证书'" :label-width="100" prop="priveteKey1">
            <el-input v-model="config.priveteKey1" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item :label="config.systemCode == 'szmz'?'银行公钥地址':'银行签名证书'" :label-width="100" prop="publicKey2">
            <el-input v-model="config.publicKey2" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item :label="config.systemCode == 'szmz'?'银行私钥地址':'银行加密证书'" :label-width="100" prop="privateKey2">
            <el-input v-model="config.privateKey2" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="数据位置" :label-width="100" prop="attributeLocation">
            <el-select v-model="config.attributeLocation" placeholder="请选择数据位置">
              <el-option v-for="dict in dictData.attributeLocation" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="元素节点" :label-width="100" prop="elementNode">
            <el-input v-model="config.elementNode" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="sm4文件解密密钥" :label-width="100" prop="secretKey">
            <el-input v-model="config.secretKey" />
          </el-form-item>
        </el-col>


        <el-col :span="12">
          <el-form-item label="是否允许自动审批" :label-width="100" prop="isAutoAudit">
            <!-- <el-input v-model="config.isAutoAudit" /> -->
            <el-select v-model="config.isAutoAudit">
              <el-option v-for="dict in dictData.isAuto" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12"  v-show="config.systemCode == 'szmz'">
          <el-form-item label="是否自动下载承诺和授权书pdf文件" :label-width="200" prop="isAutoDownloadPdfFile">
            <!-- <el-input v-model="config.isAutoAudit" /> -->
            <el-select v-model="config.isAutoDownloadPdfFile">
              <el-option v-for="dict in dictData.isAuto" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <!-- <el-col :span="12">
          <el-form-item label="是否自动发送邮件" :label-width="100" prop="isAutoSendEmail">
            <el-select v-model="config.isAutoSendEmail">
              <el-option v-for="dict in dictData.isAuto" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="是否自动发送短信" :label-width="100" prop="isAutoSendSms">
            <el-select v-model="config.isAutoSendSms">
              <el-option v-for="dict in dictData.isAuto" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col> -->

        <el-col :span="12">
          <el-form-item label="文书模板目录" :label-width="100" prop="writerTemplateDir">
            <el-input v-model="config.writerTemplateDir" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="上传/下载本地保存目录" :label-width="150" prop="localMainDirectory">
            <el-input v-model="config.localMainDirectory" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="WebService地址" :label-width="150" prop="socketUrl">
            <el-input v-model="config.socketUrl" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'zgfy'">
          <el-form-item label="SocketUrl地址" :label-width="150" prop="webServiceUrl">
            <el-input v-model="config.webServiceUrl" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="银行机构代码" :label-width="150" prop="bankOrgCode">
            <el-input v-model="config.bankOrgCode" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="增量灰名单目录" :label-width="150" prop="incGreyList">
            <el-input v-model="config.incGreyList" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="增量黑名单目录" :label-width="150" prop="incBlackList">
            <el-input v-model="config.incBlackList" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="全量灰名单目录" :label-width="150" prop="allGreyList">
            <el-input v-model="config.allGreyList" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="全量黑名单目录" :label-width="150" prop="allBlackList">
            <el-input v-model="config.allBlackList" />
          </el-form-item>
        </el-col>
      </el-row>


      <span class="dialog-footer" style="margin-left: -2%">
        <el-button type="primary" @click="ceshi">
          <i class="iconfont icon_binding"></i> 前置机连通性测试</el-button>
        <el-button type="primary" @click="save">
          <i class="iconfont icon_update"></i> 保存</el-button>
        <el-button @click="reset">
          <i class="iconfont icon_reset"></i>重置</el-button>
      </span>
    </el-form>
  </el-card>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
</script>
<script setup lang="ts">
import { ref } from 'vue';
import { saveOrUpdateQuartz, getQuartzList, shareTest } from '@/views/sys/config/config.api.js'
import { RkDetailForm } from 'riking-ui'

useDict([], [], dictData)

const config = ref({
  address: '',
  attributeLocation: '',
  elementNode: '',
  fdownloadDirectory: '',
  fuploadDirectory: '',
  id: '',
  isEnable: '',
  jdownloadDirectory: '',
  juploadDirectory: '',
  password: '',
  port: '',
  privateKey2: '',
  priveteKey1: '',
  publicKey1: '',
  publicKey2: '',
  secretKey: '',
  systemCode: '',
  userName: '',
  isAutoDownloadPdfFile: '',
  localMainDirectory: '',
  connectionType: '',
  isAutoAudit: '',
  isAutoCreateUploadReport: '',
  isAutoSendEmail: '',
  isAutoSendSms: '',
  writerTemplateDir: '',
  socketUrl: '',
  webServiceUrl: '',
  bankOrgCode: '',
  incGreyList: '',
  incBlackList: '',
  allGreyList: '',
  allBlackList: '',
});

// 初始化获取数据
onMounted(async () => {
  const response = await getQuartzList(config.value);
  const result = response.result;
  if (result != null) {
    handleResult(result);
  }
});

// 重置时获取数据
const reset = async () => {
  const response = await getQuartzList(config.value);
  const result = response.result;
  console.log('重置时获取数据', result)

  handleResult(result);
  if (result != null) {
    ElMessage.success({ message: '重置完成!' });
  }
};

// 查询系统配置信息 更新config
const handleResult = (result: any) => {
  if (result != null) {
    config.value = {
      address: result.address,
      attributeLocation: result.attributeLocation,
      elementNode: result.elementNode,
      fdownloadDirectory: result.fdownloadDirectory,
      fuploadDirectory: result.fuploadDirectory,
      id: result.id,
      isEnable: result.isEnable,
      jdownloadDirectory: result.jdownloadDirectory,
      juploadDirectory: result.juploadDirectory,
      password: result.password,
      port: result.port,
      privateKey2: result.privateKey2,
      priveteKey1: result.priveteKey1,
      publicKey1: result.publicKey1,
      publicKey2: result.publicKey2,
      secretKey: result.secretKey,
      systemCode: result.systemCode,
      userName: result.userName,
      isAutoDownloadPdfFile: result.isAutoDownloadPdfFile,
      localMainDirectory: result.localMainDirectory,
      connectionType: result.connectionType,
      isAutoAudit: result.isAutoAudit,
      isAutoCreateUploadReport: result.isAutoCreateUploadReport,
      isAutoSendEmail: result.isAutoSendEmail,
      isAutoSendSms: result.isAutoSendSms,
      writerTemplateDir: result.writerTemplateDir,
      socketUrl: result.socketUrl,
  webServiceUrl: result.webServiceUrl,
  bankOrgCode: result.bankOrgCode,
  incGreyList: result.incGreyList,
  incBlackList: result.incBlackList,
  allGreyList: result.allGreyList,
  allBlackList: result.allBlackList,
    };
  } else {
    ElMessage.warning({ message: '未查到数据!' })
  }
};

// 测试sftp连接
const ceshi = () => {
  shareTest().then(res => {
    console.log(res)
    if (res.code == 200) {
      ElMessage.success({ message: res.msg })
    } 
  })
    .catch(err => {
      // 处理异常
    });
};

// 保存数据
const save = async () => {
  if (config.value.id) {
    const saveR = await saveOrUpdateQuartz(config.value, true);
    if (saveR) {
      ElMessage.success({ message: '修改成功!' })
    }
  } else {
    const UpdateR = await saveOrUpdateQuartz(config.value, false);
    if (UpdateR) {
      ElMessage.success({ message: '保存成功!' })
    }
  }
  const response = await getQuartzList(config.value);
  const result = response.result;
  handleResult(result);
}


</script>

<style scoped>
.custom-card {
  height: auto !important;
  overflow: scroll;
}
.dialog-footer {
  display: flex;
  justify-content: center;
}
</style>