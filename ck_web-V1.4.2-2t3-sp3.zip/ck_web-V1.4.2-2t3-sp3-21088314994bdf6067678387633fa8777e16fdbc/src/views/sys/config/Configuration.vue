<template>
<rk-index-layout>
  <rk-search-form ref="searchFormRef" @keyup.enter="search" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search" :label-width="50">
  </rk-search-form>

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page" @page-change="pageChange" @refresh="search"
                 stripe
                 @selection-change="handleSelectionChange"
                 @sort-change="handleSortChange">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
    </template>
    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
    </template>
  </rk-page-table>
</rk-index-layout>


  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" >
    <el-form ref="configForm" :model="config" label-width="70px">

      <el-row>
        <el-col :span="12">
          <el-form-item label="所属系统" :label-width="100" prop="systemCode" :rules="[{required: true,message: '必填',}]">
            <el-select v-model="config.systemCode" >
              <el-option v-for="dict in dictData.systemCode" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="结构化下载目录" :label-width="100" prop="jdownloadDirectory">
            <el-input v-model="config.jdownloadDirectory" />
          </el-form-item>
        </el-col>

        <el-col :span="12" v-show="config.systemCode == 'szmz'">
          <el-form-item label="非结构化下载目录" :label-width="100" prop="fdownloadDirectory">
            <el-input v-model="config.fdownloadDirectory" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="结构化上传目录" :label-width="100" prop="juploadDirectory">
            <el-input v-model="config.juploadDirectory" />
          </el-form-item>
        </el-col>

        <el-col :span="12" v-show="config.systemCode == 'szmz'">
          <el-form-item label="非结构化上传目录" :label-width="100" prop="fuploadDirectory">
            <el-input v-model="config.fuploadDirectory" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="连接方式" :label-width="100" prop="connectionType">
            <el-select v-model="config.connectionType" placeholder="请选择连接方式">
              <el-option v-for="dict in dictData.connectionType" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="地址" :label-width="100" prop="address">
            <el-input v-model="config.address" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="用户名" :label-width="100" prop="userName">
            <el-input v-model="config.userName" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="密码:" :label-width="100" prop="password">
            <!-- <el-input v-model="config.password" type="password" show-password /> -->
            <el-input v-model="config.password"/>
          </el-form-item>
        </el-col>

        <el-col :span="12" v-show="config.connectionType == '2'">
          <el-form-item label="端口号" :label-width="100" prop="port">
            <el-input v-model="config.port" />
          </el-form-item>
        </el-col>



        <el-col :span="12">
          <el-form-item :label="config.systemCode == 'szmz'?'平台公钥地址':'平台签名证书'" :label-width="100" prop="publicKey1">
            <el-input v-model="config.publicKey1" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item :label="config.systemCode == 'szmz'?'平台私钥地址':'平台加密证书'" :label-width="100" prop="priveteKey1">
            <el-input v-model="config.priveteKey1" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item :label="config.systemCode == 'szmz'?'银行公钥地址':'银行签名证书'" :label-width="100" prop="publicKey2">
            <el-input v-model="config.publicKey2" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item :label="config.systemCode == 'szmz'?'银行私钥地址':'银行加密证书'" :label-width="100" prop="privateKey2">
            <el-input v-model="config.privateKey2" />
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="数据位置" :label-width="100" prop="attributeLocation" :rules="[{required: true,message: '必填',}]">
            <el-select v-model="config.attributeLocation" placeholder="请选择数据位置">
              <el-option v-for="dict in dictData.attributeLocation" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="元素节点" :label-width="100" prop="elementNode">
            <el-input v-model="config.elementNode" />
          </el-form-item>
        </el-col>

<!--        <el-col :span="12">
          <el-form-item label="sm4文件解密密钥" :label-width="100" prop="secretKey">
            <el-input v-model="config.secretKey" />
          </el-form-item>
        </el-col>-->


        <el-col :span="12">
          <el-form-item label="是否允许自动审批" :label-width="100" prop="isAutoAudit" :rules="[{required: true,message: '必填',}]">
            <!-- <el-input v-model="config.isAutoAudit" /> -->
            <el-select v-model="config.isAutoAudit">
              <el-option v-for="dict in dictData.isAuto" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12"  v-show="config.systemCode == 'szmz'">
          <el-form-item label="是否自动下载承诺和授权书pdf文件" :label-width="200" prop="isAutoDownloadPdfFile">
            <!-- <el-input v-model="config.isAutoAudit" /> -->
            <el-select v-model="config.isAutoDownloadPdfFile">
              <el-option v-for="dict in dictData.isAuto" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <!-- <el-col :span="12">
          <el-form-item label="是否自动发送邮件" :label-width="100" prop="isAutoSendEmail">
            <el-select v-model="config.isAutoSendEmail">
              <el-option v-for="dict in dictData.isAuto" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="是否自动发送短信" :label-width="100" prop="isAutoSendSms">
            <el-select v-model="config.isAutoSendSms">
              <el-option v-for="dict in dictData.isAuto" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col> -->

        <el-col :span="12">
          <el-form-item label="文书模板目录" :label-width="100" prop="writerTemplateDir">
            <el-input v-model="config.writerTemplateDir" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="上传/下载本地保存目录" :label-width="150" prop="localMainDirectory">
            <el-input v-model="config.localMainDirectory" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="WebService地址" :label-width="150" prop="socketUrl">
            <el-input v-model="config.socketUrl" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="流水号1位预留位" :label-width="150" prop="reserved" :rules="[{max:1 , message: '流水号1位预留位长度不可超过1'}, {required: false, message: '流水号1位预留位不能为空'}]">
            <el-input v-model="config.reserved" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'zgfy'">
          <el-form-item label="SocketUrl地址" :label-width="150" prop="webServiceUrl">
            <el-input v-model="config.webServiceUrl" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="银行机构代码" :label-width="150" prop="bankOrgCode" :rules="[{required: true,message: '必填',}]">
            <el-input v-model="config.bankOrgCode" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="银行机构名称" :label-width="150" prop="bankOrgName">
            <el-input v-model="config.bankOrgName" />
          </el-form-item>
        </el-col>
        <el-col :span="12" >
          <el-form-item label="是否开通六号文" :label-width="100" prop="isEnableDocumentSix" :rules="[{required: true,message: '必填',}]" >
            <el-select v-model="config.isEnableDocumentSix">
              <el-option v-for="dict in dictData.is_enable_document_six" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12" >
          <el-form-item label="是否报文加解密" :label-width="100" prop="isEnableEncryptionDecryption" :rules="[{required: true,message: '必填',}]">
            <el-select v-model="config.isEnableEncryptionDecryption">
              <el-option v-for="dict in dictData.is_enable_encryption_decryption" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="自动化方式" :label-width="100" prop="autoMethod" :rules="[{required: true,message: '必填',}]">
            <el-select v-model="config.autoMethod">
              <el-option v-for="dict in dictData.autoMethod" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="跟随主表状态" :label-width="100" prop="followMasterStatus" :rules="[{required: true,message: '必填',}]">
            <el-select v-model="config.followMasterStatus">
              <el-option v-for="dict in dictData.followMasterStatus" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否加密反馈压缩包" :label-width="100" prop="isEnableFkZipEn" :rules="[{required: true,message: '必填',}]">
            <el-select v-model="config.isEnableFkZipEn">
              <el-option v-for="dict in dictData.isEnableFkZipEn" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="失败审批开关" :label-width="100" prop="failApproveFlag" :rules="[{required: true,message: '必填',}]" >
            <el-select v-model="config.failApproveFlag">
              <el-option v-for="dict in dictData.failApproveFlag" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否允许提交人审核人为同一人" :label-width="100" prop="isAllowAuditorSubmitterSame" :rules="[{required: true,message: '必填',}]" >
            <el-select v-model="config.isAllowAuditorSubmitterSame">
              <el-option v-for="dict in dictData.isAllowAuditorSubmitterSame" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="增量灰名单目录" :label-width="150" prop="incGreyList">
            <el-input v-model="config.incGreyList" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="增量黑名单目录" :label-width="150" prop="incBlackList">
            <el-input v-model="config.incBlackList" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="全量灰名单目录" :label-width="150" prop="allGreyList">
            <el-input v-model="config.allGreyList" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-show="config.systemCode == 'taf'">
          <el-form-item label="全量黑名单目录" :label-width="150" prop="allBlackList">
            <el-input v-model="config.allBlackList" />
          </el-form-item>
        </el-col>
      </el-row>

    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <!-- <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          确认
        </el-button> -->
        <span class="dialog-footer" style="margin-left: -2%">
        <!-- <el-button v-if="dialogData.title == '编辑'" type="primary" @click="ceshi">
          <i class="iconfont icon_binding"></i> 前置机连通性测试</el-button> -->
        <el-button type="primary" @click="save(configForm)">
          <i class="iconfont icon_update"></i> 保存</el-button>
        <el-button  v-if="dialogData.title == '编辑'" @click="reset" >
          <i class="iconfont icon_reset"></i>重置</el-button>

        <el-button @click="close"> 取消</el-button>
      </span>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
  import useDictsStore from '@/store/dictStore';
  const dictsStore = useDictsStore();
  const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, FormInstance, ElMessage, ElLink, ElForm, ElFormItem, ElCol, ElRow, ElInput, ElSelect, ElOption} from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkButtonGroup, RkSearchForm,RS,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm
} from 'riking-ui'
import {columns, formItems, pagination,searchItems} from "./config.data";
import {getQuartzList, searchList, saveOrUpdateQuartz, shareTest, getOne, deleteOne, refresh} from './config.api'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm';

useDict([], [], dictData);
const { state, init, handleSortChange, handleSelectionChange  } = useState(searchList)

const handleDetail = async (row: any) => {
  console.log(row.id);
  const response =  await getOne(row.id);
  const result = response.result;
  if (result != null) {
    handleResult(result);
  }
  open(undefined,true,"编辑");

    // open(row, true, '查看');
}
const handleDel = async (row: any) => {
  // if (ids==undefined||ids.length == 0) {
  //   ElMessage.warning('请先选择数据')
  //   return
  // }
  await deleteOne(row.id);
  search();
  ElMessage.success("删除成功");
    // open(row, true, '查看');
}
const handleAdd = async () => {
  config.value = { address: '',
  attributeLocation: '',
  elementNode: '',
  fdownloadDirectory: '',
  fuploadDirectory: '',
  id: '',
  isEnable: '',
  jdownloadDirectory: '',
  juploadDirectory: '',
  password: '',
  port: '',
  privateKey2: '',
  priveteKey1: '',
  publicKey1: '',
  publicKey2: '',
  secretKey: '',
  systemCode: '',
  userName: '',
  isAutoDownloadPdfFile: '',
  localMainDirectory: '',
  connectionType: '',
  isAutoAudit: '',
  isAutoCreateUploadReport: '',
  isAutoSendEmail: '',
  isAutoSendSms: '',
  writerTemplateDir: '',
  socketUrl: '',
  reserved: '',
  webServiceUrl: '',
  bankOrgCode: '',
  bankOrgName: '',
  incGreyList: '',
  incBlackList: '',
  allGreyList: '',
  isEnableDocumentSix: '',
  isEnableEncryptionDecryption: '',
  autoMethod: '',
  followMasterStatus: '',
    isEnableFkZipEn: '',
  allBlackList: '',
    failApproveFlag: '',
    isAllowAuditorSubmitterSame: '',
  };
  open(undefined,false,"新增");
}


const handleRefresh = async () => {
  const result = await refresh();
  ElMessage.success(result.data)
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
{
    key: 'TEST', label: '测试', tag: 'button', type: 'primary', handler: () => {
      ceshi(row);
    }
  },
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => {
      handleDetail(row);
    }
  },
  {
    key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
    handler: () => handleDel(row)
  },
]

const buttons: ButtonInfo[] = [
{
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => {
      handleAdd()
    }
  },
  {
    key: 'refresh',
    label: '刷新权限数据',
    tag: 'button',
    type: 'primary',
    icon: 'icon_update',
    handler: () => {
      handleRefresh()
    }
  },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
const configForm = ref({})
const systemList = ['ga','nsa','gjw','zyjw','jcy','zgfy']
const search = async () => {
  init();
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  console.log(result.result)
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;
}



onMounted(async () => {

  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})




// 表单·····································
const config = ref({
  address: '',
  attributeLocation: '',
  elementNode: '',
  fdownloadDirectory: '',
  fuploadDirectory: '',
  id: '',
  isEnable: '',
  jdownloadDirectory: '',
  juploadDirectory: '',
  password: '',
  port: '',
  privateKey2: '',
  priveteKey1: '',
  publicKey1: '',
  publicKey2: '',
  secretKey: '',
  systemCode: '',
  userName: '',
  isAutoDownloadPdfFile: '',
  localMainDirectory: '',
  connectionType: '',
  isAutoAudit: '',
  isAutoCreateUploadReport: '',
  isAutoSendEmail: '',
  isAutoSendSms: '',
  writerTemplateDir: '',
  socketUrl: '',
  reserved: '',
  webServiceUrl: '',
  bankOrgCode: '',
  bankOrgName: '',
  incGreyList: '',
  incBlackList: '',
  allGreyList: '',
  allBlackList: '',
  isEnableDocumentSix: '',
  isEnableEncryptionDecryption: '',
  autoMethod: '',
  followMasterStatus: '',
  isEnableFkZipEn: '',
  failApproveFlag: '',
  isAllowAuditorSubmitterSame: '',
});

// 初始化获取数据
// onMounted(async () => {
//   const response = await getQuartzList(config.value);
//   const result = response.result;
//   if (result != null) {
//     handleResult(result);
//   }
// });

// 重置时获取数据
const reset = async () => {
  const response = await getOne(config.value.id);
  const result = response.result;
  console.log('重置时获取数据', result)

  handleResult(result);
  if (result != null) {
    ElMessage.success({ message: '重置完成!' });
  }
};

// 查询系统配置信息 更新config
const handleResult = (result: any) => {
  if (result != null) {
    config.value = {
      address: result.address,
      attributeLocation: result.attributeLocation,
      elementNode: result.elementNode,
      fdownloadDirectory: result.fdownloadDirectory,
      fuploadDirectory: result.fuploadDirectory,
      id: result.id,
      isEnable: result.isEnable,
      jdownloadDirectory: result.jdownloadDirectory,
      juploadDirectory: result.juploadDirectory,
      password: result.password,
      port: result.port,
      privateKey2: result.privateKey2,
      priveteKey1: result.priveteKey1,
      publicKey1: result.publicKey1,
      publicKey2: result.publicKey2,
      secretKey: result.secretKey,
      systemCode: result.systemCode,
      userName: result.userName,
      isAutoDownloadPdfFile: result.isAutoDownloadPdfFile,
      localMainDirectory: result.localMainDirectory,
      connectionType: result.connectionType,
      isAutoAudit: result.isAutoAudit,
      isAutoCreateUploadReport: result.isAutoCreateUploadReport,
      isAutoSendEmail: result.isAutoSendEmail,
      isAutoSendSms: result.isAutoSendSms,
      writerTemplateDir: result.writerTemplateDir,
      socketUrl: result.socketUrl,
      reserved: result.reserved,
  webServiceUrl: result.webServiceUrl,
  bankOrgCode: result.bankOrgCode,
  bankOrgName: result.bankOrgName,
  incGreyList: result.incGreyList,
  incBlackList: result.incBlackList,
  allGreyList: result.allGreyList,
  allBlackList: result.allBlackList,
  isEnableDocumentSix: result.isEnableDocumentSix,
  isEnableEncryptionDecryption: result.isEnableEncryptionDecryption,
  autoMethod: result.autoMethod,
  followMasterStatus: result.followMasterStatus,
      isEnableFkZipEn: result.isEnableFkZipEn,
      failApproveFlag: result.failApproveFlag,
      isAllowAuditorSubmitterSame: result.isAllowAuditorSubmitterSame,
    };
  } else {
    ElMessage.warning({ message: '未查到数据!' })
  }
};

// 测试sftp连接
const ceshi = (row: any) => {
  console.log(row.systemCode);
  shareTest(row.systemCode).then(res => {
    console.log(res)
    /*if (res.code == 200) {
      ElMessage.success({ message: res.msg })
    } */
    if (res.msg=='连接成功') {
      ElMessage.success({ message: res.msg })
    }else if(res.msg=='连接失败'){
      ElMessage.error({ message: res.msg, grouping: true, showClose: true, duration: 0})
    }
  })
    .catch(err => {
      // 处理异常
    });
};

const edit=async ()=>{
  if (config.value.systemCode=='taf'&&config.value.bankOrgCode.length!=12){
    ElMessage.error({ message:'taf的银行机构代码必须为12位！', grouping: true, showClose: true, duration: 0})
    return
  }
  const saveR = await saveOrUpdateQuartz(config.value, true);
  if (saveR) {
    ElMessage.success({ message: '修改成功!' })
  }
  close();
  search();
}

const add=async ()=>{
  /*if (config.value.systemCode=='taf'&&config.value.bankOrgCode.length!=12){
    ElMessage.error({message:'taf的银行机构代码必须为12位！', grouping: true, showClose: true, duration: 0})
    return
  }*/
  const UpdateR =await  saveOrUpdateQuartz(config.value, false);
  if (UpdateR) {
    ElMessage.success({ message: '保存成功!' })
  }
  close();
  search();
}
// 保存数据
const save = async (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.validate((valid) => {
    if (valid) {
      if (config.value.id) {
        edit()
      } else {
        add()
      }
    } else {
      ElMessage.warning({message:"有必输项未填",grouping: true})
      console.log('error submit!')
      return false
    }
  })
}

</script>

<style scoped></style>
