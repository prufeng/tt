<template>
<rk-index-layout>
  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search" :label-width="50" @keyup.enter="search">
    <!-- 自定义渲染 -->
    <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
  </rk-search-form>

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page" @page-change="pageChange" @refresh="search">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="['ADD', 'DELETE_BATCH']"></rk-button-group>
    </template>

    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="['EDIT', 'DELETE','EXECUTE','STATUS']" link></rk-button-group>
    </template>
  </rk-page-table>
</rk-index-layout>



  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" >
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm"  :form-items="formItems" :disabled="dialogData.formDisabled" >
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <!-- <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          确认
        </el-button> -->
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog :close-on-click-modal="false" v-model="dialogData2.visible" :title="dialogData2.title" class="rk-dialog-default" @closed="closed2" >
    <rk-detail-form ref="dialogFormRef2" v-model="dialogForm2"  :form-items="formItems2" :disabled="dialogData2.formDisabled" >
      <template #templateContent >
      <TEditor ref="editor" v-model="formState.contents"  @getContent="getContent" class="my-editor" disabled />
    </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <!-- <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button> -->
        <el-button @click="close2"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
  import useDictsStore from '@/store/dictStore';
  const dictsStore = useDictsStore();
  const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import {provide,onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage} from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm,RS,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm
} from 'riking-ui'
import {columns, formItems, pagination,searchItems,formItems2} from "@/views/sys/emailLog/emailLog.data";
import {getQuartzList,searchList } from '@/views/sys/emailLog/emailLog.api'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm';
import oauthUser  from "@/views/sys/oauthUser/oauthUser.vue";
const myComponent =  ref();

useDict([], [], dictData);
const { state, init, handlePageChange, handleSortChange, handleSelectionChange  } = useState(searchList)
// const handleEdit = async (row: any) => {
//   open(row,false,'编辑');
//   search();
// }
const formState = reactive({contents :''});

const getContent = (v: string) => {
  formState.contents = v
}
const handleDetail = async (row: any) => {
  if(row.emailType == 1){
    open(row, true, '查看');
  }else{
    formState.contents = row.templateContent
    open2(row, true, '查看');
  }

}

const handleRowId = {

}
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => {
     handleDetail(row); ;
    }
  },
  // {
  //   key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => handleEdit(row)
  // },
 
]
const buttons: ButtonInfo[] = [
  // {
  //   key: 'add',
  //   label: '新增',
  //   tag: 'button',
  //   type: 'primary',
  //   icon: 'icon_add',
  //   handler: () => handleAdd(),
  // },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const search = async () => {
  init();
  console.log(searchForm.value);
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  console.log(result.result);
  console.log(page.value);
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}



onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})
const {
  dialogData :dialogData2, open: open2, close: close2, closed: closed2,
  form: dialogForm2,
  nameRef: dialogFormRef2
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef2', {type: []})

//控制表单提交
// const handleSave = async () => {
//   dialogData.loading = true
//   try {
//     const valid = await dialogFormRef.value?.asyncValidate();
//     // console.log(dialogForm._rawValue.jobClassName);
//     console.log('value12', dialogForm._rawValue);
 
//     const myPropName = await myComponent.value.onSelectionChange();
//     console.log('value12',myPropName);
//     await addUser(myPropName);
//     search();
//     close();
//     ElMessage.success('success')
//   } finally {
//     setTimeout(() => (dialogData.loading = false), 50)
//   }
// }
</script>

<style scoped></style>