<template>

  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search"
                  :label-width="50">
    <!-- 自定义渲染 -->
    <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
  </rk-search-form>

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page"
                 @page-change="pageChange" @refresh="search">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
    </template>

    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta"
                       link></rk-button-group>
    </template>
  </rk-page-table>


  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title"
             class="rk-dialog-default" @closed="closed">
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems"
                    :disabled="dialogData.formDisabled">
    </rk-detail-form>
    <!--    <el-tabs v-model="tabsValue" type="border-card" class="demo-tabs" >
        <el-tab-pane label="选择用户">
          <oauthUser ref="myComponent" :onSelectionChange="handleRowId"/>
        </el-tab-pane>
        <el-tab-pane label="手动新增">
          <rk-detail-form ref="dialogFormRef2" v-model="dialogForm2" :form-items="formItems"  :disabled="dialogData2.formDisabled">
         </rk-detail-form>
        </el-tab-pane>
      </el-tabs>-->
    <template #footer>
        <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-if="dialogData2.visible" :close-on-click-modal="false" v-model="dialogData2.visible" :title="dialogData2.title"
             class="rk-dialog-default" @closed="closed2">
    <addressee :prop1="ruleId"/>
    <!--    <rk-detail-form ref="dialogFormRef2" v-model="dialogForm2" :form-items="formItems"  :disabled="dialogData2.formDisabled">

        </rk-detail-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button v-if="!dialogData2.formDisabled" :loading="dialogData2.loading" type="primary" @click="handleSave2">
              保存
            </el-button>
            <el-button @click="close2"> 取消</el-button>
          </span>
        </template>-->
  </el-dialog>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
</script>

<script setup lang="ts">
import {provide, onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage} from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm, RS,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm
} from 'riking-ui'
import {columns, formItems, pagination, searchItems} from "@/views/sys/note/addresseeRules/addresseeRules.data";
import {
  getQuartzList,
  addUser,
  deleteQuartz,
  searchList,
  edit,
  add
} from '@/views/sys/note/addresseeRules/addresseeRules.api'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm';
import oauthUser from "@/views/sys/oauthUser/oauthUser.vue";
import addressee from "@/views/sys/note/addresseeRules/addressee/addressee.vue"
// import {getTemplateNameOptions} from "@/views/sys/email/emailRules/emailRules.api";

useDict([], [], dictData);
const myComponent = ref();
let tabsValue = '0';
const {state, init, handlePageChange, handleSortChange, handleSelectionChange} = useState(searchList)
const handleDelete = async (row: any) => {
  await deleteQuartz(row);
  ElMessage.success('删除成功');
  search();
}
const handleEdit = async (row: any) => {
  tabsValue = '0'
  open(row, false, '编辑');
  // search();
}
// const handleEdit = async (row: any) => {
//   open(row,false,'编辑');
//   search();
// }
const handleAdd = async () => {
  tabsValue = '1'
  open(undefined, false, "新增");
}
const handleRowId = {}
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  // {
  //   key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => {
  //     open(row, true, '查看');
  //   }
  // },
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => handleEdit(row)
  },
  {
    key: 'ADDRESSEE', label: '收件人', tag: 'button', type: 'primary', handler: () => handleAddressee(row)
  },
  {
    key: 'DELETE', label: '删除', tag: 'popconfirm', type: 'danger',
    title: '确定删除吗?', handler: () => handleDelete(row)
  },

]
const buttons: ButtonInfo[] = [
  {
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleAdd(),
  },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
const ruleId = ref({})

const search = async () => {
  // let templateNameOptions = await getTemplateNameOptions('sms')
  init();
  const res=searchForm.value;
  res['ruleType']='sms'
  let result = await getQuartzList(res, page.value.currentPage, page.value.pageSize);
  let records = result.result;
  data.value = records.records;
      /*(records.records||"").map(item=>{
    const newObj= {
      ...item,
      businessLine:templateNameOptions.result.map(it=>{
        return it.value==item.businessLine?it.label:''
      }).filter(ite=>ite!='')[0],
      templateId:templateNameOptions.result.map(it=>{
        return it.value==item.templateId?it.label:''
      }).filter(ite=>ite!='')[0]
    }
    return newObj
  });*/
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}

// useDict([], [], dictData);


onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

const {
  dialogData: dialogData2, open: open2, close: close2, closed: closed2,
  form: dialogForm2,
  nameRef: dialogFormRef2,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef2', {type: []})
//控制表单提交
const handleSave = async () => {

  if (tabsValue == '0') {
    //编辑
    dialogData.loading = true
    try {
      const valid = await dialogFormRef.value?.asyncValidate();
      if (valid) {
        await edit(dialogForm.value);
        search();
        close();
        ElMessage.success('修改成功')
      }
    } finally {
      setTimeout(() => (dialogData.loading = false), 50)
    }
  } else if (tabsValue == '1') {
    /*const data = toRaw(dialogForm2.value);
    data.status = '1';
    await add(data);
    close();
    await search();*/
    //新增
    dialogData.loading = true
    try {
      const valid = await dialogFormRef.value?.asyncValidate();
      if (valid) {
        const result=dialogForm.value
        result['ruleType']='sms'
        await add(result);
        search();
        close();
        ElMessage.success('新增成功')
      }
    } finally {
      setTimeout(() => (dialogData.loading = false), 50)
    }
  }

}

const handleAddressee = async (row: any) => {
  ruleId.value =  row.id;
  open2(row, false, '收件人');
  search();
}
//控制表单2提交
const handleSave2 = async () => {
  if (dialogData2.title == "编辑") {
    // const valid = await dialogFormRef2.value?.asyncValidate();
    // if (valid) {
    const data = toRaw(dialogForm2.value);
    data.status = '1';
    delete data.type;
    await edit(data);
    close2();
    await search();
    // }
  }
}
</script>

<style scoped></style>