// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  list = '/sysSmsConsignee/list',
  get = '/sysSmsConsignee/queryById',
  delete = '/sysSmsConsignee/delete',
  deleteBatch = '/sysSmsConsignee/deleteBatch',
  addUser = '/sysSmsConsignee/addUser',
  edit = '/sysSmsConsignee/edit',
  add = '/sysSmsConsignee/add',
}
/**
 * 普通增加
 * @param params
 */
export const add = (data: any,ruleId: string): Promise<RS> => {
  return service({
    url: Api.add ,
    method: 'POST',
    data,
    params: { ...getCommonParams(),ruleId}
})
};
/**
 * 修改
 * @param params
 */
export const edit = (data: any): Promise<RS> => {
  return service({
    url: Api.edit ,
    method: 'POST',
    data,
    params: { ...getCommonParams()} 
})
};
/**
 * 增加用户
 * @param params
 */
export const addUser = (data: any,ruleId: string): Promise<RS> => {
  return service({
    url: Api.addUser + "?ids=" + data,
    method: 'POST',
    data,
    params: { ...getCommonParams(),ruleId}
})
};
/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize, ...getCommonParams()}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: { ...getCommonParams()} 
  })
}

/**
 * 保存或者更新任务
 * @param params
 */
// export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
//   console.log(data);
//   let url = isUpdate ? Api.edit : Api.save;
//   return service({
//     url: url,
//     method: 'POST',
//     data,
// })
// };

/**
 * 删除任务
 * @param params
 */
export const deleteQuartz = (params: any) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    params: params,
    // params:{...getCommonParams()}
})
  // return defHttp.delete({ url: Api.delete, data: params }, { joinParamsToUrl: true }).then(() => {
  //   handleSuccess();
  // });
};

/**
 * 批量删除任务
 * @param params
 */
// export const batchDeleteQuartz = (params: any, handleSuccess: () => void) => {
//   Modal.confirm({
//     title: '确认删除',
//     content: '是否删除选中数据',
//     okText: '确认',
//     cancelText: '取消',
//     onOk: () => {
//       return defHttp.delete({ url: Api.deleteBatch, data: params }, { joinParamsToUrl: true }).then(() => {
//         handleSuccess();
//       });
//     },
//   });
// };
