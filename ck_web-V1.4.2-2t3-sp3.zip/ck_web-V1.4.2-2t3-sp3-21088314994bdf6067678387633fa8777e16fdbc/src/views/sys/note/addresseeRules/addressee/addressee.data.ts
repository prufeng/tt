import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    // {key: 'id', type: 'selection'},
    // {prop: 'userName', label: '用户名称'},
    {prop: 'nickName', label: '昵称'},
    // {prop: 'roleName', label: '角色名称'},
    {prop: 'phone', label: '手机号'},
    // {prop: 'systemCode', label: '所属系统',dictFormatKey: "systemCode"},
    {prop: 'branchCode', label: '所属机构',dictFormatKey:'branchTree'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        fixedWidth: 200,
        fixed: 'right',
    },
];

export const searchItems: FormItemInfo[] = [
    {
        prop: 'nickName',
        label: '用户昵称',
        inputType: 'input',
        labelWidth: 100,
    },
    {
        prop: 'ruleId',
        label: '规则id',
        inputType: 'input',
        labelWidth: 100,
    },
];

export const formItems: FormItemInfo[] = [
    {prop: 'nickName', label: '昵称', extra: {span: 24}, rules: [{required: true, message: '必填'}]},
    // {prop: 'roleName', label: '角色名称'},
    {prop: 'phone', label: '手机号', extra: {span: 24}, rules: [{required: true, message: '必填'}]},
    {
        prop: 'branchCode',
        label: '所属机构',
        rules: [{required: true, message: '必填'}],
        inputType: {
            tag: 'tree-select',
            options: 'branchTree',
            showCheckbox: true,
            checkStrictly: true,
        },
        extra: {span: 8},
    },

];
export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 100,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}

// 字典
export const dictData = {}