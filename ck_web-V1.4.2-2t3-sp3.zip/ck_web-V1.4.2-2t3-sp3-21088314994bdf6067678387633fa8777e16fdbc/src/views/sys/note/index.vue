<template>
  <el-tabs type="border-card" class="demo-tabs" tab-position="top">
    <el-tab-pane label="短信模板管理" lazy>
      <noteTemplate />
    </el-tab-pane>
    <el-tab-pane label="发件管理" lazy>
      <send />
    </el-tab-pane>
    <el-tab-pane label="短信规则管理" lazy>
      <addresseeRules />
    </el-tab-pane>
  </el-tabs>
</template>
<script lang="ts">

</script>
<script setup lang="ts">
import send from "@/views/sys/note/send/send.vue"
import addresseeRules from "@/views/sys/note/addresseeRules/addresseeRules.vue"
import noteTemplate from "@/views/sys/note/noteTemplate/noteTemplate.vue";
</script>
   
<style scoped>  .demo-tabs {
    height: 100%;
    width: 100%;
  }
</style>