import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  list = '/sysSmsTemplate/list',
  save = '/sysSmsTemplate/add',
  edit = '/sysSmsTemplate/edit',
  get = '/sysSmsTemplate/queryById',
  delete = '/sysSmsTemplate/delete',
  deleteBatch = '/sysSmsTemplate/deleteBatch',
}

/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize,...getCommonParams()}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: {...getCommonParams()}
  })
}

/**
 * 保存或者更新任务
 * @param params
 */
export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
  console.log(data);
  let url = isUpdate ? Api.edit : Api.save;
  return service({
    url: url,
    method: 'POST',
    data,
})
};
/**
 * 删除任务
 * @param params
 */
export const deleteQuartz = (data: any) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    data: data,
    params: data
})
  // return defHttp.delete({ url: Api.delete, data: params }, { joinParamsToUrl: true }).then(() => {
  //   handleSuccess();
  // });
};




/**
 * 批量删除任务
 * @param params
 */
// export const batchDeleteQuartz = (params: any, handleSuccess: () => void) => {
//   Modal.confirm({
//     title: '确认删除',
//     content: '是否删除选中数据',
//     okText: '确认',
//     cancelText: '取消',
//     onOk: () => {
//       return defHttp.delete({ url: Api.deleteBatch, data: params }, { joinParamsToUrl: true }).then(() => {
//         handleSuccess();
//       });
//     },
//   });
// };
