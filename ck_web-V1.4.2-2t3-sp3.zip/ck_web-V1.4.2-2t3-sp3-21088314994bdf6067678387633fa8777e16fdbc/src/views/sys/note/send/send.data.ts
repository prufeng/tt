import { FormItemInfo } from "riking-ui";

// 表单项
export const formItems: FormItemInfo[] = [
  {
    prop: 'gatewayId',
    label: '网关ID',
    inputType: 'input',
    extra: { span: 18 },
    labelWidth:300,
    rules: [{ required: true, message: '网关ID必填' }],
  },
  {
    prop: 'comPort',
    label: '串行端口名称',
    inputType: 'input',
    extra: { span: 18 },
    labelWidth:300,
    rules: [{ required: true, message: '串行端口名称必填' }],
  },
  {
    prop: 'baudRate',
    label: '串行端口波特率',
    inputType: 'input-number',
    extra: { span: 18 },
    labelWidth: 300,
    rules: [{ required: true, message: '串行端口波特率必填' }],
  },
  {
    prop: 'manufacturer',
    label: '制造商名称',
    inputType: 'input',
    extra: { span: 18 },
    labelWidth: 300,
    rules: [{ required: true, message: '制造商名称必填' }],
  },
  {
    prop: 'model',
    label: '设备型号',
    inputType: 'input',
    extra: { span: 18 },
    labelWidth: 300,
    rules: [{ required: true, message: '设备型号必填' }],
  },
  {
    prop: 'testPhone',
    label: '短信测试接收手机号',
    inputType: 'input',
    extra: { span: 18 },
    labelWidth: 300,
    rules: [{ required: true, message: '短信测试接收手机号必填' }],
  }

];

// 字典
export const dictData = {
}