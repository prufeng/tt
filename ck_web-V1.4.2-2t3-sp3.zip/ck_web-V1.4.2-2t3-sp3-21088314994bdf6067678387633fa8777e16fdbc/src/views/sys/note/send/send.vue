<template>
   <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" >
  </rk-detail-form>

  <span class="dialog-footer">
    <el-button type="primary" @click="smsTest">
      <i class="iconfont icon_binding"></i> 短信测试</el-button>
    <el-button type="primary" @click="save">
      <i class="iconfont icon_update"></i> 保存</el-button>
    <el-button @click="reset">
      <i class="iconfont icon_reset"></i>重置</el-button>
  </span>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { formItems, dictData } from "@/views/sys/note/send/send.data";
import { saveOrUpdateQuartz, getQuartzList,testSMS } from '@/views/sys/note/send/send.api'
import {
  RkDetailForm, RkFormInstance
} from 'riking-ui'

useDict([], [], dictData)
// const {hideFields} from RkFormInstance;
const dialogFormRef=ref();
const dialogForm = ref({
  id: '',
  gatewayId: '',
  comPort: '',
  baudRate: '',
  manufacturer: '',
  model: '',
  testPhone: ''
});

onMounted(async () => {
  search();
})

const smsTest = async () => {
  const valid = await dialogFormRef.value?.asyncValidate();
  if (valid){
    await testSMS();
    ElMessage.success({ message: '测试成功!' })
  }
}

const save = async () => {
  const valid = await dialogFormRef.value?.asyncValidate();
  if (!valid){
    return
  }
  if (dialogForm.value.id) {
    const valid = await saveOrUpdateQuartz(dialogForm.value, true);
    if (valid) {
      ElMessage.success({ message: '修改成功!' })
    }
  } else {
    const valid2 = await saveOrUpdateQuartz(dialogForm.value, false);
    if (valid2) {
      ElMessage.success({ message: '保存成功!' })
    }
  }
}
const search = async () => {
  const response = await getQuartzList(dialogForm.value);
    if(response.result.records.length > 0){
      const result = response.result.records[0];
       console.log(result);
       dialogForm.value = {
      id:result.id,
      gatewayId: result.gatewayId,
      comPort: result.comPort,
      baudRate: result.baudRate,
      manufacturer: result.manufacturer,
      model: result.model,
      testPhone: result.testPhone,
    };
    console.log(formItems);
    }else {
      dialogForm.value = {
        id: '',
  gatewayId: '',
  comPort: '',
  baudRate: '',
  manufacturer: '',
  model: '',
  testPhone: ''
    };
    }
  
}
const reset = async () => {
    search();
    ElMessage.success({ message: '重置完成!' })
}

</script>
<style scoped>

.dialog-footer {
  display: flex;
  justify-content: center;
}
</style>