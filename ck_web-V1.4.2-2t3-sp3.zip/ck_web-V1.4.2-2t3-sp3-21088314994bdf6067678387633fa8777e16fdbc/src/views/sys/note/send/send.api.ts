import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";

enum Api {
  save = '/sysSmsConfig/add',
  edit = '/sysSmsConfig/edit',
  list = '/sysSmsConfig/list',
  test = '/sysSmsConfig/testSms',
}
/**
 * 测试邮件
 * @param params
 */
export const testSMS = () => {
  return service({
    url: Api.test,
    method: 'POST',
    params: {...getCommonParams()} 
  })
};

/**
 * 保存或者更新任务
 * @param params
 */
export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
  console.log(data);
  let url = isUpdate ? Api.edit : Api.save;
  return service({
    url: url,
    method: 'POST',
    data,
    params: {...getCommonParams()} 
  })
};

/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: { ...getCommonParams()}
  })
};