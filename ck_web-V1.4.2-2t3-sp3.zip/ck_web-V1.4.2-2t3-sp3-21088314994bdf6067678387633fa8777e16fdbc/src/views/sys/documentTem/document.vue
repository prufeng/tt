<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" @keyup.enter="search" v-model="searchForm" :loading="loading"
                    :form-items="searchItems" @search="search" :label-width="50">
    </rk-search-form>

    <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page"
                   @page-change="pageChange" @refresh="search" stripe @selection-change="handleSelectionChange"
                   @sort-change="handleSortChange">
      <template #operations>
        <!-- <div style="display: flex; flex-direction: row"> -->
        <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
        <!-- <el-upload class="upload-demo"  :action="upluadPath"  multiple @success="handleSuccess" :show-file-list="false
        ">
           <el-button size="medium" style="font-size: 12px" type="primary">上传</el-button>
         </el-upload> -->
        <!-- </div> -->
      </template>
      <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
      <template #url="{ row }">
        <el-link :href="row.url">{{ row.url }}</el-link>
      </template>
      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
      </template>
    </rk-page-table>
  </rk-index-layout>

      <el-dialog v-model="uploadDialog" title="上传" width="30%" draggable @closed="() => {config.systemCode=null; config.templateName=null }">
        <el-form ref="uploadForm" :model="config" >
          <el-row>
            <el-col>
              <el-form-item label="所属系统" :label-width="100" prop="systemCode" :rules="[{required: true,message: '必填',}]">
                <el-select v-model="config.systemCode" @change="option()">
                  <el-option v-for="dict in dictData.systemCode" :key="dict.value" :label="dict.label" :value="dict.value" />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col>
              <el-form-item label="模板名称" :label-width="100" prop="templateName" :rules="[{required: true,message: '必填',}]">
                <!-- <el-input v-model="templateName" style="width: 200px" /> -->
                <el-select filterable clearable placeholder="请选择" v-model="config.templateName">
                  <el-option
                      v-for="template in templateList"
                      :key="template.writerTemplateName"
                      :label="template.writerTemplateName"
                      :value="template.writerTemplateName"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
    <template #footer>
      <span class="dialog-footer">
        <div style="display: flex; justify-content: flex-end;">
        <el-button  style="font-size: 12px" type="primary" @click="upload(uploadForm)">上传文件</el-button>
        <el-button type="default" @click="uploadDialog = false;">
          取消
        </el-button>
        </div>
      </span>
    </template>
  </el-dialog>
  <template>
    <div>
      <el-upload class="upload-demo"  :action="getUploadUrl()"  multiple @success="handleSuccess" :show-file-list="false " :headers=" {Authorization:getToken()} ">
        <el-button  style="font-size: 12px" type="primary" id="uploadButton" >上传文件</el-button>
      </el-upload>
    </div>
  </template>
  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" :close-on-click-modal="false">

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close">取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage, ElForm, ElFormItem, FormInstance, ElLink, ElUpload, ElOption,
  ElSelect, ElCol, ElRow} from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  Pagination,
  ButtonInfo,
  useState,
  RkFormInstance,
  useDialogForm,
  RkIndexLayout
} from 'riking-ui'
import { columns, pagination, searchItems } from "@/views/sys/documentTem/document.data";
import { getQuartzList, searchList,getTemplateList } from '@/views/sys/documentTem/document.api'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm';
import { getSubSystem} from "@/utils/subSystem";
import {getToken} from "@/utils/token";
import {BASE_PREFIX} from "@/utils/request";
useDict([], [], dictData);
const { state, init, handleSortChange, handleSelectionChange } = useState(searchList)
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'DOWNLOAD', label: '下载', tag: 'button', type: 'primary', handler: () => {
       handledownload(row);
    }
  },

]
const handledownload = async (row: any) => {
  fetch(BASE_PREFIX + "/sys-writer-template/download?writerTemplateName=" + row.writerTemplateName)
  .then(response => {
    console.log(response);
    // 检查后端返回的状态码
    if (response.ok) {
      window.location.href = BASE_PREFIX + "/sys-writer-template/download?writerTemplateName=" + row.writerTemplateName;
    } else {
      // 如果状态码不是2xx，则显示错误提示
      ElMessage.warning('下载失败，请重试！');
    }
  })
  .catch(error => {
    // 捕获网络请求或其他错误，并显示错误提示
    alert('下载失败，请重试！');
  });
}

const handleSuccess = (response: any, file: any, fileList: any) => {
  const result = response;
  console.log(result);
  if (result.code === 200) {
    // 上传成功
    ElMessage.success({ message: result.msg });

  } else {
    // 上传失败
    console.log(result);
    ElMessage.warning({ message: result.msg })

  }
  uploadDialog.value = false;
}
const buttons: ButtonInfo[] = [
  {
    key: 'UPLOAD',
    label: '上传',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => {
      systemCode.value = '';
      templateName.value = '';
      uploadDialog.value = true
    }
    },
]
const loading = ref(false)
const data = ref<any[]>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
const uploadDialog = ref(false);
const systemCode = ref("");
const uploadForm= ref("");
const config= ref({
  systemCode: null,
  templateName: null,
});
const templateName = ref("");
let templateList=ref([]);
const search = async () => {
  init();
  let res = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  // console.log(page.value);
  let result = res.result;
  data.value = result.records;
  page.value.currentPage = result.current;
  page.value.pageSize = result.size;
  page.value.total = result.total;
}

const upload =  (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.validate((valid) => {
    if (valid) {
      var elementById = document.getElementById("uploadButton");
      elementById.click();
    } else {
      return false
    }
  })
}

const option = async () => {
  config.value.templateName=null;
  let listResult = await getTemplateList();
  templateList.value=listResult.result.filter(item=>item.systemCode==config.value.systemCode)
}

function getUploadUrl() {
  const upluadPath =  BASE_PREFIX+"/sys-writer-template/upload?subSystem=" + config.value.systemCode + "&templateName=" + config.value.templateName;
    return upluadPath;
}

// 初始化方法
onMounted(async () => {
  /*let listResult = await getTemplateList();
  templateList = listResult.result;*/
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

</script>
