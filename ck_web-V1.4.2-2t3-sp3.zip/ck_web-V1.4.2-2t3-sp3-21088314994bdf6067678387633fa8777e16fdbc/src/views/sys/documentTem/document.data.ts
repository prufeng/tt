import {  FormItemInfo, Pagination, TableColumnInfo } from "riking-ui";

export const columns: TableColumnInfo[] = [
  // { key: 'id', type: 'selection' },
  { prop: 'writerTemplateName', label: '文书模板名称' },
  { prop: 'writerTemplateType', label: '文书模板类型', dictFormatKey: "documentType" },
  {
    prop: 'systemCode',
    label: '所属系统',
    dictFormatKey: "systemCode"
  },
  {
    key: 'actions', label: '操作', scopedSlots: 'actions',
    fixedWidth: 200, fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'systemCode',
    label: '所属系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },  
    labelWidth: 100
  },
  {
    prop: 'writerTemplateName',
    label: '文书模板名称',
    inputType: "input",
    labelWidth: 100,
  },
  {
    prop: 'writerTemplateType',
    label: '文书模板类型',
    labelWidth: 100,
    inputType: {
      tag: 'select',
      options: 'documentType',
    },
  },
];

//弹出层
export const formItems: FormItemInfo[] = [
  { prop: 'phone', label: '接收人手机号', inputType: 'input' },
  {
    prop: 'writerTemplatePath',
    label: '文书模板路径',
    inputType: "input",
    labelWidth: 100,
  },{
    prop: 'content',
    label: '内容',
    inputType: {
      tag: 'input', type: 'textarea', maxlength: '30'
    },
    extra: { span: 18 },
  },

];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData = {
}