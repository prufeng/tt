// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  list = '/sys-writer-template/list',
  download = '/sys-writer-template/download',
  templateList = '/sys-writer-template/getList',
}
export function downloadFile(data: any) {
  return service({
    url: Api.download,
    method: 'GET',
    data,
    params: {data, ...getCommonParams()} 
  })
}

/**
 * 获取模板名称列表
 * @param params
 */
export const getTemplateList = (): Promise<RS> => {
  return service({
    url: Api.templateList,
    method: 'POST',
    params: {...getCommonParams()}
})
};
/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize, ...getCommonParams()}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: {...getCommonParams()} 
  })
}
// /**
//  * 删除任务
//  * @param params
//  */
// export const deleteQuartz = (data: any) => {
//   return service({
//     url: Api.delete,
//     method: 'DELETE',
//     data: data,
//     params: data
// })
//   // return defHttp.delete({ url: Api.delete, data: params }, { joinParamsToUrl: true }).then(() => {
//   //   handleSuccess();
//   // });
// };
