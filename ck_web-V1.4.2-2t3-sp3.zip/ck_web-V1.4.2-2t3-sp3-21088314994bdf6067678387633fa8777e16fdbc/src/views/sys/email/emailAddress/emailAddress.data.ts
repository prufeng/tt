import { FormItemInfo } from "riking-ui";

// 表单项
export const formItems: FormItemInfo[] = [
  {
    prop: 'userName',
    label: '发件人名称',
    inputType: 'input',
    extra: { span: 18 },
    labelWidth:300,
    rules: [{ required: true, message: '发件人名称必填' }],
  },
  {
    prop: 'emailAddress',
    label: '发件人邮箱',
    inputType: 'input',
    extra: { span: 18 },
    labelWidth:300,
    rules: [{ required: true, message: '发件人邮箱必填' }],
  },
  {
    prop: 'password',
    label: '发件人密码',
    scopedSlot: 'passwordSlot',
    extra: { span: 18 },
    labelWidth:300, 
    rules: [{ required: true, message: '发件人密码必填' }],
  },
  {
    prop: 'emailHost',
    label: '邮箱服务器',
    inputType: {
      tag: 'select',
      options: 'emailHost',
  },
    extra: { span: 18 },
    labelWidth: 300,
  },
  {
    prop: 'smtpPort',
    label: 'smtp协议端口',
    inputType: {
      tag: 'select',
      options: 'smtpPort',
  },
    extra: { span: 18 },
    labelWidth: 300,
  },
  {
    prop: 'testEmail',
    label: '测试邮箱',
    inputType: 'input',
    extra: { span: 18 },
    labelWidth:300,
    rules: [{ required: true, message: '测试邮箱必填' }],
  },
  {
    prop: 'exchangeHostUrl',
    scopedSlot: 'exchangeSlot',
    extra: { span: 24  },
    labelWidth: 170,
  },
];
