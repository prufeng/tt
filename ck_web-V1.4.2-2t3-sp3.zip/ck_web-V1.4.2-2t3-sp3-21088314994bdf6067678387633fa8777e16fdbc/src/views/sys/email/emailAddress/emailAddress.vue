<template>
   <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" >
    <template #passwordSlot>
    <el-input v-model="dialogForm.password" type="password"  show-password />
  </template>
    <template #exchangeSlot>
     <el-form-item label="exchange服务器地址"  v-show="dialogForm.emailHost == '1'"  label-width="130">
      <el-input ref="editor" v-model="dialogForm.exchangeHostUrl"  style="width:30vw" />
    </el-form-item>
    </template>
  </rk-detail-form>

  <span class="dialog-footer">
    <el-button type="primary" @click="emailTest">
      <i class="iconfont icon_binding"></i> 邮件测试</el-button>
    <el-button type="primary" @click="save">
      <i class="iconfont icon_update"></i> 保存</el-button>
    <el-button @click="reset">
      <i class="iconfont icon_reset"></i>重置</el-button>
  </span>
</template>

<script lang="ts">
  import useDictsStore from '@/store/dictStore';
  const dictsStore = useDictsStore();
  const dictData = await dictsStore.getDict;
</script>

<script setup lang="ts">
import { ref } from 'vue';
import { ElDialog, ElButton, ElMessage, ElInput, ElFormItem, ElLink } from 'element-plus'
import { formItems } from "@/views/sys/email/emailAddress/emailAddress.data";
import { saveOrUpdateQuartz, getQuartzList,testEmail } from '@/views/sys/email/emailAddress/emailAddress.api'
import {RkDetailForm, RkFormInstance} from 'riking-ui'

const dialogFormRef=ref();
useDict([], [], dictData)
// const {hideFields} from RkFormInstance;
const dialogForm = ref({
  userName: '',
  emailAddress: '',
  password: '',
  emailHost: '',
  exchangeHostUrl: '',
  smtpPort: '',
  id: '',
  testEmail: ''
});

onMounted(async () => {
  search();
})

const emailTest = async () => {
  const valid = await dialogFormRef.value?.asyncValidate();
  if (valid){
    const response =  await testEmail();
    console.log(response)
    ElMessage.success({ message: '测试成功!' })
  }
}

const save = async () => {
  const valid = await dialogFormRef.value?.asyncValidate();
  if (!valid){
    return
  }
  if (dialogForm.value.id) {
    const valid = await saveOrUpdateQuartz(dialogForm.value, true);
    if (valid) {
      ElMessage.success({ message: '修改成功!' })
    }
  } else {
    const valid2 = await saveOrUpdateQuartz(dialogForm.value, false);
    if (valid2) {
      ElMessage.success({ message: '保存成功!' })
    }
  }
}
const search = async () => {
  const response = await getQuartzList(dialogForm.value);
    if(response.result.records.length > 0){
      const result = response.result.records[0];
       console.log(result);
       dialogForm.value = {
      emailAddress: result.emailAddress,
      password: result.password,
      userName: result.userName,
      emailHost: result.emailHost,
      exchangeHostUrl: result.exchangeHostUrl,
      smtpPort: result.smtpPort,
      id: result.id,
      testEmail: result.testEmail
    };
    console.log(formItems);
    }else {
      dialogForm.value = {
        emailAddress: '',
  password: '',
  emailHost: '',
  userName: '',
  exchangeHostUrl: '',
  smtpPort: '',
  id: '',
  testEmail: ''
    };
    }

}
const reset = async () => {
    search();
    ElMessage.success({ message: '重置完成!' })
}

</script>
<style scoped>

.dialog-footer {
  display: flex;
  justify-content: center;
}
</style>
