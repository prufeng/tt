import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  save = '/rkSysEmailConsigner/add',
  edit = '/rkSysEmailConsigner/edit',
  list = '/rkSysEmailConsigner/list',
  test = '/rkSysEmailConsigner/testEmail',
}

/**
 * 保存或者更新任务
 * @param params
 */
export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
  console.log(data);
  let url = isUpdate ? Api.edit : Api.save;
  return service({
    url: url,
    method: 'POST',
    data,
    params: { ...getCommonParams()} 
  })
};

/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: { ...getCommonParams()} 
  })
};
/**
 * 邮件测试
 * @param params
 */
export const testEmail = (): Promise<RS> => {
  return service({
    url: Api.test,
    method: 'POST',
    params: { ...getCommonParams()} 
  })
};