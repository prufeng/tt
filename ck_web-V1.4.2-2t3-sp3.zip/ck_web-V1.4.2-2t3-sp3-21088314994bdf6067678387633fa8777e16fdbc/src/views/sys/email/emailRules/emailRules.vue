<template>
  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search" :label-width="50">
    <!-- 自定义渲染 -->
    <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
  </rk-search-form>
  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page"
                 @page-change="pageChange" @refresh="search">
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta" v-if="isDEV"> </rk-button-group>
    </template>

    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta"
                       link></rk-button-group>
    </template>
  </rk-page-table>


  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed"
             :close-on-click-modal="false">
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems"
                    :disabled="dialogData.formDisabled">
    </rk-detail-form>
    <template #footer>
        <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog  v-if="dialogData2.visible" v-model="dialogData2.visible" :title="dialogData2.title" class="rk-dialog-default" @closed="closed2"
             :close-on-click-modal="false">
    <emailPerson :prop1="ruleId" />
  </el-dialog>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
</script>

<script setup lang="ts">
import emailPerson from "@/views/sys/email/emailRules/emailPerson/emailPerson.vue"
import {provide, onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage, ElLink} from 'element-plus'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm, RS, RkDetailForm,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm
} from 'riking-ui'
import {columns, formItems, pagination, searchItems} from "@/views/sys/email/emailRules/emailRules.data";
import {
  getQuartzList,
  deleteRule,
  searchList,
  add,
  edit
} from '@/views/sys/email/emailRules/emailRules.api'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm';
import {isDEV} from "@/utils/request";

useDict([], [], dictData);
const myComponent = ref();
const {state, init, handlePageChange, handleSortChange, handleSelectionChange} = useState(searchList)
const handleDelete = async (row: any) => {
  await deleteRule(row);
  ElMessage.success('删除成功');
  search();
}
const formState = reactive({contents: ''});
const getContent = (v: string) => {
  formState.contents = v
}
let tabsValue = '0';
const handleEdit = async (row: any) => {
  tabsValue='0'
  open(row, false, '编辑');
  search();
}

const handleView = async (row: any) => {
  open(row, true, '查看');
}

const handlePerson = async (row: any) => {
  ruleId.value =  row.id;
  open2(row, false, '收件人');
  search();
}
const handleAdd = async () => {
  tabsValue='1'
  open(undefined, false, "新增");
}
const handleRowId = {}
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary',invisible:!isDEV, handler: () => handleEdit(row)
  },
  {
    key: 'PERSON', label: '收件人', tag: 'button', type: 'primary', handler: () => handlePerson(row)
  },
  {
    key: 'DELETE', label: '删除', tag: 'popconfirm', type: 'danger',invisible:!isDEV,
    title: '确定删除吗?', handler: () => handleDelete(row)
  },
  {
    key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => handleView(row)
  },

]
const buttons: ButtonInfo[] = [
  {
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleAdd(),
  },
]
const ruleId = ref({})
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const search = async () => {
  // let templateNameOptions = await getTemplateNameOptions('email')
  // init();
  const res=searchForm.value;
  res['ruleType']='email'
  let result = await getQuartzList(res, page.value.currentPage, page.value.pageSize);
  let records = result.result;
  data.value = records.records;
      /*(records.records||"").map(item=>{
    const newObj= {
      ...item,
      businessLine:templateNameOptions.result.map(it=>{
        return it.value==item.businessLine?it.label:''
      }).filter(ite=>ite!='')[0],
      templateId:templateNameOptions.result.map(it=>{
        return it.value==item.templateId?it.label:''
      }).filter(ite=>ite!='')[0]
    }
    return newObj
  });*/
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;
}


onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

const {
  dialogData: dialogData2, open: open2, close: close2, closed: closed2
}: DialogForm<RkFormInstance, any> = useDialogForm('', {type: []})
//控制表单提交
const handleSave = async () => {
  if (tabsValue == '0') {
    //编辑
    dialogData.loading = true
    try {
      const valid = await dialogFormRef.value?.asyncValidate();
      if (valid){
        await edit(dialogForm.value);
        search();
        close();
        ElMessage.success('修改成功')
      }
    } finally {
      setTimeout(() => (dialogData.loading = false), 50)
    }
  } else if (tabsValue == '1') {
    //新增
    dialogData.loading = true
    try {
      const valid = await dialogFormRef.value?.asyncValidate();
      if (valid){
        const result=dialogForm.value
        result['ruleType']='email'
        await add(result);
        search();
        close();
        ElMessage.success('新增成功')
      }
    } finally {
      setTimeout(() => (dialogData.loading = false), 50)
    }
  }

}
//控制表单2提交
</script>

<style scoped></style>
