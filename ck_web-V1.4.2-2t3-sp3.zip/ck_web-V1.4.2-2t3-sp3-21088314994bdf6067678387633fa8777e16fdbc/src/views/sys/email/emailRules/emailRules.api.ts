import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";

enum Api {
    list = '/sysRule/list',
    add = '/sysRule/add',
    edit = '/sysRule/edit',
    delete = '/sysRule/delete',
    // getTemplateNameOptions = '/sysRule/getTemplateNameOptions',
}

/**
 * 修改
 * @param params
 */
export const edit = (data: any): Promise<RS> => {
    return service({
        url: Api.edit,
        method: 'POST',
        data,
    })
};
/**
 * 邮件、业务线、短信下拉框
 * @param params
 */
/*export const getTemplateNameOptions = (data:any): Promise<RS> => {
    return service({
        url: Api.getTemplateNameOptions,
        method: 'POST',
        data
    })
};*/

/**
 * 新增
 * @param params
 */
export const add = (data: any): Promise<RS> => {
    return service({
        url: Api.add,
        method: 'POST',
        data,
    })
};

/**
 * 查询规则列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
    return service({
        url: Api.list,
        method: 'POST',
        data,
        params: {pageNo, pageSize}
    })
};

//分页查询
export function searchList(data: any) {
    return service({
        url: Api.list,
        method: 'post',
        data,
        params: {...getCommonParams()}
    })
}

/**
 * 删除
 * @param params
 */
export function deleteRule(data: any) {
    return service({
        url: Api.delete,
        method: 'DELETE',
        data: data,
    })
};
