// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  list = '/emailConsignee/list',
  get = '/emailConsignee/queryById',
  delete = '/emailConsignee/delete',
  deleteBatch = '/emailConsignee/deleteBatch',
  addUser = '/oauthUser/addUser',
  add = '/emailConsignee/add',
  edit = '/emailConsignee/edit'
}
/**
 * 修改
 * @param params
 */
export const edit = (data: any): Promise<RS> => {
  return service({
    url: Api.edit ,
    method: 'POST',
    data,
    params: { ...getCommonParams()}
})
};
/**
 * 普通增加
 * @param params
 */
export const add = (data: any,ruleId: string): Promise<RS> => {
  return service({
    url: Api.add ,
    method: 'POST',
    data,
    params: { ...getCommonParams(),ruleId}
})
};
/**
/**
 * 增加用户
 * @param params
 */
export const addUser = (data: any,ruleId: string): Promise<RS> => {
  return service({
    url: Api.addUser + "?ids=" + data,
    method: 'POST',
    data,    
    params: {...getCommonParams(),ruleId}
})
};
/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize, ...getCommonParams()}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: { ...getCommonParams()}
  })
}


/**
 * 删除任务
 * @param params
 */
export function deleteQuartz(params: any) {
  return service({
    url: Api.delete,
    method: 'DELETE',
    params: params,
})
};
