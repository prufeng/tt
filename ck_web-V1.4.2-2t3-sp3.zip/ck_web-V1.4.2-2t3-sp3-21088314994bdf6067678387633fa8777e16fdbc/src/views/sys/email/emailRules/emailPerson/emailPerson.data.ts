import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
    // {key: 'id', type: 'selection'},
    // {prop: 'userName', label: '用户名称'},
    {prop: 'nickName', label: '昵称'},
    // {prop: 'roleName', label: '角色名称'},
    {prop: 'email', label: '邮箱'},
    {prop: 'ccEmail', label: '抄送人邮箱'},
    {prop: 'departmentCode', label: '部门编码',dictFormatKey:'departmentCode'},
    // {prop: 'systemCode', label: '所属系统',dictFormatKey: "systemCode"},
    {prop: 'branchCode', label: '所属机构',dictFormatKey:'branchTree'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        fixedWidth: 200,
        fixed: 'right',
    },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'nickName',
    label: '用户昵称',
    inputType: 'input',
    labelWidth: 100,
  },
  {
    prop: 'ruleId',
    label: '规则id',
    inputType: 'input',
    labelWidth: 100,
  },
];

export const formItems: FormItemInfo[] = [
    {prop: 'nickName', label: '昵称',labelWidth: 200, extra: {span: 24}, rules: [{required: true, message: '必填'}],},
    {prop: 'email', label: '邮箱(多个邮箱以英文;分隔)', labelWidth: 200,extra: {span: 24}, rules: [{required: true, message: '必填'},{}]},
    {prop: 'ccEmail', label: '抄送人邮箱(多个邮箱以英文;分隔)',labelWidth: 200, extra: {span: 24}, rules: [{required: false, message: '必填'}],},
    {prop: 'departmentCode', label: '部门编码',labelWidth: 200, extra: {span: 24},inputType: {
    tag: 'select',
        options: 'departmentCode',
},},
    {
        prop: 'branchCode',
        label: '所属机构',
        labelWidth: 200,
        extra: {span: 24},
        rules: [{required: true, message: '必填'}],
        inputType: {
            tag: 'tree-select',
            // options: 'branchTree',
            // showCheckbox: true,
            // checkStrictly: true,
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
            collapseTags: true,
            maxCollapseTags:1
        },
        extra: {span: 8},
    },
];
// {
//     key: 'BATCH_DELETE',
//     label: '批量删除',
//     tag: 'button',
//     type: 'danger',
//     icon: 'icon_delete',
//     handler: () => ElMessage.warning('批量删除'),
// },
export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 100,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}

// 字典
export const dictData = {
    "publishState": [
        {
            "label": "正常",
            "value": 0,
            "type": "publishState"
        },
        {
            "label": "停止",
            "value": -1,
            "type": "publishState"
        },
    ]
}
