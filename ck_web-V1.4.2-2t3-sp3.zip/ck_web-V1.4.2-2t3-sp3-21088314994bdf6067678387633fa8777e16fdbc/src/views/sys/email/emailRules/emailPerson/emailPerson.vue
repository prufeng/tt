<template>

  <!-- <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search" :label-width="50">


  </rk-search-form> -->

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page" @page-change="pageChange" @refresh="search">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
    </template>

    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
    </template>
  </rk-page-table>


  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" :close-on-click-modal="false">
    <!-- <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :disabled="dialogData.formDisabled" >
    </rk-detail-form> -->
    <el-tabs v-model="tabsValue" type="border-card" class="demo-tabs" >
    <el-tab-pane label="选择用户">
      <oauthUser ref="myComponent"/>
    </el-tab-pane>
    <el-tab-pane label="手动新增">
      <rk-detail-form ref="dialogFormRef2" v-model="dialogForm2" :form-items="formItems"  :disabled="dialogData2.formDisabled">
     </rk-detail-form>
  <!-- <template #footer>
    <span class="dialog-footer">
      <el-button v-if="!dialogData2.formDisabled" :loading="dialogData2.loading" type="primary" @click="handleSave2">
        确认
      </el-button>
      <el-button @click="close2"> 取消</el-button>
    </span>
  </template> -->
    </el-tab-pane>
  </el-tabs>
  <template #footer>
        <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
      </template>
  </el-dialog>
  <el-dialog v-model="dialogData2.visible" :title="dialogData2.title" class="rk-dialog-default" @closed="closed2" :close-on-click-modal="false">
    <!-- <questionList ref="myComponent"/> -->

    <rk-detail-form ref="dialogFormRef2" v-model="dialogForm2" :form-items="formItems"  :disabled="dialogData2.formDisabled">

    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData2.formDisabled" :loading="dialogData2.loading" type="primary" @click="handleSave2">
          保存
        </el-button>
        <el-button @click="close2"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
</script>

<script setup lang="ts">
import {provide,onMounted, ref} from 'vue'
import { ElDialog, ElButton, ElMessage, ElTabs, ElTabPane, ElLink } from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm,RS, RkDetailForm,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm
} from 'riking-ui'
import {columns, formItems, pagination,searchItems} from "@/views/sys/email/emailRules/emailPerson/emailPerson.data";
import {getQuartzList,addUser,deleteQuartz,searchList,add,edit } from '@/views/sys/email/emailRules/emailPerson/emailPerson.api'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm';
import oauthUser  from "@/views/sys/oauthUser/oauthUser.vue";
import {isEmpty} from "@/views/taf/utils";

useDict([], [], dictData);
const myComponent =  ref();
const { state, init, handlePageChange, handleSortChange, handleSelectionChange  } = useState(searchList)
const handleDelete = async (row: any) => {
  await deleteQuartz(row);
  ElMessage.success('删除成功');
  search();
}
const props = defineProps({
  prop1:String,
		})
let tabsValue = '0';
const handleEdit = async (row: any) => {
  open2(row,false,'编辑');
  search();
}
const handleAdd = async () => {
  open(undefined,false,"新增");
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  // {
  //   key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => {
  //     open(row, true, '查看');
  //   }
  // },
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => {
      if (!isEmpty(row.branchCode)) {
        row.branchCode = row.branchCode.split(',')
      }
      handleEdit(row)
    }
  },
  {
    key: 'DELETE', label: '删除',   tag: 'popconfirm',  type: 'danger',
        title: '确定删除吗?', handler: () => handleDelete(row)
  },

]
const buttons: ButtonInfo[] = [
  {
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleAdd(),
  },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const search = async () => {
  init();
  searchForm.value.ruleId = props.prop1;
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}

// useDict([], [], dictData);


onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

  const {
  dialogData: dialogData2, open: open2, close: close2, closed: closed2,
  form: dialogForm2,
  nameRef: dialogFormRef2,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef2', {type: []})
//控制表单提交
const handleSave = async () => {

  if(tabsValue == '0'){
    dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate();

    // const myPropName = await myComponent.value.onSelectionChange();
    const selectRowIds = myComponent.value.selectRowIds ;
    if (selectRowIds.length==0){
      ElMessage.warning('请至少选择一条数据')
    }else {
      await addUser(selectRowIds, searchForm.value.ruleId);
      search();
      close();
      ElMessage.success('新增成功')
    }

  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
  }else if(tabsValue == '1'){
    //弹出框的新增
    const valid = await dialogFormRef2.value?.asyncValidate();
    if (valid){
      const data = toRaw(dialogForm2.value);
      data.status = '1';
      data.branchCode = data.branchCode.toString()
      await add(data,searchForm.value.ruleId);
      close();
      await search();
    }

  }

}
//控制表单2提交
const handleSave2 = async () => {
  if(dialogData2.title == "编辑"){
    const valid = await dialogFormRef2.value?.asyncValidate();
  if (valid) {
    const data = toRaw(dialogForm2.value);
    data.status = '1';
    delete data.type;
    data.branchCode = data.branchCode.toString()
    await edit(data);
    close2();
    ElMessage.success('修改成功')
    await search();
  }
  }
}
</script>

<style scoped></style>
