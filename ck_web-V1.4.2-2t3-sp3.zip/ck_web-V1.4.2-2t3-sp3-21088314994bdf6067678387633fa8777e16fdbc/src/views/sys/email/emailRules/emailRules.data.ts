import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
/*import {getTemplateNameOptions} from "@/views/sys/email/emailRules/emailRules.api";
const templateNameOptions = await getTemplateNameOptions("email")*/
export const columns: TableColumnInfo[] = [
    /*{
        prop: '',
        label: '序号'
    },*/
    {
        prop: 'ruleName',
        label: '规则名称'
    },
    {
        prop: 'triggerConditions',
        label: '触发条件',
        dictFormatKey: "trigger_conditions"
    },
    /*{
        prop: 'businessLine',
        label: '业务线',
        dictFormatKey:"businessLine"
    },*/
    {
        prop: 'templateId',
        label: '模板名称',
        dictFormatKey:"templateId_email"
    },
    {
        prop: 'frequency',
        label: '发送频率',
        // dictFormatKey: "frequency"
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        fixedWidth: 200,
        fixed: 'right',
    },
];

export const searchItems: FormItemInfo[] = [
    {
        prop: 'triggerConditions',
        label: '触发条件',
        inputType: {
            tag: 'select',
            options: 'trigger_conditions',
            multiple: false,
        },
        extra: {span: 8},
    },
    /*{
        prop: 'businessLine',
        label: '业务线',
        inputType: {
            tag: 'select',
            // options: templateNameOptions.result.filter(f=>f.type=='businessLine'),
            options:'businessLine',
            multiple: false,
        },
        extra: {span: 8},
    },*/
];

export const formItems: FormItemInfo[] = [
    {
        prop: 'ruleName',
        label: '规则名称',
        rules: [{required: true, message: '必填'}],
        extra: {span: 8},
    },
    {
        prop: 'triggerConditions',
        label: '触发条件',
        inputType: {
            tag: 'select',
            options: 'trigger_conditions',
            multiple: false,
        },
        extra: {span: 8},
    },
    /*{
        prop: '',
        label: '系统',
        inputType: {
            tag: 'select',
            options: '',
            multiple: false,
        },
        extra: {span: 8},
    },*/
    /*{
        prop: 'branchCode',
        label: '所属机构',
        rules: [{required: false, message: '必填'}],
        inputType: {
            tag: 'tree-select',
            options: 'branchTree',
            showCheckbox: true,
            checkStrictly: true,
        },
        extra: {span: 8},
    },*/
    /*{
        prop: 'businessLine',
        label: '业务线',
        inputType: {
            tag: 'select',
            // options: templateNameOptions.result.filter(f=>f.type=='businessLine'),
            options: 'businessLine',
            multiple: false,
        },
        extra: {span: 8},
    },*/
    {
        prop: 'templateId',
        label: '模板名称',
        inputType: {
            tag: 'select',
            // options: templateNameOptions.result.filter(f=>f.type=='emailTemplateName'),
            options:'templateId_email',
            multiple: false,
        },
        rules: [{required: true, message: '必填'}],
        extra: {span: 8},
    },
    {
        prop: 'frequency',
        label: '发送频率',
        inputType: 'input',
        /*inputType: {
            tag: 'select',
            options: 'frequency',
            multiple: false,
        },*/
        rules: [{required: true, message: '必填'}],
        extra: {span: 8},
    },
    /*{
        prop: '',
        label: '邮件内容',
        scopedSlot: 'templateContent',
        extra: {span: 24},
    },*/
];

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 100,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}

// 字典
export const dictData = {
    "publishState": [
        {
            "label": "正常",
            "value": 0,
            "type": "publishState"
        },
        {
            "label": "停止",
            "value": -1,
            "type": "publishState"
        },
    ]
}
