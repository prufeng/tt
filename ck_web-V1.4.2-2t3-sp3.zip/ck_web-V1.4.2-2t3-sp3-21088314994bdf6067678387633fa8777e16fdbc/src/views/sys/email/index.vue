<template>
  <el-tabs type="border-card" class="demo-tabs">
    <el-tab-pane label="邮件模板管理">
      <emailTemplate />
    </el-tab-pane>
    <el-tab-pane label="发件人管理">
      <emailAddress />
    </el-tab-pane>
    <el-tab-pane label="邮件规则管理">
      <emailRules />
    </el-tab-pane>
    <!--    <el-tab-pane label="收件人配置">
      <emailPerson/>
    </el-tab-pane>-->
  </el-tabs>
</template>

<script setup lang="ts">
import emailRules from "@/views/sys/email/emailRules/emailRules.vue"
import emailTemplate from "@/views/sys/email/emailTemplate/emailTemplate.vue"
import emailAddress from "@/views/sys/email/emailAddress/emailAddress.vue"
import {ElTabs, ElTabPane} from 'element-plus'

</script>

<style scoped>
.demo-tabs {
  height: 100%;
  width: 100%;
}
</style>
