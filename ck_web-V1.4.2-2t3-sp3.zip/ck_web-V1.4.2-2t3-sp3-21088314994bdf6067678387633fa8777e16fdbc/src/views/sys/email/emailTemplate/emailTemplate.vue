<template>
  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search"
    :label-width="50">
    <!-- 自定义渲染 -->
    <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
    </template>
  </rk-search-form>

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page"
    @page-change="pageChange" @refresh="search" stripe @selection-change="handleSelectionChange"
    @sort-change="handleSortChange">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta" v-if="isDEV"></rk-button-group>
    </template>
    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta"
        link></rk-button-group>
    </template>
  </rk-page-table>
  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title"
    class="el-dialog rk-dialog-default" @closed="closed(formState.contents = '')">
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :disabled="dialogData.formDisabled">
      <template #templateContent>
        <TEditor ref="editor" v-model="formState.contents" @getContent="getContent" class="my-editor" />
        <!-- <ckeditor v-model="app_message" :editor="editor" :config="editorConfig"></ckeditor> dialogForm.templateContent-->
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;
</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage, ElLink } from 'element-plus'
import { useDict } from 'riking-layout'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm, RS, RkDetailForm,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm
} from 'riking-ui'
import {
  columns,
  formItems,

  pagination,
  searchItems
} from "@/views/sys/email/emailTemplate/emailTemplate.data";
import {
  getQuartzList,
  saveOrUpdateQuartz,
  deleteQuartz,
  searchList
} from '@/views/sys/email/emailTemplate/emailTemplate.api'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm';
import { Base64 } from 'js-base64';
import TEditor from "@/components/TEditor.vue";
import {isDEV} from "@/utils/request";

useDict([], [], dictData);
const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })
const formState = reactive({ contents: '' });

const getContent = (v: string) => {
  formState.contents = v
}

const { state, init, handlePageChange, handleSortChange, handleSelectionChange } = useState(searchList)
const handleDelete = async (id: any) => {
  await deleteQuartz(id);
  ElMessage.success('删除成功');
  search();
}
const handleEdit = async (row: any) => {
  // formState.contents =  btoa( row.templateContent);
  formState.contents = row.templateContent;
  open(row, false, '编辑');
  search();
}
// const handleAdd = async () => {
//   open(undefined,false,"新增");
//   search();
// }
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  // {
  //   key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => {
  //     open(row, true, '查看');
  //   }
  // },
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => handleEdit(row)
  },
  {
    key: 'DELETE', label: '删除', tag: 'popconfirm', type: 'danger',invisible:!isDEV,
    title: '确定删除吗?', handler: () => handleDelete(row.id)
  },

]
const buttons: ButtonInfo[] = [
  {
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleAdd(),
  },
]
const loading = ref(false)
const data = ref<any[]>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const search = async () => {
  init();
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;
}

// useDict([], [], dictData);


onMounted(() => {
  page.value = {...pagination}
  search();
})

const handleAdd = async () => {
  open(undefined, false, "新增");
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}


//控制表单提交
const handleSave = async () => {
  dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate();
    if (valid) {
      if (dialogData.title === "新增") {
        dialogForm._rawValue.templateContent = Base64.encode(formState.contents);
        await saveOrUpdateQuartz(dialogForm._rawValue, false);
        ElMessage.success('新增成功')
      } else {
        dialogForm._rawValue.templateContent = Base64.encode(formState.contents);
        await saveOrUpdateQuartz(dialogForm._rawValue, true);
        ElMessage.success('修改成功')
      }
      close();
      search();

    }
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}
</script>

<style scoped>
/* .el-dialog rk-dialog-small {
  width: 500px;
  } */
.my-editor {
  width: 100%;
}
</style>
