import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";

enum Api {
    list = '/emailTemplate/list',
    save = '/emailTemplate/add',
    edit = '/emailTemplate/edit',
    get = '/emailTemplate/queryById',
    delete = '/emailTemplate/delete',
    deleteBatch = '/emailTemplate/deleteBatch',
}

/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
    return service({
        url: Api.list,
        method: 'POST',
        data,
        params: {pageNo, pageSize, ...getCommonParams()}
    })
};

//分页查询
export function searchList(data: any) {
    return service({
        url: Api.list,
        method: 'post',
        data,
        params: {...getCommonParams()}
    })
}

/**
 * 保存或者更新任务
 * @param params
 */
export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
    let url = isUpdate ? Api.edit : Api.save;
    return service({
        url: url,
        method: 'POST',
        data,
    })
};

/**
 * 删除任务
 * @param params
 */
export function deleteQuartz(id: any) {
    return service({
        url: Api.delete,
        method: 'DELETE',
        params: {id:id},
    })
};




