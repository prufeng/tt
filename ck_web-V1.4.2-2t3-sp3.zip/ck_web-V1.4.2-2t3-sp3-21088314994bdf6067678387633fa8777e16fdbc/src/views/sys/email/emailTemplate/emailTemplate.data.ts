import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
import {isDEV} from "@/utils/request";

export const columns: TableColumnInfo[] = [
    // {key: 'id', type: 'selection'},
    {
        prop: 'templateName',
        label: '模板名称'
    },
    {
        prop: 'templateType',
        label: '模板类型',
        dictFormatKey: "email_template_type"
    },
    {
        prop: 'emailSubject',
        label: '邮件主题',
    },
    {
        prop: 'isEnabled',
        label: '启用',
        dictFormatKey: "enableStatus"
    },
    /*{
        prop: 'systemCode',
        label: '所属系统',
        dictFormatKey: "systemCode"
    },*/
    // {prop: 'createTime', label: '创建时间'},
    {
        prop: 'templateContent',
        label: '模板内容',
    },
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        fixedWidth: 200,
        fixed: 'right',
    },
];

export const searchItems: FormItemInfo[] = [
    {
        prop: 'templateName',
        label: '模板名称',
        inputType: 'input',
        labelWidth: 100,
    },
];

export const formItems: FormItemInfo[] = [
    {
        prop: 'templateName',
        label: '模板名称',
        inputType: {tag:'input',disabled: !isDEV},
        // required: true,
        rules: [{required: true, message: '必填'}],
        extra: {
            notModifiable: false,
            span: 24
        }
    },
    {
        prop: 'emailSubject',
        label: '邮件主题',
        inputType: 'input',
        rules: [{required: true, message: '必填'}],
        extra: {
            notModifiable: false,
            span: 24
        }
    },
    {
        prop: 'isEnabled',
        label: '启用',
        rules: [{required: true, message: '必填'}],
        inputType: {
            tag: 'select',
            options: 'enableStatus',
            multiple: false,
        },
        extra: {
            notModifiable: false,
            span: 24
        }
    },
    {
        prop: 'templateType',
        label: '模板类型',
        inputType: {
            tag: 'select',
            options: 'email_template_type',
            multiple: false,
            disabled:!isDEV,
        },
        extra: {
            notModifiable: false,
            span: 24
        }
    },
    {
        prop: 'templateContent',
        label: '模板内容',
        scopedSlot: 'templateContent',
        // rules: [{required: true, message: '必填'}],
        extra: {span: 24},
    },

];
// {
//     key: 'BATCH_DELETE',
//     label: '批量删除',
//     tag: 'button',
//     type: 'danger',
//     icon: 'icon_delete',
//     handler: () => ElMessage.warning('批量删除'),
// },
export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 100,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}

// 字典
export const dictData = {
    "publishState": [
        {
            "label": "正常",
            "value": 0,
            "type": "publishState"
        },
        {
            "label": "停止",
            "value": -1,
            "type": "publishState"
        },
    ]
}
