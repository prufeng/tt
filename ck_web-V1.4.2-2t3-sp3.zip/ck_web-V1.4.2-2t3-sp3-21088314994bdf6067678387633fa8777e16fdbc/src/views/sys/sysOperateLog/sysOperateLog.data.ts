import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
/*import {getTemplateNameOptions} from "@/views/sys/email/emailRules/emailRules.api";
const templateNameOptions = await getTemplateNameOptions("email")*/
export const columns: TableColumnInfo[] = [
    {
        prop: 'userName',
        label: '操作人'
    },
    // {
    //     prop: 'tenantCode',
    //     label: '租户编号'
    // },
    {
        prop: 'module',
        label: '操作模块名'
    },
    {
        prop: 'operationName',
        label: '操作名'
    },
    {
        prop: 'operationType',
        label: '操作分类'
    },
    {
        prop: 'requestMethod',
        label: '请求方法名'
    },
    {
        prop: 'requestUrl',
        label: '请求地址'
    },
    {
        prop: 'userIp',
        label: '用户 IP'
    },
    {
        prop: 'userAgent',
        label: '浏览器 UserAgent'
    },
    {
        prop: 'javaMethod',
        label: 'Java 方法名'
    },
    {
        prop: 'javaMethodArgs',
        label: 'Java 方法的参数'
    },
    {
        prop: 'startTime',
        label: '开始时间',
    },
    {
        prop: 'duration',
        label: '执行时长'
    },
    {
        prop: 'content',
        label: '内容'
    },
    {
        prop: 'resultCode',
        label: '结果码'
    },
    {
        prop: 'resultMsg',
        label: '结果提示'
    },
    {
        prop: 'resultData',
        label: '结果数据'
    },
    /*{
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        fixedWidth: 200,
        fixed: 'right',
    },*/
];

export const searchItems: FormItemInfo[] = [
    {
        prop: 'userName',
        label: '操作人'
    },
    // {
    //     prop: 'tenantCode',
    //     label: '租户编号'
    // },
    {
        prop: 'module',
        label: '操作模块名'
    },
    {
        prop: 'operationName',
        label: '操作名'
    }
];

export const formItems: FormItemInfo[] = [
    {
        prop: 'ruleName',
        label: '规则名称',
        rules: [{required: true, message: '必填'}],
        extra: {span: 8},
    },
    {
        prop: 'triggerConditions',
        label: '触发条件',
        rules: [{required: true, message: '必填'}],
        inputType: {
            tag: 'select',
            options: 'trigger_conditions',
            multiple: false,
        },
        extra: {span: 8},
    },
    /*{
        prop: '',
        label: '系统',
        inputType: {
            tag: 'select',
            options: '',
            multiple: false,
        },
        extra: {span: 8},
    },*/
    {
        prop: 'branchCode',
        label: '所属机构',
        rules: [{required: true, message: '必填'}],
        inputType: {
            tag: 'tree-select',
            options: 'branchTree',
            showCheckbox: true,
            checkStrictly: true,
        },
        extra: {span: 8},
    },
    {
        prop: 'businessLine',
        label: '业务线',
        inputType: {
            tag: 'select',
            // options: templateNameOptions.result.filter(f=>f.type=='businessLine'),
            options: 'businessLine',
            multiple: false,
        },
        extra: {span: 8},
    },
    {
        prop: 'templateId',
        label: '模板名称',
        inputType: {
            tag: 'select',
            // options: templateNameOptions.result.filter(f=>f.type=='emailTemplateName'),
            options:'templateId_email',
            multiple: false,
        },
        extra: {span: 8},
    },
    {
        prop: 'frequency',
        label: '发送频率',
        inputType: {
            tag: 'select',
            options: 'frequency',
            multiple: false,
        },
        extra: {span: 8},
    },
];

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 100,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}

// 字典
export const dictData = {
    "publishState": [
        {
            "label": "正常",
            "value": 0,
            "type": "publishState"
        },
        {
            "label": "停止",
            "value": -1,
            "type": "publishState"
        },
    ]
}
