<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" v-model="searchForm" @keyup.enter="search" :loading="loading"
      :form-items="searchItems" @search="search" :label-width="50">
      <!-- 自定义渲染 -->
      <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
    </rk-search-form>

    <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page"
      @page-change="pageChange" @refresh="search">
      <!--<template #tableTools>-->
      <!--  <el-link>自定义工具栏</el-link>-->
      <!--</template>-->
      <template #operations>
        <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
      </template>

      <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
      <template #url="{ row }">
        <el-link :href="row.url">{{ row.url }}</el-link>
      </template>

      <template #actions="{ row }">
        <rk-button-group :max="5" :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
      </template>
    </rk-page-table>
  </rk-index-layout>



  <!-- 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed"
    :close-on-click-modal="false">
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :disabled="dialogData.formDisabled">
      <!-- 自定义渲染 -->
      <template #cronExpression="{ item: i, form: f }">
        <el-input v-model="f[i.prop as string]" placeholder="请输入cron表达式">
          <template #append>
            <el-tooltip content="配置cron表达式" placement="top">
              <el-button @click="() => { isShowCronCore = !isShowCronCore }" :icon="ArrowDown" />
            </el-tooltip>
          </template>
        </el-input>
        <div style="width:100%;padding-left: 10px;margin-top: -5px;" v-show="isShowCronCore">
          <!-- <Vue3Cron @change="changeCron" v-model:value="dialogForm.cronExpression" /> -->
          <Crontab :expression="f[i.prop as string]" @hide="isShowCronCore = false" @fill="crontabFill"></Crontab>
        </div>
      </template>

    </rk-detail-form>

    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close">取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage, ElInput, ElTooltip, ElLink, ElFormItem } from 'element-plus'
import {
  RkIndexLayout, RkPageTable, RkButtonGroup, RkSearchForm, RkDetailForm,
  Pagination, ButtonInfo, RkFormInstance, useDialogForm
} from 'riking-ui'

import  Crontab from '@/components/Crontab/index.vue'
import { useDict } from 'riking-layout'
import { ArrowDown } from '@element-plus/icons-vue'
import { columns, formItems, pagination, searchItems } from "@/views/sys/quartz/quartz.data";
import { getQuartzList, saveOrUpdateQuartz, executeImmediately, resumeJob, deleteQuartz, searchList, pauseJob } from '@/views/sys/quartz/quartz.api'
import  DialogForm  from 'riking-ui/dist/hooks/useDialogForm';

useDict([], [], dictData);

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })


//是否打开cron表达式
const isShowCronCore = ref(true);

const crontabFill = (val) => {
  console.log(val);
  dialogForm._rawValue.cronExpression = val;
};


const { state, init } = useState(searchList)

const handleResume = async (row: any) => {
  await resumeJob(row);
  ElMessage.success('启用成功');
  search();
}
const handlePause = async (row: any) => {
  await pauseJob(row);
  ElMessage.success('禁用成功');
  search();
}
const handleExecute = async (row: any) => {
  await executeImmediately(row);
  ElMessage.success('立即执行成功');
  search();
}
const handleDelete = async (row: any) => {
  await deleteQuartz(row);
  ElMessage.success('删除成功');
  search();
}
const handleEdit = async (row: any) => {
  open(row, false, '编辑');
  // search();
}
const handleAdd = async () => {
  open(undefined, false, "新增");
  // search();
}
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  // {
  //   key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => {
  //     open(row, true, '查看');
  //   }
  // },
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => handleEdit(row)
  },
  {
    key: 'DELETE', label: '删除', tag: 'popconfirm', type: 'danger',
    title: '确定删除吗?', handler: () => handleDelete(row)
  },
  {
    key: 'STATUS', label: '启用', tag: 'button', type: 'primary', handler: () => handleResume(row), invisible: row.status == "1" ? true : false
  },
  {
    key: 'STATUS', label: '禁用', tag: 'button', type: 'primary', handler: () => handlePause(row), invisible: row.status == "0" ? true : false
  },
  {
    key: 'EXECUTE', label: '立即执行', tag: 'button', type: 'primary', handler: () => handleExecute(row)
  },
]
const buttons: ButtonInfo[] = [
  {
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => handleAdd(),
  },
]
const loading = ref(false)
const data = ref<any[]>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})

const search = async () => {
  init();
  console.log(searchForm.value);
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  console.log(result.result);
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}



onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}


//控制表单提交
const handleSave = async () => {
  dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate();
    console.log(dialogForm._rawValue.jobClassName);
    console.log('value12', dialogForm.value);

    if (dialogForm._rawValue.cronExpression=="" || dialogForm._rawValue.cronExpression == undefined ){
      ElMessage.error({message: 'cron表达式不可为空',grouping: true, duration: 0, showClose: true});
      return
    }
    if (valid) {
      if (dialogData.title === "新增") {
        await saveOrUpdateQuartz(dialogForm._rawValue, false);
        ElMessage.success('新增成功');
      } else {
        await saveOrUpdateQuartz(dialogForm._rawValue, true);
        ElMessage.success('编辑成功');
      }
      close();
      search();
    }

  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}
</script>

<style scoped></style>
