
import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  list = '/sys/quartzJob/list',
  save = '/sys/quartzJob/add',
  edit = '/sys/quartzJob/edit',
  get = '/sys/quartzJob/queryById',
  pause = '/sys/quartzJob/pause',
  resume = '/sys/quartzJob/resume',
  delete = '/sys/quartzJob/delete',
  exportXlsUrl = '/sys/quartzJob/exportXls',
  importExcelUrl = '/sys/quartzJob/importExcel',
  execute = '/sys/quartzJob/execute',
  deleteBatch = '/sys/quartzJob/deleteBatch',
}

/**
 * 导出api
 */
export const getExportUrl = Api.exportXlsUrl;
/**
 * 导入api
 */
export const getImportUrl = Api.importExcelUrl;
/**
 * 查询任务列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize,...getCommonParams()}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: {...getCommonParams()}
  })
}

/**
 * 保存或者更新任务
 * @param params
 */
export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
  console.log(data);
  let url = isUpdate ? Api.edit : Api.save;
  return service({
    url: url,
    method: 'POST',
    data,
    params: {...getCommonParams()}
})
};


/**
 * 删除任务
 * @param params
 */
export const deleteQuartz = (data: any) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    data: data,
    params: {id :data.id,...getCommonParams()}
})
};

/**
 * 启动
 * @param params
 */
export const resumeJob = (data: any) => {
  return service({
    url: Api.resume,
    method: 'GET',
    params: data
})
};
/**
 * 停止
 * @param params
 */
export const pauseJob = (data: any) => {
  return service({
    url: Api.pause,
    method: 'GET',
    params: data
})
};

/**
 * 立即执行
 * @param params
 */
export const executeImmediately = (data: any) => {
  return service({
    url: Api.execute,
    method: 'GET',
    params: data
})
  // return defHttp.get({ url: Api.execute, params }).then(() => {
  //   handleSuccess();
  // });
};
