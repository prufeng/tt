import {FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
export const columns: TableColumnInfo[] = [
  // {key: 'id', type: 'selection'},
  {prop: 'jobName', label: '任务名称',fixedWidth: 200},
  {prop: 'jobClassName', label: '任务类名',fixedWidth: 400},
  {prop: 'cronExpression', label: 'Cron表达式'},
  {prop: 'parameter', label: '参数'},
  {prop: 'description', label: '描述'},
  {prop: 'status', label: '状态',dictFormatKey: 'quartzStatus'},
  {
    prop: 'systemCode',
    label: '所属系统',dictFormatKey: "systemCode"
  },
  {
      key: 'actions',
      label: '操作',
      scopedSlots: 'actions',
      fixedWidth: 200,
      fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'systemCode',
    label: '所属系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },  
    labelWidth: 100
  },
  {prop: 'jobName', label: '任务名称',inputType: 'input',
  labelWidth: 100,},
  {
    prop: 'jobClassName',
    label: '任务类名',
    inputType: 'input',
    labelWidth: 100,
  },
  {
    prop: 'status',
    label: '任务状态',
    labelWidth: 100,
    inputType: {
      tag: 'select',
      options: 'quartzStatus',
      // multiple: true,
  },
  },
];

export const formItems: FormItemInfo[] = [
  {prop: 'jobName', label: '任务名称',inputType: 'input',
  rules: [{ required: true, message: '必填' }],},
  {
    prop: 'systemCode',
    label: '所属系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },  
    labelWidth: 100,
    rules: [{ required: true, message: '所属系统必填' }],},
  {
    prop: 'jobClassName',
    label: '任务类名',
    inputType: 'input',
    rules: [{ required: true, message: '必填' }],
  },
  {
    prop: 'parameter',
    label: '参数',
    inputType:'input' 
  },
  {
    prop: 'status',
    label: '任务状态',
    inputType: {
      tag: 'select',
      options: 'quartzStatus',
  },
  rules: [{ required: true, message: '必填' }],
  },

  {
    prop: 'description',
    label: '描述',
    inputType: {
      tag: 'input', type: 'textarea', maxlength: '30'
    },
    // component: 'InputTextArea',
  },
  {
    prop: 'cronExpression',
    label: 'Cron表达式',
    inputType:'input',
    scopedSlot: 'cronExpression',
    extra: { span: 24 },
  },
];

export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 30,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
  "publishState": [
    {
      "label": "正常",
      "value": "1",
      "type": "publishState"
    },
    {
      "label": "停止",
      "value": "0",
      "type": "publishState"
    },
  ],
   
}