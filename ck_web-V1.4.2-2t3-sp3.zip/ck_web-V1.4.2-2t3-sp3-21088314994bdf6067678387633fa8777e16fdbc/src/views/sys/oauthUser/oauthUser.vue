<template>
  <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search"
    :label-width="50">
    <!-- 自定义渲染 -->
    <!--<template #dynamic="{ item: i, form: f }"> <rk-input v-model="f[i.prop as string]"></rk-input> </template>-->
  </rk-search-form>

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data"
     @refresh="search" stripe
    @sort-change="handleSortChange" @selection-change="selectionChange">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="['ADD', 'DELETE_BATCH']"></rk-button-group>
    </template>

    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>

    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="['EDIT', 'DELETE', 'EXECUTE', 'STATUS']"
        link></rk-button-group>
    </template>
  </rk-page-table>


  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title"
    class="rk-dialog-default" @closed="closed">
    <!-- <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :disabled="dialogData.formDisabled" >
    </rk-detail-form> -->
    <index />
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElMessage } from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkCollapseForm, RkButtonGroup, RkSearchForm, RS,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm
} from 'riking-ui'
import { columns, formItems, pagination, searchItems } from "@/views/sys/oauthUser/oauthUser.data";
import { saveOrUpdateQuartz, deleteQuartz, searchList } from '@/views/sys/oauthUser/oauthUser.api'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm';
import index from "@/views/sys/email/emailRules/emailPerson/emailPerson.vue";
const { state, init, handlePageChange, handleSortChange, handleSelectionChange } = useState(searchList)
const handleDelete = async (row: any) => {
  await deleteQuartz(row);
  ElMessage.success('删除成功');
  search();
}
// const propName = ref("hello world");
let propName = state.selectedRows.map((item) => item.id);
const onSelectionChange = async () => {
  propName = state.selectedRows.map((item) => item.id);
  return propName;
}

const selectRowIds = ref([]);
const selectionChange = async (val: any) => {
  selectRowIds.value = val.map((item: any) => item.id);
}

defineExpose({ selectRowIds })
// defineExpose({ onSelectionChange, propName })


// const handleEdit = async (row: any) => {
//   open(row,false,'编辑');
//   search();
// }
// const handleAdd = async () => {
//   open(undefined,false,"新增");
//   search();
// }
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [

  {
    key: 'DELETE', label: '删除', tag: 'popconfirm', type: 'danger',
    title: '确定删除吗?', handler: () => handleDelete(row)
  },

]
const buttons: ButtonInfo[] = [
  // {
  //   key: 'add',
  //   label: '新增',
  //   tag: 'button',
  //   type: 'primary',
  //   icon: 'icon_add',
  //   handler: () => handleAdd(),
  // },
]
const loading = ref(false)
const data = ref<any[]>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
const search = async () => {
  init();
  let result = await searchList(searchForm.value);
  data.value = result.result;
}

useDict([], [], dictData);


onMounted(() => {
  page.value = {...pagination}
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

//控制表单提交
const handleSave = async () => {
  dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate();

    if (valid) {
      if (dialogData.title === "新增") {
        await saveOrUpdateQuartz(dialogForm._rawValue, false);
        ElMessage.success('新增成功')
      } else {
        await saveOrUpdateQuartz(dialogForm._rawValue, true);
        ElMessage.success('修改成功')
      }
    }
    close();

  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}
</script>

<style scoped></style>