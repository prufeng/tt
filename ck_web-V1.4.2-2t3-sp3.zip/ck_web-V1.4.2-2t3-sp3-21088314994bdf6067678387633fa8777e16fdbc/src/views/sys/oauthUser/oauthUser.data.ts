import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
  {key: 'id', type: 'selection'},
  {prop: 'username', label: '用户名称'},
  {prop: 'nickname', label: '昵称'},
  {prop: 'userTypeCode', label: '用户类型'},
  {prop: 'email', label: '邮箱'},
  {prop: 'phoneNumber', label: '手机号码'},
  {prop: 'flowStatus', label: '数据状态'},
  {prop: 'branchCodeBelong', label: '所属机构',dictFormatKey:'branchTree'},
  {prop: 'enableStatus', label: '启用状态',dictFormatKey: 'userEnableStatus'},
 
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'branchCodes',
    label: '机构',
    labelWidth: 100,
    inputType: {
      tag: 'tree-select',
      options: 'branchCode',
      multiple: true,
      showCheckbox: true,
      checkStrictly: true,
      collapseTags: true,
      maxCollapseTags: 1,
    },
  },
  {
    prop: 'nickname',
    label: '昵称',
    inputType: 'input',
    labelWidth: 100,
  },
  {
    prop: 'username',
    label: '用户名称',
    inputType: 'input',
    labelWidth: 100,
  },
];

export const formItems: FormItemInfo[] = [

];
  // {
  //     key: 'BATCH_DELETE',
  //     label: '批量删除',
  //     tag: 'button',
  //     type: 'danger',
  //     icon: 'icon_delete',
  //     handler: () => ElMessage.warning('批量删除'),
  // },
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
  "publishState": [
    {
      "label": "正常",
      "value": 0,
      "type": "publishState"
    },
    {
      "label": "停止",
      "value": -1,
      "type": "publishState"
    },
  ]
}