// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  list = '/quartzRecord/list',
  getError = '/sys-quartz-job-record-detail/list',
  get = '/quartzRecord/queryById',
  delete = '/quartzRecord/delete',
  deleteBatch = '/quartzRecord/deleteBatch',
  addUser = '/quartzRecord/addUser',
  jobList='/sys/quartzJob/listBySystem'
}
/**
 * 查询任务列表
 * @param params
 */
export const getJobList = (): Promise<RS> => {
  return service({
    url: Api.jobList,
    method: 'POST',
    // params: {...getCommonParams()}
})
};
/**
 * 查询任务列表
 * @param params
 */
export const getErrorList = (data: any,pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.getError,
    method: 'POST',
    data,
    // params: {...getCommonParams()}
})
};
/**
 * 查询列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize,...getCommonParams()}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: {...getCommonParams()}
  })
}
/**
 * 删除任务
 * @param params
 */
export const deleteQuartz = (data: any) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    data: data,
    params: data
})
  // return defHttp.delete({ url: Api.delete, data: params }, { joinParamsToUrl: true }).then(() => {
  //   handleSuccess();
  // });
};
