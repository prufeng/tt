<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" @keyup.enter="search" v-model="searchForm" :loading="loading"
      :form-items="searchItems" @search="search" :label-width="50">
      <!-- 自定义渲染 -->
      <template #jobName="{ item: i, form: f }"> <el-select filterable clearable placeholder="请选择定时任务名"
          v-model="f[i.prop as string]">
          <el-option v-for="job in jobList" :key="job" :label="job" :value="job">
          </el-option>
        </el-select> </template>
    </rk-search-form>

    <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page"
      @page-change="pageChange" @refresh="search" stripe @selection-change="handleSelectionChange"
      @sort-change="handleSortChange">
      <!--<template #tableTools>-->
      <!--  <el-link>自定义工具栏</el-link>-->
      <!--</template>-->
      <template #operations>
        <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
      </template>
      <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
      <template #url="{ row }">
        <el-link :href="row.url">{{ row.url }}</el-link>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
      </template>
    </rk-page-table>
  </rk-index-layout>


  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title"
    class="rk-dialog-default" @closed="closed">
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :disabled="dialogData.formDisabled">
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <!-- <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          确认
        </el-button> -->
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>

  <el-dialog :close-on-click-modal="false" v-model="dialogData2.visible" :title="dialogData2.title"
    class="rk-dialog-default" @closed="closed2">
    <!--    <rk-detail-form ref="dialogFormRef2" v-model="dialogForm2" :form-items="formItems2" :disabled="dialogData2.formDisabled" >
    </rk-detail-form>-->
    <rk-page-table ref="tableRef2" :loading="state.loading" :columns="columns2" :data="data2" :pagination="page"
      @page-change="pageChange" @refresh="search" stripe @selection-change="handleSelectionChange"
      @sort-change="handleSortChange" hidden-table-tools>
      <!--<template #tableTools>-->
      <!--  <el-link>自定义工具栏</el-link>-->
      <!--</template>-->
      <template #operations>
        <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
      </template>
      <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
      <template #url="{ row }">
        <el-link :href="row.url">{{ row.url }}</el-link>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
      </template>
    </rk-page-table>
    <template #footer>
      <span class="dialog-footer">
        <!-- <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          确认
        </el-button> -->
        <el-button @click="close2"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
import useDictsStore from '@/store/dictStore';
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElDialog, ElButton, ElSelect, ElOption, ElLink, ElFormItem } from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkButtonGroup, RkSearchForm, RS, RkDetailForm,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm, RkIndexLayout
} from 'riking-ui'
import { columns, columns2, formItems, pagination, searchItems } from "./quartzRecord.data";
import { getQuartzList, searchList, getJobList, getErrorList } from './quartzRecord.api'
import { DialogForm } from 'riking-ui/dist/hooks/useDialogForm';

useDict([], [], dictData);
const { state, init, handleSortChange, handleSelectionChange } = useState(searchList)

const handleDetail = async (row: any) => {
  open(row, true, '查看');
}
const handleError = async (row: any) => {
  const result = await getErrorList({ parentId: row.id }, page2.value.currentPage, page2.value.pageSize)
  data2.value = result.result.records
  let records = result.result;
  page2.value.currentPage = records.current;
  page2.value.pageSize = records.size;
  page2.value.total = records.total;
  open2('', true, '异常信息');
}
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => {
      handleDetail(row);
    }
  },
  {
    key: 'ERROR', label: '异常信息', tag: 'button', type: 'primary', invisible: row.result == '0', handler: () => {
      handleError(row);
    }
  },

]
const buttons: ButtonInfo[] = [

]
const loading = ref(false)
const data = ref<any[]>([]);
const data2 = ref<any[]>([]);
const page = ref<Pagination>(pagination)
const page2 = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
let jobList: any[] = [];
const search = async () => {
  init();
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}



onMounted(async () => {
  let jobListResult = await getJobList();
  jobList = jobListResult.result;
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

const {
  dialogData: dialogData2, open: open2, close: close2, closed: closed2,
  form: dialogForm2,
  nameRef: dialogFormRef2
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef2', { type: [] })
</script>

<style scoped></style>