import { FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";



export const columns: TableColumnInfo[] = [
  // {key: 'id', type: 'selection'},
  {prop: 'jobName', label: '定时任务名称'},
  {prop: 'description', label: '定时任务描述'},
  {prop: 'beginDate', label: '执行开始时间'},
  {prop: 'endDate', label: '执行结束时间'},
  {
    prop: 'duration',
    label: '持续时间',
  },
  {
    prop: 'totalNum',
    label: '执行总记录数',
    inputType:'input' 
  },
  {
    prop: 'successNum',
    label: '成功记录数',
    inputType:'input' 
  },
  {
    prop: 'failNum',
    label: '失败记录数',
    inputType:'input' 
  },

  {
    prop: 'result',
    label: '执行结果',
    inputType: 'input',
    dictFormatKey: "zxjg"
  },
  {
    prop: 'systemCode',
    label: '所属系统',
    inputType: 'input',
    dictFormatKey: "systemCode"
  },
  // {
  //   prop: 'createdBy',
  //   label: '创建人',
  //   inputType: 'input'
  // },
  // {
  //   prop: 'createTime',
  //   label: '创建时间',
  //   inputType: 'input'
  // },
  // {
  //   prop: 'updatedBy',
  //   label: '修改人',
  //   inputType: 'input'
  // },
  // {
  //   prop: 'updateTime',
  //   label: '修改时间',
  //   inputType: 'input'
  // },
  {
      key: 'actions',
      label: '操作',
      scopedSlots: 'actions',
      fixedWidth: 200,
      fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'systemCode',
    label: '所属系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },  
    labelWidth: 100
  },
  {
    prop: 'jobName',
    label: '定时任务名称',
    /*inputType: {
      tag: 'select',
      options: 'zxjg-dsrw',
  },*/
    labelWidth: 100,
    scopedSlot: 'jobName'
  },
  {
    prop: 'result',
    label: '执行结果',
    labelWidth: 100,
    inputType: {
      tag: 'select',
      options: 'zxjg-dsrw',
  },

  },
];

export const formItems: FormItemInfo[] = [
  {prop: 'jobName', label: '定时任务名称'},
  {prop: 'description', label: '定时任务描述'},
  {prop: 'beginDate', label: '执行开始时间'},
  {prop: 'endDate', label: '执行结束时间'},
  {
    prop: 'duration',
    label: '持续时间',
  },
  {
    prop: 'totalNum',
    label: '执行总记录数',
    inputType:'input' 
  },
  {
    prop: 'successNum',
    label: '成功记录数',
    inputType:'input' 
  },
  {
    prop: 'failNum',
    label: '失败记录数',
    inputType:'input' 
  },

  {
    prop: 'result',
    label: '执行结果',
    inputType: {
      tag: 'select',
      options: 'zxjg-dsrw',
    },
  },
  {
    prop: 'systemCode',
    label: '所属系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },
  },
  {prop: 'errorMessage',
   label: '异常信息', 
    inputType:{
       tag: 'input', type: 'textarea'
      },
   extra: { span: 18 },
    },
      
];
export const columns2: TableColumnInfo[]  = [
  {
    prop: 'qqdbs',
    label: '请求单标识',
    inputType:'input'
  },
  {
    prop: 'rwlsh',
    label: '任务流水号',
    inputType:'input'
  },
  {
    prop: 'errorMessage',
    label: '异常信息',
    inputType:{
      tag: 'input', type: 'textarea'
    },
    // extra: { span: 18 },
  },
  {
    prop: 'systemCode',
    label: '系统编号',
    inputType:'input'
  },
];
export const formItems3: FormItemInfo[] = [
  // {
  //   prop: 'jobClassName',
  //   label: '任务类名',
  //   inputType: 'input',
  //   required: true,
  // },
  {prop: 'phone', label: '接收人手机号',  inputType:'input' },
  {
    prop: 'systemCode',
   labelWidth: 150,
    label: '所属系统',
    inputType: {
      tag: 'select',
      options: 'systemType',
    },
  },
  {
    prop: 'credateBy',
    label: '创建人',
    inputType:'input' 
  },
  {
    prop: 'createTime',
    label: '创建时间',
    inputType:'input' 
  },
  {
    prop: 'updateBy',
    label: '更新人',
    inputType:'input' 
  },

  {
    prop: 'updateTime',
    label: '更新时间',
    inputType: 'input'
  },
  {
    prop: 'isSend',
    label: '发送状态',
    inputType: {
      tag: 'select',
      options: 'isSend',
      // multiple: true,
  },
  },
  {
    prop: 'templateModel',
    label: '模板参数',
    inputType: 'input'
  },
  {
    prop: 'templateContent',
    label: '模板内容',
    scopedSlot: 'templateContent',
    extra: { span: 24 },
  },
      
];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
}