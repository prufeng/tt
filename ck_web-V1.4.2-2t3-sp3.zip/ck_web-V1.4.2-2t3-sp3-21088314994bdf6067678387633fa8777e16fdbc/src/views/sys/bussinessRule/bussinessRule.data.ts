import { FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";



export const columns: TableColumnInfo[] = [
  // {key: 'id', type: 'selection'},
  {prop: 'tableName', label: '反馈表名称',dictFormatKey:"tableNameLabel"},
  {prop: 'tableName', label: '反馈表名称'},
  {prop: 'queryCondition', label: '查询条件'},
  {
    prop: 'subSystemcode',
    label: '系统名称',
    inputType: 'input',
    dictFormatKey: "systemCode"
  },
  {
      key: 'actions',
      label: '操作',
      scopedSlots: 'actions',
      fixedWidth: 200,
      fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'subSystemcode',
    label: '系统名称',
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },  
    labelWidth: 100
  },
  {
    prop: 'businesslineCode',
    label: '业务线CODE',
    inputType: 'input',
    labelWidth: 100,
  },
  
];

export const formItems: FormItemInfo[] = [
  {
    prop: 'subSystemcode',
    label: '系统名称',
    // inputType: {
    //   tag: 'select',
    //   options: 'systemCode',
    // },  
    scopedSlot: 'systemCode',
    labelWidth: 100
  },
  {
    prop: 'tableName',
    label: '反馈表名称',
    scopedSlot: 'tableName',
    rules: [{required: true, message: '必填'}],
    labelWidth: 100
  },
  {
    prop: 'queryCondition',
    label: '查询条件',
    inputType:{
      tag: 'input', type: 'textarea'
     },
    // rules: [{required: true, message: '必填'}],
    labelWidth: 100
  },
  {
    prop: 'businesslineCode',
    scopedSlot:'businesslineCode',
    labelWidth: 100,
  },
];
export const formItems2: FormItemInfo[] = [
  {
    prop: 'subSystemcode',
    label: '系统名称',
    // inputType: {
    //   tag: 'select',
    //   options: 'systemCode',
    // },
    scopedSlot: 'systemCode',
    labelWidth: 100
  },
  {
    prop: 'queryCondition',
    label: '查询条件',
    inputType:{
      tag: 'input', type: 'textarea'
    },
    // rules: [{required: true, message: '必填'}],
    labelWidth: 100
  },
  {
    prop: 'tableName',
    label: '反馈表名称',
    scopedSlot: 'tableName',
    labelWidth: 100,
    extra:{span: 24},
  },
  {
    prop: 'businesslineCode',
    scopedSlot:'businesslineCode',
    labelWidth: 100,
  },
];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
}