// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  list = '/sys-bussiness-rule/list',
  edit = '/sys-bussiness-rule/edit',
  save = '/sys-bussiness-rule/add',
  get = '/sys-bussiness-rule/queryById',
  delete = '/sys-bussiness-rule/delete',
  deleteBatch = '/sys-bussiness-rule/deleteBatch',
  jobList='/sys/quartzJob/listBySystem',
  tableList = '/sys-table-list/list'
}
/**
 * 查询列表名表
 * @param params
 */
export const getTableNameList = (systemCode: string): Promise<RS> => {
  console.log("11" + systemCode);
  return service({
    url: Api.tableList,
    method: 'POST',
    params: {"systemCode": systemCode}
  })
};

/**
 * 保存或者更新
 * @param params
 */
export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
  console.log(data);
  let url = isUpdate ? Api.edit : Api.save;
  return service({
    url: url,
    method: 'POST',
    data,
  })
};

/**
 * 查询任务列表
 * @param params
 */
export const getJobList = (): Promise<RS> => {
  return service({
    url: Api.jobList,
    method: 'POST',
    params: {...getCommonParams()}
})
};
/**
 * 查询列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize,...getCommonParams()}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: {...getCommonParams()}
  })
}
/**
 * 删除任务
 * @param params
 */
export const deleteQuartz = (data: any) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    params: {id : data.id}
})
  // return defHttp.delete({ url: Api.delete, data: params }, { joinParamsToUrl: true }).then(() => {
  //   handleSuccess();
  // });
};
