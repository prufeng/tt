<template>

  <!-- <rk-search-form ref="searchFormRef" @keyup.enter="search" v-model="searchForm" :loading="loading" :form-items="searchItems" @search="search" :label-width="50">

  </rk-search-form> -->

  <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page" @page-change="pageChange" @refresh="search"
  stripe
    @selection-change="handleSelectionChange"
    @sort-change="handleSortChange">
    <!--<template #tableTools>-->
    <!--  <el-link>自定义工具栏</el-link>-->  
    <!--</template>-->
    <template #operations>
      <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
    </template>
    <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
    <template #url="{ row }">
      <el-link :href="row.url">{{ row.url }}</el-link>
    </template>
    <template #actions="{ row }">
      <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" link></rk-button-group>
    </template>
  </rk-page-table>

  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" >
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :disabled="dialogData.formDisabled" >
      <template #systemCode="{ item: i, form: f }">
        <el-select v-model="f[i.prop as string]" :disabled=true filterable  remote :remote-method="remoteMethod" :loading="loading" style="width: 100%" >
              <el-option v-for="dict in dictData.systemCode" :key="dict.value" :label="dict.label" :value="dict.value"/>
            </el-select>
       </template>
       <template #tableName="{ item: i, form: f }" >
        <el-select v-model="f[i.prop as string]" :disabled=true filterable  remote  :loading="loading"  style="width: 100%">
          <el-option v-for="item in tableNameList" :key="item.tableName" :label="item.remarks"
          :value="item.tableName" />
            </el-select>
       </template>
      <template #businesslineCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop as string]"  v-show="false"></el-input>
       </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          保存
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog :close-on-click-modal="false" v-model="dialogData2.visible" :title="dialogData2.title" class="rk-dialog-default" @closed="closed2" >
    <rk-detail-form ref="dialogFormRef2" v-model="dialogForm2" :form-items="formItems2" :disabled="dialogData2.formDisabled" >
      <template #systemCode="{ item: i, form: f }">
        <el-select v-model="f[i.prop as string]" :disabled=true filterable  remote :remote-method="remoteMethod" :loading="loading" style="width: 100%" >
          <el-option v-for="dict in dictData.systemCode" :key="dict.value" :label="dict.label" :value="dict.value"/>
        </el-select>
      </template>
      <template #tableName="{ item: i, form: f }">
        <el-transfer
            v-model="f[i.prop as string]"
            filterable
            @mouseover="addSupTitle"
            filter-placeholder="搜索"
            :data="tableNameList"
            :titles="['未选', '已选']"
        />
      </template>
      <template #businesslineCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop as string]"  v-show="false"></el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData2.formDisabled" :loading="dialogData2.loading" type="primary" @click="handleSave2">
          保存
        </el-button>
        <el-button @click="close2"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
  import useDictsStore from '@/store/dictStore';
import { login } from '@/apis/oauth';
  const dictsStore = useDictsStore();
  const dictData = await dictsStore.getDict;

</script>
<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton} from 'element-plus'
// import {useDict} from 'riking-layout'
import {
  RkPageTable, RkButtonGroup, RkSearchForm,RS,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm
} from 'riking-ui'
import {columns, formItems, formItems2, pagination, searchItems} from "./bussinessRule.data";
import {getQuartzList,searchList,getJobList,saveOrUpdateQuartz,deleteQuartz,getTableNameList } from './bussinessRule.api'
import {DialogForm} from 'riking-ui/dist/hooks/useDialogForm';
useDict([], [], dictData);
const { state, init, handleSortChange, handleSelectionChange  } = useState(searchList)
//穿梭框逻辑
interface Option {
  key: string
  label: string
  // disabled: boolean
}
const handleEdit = async (row: any) => {
  getTableNameList(row.subSystemcode).then(res => {
      tableNameList.value = res.result
     })
    open(row, false, '编辑');
}

// const props = defineProps(['prop1'])
const props = defineProps({
  prop1:String,
  prop2:String
		})
const handleDel = async (row: any) => {
  await deleteQuartz(row);
  search();
  ElMessage.success("删除成功");
}
const addSupTitle=(e)=> {
  const target = e.target
  if (target.title) return
  target.title = target.innerText
}
const generateData = async () => {
  let data: Option[] = [];
  let tableNameListResult = await getTableNameList(props.prop2)
  let tableNameList = tableNameListResult.result;
  const copyTableNameList=tableNameList.filter(f=>
      !(f.subSystemcode=='jcy'&&f.tableName=='t_jcy_fk_payment_detail')&&
      !(f.subSystemcode=='gjw'&&f.tableName=='t_gjw_fk_freeze_detail'||f.tableName=='t_gjw_fk_payment_detail')&&
      !(f.subSystemcode=='nsa'&&f.tableName=='t_nsa_fk_freeze_detail'||f.tableName=='t_nsa_fk_payment_detail')&&
      !(f.subSystemcode=='zyjw'&&f.tableName=='t_zyjw_fk_freeze_detail'||f.tableName=='t_zyjw_fk_payment_detail')&&
      !(f.subSystemcode=='taf'&&f.tableName=='t_taf_list_black'||f.tableName=='t_taf_list_compare'||f.tableName=='t_taf_list_gray'||f.tableName=='t_taf_receive_record'))
  copyTableNameList.map((tableName: any) => (
      data.push({
        key: tableName.tableName,
        label: tableName.remarks,
      })
  ));
  return data
}
const fetchData = async () => {
  const generatedData = await generateData();
  tableNameList.value = generatedData;
};
const handleAdd = async () => {
  const tableNameList=await searchTableName();
  dialogForm2._rawValue.tableName=tableNameList
  dialogForm2._rawValue.subSystemcode = props.prop2;
  fetchData()
  open2(dialogForm2._rawValue,false,"新增规则表");
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
{
    key: 'EditRule', label: '编辑', tag: 'button', type: 'primary', handler: () => {
      handleEdit(row);
    }
  },
  {
    key: 'deleterule', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
    handler: () => handleDel(row)
  },
]
const buttons: ButtonInfo[] = [
{
    key: 'addrule',
    label: '新增规则表',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => {
      handleAdd()
    }
  },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
const tableNameList = ref<any[]>([])
const search = async () => {
  // init();
  searchForm.value.businesslineCode = props.prop1;
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  let records = result.result;
  data.value = records.records;
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;

}
const searchTableName = async () => {
  searchForm.value.businesslineCode = props.prop1;
  let result = await getQuartzList(searchForm.value, 1, 99999);
  let records = result.result.records;
  return records.map(item=>item.tableName)
}

const remoteMethod = (query: string) => {

    loading.value = true;
    console.log(dialogForm._rawValue.subSystemcode);
    // setTimeout(() => {
      loading.value = false
     getTableNameList(dialogForm._rawValue.subSystemcode).then(res => {
      console.log(res.result);
      tableNameList.value = res.result
     })
      // options.value = list.value.filter((item) => {
      //   return item.label.toLowerCase().includes(query.toLowerCase())
      // })
    // }, 200)
 
}
//控制表单提交
const handleSave = async () => {
  dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate();
    if (valid) {
      if (dialogData.title === "新增") {
        dialogForm._rawValue.businesslineCode = searchForm.value.businesslineCode;
        await saveOrUpdateQuartz(dialogForm._rawValue, false);
        ElMessage.success('新增成功')
      } else {
        await saveOrUpdateQuartz(dialogForm._rawValue, true);
        ElMessage.success('修改成功')
      }
      close();
      search();
    }
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}

const handleSave2 = async () => {
  dialogData.loading = true
  try {
    dialogForm2._rawValue.businesslineCode = searchForm.value.businesslineCode;
    const newObj={
      businesslineCode:dialogForm2._rawValue.businesslineCode,
      queryCondition:dialogForm2._rawValue.queryCondition,
      subSystemcode:dialogForm2._rawValue.subSystemcode,
      tableNameList:dialogForm2._rawValue.tableName
    }
    await saveOrUpdateQuartz(newObj, false);
    ElMessage.success('新增成功')
    close2();
    search();
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}

onMounted( () => {
  search();
})


const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

const {
  dialogData:dialogData2, open:open2, close:close2, closed:closed2,
  form: dialogForm2,
  nameRef: dialogFormRef2
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef2', {type: []})

defineExpose({
 search
});

</script>

<style scoped>
</style>