<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" @keyup.enter="search" v-model="searchForm" :loading="loading"
                    :form-items="searchItems" @search="search" :label-width="50">

    </rk-search-form>

    <rk-page-table ref="tableRef" :loading="state.loading" :columns="columns" :data="data" :pagination="page"
                   @page-change="pageChange" @refresh="search"
                   stripe
                   @selection-change="handleSelectionChange"
                   @sort-change="handleSortChange">
      <!--<template #tableTools>-->
      <!--  <el-link>自定义工具栏</el-link>-->
      <!--</template>-->
      <template #operations>
        <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
      </template>
      <template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>
      <template #url="{ row }">
        <el-link :href="row.url">{{ row.url }}</el-link>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta"
                         link></rk-button-group>
      </template>
    </rk-page-table>
  </rk-index-layout>


  <!-- 弹出层 -->
  <el-dialog :close-on-click-modal="false" v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed">
    <rk-detail-form ref="dialogFormRef" v-model="dialogForm" :form-items="formItems" :disabled="dialogData.formDisabled">
      <template #roles="{ item: i, form: f }">
        <el-transfer
            v-model="f[i.prop as string]"
            filterable
            @mouseover="addSupTitle"
            filter-placeholder="搜索"
            :data="roleData"
            :titles="['未选', '已选']"
        />
      </template>
    </rk-detail-form>

    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!dialogData.formDisabled" :loading="dialogData.loading" type="primary" @click="handleSave">
          确认
        </el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>

  <el-dialog v-if="dialogData2.visible" v-model="dialogData2.visible" :title="dialogData2.title"
             class="rk-dialog-default" @closed="closed2"
             :close-on-click-modal="false">
    <bussinessRule ref="childComp" :prop1="rowId" :prop2="rowSystem"/>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';

const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElTransfer} from 'element-plus'
import {RkPageTable, RkButtonGroup, RkSearchForm, RS,
  Pagination, ButtonInfo, useState, RkFormInstance, useDialogForm, RkIndexLayout
} from 'riking-ui'
import {columns, formItems, pagination, searchItems} from "./bussiness.data";
import {getQuartzList, searchList, getJobList, getRoleList, saveOrUpdateQuartz, deleteQuartz} from './bussiness.api'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm';
import bussinessRule from "@/views/sys/bussinessRule/index.vue";

useDict([], [], dictData);

const {state, init, handleSortChange, handleSelectionChange} = useState(searchList)

const addSupTitle=(e)=> {
  const target = e.target
  if (target.title) return
  target.title = target.innerText
}

const handleEdit = async (row: any) => {
  id.value = row.id;
  fetchData();
  open(row, false, '编辑');
}

const childComp = ref(null);

const handleRule = async (row: any) => {
  rowId.value = row.businesslineCode;
  rowSystem.value = row.subSystemcode;
  // if(childComp.value != null){
  //   childComp.value.search();
  // }
  open2(row, false, '业务线规则');
}

const handleDel = async (row: any) => {
  await deleteQuartz(row);
  search();
  ElMessage.success("删除成功");
}

const handleAdd = async () => {
  fetchData();
  open(undefined, false, "新增");
}

const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => {
      handleEdit(row);
    }
  },
  {
    key: 'RULE', label: '规则', tag: 'button', type: 'primary', handler: () => {
      handleRule(row);
    }
  },
  {
    key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
    handler: () => handleDel(row)
  },
]

const buttons: ButtonInfo[] = [
  {
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => {
      handleAdd()
    }
  },
]
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
const rowId = ref({})
const rowSystem = ref({})
const id = ref({})

// watch(rowId, (newValue) => {
//       // 在这里可以执行一些逻辑，然后更新bussinessRule组件的属性
//       // 例如，可以将新的prop1值传递给bussinessRule组件
//       // 通过修改prop1Value的值来更新bussinessRule组件的属性
//       rowId.value = newValue;
//     });

let jobList: any[] = [];

const search = async () => {
  init();
  let result = await getQuartzList(searchForm.value, page.value.currentPage, page.value.pageSize);
  let records = result.result;
  data.value = records.records.map(item => {
    const newObj={
      ...item,
      roles:item.roles.map(item => item.roleCode)
    }
    return newObj
  })
  page.value.currentPage = records.current;
  page.value.pageSize = records.size;
  page.value.total = records.total;
}

//控制表单提交
const handleSave = async () => {
  dialogData.loading = true
  try {
    const valid = await dialogFormRef.value?.asyncValidate();
    if (valid) {
      /*// 创建一个空数组来存储匹配的对象
      const roles = [];
      // 遍历第一个数组
      for (const obj1 of roleData._rawValue) {
        // 检查第二个数组是否包含具有相同 key 的对象
        const obj2 = dialogForm._rawValue.roles.find((item) => item === obj1.key);
        if (obj2) {
          // 如果找到匹配的对象，将它们添加到匹配数组中
          roles.push({ ...obj1 });
        }
      }*/
      const roles = roleData._rawValue
          .filter(f => (dialogForm._rawValue.roles || []).find((item) => item === f.key))
          .map(m => {
            const newObj = {roleId: m.roleId, roleName: m.label, roleCode: m.key}
            return newObj
          })
      const res = dialogForm._rawValue
      // res['roles'] = roles
      const copyRes1={
        ...res,
        roles:roles
      }
      if (dialogData.title === "新增") {
        await saveOrUpdateQuartz(copyRes1, false);
        ElMessage.success('新增成功')
      } else {
        const copyRes2={
          ...res,
          roles:roles,
          id:id.value
        }
        // res['id'] = id.value
        await saveOrUpdateQuartz(copyRes2, true);
        ElMessage.success('修改成功')
      }
      close();
      search();
    }
  } finally {
    setTimeout(() => (dialogData.loading = false), 50)
  }
}


onMounted(async () => {
  search();
})

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed,
  form: dialogForm,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

const {
  dialogData: dialogData2, open: open2, close: close2, closed: closed2
}: DialogForm<RkFormInstance, any> = useDialogForm('', {type: []})

//穿梭框逻辑
interface Option {
  key: string
  label: string
  roleId:number
  // disabled: boolean
}


const roleData = ref<Option[]>()

const fetchData = async () => {
  let data: Option[] = [];
  let roleListResult = await getRoleList();
  let roleList = roleListResult.data;
  roleList.map((role: any) => (
      data.push({
        key: role.id,
        // key: role.roleCode,
        label: role.roleName,
        roleId:role.id
      })
  ));

  roleData.value = data;
};

// fetchData();

const roleValue = ref([])
</script>

<style scoped>
/*:deep(.el-transfer-panel) {
  width: 350px;
}*/
</style>