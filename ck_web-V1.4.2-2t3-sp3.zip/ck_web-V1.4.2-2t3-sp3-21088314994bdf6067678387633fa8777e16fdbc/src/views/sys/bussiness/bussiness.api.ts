// import { defHttp } from '/@/utils/http/axios';
// import { Modal } from 'ant-design-vue';
import {RS} from 'riking-ui'
import service from '@/utils/request';
import {getCommonParams} from "@/utils/subSystem";
enum Api {
  list = '/sys-bussiness/list',
  edit = '/sys-bussiness/edit',
  save = '/sys-bussiness/add',
  get = '/sys-bussiness/queryById',
  delete = '/sys-bussiness/delete',
  deleteBatch = '/sys-bussiness/deleteBatch',
  jobList='/sys/quartzJob/listBySystem',
  roleList = '/oauth/roleList',
}


/**
 * 保存或者更新
 * @param params
 */
export const saveOrUpdateQuartz = (data: any, isUpdate: any) => {
  console.log(data);
  let url = isUpdate ? Api.edit : Api.save;
  return service({
    url: url,
    method: 'POST',
    data,
  })
};
/**
 * 查询角色列表
 * @param params
 */
export const getRoleList = (): Promise<RS> => {
  return service({
    url: Api.roleList,
    method: 'GET',
  })
};
/**
 * 查询任务列表
 * @param params
 */
export const getJobList = (): Promise<RS> => {
  return service({
    url: Api.jobList,
    method: 'POST',
    params: {...getCommonParams()}
})
};
/**
 * 查询列表
 * @param params
 */
export const getQuartzList = (data: any, pageNo: number, pageSize: number): Promise<RS> => {
  return service({
    url: Api.list,
    method: 'POST',
    data,
    params: {pageNo, pageSize,...getCommonParams()}
})
};
//分页查询
export function searchList(data: any) {
  return service({
    url: Api.list,
    method: 'post',
    data,
    params: {...getCommonParams()}
  })
}
/**
 * 删除任务
 * @param params
 */
export const deleteQuartz = (data: any) => {
  return service({
    url: Api.delete,
    method: 'DELETE',
    params: {id : data.id}
})
  // return defHttp.delete({ url: Api.delete, data: params }, { joinParamsToUrl: true }).then(() => {
  //   handleSuccess();
  // });
};
