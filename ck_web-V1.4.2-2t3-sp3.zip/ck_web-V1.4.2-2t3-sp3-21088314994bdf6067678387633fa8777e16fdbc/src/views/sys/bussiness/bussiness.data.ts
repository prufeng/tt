import { FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";



export const columns: TableColumnInfo[] = [
  // {key: 'id', type: 'selection'},
  {prop: 'businesslineCode', label: '业务线CODE'},
  {prop: 'businesslineName', label: '业务线名称'},
  {
    prop: 'subSystemcode',
    label: '系统名称',
    inputType: 'input',
    dictFormatKey: "systemCode"
  },
  {
      key: 'actions',
      label: '操作',
      scopedSlots: 'actions',
      fixedWidth: 200,
      fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'subSystemcode',
    label: '系统名称',
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },  
    labelWidth: 100
  },
  {
    prop: 'businesslineCode',
    label: '业务线CODE',
    inputType: 'input',
    labelWidth: 100,
  },
  {
    prop: 'businesslineName',
    label: '业务线名称',
    inputType: 'input',
    labelWidth: 100,
  },
];

export const formItems: FormItemInfo[] = [
  {
    prop: 'subSystemcode',
    label: '系统名称',
    rules: [{required: true, message: '必填'}],
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },
    labelWidth: 100
  },
  {
    prop: 'businesslineCode',
    label: '业务线CODE',
    rules: [{required: true, message: '必填'}],
    inputType: 'input',
    labelWidth: 100,
  },
  {
    prop: 'businesslineName',
    label: '业务线名称',
    rules: [{required: true, message: '必填'}],
    inputType: 'input',
    labelWidth: 100,
  },
  {
    prop: 'roles',
    label: '业务线角色',
    scopedSlot: 'roles',
    labelWidth: 100,
    extra:{span: 24},
  },
];
export const formItems2: FormItemInfo[] = [
  // {
  //   prop: 'jobClassName',
  //   label: '任务类名',
  //   inputType: 'input',
  //   required: true,
  // },
  {prop: 'phone', label: '接收人手机号',  inputType:'input' },
  {
    prop: 'systemCode',
   labelWidth: 150,
    label: '所属系统',
    inputType: {
      tag: 'select',
      options: 'systemType',
    },
  },
  {
    prop: 'credateBy',
    label: '创建人',
    inputType:'input' 
  },
  {
    prop: 'createTime',
    label: '创建时间',
    inputType:'input' 
  },
  {
    prop: 'updateBy',
    label: '更新人',
    inputType:'input' 
  },

  {
    prop: 'updateTime',
    label: '更新时间',
    inputType: 'input'
  },
  {
    prop: 'isSend',
    label: '发送状态',
    inputType: {
      tag: 'select',
      options: 'isSend',
      // multiple: true,
  },
  },
  {
    prop: 'templateModel',
    label: '模板参数',
    inputType: 'input'
  },
  {
    prop: 'templateContent',
    label: '模板内容',
    scopedSlot: 'templateContent',
    extra: { span: 24 },
  },
      
];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
}