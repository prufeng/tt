import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";

export const columns: TableColumnInfo[] = [
  // {key: 'id', type: 'selection'},
  {prop: 'phone', label: '接收人手机号'},
  {prop: 'isSend', label: '发送状态',dictFormatKey: "isSend"},
  // {prop: 'systemCode', label: '所属系统',dictFormatKey: "systemCode"},
  {
    prop: 'smsType',
    label: '短信类型',
    dictFormatKey: 'emailType',
  },
  /*{
    prop: 'credateBy',
    label: '创建人',
    inputType:'input' 
  },*/
  {
    prop: 'createTime',
    label: '创建时间',
    inputType:'input' 
  },
  /*{
    prop: 'updateBy',
    label: '更新人',
    inputType:'input' 
  },*/

  /*{
    prop: 'updateTime',
    label: '更新时间',
    inputType: 'input'
  },*/
  {
      key: 'actions',
      label: '操作',
      scopedSlots: 'actions',
      fixedWidth: 200,
      fixed: 'right',
  },
];

export const searchItems: FormItemInfo[] = [
  {
    prop: 'systemCode',
    label: '所属系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
    },  
    labelWidth: 100
  },
  {
    prop: 'phone',
    label: '接收人手机号',
    inputType: "input",
    labelWidth: 100,
  },
  {
    prop: 'isSend',
    label: '发送状态',
    labelWidth: 100,
    inputType: {
      tag: 'select',
      options: 'isSend',
   
      // multiple: true,
  },
  },
];

export const formItems: FormItemInfo[] = [
  // {
  //   prop: 'jobClassName',
  //   label: '任务类名',
  //   inputType: 'input',
  //   required: true,
  // },
  {prop: 'phone', label: '接收人手机号',  inputType:'input' },
  // {
  //   prop: 'systemCode',
  //   label: '系统编号',
  //   inputType:'input' 
  // },
  {
    prop: 'credateBy',
    label: '创建人',
    inputType:'input' 
  },
  {
    prop: 'createTime',
    label: '创建时间',
    inputType:'input' 
  },
  {
    prop: 'updateBy',
    label: '更新人',
    inputType:'input' 
  },

  {
    prop: 'updateTime',
    label: '更新时间',
    inputType: 'input'
  },
  {
    prop: 'isSend',
    label: '发送状态',
    inputType: {
      tag: 'select',
      options: 'isSend',
      // multiple: true,
  },
  },
  {prop: 'content',
   label: '内容', 
    inputType:{
       tag: 'input', type: 'textarea', maxlength: '30' 
      },
   extra: { span: 18 },
    },
      
];
export const formItems2: FormItemInfo[] = [
  // {
  //   prop: 'jobClassName',
  //   label: '任务类名',
  //   inputType: 'input',
  //   required: true,
  // },
  {prop: 'phone', label: '接收人手机号',  inputType:'input' },
  {
    prop: 'systemCode',
    label: '系统编号',
    inputType:'input' 
  },
  {
    prop: 'credateBy',
    label: '创建人',
    inputType:'input' 
  },
  {
    prop: 'createTime',
    label: '创建时间',
    inputType:'input' 
  },
  {
    prop: 'updateBy',
    label: '更新人',
    inputType:'input' 
  },

  {
    prop: 'updateTime',
    label: '更新时间',
    inputType: 'input'
  },
  {
    prop: 'isSend',
    label: '发送状态',
    inputType: {
      tag: 'select',
      options: 'isSend',
      // multiple: true,
  },
  },
  {
    prop: 'templateModel',
    label: '模板参数',
    inputType: 'input'
  },
  {
    prop: 'templateContent',
    label: '模板内容',
    scopedSlot: 'templateContent',
    extra: { span: 24 },
  },
      
];
export const pagination: Pagination = {
  currentPage: 1,
  pageSize: 10,
  pageSizes: [10, 30, 50, 100],
  total: 100,
  layout: 'total, sizes, prev, pager, next, jumper',
  pagerCount: 5,
}

// 字典
export const dictData =  {
}