<template>
  <rk-index-layout>
    <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search" :form-items="searchItem" @search="search"
                    :label-width="50"/>

    <rk-page-table :loading="loading" :columns="columns" :data="data" :pagination="page" @refresh="search" @page-change="pageChange"
                   @selection-change="handleSelectionChange" >
      <!-- <template #operations>
        <div style="display: flex; flex-direction: row">
          <UpAndDown :imp="imp" :exp="exp"/>
        </div>
      </template> -->

      <!--<template #urlTh="{ column, $index }">{{ column.label + '-' + $index }}</template>-->
      <!--<template #url="{ row }">-->
      <!--  <el-link :href="row.url">{{ row.url }}</el-link>-->
      <!--</template>-->

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="$route.meta" :max="9" link/>
      </template>
    </rk-page-table>
  </rk-index-layout>


  <!-- 弹出层 -->
    <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed" :close-on-click-modal="false">
      <!-- 弹出层头信息 -->
      <rk-detail-form ref="dialogFormRef" v-model="form" :form-items="cxParentsFormItems" disabled="true">

      </rk-detail-form>
      <el-tabs v-model="activeName"  class="demo-tabs" @tab-click="handleClick" >
        <!-- 标签页-主信息 -->
      <el-tab-pane v-for="(tab,index) in formItems" :key=index+1 :label="tab.name" :name=index+1>
        <div style="display: flex; flex-direction: row">

          <el-space wrap :size="10">
            <rk-button-group :buttons="dialogData.title === getTitleName() + '编辑' || dialogData.title === getTitleName() + '新增' ? parentsButtons : parentsButtons2"
                             :route-meta="$route.meta"
                             :max="9"></rk-button-group>
            <el-text class="mx-1" size="small">状态 :</el-text>
            <el-tag size="large">{{ status }}</el-tag>
          </el-space>

        </div>
        <br>
        <rk-detail-form ref="dialogFormRef" v-model="form" :form-items="tab.items" :disabled="dialogData.formDisabled">

        </rk-detail-form>

      </el-tab-pane>
        <!-- 标签页-从表信息 -->
        <el-tab-pane    v-for="(subTable, index) in subTables" :key="'sub'+index"  :label="subTable.name" :name="'sub'+index">
          <rk-page-table  :loading="subLoading" :columns="subTable.columns" :data="subData" :pagination="subPage" @page-change="subPageChange"
                         @selection-change="handleSelectionChange" @refresh="handleClick(undefined)">
            <template #operations>
              <div style="display: flex; flex-direction: row">
                <rk-button-group :buttons="subButtons(subTable.listName,subTable.items)"
                                 :route-meta="$route.meta"
                                 :max="9"></rk-button-group>
              </div>
            </template>
            <template #actions="{ row }">
              <rk-button-group :buttons="subGenActButtons(row,subTable.listName,subTable.items)" :route-meta="['view', 'edit', 'submit', 'audit','reset', 'delete']" :max="2" link/>
            </template>
          </rk-page-table>
      </el-tab-pane>
    </el-tabs>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-model="subDialogData.visible" :title="subDialogData.title" class="rk-dialog-default" @closed="subClosed" :close-on-click-modal="false">
    <rk-detail-form ref="subDialogFormRef" v-model="subForm" :form-items="subFormItems" :disabled="subDialogData.formDisabled">

    </rk-detail-form>
    <template #footer>
               <span class="dialog-footer">
                 <el-button type="primary" v-if="subDialogData.title.includes('编辑') || subDialogData.title.includes('新增')"
                            @click="save1(null, listName)">保存</el-button>
                 <el-button @click="subClose"> 取消 </el-button>
               </span>
    </template>
  </el-dialog>
  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="Tips" width="30%" draggable>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids)">审核通过</el-button>
        <el-button type="danger" @click="()=>{msgDialog = true;msg =''}">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 子表审核弹窗 -->
  <el-dialog v-model="subAuditDialog" title="Tips" width="30%" draggable>
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="subAudit(ids,listName)">审核通过</el-button>
        <el-button type="danger" @click="()=>{subMsgDialog = true;msg= ''}">
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog"  width="30%" draggable>
    <el-form >
      <el-form-item>
        <el-input v-model="msg"  type="textarea"  placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
      <el-button type="primary" @click="auditNotPass(ids)">提交</el-button>
      </span>
   </template>
  </el-dialog>
  <!-- 子表审核不通过原因输入弹窗 -->
  <el-dialog v-model="subMsgDialog"  width="30%" draggable>
    <el-form >
      <el-form-item>
        <el-input v-model="msg"  type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
      <el-button type="primary" @click="subAuditNotPass(ids,listName)">提交</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore';
// TODO 启动时加载，不在页面里调用   子系统设置
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>

<script setup lang="ts">
//主表所需代码
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage, ElForm, ElFormItem, ElInput,
  ElTabs, ElTabPane, ElText, ElSpace, ElTag } from 'element-plus'

import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  RkDetailForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm, dictFormatter, RkIndexLayout,
} from 'riking-ui'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'
import {useDict} from 'riking-layout'
import {pagination, subPagination} from "./data";
import {derivedPageElements, fkAccountFormItems, searchItems, zhSearchItems} from "./page";
import {
  list,
  exportExcel,
  saveData,
  submitBatch,
  testBatch,
  auditBatch,
  delBatch,
  resetBatch,
  listByRwlsh,
  subSaveData,
  subSubmitBatch,
  subResetBatch,
  subAuditBatch,
  subDelBatch,
  subTestBatch,
  fkSearchList,
  getBranchList,
  getBranchListByTenantAndSubSysCode, getBranchAndRepoBranchList, getTree, auditNotPassBatch, subAuditNotPassBatch,
} from './api'
import UpAndDown from "@/components/UpAndDown.vue";
import {cxParentsFormItems} from '@/views/query/feedback/page';

const activeName = ref(1)
const loading = ref(false)
const subLoading = ref(false)
const data = ref<any []>([]);
const subData = ref<any []>([]);
const page = ref<Pagination>(pagination);
const subPage = ref<Pagination>(subPagination);
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
const visible = ref(false)
const rwlsh = ref("")
const khbh = ref("")
const qqdbs = ref("")
let listName = "";
const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})

const {
  dialogData: subDialogData,
  open: subOpen,
  close: subClose,
  closed : subClosed,
  form : subForm,
  nameRef: subDialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('subDialogFormRef', {type: []})
let status = ref("")
let columns: any[] = [], formItems: any[] = [], subTables: any[] = [],searchItem: any[] = [], subFormItems: any[] = [];
let requestClassificationCode: string | string[];

useDict([], [], dictData)

onMounted(() => {
  page.value = {...pagination}
  let router = useRouter();
  let path = router.currentRoute.value.path;
  let pageElements = derivedPageElements('fkFreeze');
  columns = pageElements.columns;
  formItems = pageElements.formItems;
  subTables = pageElements.subTables;
  searchItem = pageElements.searchItems;
  search();
})

function getSubSystem() {
    return searchForm.value.subSystem;
}

const search = async () => {
  loading.value = true;
  console.log(searchForm.value);
  if(searchForm.value.fklx == undefined || searchForm.value.subSystem == undefined){
    searchForm.value.fklx = 'fkFreeze';
    searchForm.value.subSystem = 'jcy';
  }
  let pageElements = derivedPageElements(searchForm.value.fklx);
  columns = pageElements.columns;
  formItems = pageElements.formItems;
  subTables = pageElements.subTables;
  searchItem = pageElements.searchItems;
  // let pageElements = derivedPageElements('fkPayment');
  //     columns = pageElements.columns;
  //     formItems = pageElements.formItems;
  //     subTables = pageElements.subTables;
  //     searchItem = pageElements.searchItems;

  try {
    searchForm.value.status = '1';
    let result = await list(searchForm.value, page.value.currentPage, page.value.pageSize,searchForm.value.subSystem,searchForm.value.fklx);
    console.log(result);
    let {current, total, records} = result.data;
    data.value = records;
    page.value.currentPage = current;
    page.value.total = total;
  }catch(error) {
    console.log(error);
    ElMessage.warning('所选系统无对应反馈类型')
  }
  finally {
    loading.value = false;
  }


  // // test branch
  // let result1 = await getBranchList();
  // let result2 = await getBranchListByTenantAndSubSysCode();
  // // let result3 = await getBranchAndRepoBranchList();
  // let result4 = await getTree();

}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const subPageChange = (p: Pagination) => {
  subPage.value = p
  handleClick(undefined)
}

let ids: string;
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}

const save = async () => {
  // const valid = await dialogFormRef.value?.asyncValidate();
  // if (valid) {
    const data = toRaw(form.value);
    data.status = '1';
    delete data.type;
    await saveData(data);
    // close();
    await search();
    ElMessage.success("保存成功");
  // }
}

const submit = async (ids: string) => {
  await testBatch(ids);
  await search();
  status.value=status.value = dictFormatter("3",dictData.dataStatus)
  // close();
  ElMessage.success("审核成功");
}

const auditDialog = ref(false);
const audit = async (ids: any) => {
  await auditBatch(ids);
  await search();
  status.value=status.value = dictFormatter("3",dictData.dataStatus)
  // close();
  ElMessage.success("审核成功");
  auditDialog.value = false;
}
const auditNotPass = async (ids: any) => {
  await auditNotPassBatch(ids,msg.value);
  await search();
  status.value=status.value = dictFormatter("6",dictData.dataStatus)
  // close();
  ElMessage.success("审核不通过成功");
  msgDialog.value = false;
  auditDialog.value = false;
}

const reset = async (ids: string) => {
  await resetBatch(ids);
  await search();
  status.value=status.value = dictFormatter("1",dictData.dataStatus)
  // close();
  ElMessage.success("重置成功");
}

const del = async (ids: string) => {
  await delBatch(ids);
  await search();
  ElMessage.success("删除成功");
}

const subSubmit = async (ids: string, name:string) => {
  if (ids==undefined||ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await subTestBatch(ids, name);
  await handleClick(undefined);
  ElMessage.success("审核成功");
}

const subAuditDialog = ref(false);
const msgDialog = ref(false);
const subMsgDialog = ref(false);
const msg = ref("")
const subAudit = async (ids: any , name:string) => {
  if (ids==undefined||ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await subAuditBatch(ids , name);
  await handleClick(undefined);
  ElMessage.success("审核成功");
  subAuditDialog.value = false;
}
const subAuditNotPass = async (ids: any , name:string) => {
  if (ids==undefined||ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await subAuditNotPassBatch(ids , name,msg.value);
  await handleClick(undefined);
  ElMessage.success("审核不通过成功");
  subMsgDialog.value = false;
  subAuditDialog.value = false;
}

const subReset = async (ids: string, name:string) => {
  if (ids==undefined||ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await subResetBatch(ids, name);
  await handleClick(undefined);
  ElMessage.success("重置成功");
}

const subDel = async (ids: string,name:string) => {
  if (ids==undefined||ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }

  await subDelBatch(ids, name);
  await handleClick(undefined);
  ElMessage.success("删除成功");
}

const imp = async () => {

  ElMessage.success("导入成功");
  await search();
}

const exp = async () => {
  if (ids==undefined||ids.length == 0) {
    ElMessage.warning('请先选择数据')
    return
  }
  await exportExcel(ids);
}

const parentsButtons: ButtonInfo[] = [
  {
    key: 'submit',
    label: '提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => submit(form.value.id),
  },
  {
    key: 'audit',
    label: '审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => {
      ids = form.value.id;
      auditDialog.value = true
    },
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => reset(form.value.id),
  },
  {
    key: 'save',
    label: '保存',
    tag: 'button',
    type: 'primary',
    icon: 'icon_update',
    handler: () => save(),
  }
]
const parentsButtons2: ButtonInfo[] = [
  {
    key: 'test',
    label: '确认',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => submit(form.value.id),
  },
]
const dictDataList = [{ label: '1',value:'待提交'},{ label: '2',value:'待审核'},{ label: '3',value:'已审核'},{ label: '4',value:'已生成'}]
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'antotest', label: '自动测试', tag: 'button', type: 'primary',
    handler: () => {
      rwlsh.value = row.rwlsh;
      khbh.value = row.khbh;
      qqdbs.value = row.qqdbs;
      activeName.value = 1
      status.value = dictFormatter(row.status,dictData.dataStatus)
      if (row.status>2&&row.status!=6) {
        open(row, true, getTitleName());
      } else {
        open(row, false, getTitleName()+'自动测试');
      }
    }
  }
]

//子表所需代码
const save1 = async (data:any , name:string) => {
  data = toRaw(subForm.value);
  data.status = '1';
  data.deleted = '0';
  data.rwlsh = rwlsh.value;
  if (khbh.value!=''&&khbh.value!=undefined) {
    data.khbh = khbh.value;
  }
  data.qqdbs = qqdbs.value;
  delete data.type;
  let rs = await subSaveData(data,name);
  subClose();
  subClosed();
  ElMessage.success("保存成功");
  handleClick(undefined);

}

const subButtons: (name:string,items:any) => ButtonInfo[] = ( name:string,items:any) => [
  {
    key: 'add',
    label: '新增',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: () => {
      listName = name;
      subFormItems = items
      subOpen({}, false, getSubTitleName(name)+'新增')
    }
  },
  {
    key: 'test',
    label: '确认',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => subSubmit(ids,name),
  },
  {
    key: 'del',
    label: '批量删除',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => subDel(ids,name),
  },
]

const getTitleName = () => {
  switch (searchForm.value.fklx) {
    case 'fkCustomer' : return '账户信息查询反馈'
    case 'fkTransaction' : return '交易明细查询反馈'
    case 'fkAccountAndTransaction' : return '账户信息和交易明细综合查询反馈'
    case 'fkDynamic' : return '动态查询反馈'
    case 'fkFreeze' : return '冻结/续冻/解冻反馈'
    case 'fkPayment' : return '紧急止付/解除止付反馈'
    case 'fkCertificateImage' : return '调阅凭证图像反馈'
    case 'fkFinancialAccount' : return '金融理财账户信息反馈'
  }
}

const getSubTitleName = (name:string) => {
  switch (name) {
    case 'fkAccount' : return '账户信息'
    case 'fkMeasure' : return '强制措施'
    case 'fkPriority' : return '共有权/优先权'
    case 'fkSubAccount' : return '关联子账户'
    case 'fkTransaction' : return '交易明细'
    case 'fkDynamicReceipt' : return '动态查询请求回执'
    case 'fkFreezeDetail' : return '冻结/续冻/解冻明细'
    case 'fkPaymentDetail' : return '紧急止付/解除止付明细'
    case 'fkCertificateImageDetail' : return '调阅凭证图像明细'
    case 'fkFinancialDetail' : return '金融理财信息明细'
  }
}
const subGenActButtons: (row: any , name:string,items:any) => ButtonInfo[] = (row: any, name:string,items:any) => [

  {
    key: 'edit', label: '编辑', tag: 'button', type: 'primary',
    handler: () => {
      console.log(row)
      subFormItems = items
      if (row.status>2&&row.status!=6) {
        subOpen(row, true, getSubTitleName(name));
      } else {
        subOpen(row, false, getSubTitleName(name)+'编辑');
      }
    }
  },
  {
    key: 'submit', label: '确认', tag: 'button', type: 'primary',
    handler: () => subSubmit(row.id,name)
  },
  {
    key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
    handler: () => subDel(row.id,name)
  },
]

const fkAccountSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkAccount", rwlsh.value,khbh.value);
  subSearch(result);
}

const fkMeasureSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkMeasure", rwlsh.value,khbh.value);
  subSearch(result);
}

const fkPrioritySearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkPriority", rwlsh.value,khbh.value);
  subSearch(result);
}

const fkSubAccountSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkSubAccount", rwlsh.value,khbh.value);
  subSearch(result);
}
const fkTransactionSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkTransaction", rwlsh.value,khbh.value);
  subSearch(result);
}
const fkDynamicReceiptSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkDynamicReceipt", rwlsh.value,khbh.value);
  subSearch(result);
}
const fkFreezeDetailSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkFreezeDetail", rwlsh.value,khbh.value);
  subSearch(result);
}
const fkPaymentDetailSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkPaymentDetail", rwlsh.value,khbh.value);
  subSearch(result);
}
const fkCertificateImageDetailSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkCertificateImageDetail", rwlsh.value,khbh.value);
  subSearch(result);
}
const fkFinancialAccountDetailSearch = async () => {
  let result = await listByRwlsh(searchForm.value,  subPage.value.currentPage,  subPage.value.pageSize,"fkFinancialDetail", rwlsh.value,khbh.value);
  subSearch(result);
}
const subSearch = (result: any) => {
  console.log(result)
  let {current, total, records} = result.data;
  subData.value = records;
  subPage.value.currentPage = current;
  subPage.value.total = total;
  console.log("出发了子表查询")
}

let tabName = "";
const handleClick = async (tab: any) => {
  console.log(rwlsh);
  subLoading.value = true;
  try {
    if (tab == undefined) {
      console.log("分页查询")
      console.log(tabName)
      switch (tabName) {
        case "账户信息" :
          await fkAccountSearch();
          break;
        case "强制措施" :
          await fkMeasureSearch();
          break;
        case "共有权/优先权" :
          await fkPrioritySearch();
          break;
        case "关联子账户" :
          await fkSubAccountSearch();
          break;
        case "交易明细" :
          await fkTransactionSearch();
          break;
        case "动态查询请求回执" :
          await fkDynamicReceiptSearch();
          break;
        case "冻结/续冻/解冻明细" :
          await fkFreezeDetailSearch();
          break;
        case "紧急止付/解除止付明细" :
          await fkPaymentDetailSearch();
          break;
        case "调阅凭证图像明细" :
          await fkCertificateImageDetailSearch();
          break;
        case "金融理财信息明细" :
          await fkFinancialAccountDetailSearch();
          break;

      }
    } else {
      subPage.value.currentPage = 1;
      tabName = tab.props.label;
      switch (tab.props.label) {
        case "账户信息" :
          await fkAccountSearch();
          break;
        case "强制措施" :
          await fkMeasureSearch();
          break;
        case "共有权/优先权" :
          await fkPrioritySearch();
          break;
        case "关联子账户" :
          await fkSubAccountSearch();
          break;
        case "交易明细" :
          await fkTransactionSearch();
          break;
        case "动态查询请求回执" :
          await fkDynamicReceiptSearch();
          break;
        case "冻结/续冻/解冻明细" :
          await fkFreezeDetailSearch();
          break;
        case "紧急止付/解除止付明细" :
          await fkPaymentDetailSearch();
          break;
        case "调阅凭证图像明细" :
          await fkCertificateImageDetailSearch();
          break;
        case "金融理财信息明细" :
          await fkFinancialAccountDetailSearch();
          break;
      }
    }
  } finally {
    subLoading.value = false;
  }
}


</script>

<style scoped></style>