import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
import {ElMessage} from "element-plus";
import {getToken} from "@/utils/token";
import {auditBatch, delBatch, submitBatch} from "@/views/query/feedback/api";

// 新增，修改 提交，导入，导出，，审核，重置，反馈（已保存，已提交，审核未通过，审核通过，已反馈）
export const buttons: ButtonInfo[] = [
    {
        key: 'submit',
        label: '提交',
        tag: 'button',
        type: 'primary',
        icon: 'icon_submit',
        handler: () => ElMessage.warning('提交'),
    },
    {
        key: 'audit',
        label: '审核',
        tag: 'button',
        type: 'primary',
        icon: 'icon_audit',
        handler: () => ElMessage.warning('审核'),
    },
    {
        key: 'reset',
        label: '重置',
        tag: 'button',
        type: 'primary',
        icon: 'icon_reset',
        handler: () => ElMessage.warning('重置'),
    },
    {
        key: 'batchDelete',
        label: '批量删除',
        tag: 'button',
        type: 'danger',
        icon: 'icon_delete',
        handler: () => ElMessage.warning('批量删除'),
    },
]

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}
export const subPagination: Pagination = {
    currentPage: 1,
    pageSize: 10,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}



// export const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
//     {key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => ElMessage.warning(row.id)},
//     {key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => ElMessage.warning(row.id)},
//     {key: 'DELETE', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗', handler: () => ElMessage.warning(row.id),},
// ]
