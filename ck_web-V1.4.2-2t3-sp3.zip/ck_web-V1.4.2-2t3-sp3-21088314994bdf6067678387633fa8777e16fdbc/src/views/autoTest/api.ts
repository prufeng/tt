import {RS} from 'riking-ui'
import service from '@/utils/request'
import {getRequestClassificationCode, getSubSystem} from "@/utils/subSystem";
let sub = '';
let reqCode = '';
function getCommonParams() {
    const subSystem: string = sub;
    const requestClassificationCode: string | string[] = reqCode;
    const commonParams = {subSystem, requestClassificationCode};
    return commonParams;
}

function getCommonParams1(name : string) {
    console.log("name " +name)
    const subSystem: string = sub;
    const requestClassificationCode: string | string[] = name;
    const commonParams = {subSystem, requestClassificationCode};
    return commonParams;
}



export function getBranchList(): Promise<RS> {
    return service({
        url: '/branch/getBranchList',
        method: 'POST',
    })
}
export function getBranchListByTenantAndSubSysCode(): Promise<RS> {
    return service({
        url: '/branch/getBranchListByTenantAndSubSysCode',
        method: 'POST',
        params: {tenant: 'base_tenant', subSystem: 'jcy'}
    })
}
export function getBranchAndRepoBranchList(): Promise<RS> {
    return service({
        url: '/branch/getBranchAndRepoBranchList',
        method: 'POST',
    })
}
export function getTree(): Promise<RS> {
    return service({
        url: '/branch/getTree',
        method: 'POST',
    })
}





export function list(data = {}, current: number, size: number,subSystem: string, requestClassificationCode: string): Promise<RS> {
   console.log(data);
 sub = subSystem;
 reqCode =  requestClassificationCode;
    return service({
        url: `/${reqCode}/list`,
        method: 'POST',
        data,
        params: {current, size, subSystem, requestClassificationCode}
    })
}
//分页查询
export function fkSearchList(data = {}) {
    return service({
        url: `/${reqCode}/list`,
        method: 'POST',
        data,
        params: {current:1, size:10, ...getCommonParams()}
    })
}

export function listByRwlsh(data = {}, current: number, size: number,name:string, rwlsh:string, khbh:string): Promise<RS> {
    return service({
        url: `/${reqCode}/listSub`,
        method: 'POST',
        data,
        params: {current, size, rwlsh ,khbh,  ...getCommonParams1("")}
    })
}

export function saveData(data = {}): Promise<RS> {
    return service({
        url: `/${reqCode}/save`,
        method: 'POST',
        data,
        params: getCommonParams()
    })
}
export function subSaveData(data = {}, name:string): Promise<RS> {
    return service({
        url: `/${name}/save`,
        method: 'POST',
        data,
        params: getCommonParams1(name)
    })
}

export function submitBatch(ids:any): Promise<RS> {
    console.log(getCommonParams());
    return service({
        url: `/${reqCode}/submit`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}


export function testBatch(ids:any): Promise<RS> {
    console.log(getCommonParams());
    return service({
        url: `/${reqCode}/test`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}

export function subTestBatch(ids:any,name:string): Promise<RS> {
    return service({
        url: `/${name}/test`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}

export function subSubmitBatch(ids:any,name:string): Promise<RS> {
    return service({
        url: `/${name}/submit`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}

export function auditBatch(ids: any): Promise<RS> {
    return service({
        url: `/${reqCode}/audit`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}

export function auditNotPassBatch(ids: any,msg:any): Promise<RS> {
    return service({
        url: `/${reqCode}/auditNotPass`,
        method: 'POST',
        params: {ids,msg, ...getCommonParams()},
    })
}

export function subAuditBatch(ids: any,name:string): Promise<RS> {
    return service({
        url: `/${name}/audit`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}

export function subAuditNotPassBatch(ids: any,name:string,msg:any): Promise<RS> {
    return service({
        url: `/${name}/auditNotPass`,
        method: 'POST',
        params: {ids, msg,...getCommonParams1(name)},
    })
}

export function resetBatch(ids: any): Promise<RS> {
    return service({
        url: `/${reqCode}/reset`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}

export function subResetBatch(ids: any ,name:string): Promise<RS> {
    return service({
        url: `/${name}/reset`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}

export function delBatch(ids: any): Promise<RS> {
    return service({
        url: `/${reqCode}/del`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
    })
}

export function subDelBatch(ids: any,name:string): Promise<RS> {
    return service({
        url: `/${name}/del`,
        method: 'POST',
        params: {ids, ...getCommonParams1(name)},
    })
}


export function importExcel(): Promise<RS> {
    return service({
        url: `/${reqCode}/importExcel`,
        method: 'POST',
        params: getCommonParams(),
        headers: {'Content-Type': 'multipart/form-data'},
        responseType: 'blob'
    })
}

export function exportExcel(ids:any): Promise<RS> {
    return service({
        url: `/${reqCode}/exportExcel`,
        method: 'POST',
        params: {ids, ...getCommonParams()},
        headers: {'Content-Type': 'multipart/form-data',},
        responseType: 'blob'
    })
}
