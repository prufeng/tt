import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
import {ElMessage} from "element-plus";
import {dateFormatter} from "@/utils/utils";
import {getSubSystem} from "@/utils/subSystem";

declare interface PageElements {
    formItems: TableColumnInfo[],
    columns: FormItemInfo[],
    subTables: TableColumnInfo[],
    searchItems: FormItemInfo[],
}

const sqjgdm = 'sqjgdm' + "." + getSubSystem();
export const derivedPageElements = (key: string) => {
    let elements: PageElements = {formItems: [], columns: [], subTables: [], searchItems: []};
    switch (key) {
        case 'fkCustomer':
            elements.columns = customerParentsColumns;
            elements.formItems = [{name: "客户信息", items: fkCustomerFormItems}];
            elements.subTables = [
                {name: "账户信息", items: fkAccountFormItems, columns: fkAccountColumns, listName: "fkAccount"},
                {name: "强制措施", items: fkMeasureFormItems, columns: fkMeasureColumns, listName: "fkMeasure"},
                {name: "共有权/优先权", items: fkPriorityFormItems, columns: fkPriorityColumns, listName: "fkPriority"},
                {name: "关联子账户", items: fkSubAccountFormItems, columns: fkSubAccountColumns, listName: "fkSubAccount"}
            ]
            elements.searchItems = customerSearchItems;
            break;
        case 'fkTransaction':
            elements.columns = transactionParentsColumns;
            elements.formItems = [{name: "交易明细", items: fkTransactionFormItems}];
            elements.subTables = [];
            elements.searchItems = transactionSearchItems;
            break;
        case 'fkAccountAndTransaction':
            elements.columns = customerParentsColumns;
            elements.formItems = [{name: "客户信息", items: fkCustomerFormItems}];
            elements.subTables = [
                {name: "账户信息", items: fkAccountFormItems, columns: fkAccountColumns, listName: "fkAccount"},
                {name: "强制措施", items: fkMeasureFormItems, columns: fkMeasureColumns, listName: "fkMeasure"},
                {name: "共有权/优先权", items: fkPriorityFormItems, columns: fkPriorityColumns, listName: "fkPriority"},
                {name: "关联子账户", items: fkSubAccountFormItems, columns: fkSubAccountColumns, listName: "fkSubAccount"},
                {name: "交易明细", items: fkTransactionFormItems, columns: fkTransactionColumns, listName: "fkTransaction"}
            ];
            elements.searchItems = customerSearchItems;
            break;
        case 'fkDynamic':
            elements.columns = zhParentsColumns;
            elements.formItems = [{name: "动态查询", items: fkDynamicFormItems}];
            elements.subTables = [{
                name: "动态查询请求回执",
                items: fkDynamicReceiptFormItems,
                columns: fkDynamicReceiptColumns,
                listName: "fkDynamicReceipt"
            }];
            elements.searchItems = zhSearchItems;
            break;
        case 'fkFreeze':
            elements.columns = zhParentsColumns;
            elements.formItems = [{name: "冻结/续冻/解冻", items: fkFreezeFormItems}];
            elements.subTables = [{
                name: "冻结/续冻/解冻明细",
                items: fkFreezeDetailFormItems,
                columns: fkFreezeDetailColumns,
                listName: "fkFreezeDetail"
            }];
            elements.searchItems = zhSearchItems;
            break;
        case 'fkPayment':
            elements.columns = paymentParentsColumns;
            elements.formItems = [{name: "紧急止付/解除止付", items: fkPaymentFormItems}];
            elements.subTables = [{
                name: "紧急止付/解除止付明细",
                items: fkPaymentDetailFormItems,
                columns: fkPaymentDetailColumns,
                listName: "fkPaymentDetail"
            }];
            elements.searchItems = zhSearchItems;
            break;
        case 'fkCertificateImage':
            elements.columns = customerParentsColumns;
            elements.formItems = [{name: "调阅凭证图像", items: fkCertificateFormItems}];
            elements.subTables = [];
            elements.searchItems = customerSearchItems;
            break;
        case 'fkFinancialAccount':
            elements.columns = customerParentsColumns;
            elements.formItems = [{name: "金融理财账户信息", items: fkFinancialFormItems}];
            elements.subTables = [{
                name: "金融理财信息明细",
                items: fkFinancialDetailFormItems,
                columns: fkFinancialDetailColumns,
                listName: "fkFinancialDetail"
            }];
            elements.searchItems = customerSearchItems;
            break;
    }
    return elements;
}

export const parentsColumns: TableColumnInfo[] = [
    {prop: 'qqdbs', label: '请求单标识', minWidth: 200},
    {prop: 'rwlsh', label: '任务流水号', minWidth: 210},
    {prop: 'ckztlb', label: '查控主体类别', minWidth: 200, dictFormatKey: 'ckztlb'},
    {prop: 'sqjgdm', label: '申请机构代码', minWidth: 200, dictFormatKey: sqjgdm},
    {prop: 'mbjgdm', label: '目标机构代码', minWidth: 200, dictFormatKey: 'mbjgdm'},
    {prop: 'branchCode', label: '业务操作机构', width: 100, dictFormatKey: 'branchTree'},
    // {prop: 'cxfkjg', label: '查询反馈结果',dictFormatKey:'cxfkjg'},
    // {prop: 'cxfkjgyy', label: '查询反馈结果原因'},
    {prop: 'createBy', label: '创建人', minWidth: 200},
    {prop: 'createTime', label: '创建时间', minWidth: 200, formatter:dateFormatter},
    {prop: 'updateBy', label: '修改人', minWidth: 200},
    {prop: 'updateTime', label: '修改时间', minWidth: 200, formatter:dateFormatter},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]

// 展示列字段
export const customerParentsColumns: TableColumnInfo[] = [

    {key: 'id', type: 'selection'},
    {prop: 'khmc', label: '客户名称', width: 80},
    {prop: 'zzhm', label: '证照号码', width: 170},
    ...parentsColumns,
]

// 展示列字段
export const zhParentsColumns: TableColumnInfo[] = [

    {key: 'id', type: 'selection'},
    {prop: 'zh', label: '账号', width: 170},
    {prop: 'kh', label: '卡号', width: 170},
    ...parentsColumns,
]
// 展示列字段
export const transactionParentsColumns: TableColumnInfo[] = [

    {key: 'id', type: 'selection'},
    {prop: 'cxzh', label: '账号', width: 170},
    {prop: 'cxkh', label: '卡号', width: 170},
    ...parentsColumns,
]
// 展示列字段
export const paymentParentsColumns: TableColumnInfo[] = [

    {key: 'id', type: 'selection'},
    {prop: 'zh', label: '账号', width: 170},
    ...parentsColumns,
]

export const parentsFormItems: FormItemInfo[] = [
    {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            // multiple: true,
        },

    },
    {
        prop: 'sqjgdm',
        label: '申请机构代码',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: sqjgdm,
            multiple: false,
        },
    },
    {
        prop: 'mbjgdm',
        label: '目标机构代码',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'mbjgdm',
            multiple: false,
        },
    },
    // {
    //     prop: 'status',
    //     label: '状态',
    //     labelWidth: 100,
    //     inputType: {
    //         tag: 'select',
    //         options: 'dataStatus',
    //         multiple: false,
    //     },
    // },
]

// 账户信息查询请求
export const fkCustomerColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'qqdbs', label: '请求单标识', minWidth: 200},
    {prop: 'rwlsh', label: '任务流水号', minWidth: 210},
    // {prop: 'cxfkjg', label: '查询反馈结果',dictFormatKey:'cxfkjg'},
    // {prop: 'cxfkjgyy', label: '查询反馈结果原因'},
    // {prop: 'zzlxdm', label: '证照类型', dictFormatKey: 'license'},
    // {prop: 'zzhm', label: '证照号码'},
    // {prop: 'khmc', label: '客户名称'},
    // {prop: 'lxdh', label: '联系电话'},
    // {prop: 'lxsj', label: '联系手机'},
    // {prop: 'dbrxm', label: '代办人姓名'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    // {prop: 'dbrzjlx', label: '代办人证件类型'},
    // {prop: 'dbrzjhm', label: '代办人证件号码'},
    // {prop: 'zzdz', label: '住宅地址'},
    // {prop: 'zzdh', label: '住宅电话'},
    // {prop: 'gzdw', label: '工作单位'},
    // {prop: 'dwdz', label: '单位地址'},
    // {prop: 'dwdh', label: '单位电话'},
    // {prop: 'yxdz', label: '邮箱地址'},
    // {prop: 'frdb', label: '法人代表'},
    // {prop: 'frdbzjlx', label: '法人代表证件类型'},
    // {prop: 'frdbzjhm', label: '法人代表证件号码'},
    // {prop: 'khgszzhm', label: '客户工商执照号码'},
    // {prop: 'gsnsh', label: '国税纳税号'},
    // {prop: 'dsnsh', label: '地税纳税号'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]
export const fkCustomerFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    // },
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
            // multiple: true,
        },
    },
    {
        prop: 'cxfkjgyy',
        label: '查询反馈结果原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzlxdm',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            multiple: false,
        },
    },
    {
        prop: 'zzhm',
        label: '证照号码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'branchCode',
        label: '数据机构代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'branchCode',
            multiple: true,
        }
    },
    {
        prop: 'khmc',
        label: '客户名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'lxdh',
        label: '联系电话',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'lxsj',
        label: '联系手机',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'dbrxm',
        label: '代办人姓名',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'dbrzjlx',
        label: '代办人证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            // multiple: true,
        },
    },
    {
        prop: 'dbrzjhm',
        label: '代办人证件号码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzdz',
        label: '住宅地址',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzdh',
        label: '住宅电话',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'gzdw',
        label: '工作单位',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'dwdz',
        label: '单位地址',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'dwdh',
        label: '单位电话',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'yxdz',
        label: '邮箱地址',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'frdb',
        label: '法人代表',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'frdbzjlx',
        label: '法人代表证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            // multiple: true,
        },
    },
    {
        prop: 'frdbzjhm',
        label: '法人代表证件号码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'khgszzhm',
        label: '客户工商执照号码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'gsnsh',
        label: '国税纳税号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'dsnsh',
        label: '地税纳税号',
        labelWidth: 150,
        inputType: 'input',
    },
]

export const fkAccountColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'kh', label: '卡号', width: 150},
    {prop: 'zh', label: '账号', width: 150},
    {prop: 'zhlb', label: '账户类别', width: 150, dictFormatKey: 'zhlb'},
    {prop: 'zhzt', label: '账户状态', width: 150, dictFormatKey: 'zhzt'},
    // {prop: 'khwd', label: '开户网点'},
    // {prop: 'khwddm', label: '开户网点代码'},
    // {prop: 'khrq', label: '开户日期', width: 100},
    // {prop: 'xhrq', label: '销户日期', width: 100},
    // {prop: 'xhwd', label: '销户网点'},
    {prop: 'bz', label: '币种', width: 150, dictFormatKey: 'currency'},
    // {prop: 'chbz', label: '钞汇标志', width: 50},
    {prop: 'zhye', label: '账户余额', width: 150},
    {prop: 'kyye', label: '可用余额', width: 150},
    // {prop: 'zhjysj', label: '最后交易时间', width: 100},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    // {prop: 'beiz', label: '备注'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // type:'expand',
    },
]
export const fkAccountFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    //     extra: {
    //         notModifiable: true, //id有值时,不可编辑
    //     },
    // },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhlb',
        label: '账户类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zhlb',
            // multiple: true,
        },
    },
    {
        prop: 'zhzt',
        label: '账户状态',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zhzt',
            // multiple: true,
        },
    },
    {
        prop: 'khwd',
        label: '开户网点',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'khwddm',
        label: '开户网点代码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'khrq',
        label: '开户日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'xhrq',
        label: '销户日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'xhwd',
        label: '销户网点',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhye',
        label: '账户余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kyye',
        label: '可用余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhjysj',
        label: '最后交易时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
    },
]

export const fkMeasureColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'zh', label: '账号'},
    {prop: 'csxh', label: '措施序号'},
    {prop: 'djksrq', label: '冻结开始日期'},
    {prop: 'djjzrq', label: '冻结截止日期'},
    {prop: 'djjgmc', label: '冻结机关名称'},
    {prop: 'djje', label: '冻结金额'},
    // {prop: 'beiz', label: '备注'},
    {prop: 'djcslx', label: '冻结措施类型', dictFormatKey: 'djcslx'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkMeasureFormItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'csxh',
        label: '措施序号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djksrq',
        label: '冻结开始日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'djjzrq',
        label: '冻结截止日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'djjgmc',
        label: '冻结机关名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djje',
        label: '冻结金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djcslx',
        label: '冻结措施类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'djcslx',
            // multiple: true,
        },
    },
]

export const fkPriorityColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'zh', label: '账号'},
    {prop: 'xh', label: '权利序号'},
    {prop: 'qllx', label: '权利类型'},
    {prop: 'zzlxdm', label: '证件类型代码', dictFormatKey: 'license'},
    {prop: 'zzhm', label: '证件号码'},
    {prop: 'qlrxm', label: '权利人姓名'},
    {prop: 'qlje', label: '权利金额'},
    // {prop: 'qlrdz', label: '权利人通讯地址'},
    // {prop: 'qlrlxfs', label: '权利人联系方式'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkPriorityFormItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'xh',
        label: '权利序号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'qllx',
        label: '权利类型',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzlxdm',
        label: '证件类型代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            // multiple: true,
        },
    },
    {
        prop: 'zzhm',
        label: '证件号码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'qlrxm',
        label: '权利人姓名',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'qlje',
        label: '权利金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'qlrdz',
        label: '权利人通讯地址',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'qlrlxfs',
        label: '权利人联系方式',
        labelWidth: 150,
        inputType: 'input',
    },
]

export const fkSubAccountColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'zh', label: '账卡号'},
    {prop: 'zzhxh', label: '子账户序号'},
    {prop: 'zzhlb', label: '子账户类别', dictFormatKey: 'zzhlb'},
    {prop: 'zzhzh', label: '子账户账号'},
    {prop: 'bz', label: '币种', dictFormatKey: 'currency'},
    {prop: 'chbz', label: '钞汇标志'},
    {prop: 'zhye', label: '账户余额'},
    {prop: 'zhzt', label: '账户状态', dictFormatKey: 'zhzt'},
    {prop: 'kyye', label: '可用余额'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkSubAccountFormItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzhxh',
        label: '子账户序号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzhlb',
        label: '子账户类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zzhlb',
            // multiple: true,
        },
    },
    {
        prop: 'zzhzh',
        label: '子账户账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhye',
        label: '账户余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhzt',
        label: '账户状态',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zhzt',
            // multiple: true,
        },
    },
    {
        prop: 'kyye',
        label: '可用余额',
        labelWidth: 150,
        inputType: 'input',
    },
]

export const fkTransactionColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'qqdbs', label: '请求单标识', minWidth: 200},
    {prop: 'rwlsh', label: '任务流水号', minWidth: 210},
    // {prop: 'cxfkjg', label: '查询反馈结果',dictFormatKey:'cxfkjg' ,},
    // {prop: 'cxfkjgyy', label: '查询反馈结果原因'},
    {prop: 'cxzh', label: '查询帐号'},
    {prop: 'cxkh', label: '查询卡号'},
    {prop: 'jylx', label: '交易类型', dictFormatKey: 'jylxgjk'},
    {prop: 'jdbz', label: '借贷标志'},
    {prop: 'bz', label: '币种', dictFormatKey: 'currency'},
    {prop: 'je', label: '交易金额'},
    {prop: 'ye', label: '交易余额'},
    {prop: 'jysj', label: '交易时间'},
    // {prop: 'jylsh', label: '交易流水号'},
    // {prop: 'jydfxm', label: '交易对方名称'},
    // {prop: 'jydfzkh', label: '交易对方账卡号'},
    // {prop: 'jydfzkhlx', label: '交易对方帐卡号类型'},
    // {prop: 'jydfzjhm', label: '交易对方证件号码'},
    // {prop: 'jydsye', label: '交易对手余额'},
    // {prop: 'jydfzhkhh', label: '交易对方账号开户行'},
    // {prop: 'jyzy', label: '交易摘要'},
    // {prop: 'jywdmc', label: '交易网点名称'},
    // {prop: 'jywddm', label: '交易网点代码'},
    // {prop: 'rzh', label: '日志号'},
    // {prop: 'cph', label: '传票号'},
    // {prop: 'pzzl', label: '凭证种类'},
    // {prop: 'pzh', label: '凭证号'},
    // {prop: 'xjbz', label: '现金标志'},
    // {prop: 'zdh', label: '终端号'},
    // {prop: 'jysfcg', label: '交易是否成功'},
    // {prop: 'jyfsd', label: '交易发生地'},
    // {prop: 'shmc', label: '商户名称'},
    // {prop: 'shh', label: '商户号'},
    // {prop: 'ip', label: 'IP地址'},
    // {prop: 'mac', label: 'MAC地址'},
    // {prop: 'jygyh', label: '交易柜员号'},
    // {prop: 'beiz', label: '备注'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
        // minWidth: 200,
        // type:'expand',
    },
]
export const fkTransactionFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    // },
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
            // multiple: true,
        },
    },
    {
        prop: 'cxfkjgyy',
        label: '查询反馈结果原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'cxzh',
        label: '查询帐号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'cxkh',
        label: '查询卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jylx',
        label: '交易类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'jylxgjk',
            // multiple: true,
        },
    },
    {
        prop: 'jdbz',
        label: '借贷标志',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'je',
        label: '交易金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'ye',
        label: '交易余额',
        labelWidth: 150,
        inputType: 'input',
    }, {
        prop: 'jysj',
        label: '交易时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'jylsh',
        label: '交易流水号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jydfxm',
        label: '交易对方名称',
        labelWidth: 150,
        inputType: 'input',
    },

    {
        prop: 'jydfzkh',
        label: '交易对方账卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jydfzkhlx',
        label: '交易对方帐卡号类型',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jydfzjhm',
        label: '交易对方证件号码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jydsye',
        label: '交易对手余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jydfzhkhh',
        label: '交易对方账号开户行',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jyzy',
        label: '交易摘要',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jywdmc',
        label: '交易网点名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jywddm',
        label: '交易网点代码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'rzh',
        label: '日志号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'cph',
        label: '传票号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'pzzl',
        label: '凭证种类',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'pzh',
        label: '凭证号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'xjbz',
        label: '现金标志',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zdh',
        label: '终端号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jysfcg',
        label: '交易是否成功',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'jysfcg',
            // multiple: true,
        },
    },
    {
        prop: 'jyfsd',
        label: '交易发生地',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'shmc',
        label: '商户名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'shh',
        label: '商户号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'ip',
        label: 'IP地址',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'mac',
        label: 'MAC地址',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jygyh',
        label: '交易柜员号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
    },
]

export const fkDynamicReceiptColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'qqdbs', label: '请求单标识', minWidth: 200},
    {prop: 'rwlsh', label: '任务流水号', minWidth: 210},
    {prop: 'zh', label: '账号'},
    {prop: 'kh', label: '卡号'},
    {prop: 'zxjg', label: '执行结果', dictFormatKey: 'zxjg'},
    {prop: 'sbyy', label: '失败原因'},
    {prop: 'fksjhm', label: '反馈手机号码'},
    {prop: 'zxqssj', label: '执行起始时间'},
    {prop: 'zxsjqj', label: '执行时间区间', dictFormatKey: 'zxsjqj'},
    {prop: 'jssj', label: '结束时间'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkDynamicReceiptFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    // },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
            // multiple: true,
        },
    },
    {
        prop: 'sbyy',
        label: '失败原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'fksjhm',
        label: '反馈手机号码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxqssj',
        label: '执行起始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'zxsjqj',
        label: '执行时间区间',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxsjqj',
            // multiple: true,
        },
    },
    {
        prop: 'jssj',
        label: '结束时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
]

export const fkDynamicColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'qqdbs', label: '请求单标识', minWidth: 200},
    {prop: 'rwlsh', label: '任务流水号', minWidth: 210},
    {prop: 'zh', label: '账号'},
    {prop: 'kh', label: '卡号'},
    {prop: 'zhmc', label: '账户名称'},
    {prop: 'zhbz', label: '账户币种', dictFormatKey: 'currency'},
    {prop: 'zhdykh', label: '账户对应卡号'},
    {prop: 'jycz', label: '交易操作'},
    {prop: 'czsj', label: '操作时间'},
    {prop: 'jydd', label: '交易地点'},
    {prop: 'ajlx', label: '案件类型'},
    {prop: 'jyje', label: '交易金额'},
    {prop: 'jybz', label: '交易币种', dictFormatKey: 'currency'},
    {prop: 'zhxyed', label: '账户信用额度'},
    {prop: 'khzjlx', label: '客户证件类型'},
    {prop: 'khzjhm', label: '客户证件号码'},
    {prop: 'jydfzkh', label: '交易对方账卡号'},
    {prop: 'jydfzkhlx', label: '交易对方账卡号类型'},
    {prop: 'dfzhmc', label: '对方账户名称'},
    {prop: 'dfzhbz', label: '对方账户币种', dictFormatKey: 'currency'},
    {prop: 'pzzl', label: '凭证种类'},
    {prop: 'pzh', label: '凭证号'},
    {prop: 'xjbz', label: '现金标志'},
    {prop: 'fwjm', label: '服务界面'},
    {prop: 'zdh', label: '终端号'},
    {prop: 'kyxq', label: '卡有效期'},
    {prop: 'jylxyhk', label: '交易类型（银行卡）'},
    {prop: 'jylxgjk', label: '交易类型（个金、国际卡）', dictFormatKey: 'jylxgjk'},
    {prop: 'shh', label: '商户号（银行卡）'},
    {prop: 'shmc', label: '商户名（银行卡）'},
    {prop: 'wdms', label: '网点描述'},
    {prop: 'wddz', label: '网点地址'},
    {prop: 'wddh', label: '网点电话'},
    {prop: 'gyh', label: '柜员号'},
    {prop: 'sqgyh', label: '授权柜员号'},
    {prop: 'jydm', label: '交易代码'},
    {prop: 'fjybz', label: '反交易标志'},
    {prop: 'czjybs', label: '冲正交易标识'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkDynamicFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    // },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhmc',
        label: '账户名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhbz',
        label: '账户币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'zhdykh',
        label: '账户对应卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jycz',
        label: '交易操作',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'czsj',
        label: '操作时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'jydd',
        label: '交易地点',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'ajlx',
        label: '案件类型',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jyje',
        label: '交易金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jybz',
        label: '交易币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'zhxyed',
        label: '账户信用额度',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'khzjlx',
        label: '客户证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            // multiple: true,
        },
    },
    {
        prop: 'khzjhm',
        label: '客户证件号码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jydfzkh',
        label: '交易对方账卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jydfzkhlx',
        label: '交易对方账卡号类型',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'dfzhmc',
        label: '对方账户名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'dfzhbz',
        label: '对方账户币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'pzzl',
        label: '凭证种类',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'pzh',
        label: '凭证号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'xjbz',
        label: '现金标志',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'fwjm',
        label: '服务界面',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zdh',
        label: '终端号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kyxq',
        label: '卡有效期',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jylxyhk',
        label: '交易类型（银行卡）',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jylxgjk',
        label: '交易类型（个金、国际卡）',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'jylxgjk',
            // multiple: true,
        },
    },
    {
        prop: 'shh',
        label: '商户号（银行卡）',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'shmc',
        label: '商户名（银行卡）',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'wdms',
        label: '网点描述',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'wddz',
        label: '网点地址',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'wddh',
        label: '网点电话',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'gyh',
        label: '柜员号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'sqgyh',
        label: '授权柜员号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jydm',
        label: '交易代码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'fjybz',
        label: '反交易标志',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'czjybs',
        label: '冲正交易标识',
        labelWidth: 150,
        inputType: 'input',
    },
]

export const fkFreezeColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'qqdbs', label: '请求单标识', minWidth: 200},
    {prop: 'rwlsh', label: '任务流水号', minWidth: 210},
    {prop: 'zh', label: '账号'},
    {prop: 'kh', label: '卡号'},
    {prop: 'zxjg', label: '执行结果', dictFormatKey: 'zxjg'},
    {prop: 'sqdjxe', label: '申请冻结限额'},
    {prop: 'sdje', label: '执行冻结金额'},
    {prop: 'ye', label: '账户余额'},
    {prop: 'zxqssj', label: '执行起始时间'},
    {prop: 'djjsrq', label: '执行结束时间'},
    {prop: 'wndjyy', label: '未能冻结原因'},
    {prop: 'djjg', label: '在先冻结机关'},
    {prop: 'djje', label: '在先冻结金额'},
    {prop: 'djjzrq', label: '在先冻结到期日'},
    {prop: 'wdjje', label: '未冻结金额'},
    {prop: 'zhkyye', label: '账户可用余额'},
    {prop: 'beiz', label: '备注'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkFreezeFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    // },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kh',
        label: '卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
            // multiple: true,
        },
    },
    {
        prop: 'sqdjxe',
        label: '申请冻结限额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'sdje',
        label: '执行冻结金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'ye',
        label: '账户余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxqssj',
        label: '执行起始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'djjsrq',
        label: '执行结束时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'wndjyy',
        label: '未能冻结原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djjg',
        label: '在先冻结机关',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djje',
        label: '在先冻结金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djjzrq',
        label: '在先冻结到期日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'wdjje',
        label: '未冻结金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhkyye',
        label: '账户可用余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
    },
]

export const fkFreezeDetailColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    // {prop: 'qqdbs', label: '请求单标识' , minWidth:200},
    // {prop: 'rwlsh', label: '任务流水号' , minWidth:210},
    {prop: 'zh', label: '账号'},
    {prop: 'zhzzh', label: '账号子账号'},
    {prop: 'zzhxh', label: '子账号序号'},
    {prop: 'zzhye', label: '子账号余额'},
    {prop: 'zxjg', label: '执行结果', dictFormatKey: 'zxjg'},
    {prop: 'zxjgyy', label: '执行失败原因'},
    {prop: 'djjg', label: '在先冻结机关'},
    {prop: 'zxdjje', label: '在先冻结金额'},
    {prop: 'djjzrq', label: '在先冻结到期日'},
    {prop: 'djje', label: '冻结金额'},
    {prop: 'djkssj', label: '冻结开始时间'},
    {prop: 'wdjje', label: '未冻结金额'},
    {prop: 'djjssj', label: '冻结结束时间'},
    {prop: 'bz', label: '币种', dictFormatKey: 'currency'},
    {prop: 'chbz', label: '钞汇标志'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkFreezeDetailFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    // },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhzzh',
        label: '账号子账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzhxh',
        label: '子账号序号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzhye',
        label: '子账号余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
            // multiple: true,
        },
    },
    {
        prop: 'zxjgyy',
        label: '执行失败原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djjg',
        label: '在先冻结机关',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxdjje',
        label: '在先冻结金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djjzrq',
        label: '在先冻结到期日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'djje',
        label: '冻结金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djkssj',
        label: '冻结开始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'wdjje',
        label: '未冻结金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'djjssj',
        label: '冻结结束时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        inputType: 'input',
    },
]

export const fkPaymentColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'qqdbs', label: '请求单标识', minWidth: 200},
    {prop: 'rwlsh', label: '任务流水号', minWidth: 210},
    {prop: 'zh', label: '账号'},
    {prop: 'zxjg', label: '执行结果', dictFormatKey: 'zxjg'},
    {prop: 'sbyy', label: '失败原因'},
    {prop: 'zxqssj', label: '执行起始时间'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkPaymentFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    // },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
            // multiple: true,
        },
    },
    {
        prop: 'sbyy',
        label: '失败原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxqssj',
        label: '执行起始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },

]
export const fkCertificateFormItems: FormItemInfo[] = [
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
            // multiple: true,
        },
    },
    {
        prop: 'cxfkjgyy',
        label: '查询反馈结果原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'cxkh',
        label: '查询卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'cxzl',
        label: '查询种类',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxzl',
            // multiple: true,
        },
    },
    {
        prop: 'jylsh',
        label: '交易流水号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'pztxlx',
        label: '凭证图像类型',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'pztxxh',
        label: '凭证图像序号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'pztxmc',
        label: '凭证图像名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
    }

]
export const fkFinancialFormItems: FormItemInfo[] = [
    {
        prop: 'cxfkjg',
        label: '查询反馈结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxfkjg',
            // multiple: true,
        },
    },
    {
        prop: 'cxfkjgyy',
        label: '查询反馈结果原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'cxkh',
        label: '查询卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kh',
        label: '理财卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zh',
        label: '理财账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhmc',
        label: '账户名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'sfqywy',
        label: '是否签约网银',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'sfqysjyh',
        label: '是否签约手机银行',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhdlip',
        label: '最后登录IP',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhdlsj',
        label: '最后登录时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'zhlb',
        label: '账户类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zhlb',
            // multiple: true,
        },
    },
    {
        prop: 'zhzt',
        label: '账户状态',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zhzt',
            // multiple: true,
        },
    },
    {
        prop: 'khwd',
        label: '开户网点',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'khwddm',
        label: '开户网点代码',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'khrq',
        label: '开户日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'xhrq',
        label: '销户日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'xhwd',
        label: '销户网点',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhye',
        label: '账户余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kyye',
        label: '可用余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhjysj',
        label: '最后交易时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
    },

]

export const fkPaymentDetailColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    // {prop: 'qqdbs', label: '请求单标识' , minWidth:200},
    // {prop: 'rwlsh', label: '任务流水号' , minWidth:210},
    {prop: 'zh', label: '账号'},
    {prop: 'zhzzh', label: '账号子账号'},
    {prop: 'zzhxh', label: '子账号序号'},
    {prop: 'zzhye', label: '子账号余额'},
    {prop: 'zxjg', label: '执行结果', dictFormatKey: 'zxjg'},
    {prop: 'zxjgyy', label: '执行失败原因'},
    {prop: 'zfkssj', label: '止付开始时间'},
    {prop: 'zfjssj', label: '止付结束时间'},
    {prop: 'bz', label: '币种', dictFormatKey: 'currency'},
    {prop: 'chbz', label: '钞汇标志'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkPaymentDetailFormItems: FormItemInfo[] = [
    // {
    //     prop: 'rwlsh',
    //     label: '任务流水号',
    //     labelWidth: 150,
    //     inputType: 'input',
    // },
    {
        prop: 'zh',
        label: '账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zhzzh',
        label: '账号子账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzhxh',
        label: '子账号序号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zzhye',
        label: '子账号余额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zxjg',
        label: '执行结果',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxjg',
            // multiple: true,
        },
    },
    {
        prop: 'zxjgyy',
        label: '执行失败原因',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zfkssj',
        label: '止付开始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'zfjssj',
        label: '止付结束时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'chbz',
        label: '钞汇标志',
        labelWidth: 150,
        inputType: 'input',
    },
]
export const fkFinancialDetailColumns: TableColumnInfo[] = [
    {key: 'id', type: 'selection'},
    {prop: 'kh', label: '理财卡号'},
    {prop: 'zh', label: '理财账号'},
    {prop: 'jrzcmc', label: '金融理财名称'},
    {prop: 'jrzclx', label: '金融理财类型'},
    {prop: 'jrcpbh', label: '金融产品编号'},
    {prop: 'status', label: '状态', dictFormatKey: 'dataStatus'},
    {
        key: 'actions',
        label: '操作',
        scopedSlots: 'actions',
        width: 140,
        minWidth: 140,
        fixed: 'right',
    },
]
export const fkFinancialDetailFormItems: FormItemInfo[] = [

    {
        prop: 'kh',
        label: '理财卡号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zh',
        label: '理财账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jrzcmc',
        label: '金融理财名称',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jrzclx',
        label: '金融理财类型',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'cpxszl',
        label: '产品销售种类',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jrcpbh',
        label: '金融产品编号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zcglr',
        label: '资产管理人',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zcjyxzlx',
        label: '资产交易限制类型',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zcjyxzxcsj',
        label: '资产交易限制消除时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'cpzt',
        label: '产品状态',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zyqr',
        label: '质押权人',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'tgr',
        label: '托管人',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'syr',
        label: '受益人',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'clr',
        label: '成立日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {//此处shr是数据库关键词，故改成shrDate
        prop: 'shrDate',
        label: '赎回日',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
    },
    {
        prop: 'tgzh',
        label: '托管账号',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'jldw',
        label: '计量单位',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            // multiple: true,
        },
    },
    {
        prop: 'zcdwjg',
        label: '资产单位价格',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'se',
        label: '数量/份额/金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kyse',
        label: '可控数量/份额/金额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'zczse',
        label: '资产总数额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'kkzczse',
        label: '可控资产总数额',
        labelWidth: 150,
        inputType: 'input',
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
    },
]
export const searchItems: FormItemInfo[] = [
    {
        prop: 'subSystem',
        label: '所属系统',
        inputType: {
          tag: 'select',
          options: 'systemCode',
        },  
        labelWidth: 100
      },
    {
        prop: 'qqdbs',
        label: '请求单标识',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'fklx',
        label: '反馈类型',
        inputType: {
            tag: 'select',
            options: 'fklx',
        },
        labelWidth: 100
    },
    {
        prop: 'status',
        label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
            multiple: true,
        },
        labelWidth: 100
    },
];

export const customerSearchItems: FormItemInfo[] = [
    {
        prop: 'khmc',
        label: '客户名称',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'zzhm',
        label: '证照号码',
        inputType: 'input',
        labelWidth: 100
    },
    ...searchItems
];
export const zhSearchItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'kh',
        label: '卡号',
        inputType: 'input',
        labelWidth: 100
    },
    ...searchItems
];
export const transactionSearchItems: FormItemInfo[] = [
    {
        prop: 'cxzh',
        label: '账号',
        inputType: 'input',
        labelWidth: 100
    }, {
        prop: 'cxkh',
        label: '卡号',
        inputType: 'input',
        labelWidth: 100
    },
    ...searchItems
];
export const paymentSearchItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        inputType: 'input',
        labelWidth: 100
    },
    ...searchItems
];





