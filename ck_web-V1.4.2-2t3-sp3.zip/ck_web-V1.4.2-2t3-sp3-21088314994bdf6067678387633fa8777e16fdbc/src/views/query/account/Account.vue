<template>
  <rk-index-layout>
    <!--    <rk-search-form ref="searchFormRef" v-model="searchForm" @keyup.enter="search" :form-items="recordSearchFormItems"
                        @search="search" :label-width="50"/>-->
    <rk-dynamic-search-form v-model="searchForm" :form-items="recordSearchFormItems" :fields="advancedQueryItems"
                            @search="search" ></rk-dynamic-search-form>


    <rk-page-table ref="mainTable" :data="data" :columns="recordColumns" :loading="loading" :pagination="page"
                   :row-key="getRowKey" :expand-row-keys="expands" :id="getRowKey"
                   @page-change="pageChange" @refresh="search" @selection-change="handleSelectionChange"
                   @expand-change="clickRowHandle">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="buttons" :route-meta="$route.meta"></rk-button-group>
          <div style="margin: 0 4px;"></div>
          <UpAndDown :imp="imp" :exp="exp"/>
        </div>
      </template>

      <template #expand="{ row }">
        <rk-page-table ref="treeTable" :loading="treeLoading" :data="treeData" :columns="columns" border="true"
                       max-height="500" hiddenTableTools style="margin-left: 30px;width: 98%"
                       :pagination="treePage" @page-change="(p: Pagination) =>treePageChange(p,row)"
                       @refresh="treeSearch">
          <template #actions="{ row:subRow }">
            <rk-button-group :buttons="genActButtons(subRow,row)" :route-meta="$route.meta" :max='3' link/>
          </template>
        </rk-page-table>
      </template>

      <template #fileActions="{ row }">
        <rk-button-group v-if="row.importType!=='3'" :buttons="genFileActButtons(row)"
                         :route-meta="$route.meta" link/>
      </template>
    </rk-page-table>
  </rk-index-layout>
  <!-- 查看编辑 弹出层 -->
  <el-dialog v-model="dialogData.visible" :title="dialogData.title" class="rk-dialog-default" @closed="closed"
             :close-on-click-modal="false">

    <rk-collapse-form
        ref="dialogFormRef"
        v-model="form"
        :form-items="dialogData.title.includes('编辑')?
        [{
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 150,
        inputType: {tag:'input',disabled:true},
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{max:30,message:'请求单标识长度不可超过30'},{required: true, message: '请求单标识不能为空'}],
    },{
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
            disabled:true
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{required: true, message: '分类代码必填'}]
    },...formItems.filter(item => {
        return (
           item.prop !=='qqdbs'&& item.prop !=='fldm'
        );
      })]:formItems"
        :collapse-model-value="activeCollapse"
        :disabled="dialogData.formDisabled"
    >
    </rk-collapse-form>

    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" v-if="dialogData.title.includes('编辑')"
                   :loading="buttonLoading" @click="editUpdate">保存</el-button>
        <el-button @click="close"> 取消</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 新增 弹出层 -->
  <el-dialog v-model="addDialog" title="线下请求单" width="90%" @closed="()=>{addFormRef.resetFields()}">
    <rk-collapse-form ref="addFormRef" v-model="addForm" :collapse-model-value="activeCollapse"
                      :form-items="formItems">

    </rk-collapse-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="addSave">保存</el-button>
        <el-button @click="addDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 请求单页面反馈弹出框 -->
  <el-dialog title="反馈" v-model="feedbackDialog" width="90%" @closed="clearFeedbackForm();">
    <rk-collapse-form
        ref="bodyFormRef"
        v-model="bodyForm"
        :form-items="
        formItems.filter(item => {
        return (
           item.extra &&
           item.extra.collapse &&
           item.extra.collapse.name === 'body' &&
           item.extra.collapse.title === '主体信息'
        );
      })"
        :disabled="true"
    >
    </rk-collapse-form>
    <div>
      <h4>反馈信息</h4>
    </div>
    <rk-detail-form ref="feedbackFormRef" v-model="feedbackForm" :form-items=getFkItems(fldm)>
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled=true filterable style="width: 100%">
        </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="reportCode==='certificate'" type="primary" @click="uploadFile">上传凭证图像文件</el-button>
        <el-button type="primary" @click="feedback">保存</el-button>
        <el-button @click="feedbackDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 指派机构表格弹出框 -->
  <el-dialog title="指派" v-model="assignmentDialog" width="70%">

    <rk-page-table  ref="assignmentTable" :loading="assignmentLoading" :data="assignmentData"
                   :columns="assignmentColumns" border="true"
                   @selection-change="assignmentIdsHandleSelectionChange" @refresh="assignmentSearch">
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <!-- 此处按钮无需做权限配置 -->
          <rk-button-group :buttons="assignmentButtons" :route-meta="[]"></rk-button-group>
        </div>
      </template>
    </rk-page-table>
  </el-dialog>
  <!-- 指派机构form弹出框 -->
  <el-dialog title="新增指派" v-model="assignmentFormDialog" width="70%" @closed="()=>{assignmentFormRef.resetFields()}">
    <rk-detail-form ref="assignmentFormRef" v-model="assignmentForm" :form-items="[
     {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },{
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },{
        prop: 'branchCode',
        label: '业务操作机构',
        labelWidth: 150,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            showCheckbox: true,
            checkStrictly: true,
        },
        rules: [{required: true, message: '业务操作机构不能为空'}],
    },
    ]">
      <template #systemCode="{ item: i, form: f }">
        <el-input v-model="f[i.prop]" :disabled=true filterable style="width: 100%">
        </el-input>
      </template>
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="assignmentSave">保存</el-button>
        <el-button @click="assignmentFormDialog = false"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog v-model="dialogVisible" title="文件列表">
    <!-- 下面的按钮无实际作用 , 用于页面美观 , 否则下面第二个按钮会出现错位现象 -->
    <el-button disabled link>{{ '' }}</el-button>
    <!-- 文件列表按钮 -->
    <el-button v-for="xmlKey in xmlButtonKeys" :key="xmlKey" type="primary" link
               style=" margin-bottom: 10px;   display: flex;  flex-direction: column;" @click="openXml(xmlKey)">
      {{ xmlKey }}
    </el-button>
  </el-dialog>
  <template>
    <div>
      <el-upload
          ref="uploadRef"
          :on-error="()=>{ElMessage.error({ message: '上传失败', grouping: true, showClose: true, duration: 0})}"
          :show-file-list="false"
          :http-request="IUploadFile">
        >
        <el-button ref="uploadButton" id="uploadButton" type="primary">上传文件</el-button>
      </el-upload>
    </div>
  </template>
  <div class="img-viewer-box">
    <el-image-viewer v-if="showImageViewer" :url-list="urlList" @close="() => {showImageViewer   = false}"/>
  </div>
</template>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {ElDialog, ElButton, ElMessage} from 'element-plus'
import {
  assignmentDialog,
  assignmentLoading,
  assignmentData,
  assignmentColumns,
  // assignmentPage,
  // assignmentPageChange,
  assignmentSearch,
  assignmentButtons,
  assignmentQqdbs,
  assignmentRwlsh,
  assignmentIdsHandleSelectionChange,
  assignmentSave,
  assignmentFormDialog,
  assignmentFormRef,
  assignmentForm
} from '@/utils/assignment'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  RkDetailForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  FormItemInfo, TableColumnInfo, RkDynamicSearchForm,
} from 'riking-ui'
import {pagination, treePagination} from "@/views/query/account/data";
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'
import {useDict} from 'riking-layout'
import {
  derivedPageElements,
  recordColumns,
  recordSearchFormItems,
  advancedQueryItems
} from "@/views/query/account/page";
import {derivedPageElements as feedbackDerivedPageElements} from "@/views/query/feedback/page";
import {
  list,
  impZip,
  listOne,
  getPdf,
  getImage,
  downloadZip,
  getXml,
  checkData,
  del,
  update,
  save, listFldm, treeList, upload, updateRequestStatus, exportExcel
} from '@/views/query/account/api'
import * as monaco from 'monaco-editor';
import UpAndDown, {expLoading} from "@/components/UpAndDown.vue";
import {getRequestClassificationCode, getSubSystem} from '@/utils/subSystem';
import {saveData} from "@/views/query/feedback/api";
import {checkSpecialCharacters, copyProperties, specialChecks} from "@/utils/utils";

useDict([], [], {
  ...dictData,
  branchCode: async () => {
    const res = await dictsStore.loadDict()
    return res.data.branchCode
  },
  fldm: async () => {
    const path = useRoute().path;
    reportCode.value = getRequestClassificationCode();
    const res = await listFldm(reportCode.value);
    return res.data
  },
  sqjgdm: async () => {
    return dictData['sqjgdm' + "." + getSubSystem()];
  }
})

const buttonLoading = ref(false);
const addDialog = ref(false);

const addFormRef = ref<RkFormInstance>()

const addForm = getAddForm()

function getAddForm() {
  if (getSubSystem()=='ga') {
   return  ref({qqrzjlx:'110031',xcrzjlx:'110031'});
  }else if (getSubSystem()=='jcy') {
    return ref({qqrzjlx:'110041',xcrzjlx:'110041'});
  } else {

    return ref({});
  }

}
const reportCode = ref(''); // 报文编号
const loading = ref(false)
const data = ref<any []>([]);
const page = ref<Pagination>(pagination)
const dialogVisible = ref(false);
const xmlButtonKeys = ref({});
const xmlDataList = ref({});
const searchFormRef = ref<RkFormInstance>()
const searchForm = ref({})
const showImageViewer = ref(false) //组件是否显示
const urlList = ref([]) //图片List
let keyword: string
let columns: TableColumnInfo[] = [], formItems: FormItemInfo[] = [], searchFormItems: FormItemInfo[] = [];

/**
 * 反馈弹出框所需组件
 * */
 let feelbackItem: FormItemInfo[] = [];
let feelbackItem2: FormItemInfo[] = [];
const feedbackDialog = ref(false);
const feedbackForm = ref({})
const fldm = ref('')
const feedbackFormRef = ref<RkFormInstance>()
const bodyForm = ref({})
const bodyFormRef = ref<RkFormInstance>()


// todo 测试多线程下动态表名的问
// const props = defineProps<{ requestClassificationCode: string | string[] }>();

  const path = useRoute().path;
  reportCode.value = getRequestClassificationCode();
  let pageElements = derivedPageElements();
  columns = pageElements.columns;
  formItems = pageElements.formItems;
  feelbackItem = feedbackDerivedPageElements(getFeedbackCode(reportCode.value), null).formItems;
  feelbackItem2 = feedbackDerivedPageElements(getFeedbackCode(reportCode.value), null).formItems2;
  searchFormItems = pageElements.searchFormItems;

onMounted(() => {
  page.value = {...pagination}
  search()
})




let ids: string;
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(",");
}
const search = async () => {
  loading.value = true;
  try {
    let value = searchForm.value;
    const newObject = {...searchForm.value};
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null;
        console.log("转化了空串")
      }
    }
    if (value.createTime != undefined) {
      newObject.endTime = formatDate(new Date(value.createTime[1]));
      newObject.createTime = formatDate(new Date(value.createTime[0]));
    }
    // console.log(newObject)
    let result = await list(reportCode.value, newObject, page.value.currentPage, page.value.pageSize);
    let {current, total, records} = result.data;
    data.value = records;
    page.value.currentPage = current;
    page.value.total = total;

    if (expands.value.length != 0) {
      //如果存在展开行,清空expands.value数组,使它关闭
      expands.value.splice(0, expands.value.length);
      treeData.value = [];
    }
  } finally {
    loading.value = false;
  }
}

const imp = async (data = {}) => {
  var needBeOverridden = await checkData(reportCode.value, data);
  if (needBeOverridden.data) {
    ElMessageBox.confirm(
        '检测到上传文件的请求单标识已存在,是否覆盖?',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
    )
        .then(async () => {
          await impZip(reportCode.value, data);
          ElMessage.success("覆盖成功");
          await search();
        })
        .catch(() => {
          // ElMessage.warning("取消导入");
          return
        })
  } else {
    await impZip(reportCode.value, data);
    ElMessage.success("导入成功");
    await search();
  }
}
const exp = async () => {
  expLoading.value = true;
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    let value = searchForm.value;
    const newObject = {...searchForm.value};
    var branchCodeList = Array.from(searchForm.value.branchCodeList).join('-|-');
    await exportExcel(reportCode.value, ids,newObject,branchCodeList);
  } finally {
    expLoading.value = false;
  }
}
const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const {
  dialogData, open, close, closed, form,
  nameRef: dialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', {type: []})


// const basicForm = ref({});
// const personForm = ref({});
// const basicFormRef = ref<RkFormInstance>();
// const personFormRef = ref<RkFormInstance>();
// const collapseFormRef = ref<RkFormInstance>()
// const collapseForm = ref({})

const openDialog = async (columnData: any, type: string) => {
  const result = await listOne(reportCode.value, {'id': columnData.id, 'qqdbs': columnData.qqdbs});
  if (type == '查看') {
    open(result.data, true, '查看');
  } else {
    open(result.data, false, '编辑');
  }
}
const editUpdate = async () => {
  buttonLoading.value = true;
  try {
    expands.value.splice(0, expands.value.length);
    var rsPromise = await update(reportCode.value, toRaw(form.value));
    ElMessage.success(rsPromise.data);
    close();
  } finally {
    buttonLoading.value = false;
  }
};
const addSave = async () => {
  buttonLoading.value = true;
  try {
    const valid = await addFormRef.value?.asyncValidate();
    if (!valid) {
      return;
    }
    const data = toRaw(addForm.value);
    delete data.type;
    await save(reportCode.value, data);
    await search();
    addDialog.value = false;
    ElMessage.success("保存成功");
  } finally {
    buttonLoading.value = false;
  }
};

const genActButtons: (subRow: any, row: any) => ButtonInfo[] = (subRow: any, row: any) => {
  const buttons = [
    {
      key: 'view', label: '查看', tag: 'button', type: 'primary',
      handler: () => {
        openDialog(subRow, '查看')
      }
    },
    {
      key: 'assignment', label: '指派', tag: 'button', type: 'primary',
      handler: () => {
        if (subRow.status == "4" || subRow.status == "5") {
          ElMessage.warning("该条数据已经生成或上报报文,无法指派机构");
          return
        }
        assignmentDialog.value = true;
        assignmentForm.value = {};
        const data = toRaw(assignmentForm.value);
        data.qqdbs = subRow.qqdbs
        data.rwlsh = subRow.rwlsh
        assignmentQqdbs.value = subRow.qqdbs
        assignmentRwlsh.value = subRow.rwlsh
        assignmentSearch();
      }
    },
  ]
  if (row.importType == '3') {
    buttons.splice(1, 0, {
      key: 'edit', label: '编辑', tag: 'button', type: 'primary',
      handler: () => {
        openDialog(subRow, '编辑')
      }
    });
    buttons.splice(2, 0, {
      key: 'del', label: '删除', tag: 'button', type: 'primary',
      handler: async ()  => {
        try {
          const rsPromise = await del(reportCode.value, subRow.id);
          ElMessage.success(rsPromise.data);
        }finally {
          search();
        }
      }
    });
  }

  buttons.splice(1, 0, {
    key: 'feedback', label: '反馈', tag: 'button', type: 'primary',
    handler: async () => {
      if (subRow.status == "4" || subRow.status == "5") {
        ElMessage.warning("该条数据已经生成或上报报文,无法新增反馈");
        return
      }
      feelbackItem = feedbackDerivedPageElements(getFeedbackCode(reportCode.value), subRow.djfs).formItems;
      const result = await listOne(reportCode.value, {'id': subRow.id, 'qqdbs': subRow.qqdbs});
      let toRaw1 = toRaw(bodyForm.value);
      for (const key in result.data) {
        if (result.data.hasOwnProperty(key)) {
          toRaw1[key] = result.data[key];
        }
      }

      let data = toRaw(feedbackForm.value);
      data.qqdbs = subRow.qqdbs
      data.rwlsh = subRow.rwlsh
      fldm.value = subRow.fldm;
      data = copyProperties(data, subRow, reportCode.value);

      feedbackDialog.value = true;
    },
  });

  return buttons;
}
const genFileActButtons: (row: any) => ButtonInfo[] = (row: any) => [
  {
    key: 'viewPdf', label: '法律文书', tag: 'button', type: 'primary',
    handler: async () => {
      const result = await getPdf(reportCode.value, row);
      if (result.code == 500) {
        ElMessage.error({message:result.data, grouping: true, showClose: true, duration: 0})
        return
      }
      // let pdfWindow = window.open("", 'pdf预览');
      let pdfWindow = window.open("");
      // 将base64字符串转换为Uint8Array对象
      var pdfData = atob(result.data);
      var pdfArray = new Uint8Array(pdfData.length);
      for (var i = 0; i < pdfData.length; i++) {
        pdfArray[i] = pdfData.charCodeAt(i);
      }
      // 创建Blob对象
      var pdfBlob = new Blob([pdfArray], {type: 'application/pdf'});
      // 将Blob对象转换为URL
      var pdfUrl = URL.createObjectURL(pdfBlob);
      // 将URL作为iframe的src属性值
      pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>");
    }
  },
  {
    key: 'viewImage', label: '查询人证件', tag: 'button', type: 'primary',
    handler: async () => {
      const result = await getImage(reportCode.value, row);
      if (result.code == 500) {
        ElMessage.error({message:result.data, grouping: true, showClose: true, duration: 0})
        return
      }
      urlList.value = [];
      for (const image in result.data) {
        // 将base64字符串转换为Uint8Array对象
        var jpgData = atob(result.data[image]);
        var jpgArray = new Uint8Array(jpgData.length);
        for (var i = 0; i < jpgData.length; i++) {
          jpgArray[i] = jpgData.charCodeAt(i);
        }
        // 创建Blob对象
        var jpgBlob = new Blob([jpgArray], {type: 'image/jpeg'});
        // 将Blob对象转换为URL
        var jpgUrl = URL.createObjectURL(jpgBlob);
        // 将URL作为iframe的src属性值
        showImageViewer.value = true;
        urlList.value = [...urlList.value,jpgUrl];
      }
    }
  },
  {
    key: 'viewXml', label: 'xml文件', tag: 'button', type: 'primary',
    handler: async () => {
      const result = await getXml(reportCode.value, row);
      const keys = Object.keys(result.data);
      xmlButtonKeys.value = keys;
      xmlDataList.value = result.data;
      console.log(keys);
      dialogVisible.value = true;
    }
  }
]
const openXml = (key: any) => {
  // 将base64字符串转换为Uint8Array对象
  console.log(xmlDataList.value[key])
  var xmlData = atob(xmlDataList.value[key]);
  var xmlArray = new Uint8Array(xmlData.length);
  for (var i = 0; i < xmlData.length; i++) {
    xmlArray[i] = xmlData.charCodeAt(i);
  }
  // 创建Blob对象
  var xmlBlob = new Blob([xmlArray], {type: 'text/xml'});
  // 将Blob对象转换为URL
  var xmlUrl = URL.createObjectURL(xmlBlob);
  let xmlWindow = window.open(xmlUrl, 'xml预览')
};
const buttons: ButtonInfo[] = [
  {
    key: 'download',
    label: '下载',
    tag: 'button',
    type: 'primary',
    icon: 'icon_download',
    handler: async () => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
      }
      const result = await downloadZip(reportCode.value, ids);
      if (result.code == 500) {
        ElMessage.error({message:result.data, grouping: true, showClose: true, duration: 0})
      }
    }
  }, {
    key: 'add',
    label: '线下请求单',
    tag: 'button',
    type: 'primary',
    icon: 'icon_add',
    handler: async () => {
      addDialog.value = true;
    }
  },

]
const activeCollapse = ref([])

function formatDate(date: Date) {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  const seconds = date.getSeconds().toString().padStart(2, '0');

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * 树状表所需组件和方法
 * */
const {
  dialogData: treeDialogData, open: treeOpen, close: treeClose, closed: treeClosed, form: treeForm,
  nameRef: treeDialogFormRef
}: DialogForm<RkFormInstance, any> = useDialogForm('treeDialogFormRef', {type: []})
const treePage = ref<Pagination>(treePagination)
const treeData = ref<any []>([]);
const treeLoading = ref(false);
const qqdbs = ref("");
let expands = ref<any []>([]);
const treeSearch = async (row: any) => {
  treeLoading.value = true;
  qqdbs.value = row.qqdbs;
  try {
    var branchCodeList = Array.from(searchForm.value.branchCodeList).join('-|-');
    let result = await treeList(reportCode.value, qqdbs.value, row.fldm, [], treePage.value.currentPage, treePage.value.pageSize, branchCodeList);
    let {current, total, records} = result.data;
    treeData.value = records;
    treePage.value.currentPage = current;
    treePage.value.total = total;
  } finally {
    treeLoading.value = false;
  }
}
const treePageChange = (p: Pagination, row: any) => {
  treePage.value = p
  treeSearch(row)
}
const getRowKey = (row: any) => {
  return row.id
}
const clickRowHandle = (row: any) => {
  treePage.value = treePagination;
  if (expands.value.includes(row.id)) {
    expands.value = expands.value.filter(val => val !== row.id);
  } else {
    //判断是否已经存在展开的行
    if (expands.value.length != 0) {
      //如果存在展开行,清空expands.value数组,使它关闭
      expands.value.splice(0, expands.value.length);
      //打开点击的行
      expands.value.push(row.id);
    } else {
      //如果不存在展开行,直接push打开点击的行
      expands.value.push(row.id);
    }
  }
  console.log(expands)
  treeSearch(row)
}

const getFkItems = (fldm:string) => {
  if (fldm == 'SS05' || fldm == 'SS06'||fldm == 'SS32' || fldm == 'SS33') {
    return [
    {
      prop: 'qqdbs',
          label: '请求单标识',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
    },{
      prop: 'rwlsh',
          label: '任务流水号',
          labelWidth: 150,
          inputType: 'input',
          scopedSlot: 'systemCode',
    },...feelbackItem2[0].items]
  } else {
    return [
      {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },{
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        scopedSlot: 'systemCode',
      },...feelbackItem[0].items]
  }
}

const feedback = async () => {
  const valid = await feedbackFormRef.value?.asyncValidate();
  const bodyFormData = toRaw(bodyForm.value);
  const data = toRaw(feedbackForm.value);
  data.djfs = bodyFormData.djfs;
  const specialChecksReturn = specialChecks(data, getSubSystem(), getFeedbackCode(reportCode.value));
  if (specialChecksReturn.clear) {
    await feedbackFormRef.value?.clearValidate();
  }
  // 返回值 true是允许保存 , false是不允许保存
  if (!specialChecksReturn.result) {
    ElMessage.error({message:specialChecksReturn.msg, grouping: true, showClose: true, duration: 0});
    return;
  }
  //校验是否存在特殊字符
  if (checkSpecialCharacters(data)) {
    await feedbackFormRef.value?.asyncValidate();
    ElMessage.error({message:"存在特殊字符", grouping: true, showClose: true, duration: 0});
    return;
  }
  //校验必填项(仅当特殊校验通过时才进行)
  if (!valid && specialChecksReturn.continueToVerify) {
    await feedbackFormRef.value?.asyncValidate();
    ElMessage.error({message:"存在必填项未填", grouping: true, showClose: true, duration: 0});
    return;
  }
  data.status = '1';
  data.deleted = '0';
  console.log(data)
  await updateRequestStatus(reportCode.value,data);
  await saveData(getFeedbackCode(reportCode.value), data, fldm.value);
  await search();
  feedbackDialog.value = false;
  ElMessage.success("保存成功");
}
const uploadFile = () =>{
  var elementById = document.getElementById("uploadButton");
  elementById.click();
}
const IUploadFile = async (data = {}) => {
  if (!data.file.name.toLowerCase().endsWith(".pdf") && !data.file.name.toLowerCase().endsWith(".jpg")) {
    ElMessage.error({message:"仅可上传PDF/JPG文件", grouping: true, showClose: true, duration: 0});
    return;
  }
  const rsPromise = await upload(reportCode.value,feedbackForm.value.qqdbs,  feedbackForm.value.rwlsh, data);
  if (getSubSystem() === 'nsa') {
    feedbackForm.value.txwjm = rsPromise.data.txwjm
    feedbackForm.value.wjlj = rsPromise.data.wjlj
  } else {
    feedbackForm.value.pztxlx = rsPromise.data.pztxlx
    feedbackForm.value.pztxmc = rsPromise.data.pztxmc
    feedbackForm.value.pztxxh = parseInt(rsPromise.data.pztxxh,10)
    feedbackForm.value.wjlj = rsPromise.data.wjlj
  }
  ElMessage.success("上传成功");
}
function getFeedbackCode(reportCode: string) {
  switch (reportCode) {
    case 'account':
      return 'fkCustomer'
    case 'transaction':
      return 'fkTransaction'
    case 'accountAndTransaction':
      return 'fkAccountAndTransaction'
    case 'dynamic':
      return 'fkDynamic'
    case 'freeze':
      return 'fkFreeze'
    case 'payment':
      return 'fkPayment'
    case 'financial':
      return 'fkFinancialAccount'
    case 'certificate':
      return 'fkCertificateImage'
  }
}

function clearFeedbackForm() {
  feedbackForm.value = {};
  bodyForm.value = {};
  feedbackFormRef.value?.resetFields()
  bodyFormRef.value?.resetFields()
}
</script>
<script lang="ts">
import useDictsStore from '@/store/dictStore';
// TODO 启动时加载，不在页面里调用   子系统设置
const dictsStore = useDictsStore();
const dictData = await dictsStore.getDict;

</script>
<style scoped>

.el-table td.el-table__cell div{
  box-sizing: border-box;
  padding: 4px;
  height: auto;
  margin-left: 4px;
}

/*.parent :deep(.children) {样式内容}*/

.request-body :deep(.el-table__expanded-cell .table-header) {
  display: none;
}

.request-body :deep(.el-table__row) {
  background: gainsboro !important;
}

.request-body :deep(.el-table__expanded-cell .el-table__row) {
  background: transparent !important;
}

/*.test :deep(.el-table__cell) {*/
/*  background: gainsboro !important;*/
/*}*/

/*.test :deep(.el-table__expanded-cell .el-table__cell) {*/
/*  background: transparent !important;*/
/*}*/


</style>
