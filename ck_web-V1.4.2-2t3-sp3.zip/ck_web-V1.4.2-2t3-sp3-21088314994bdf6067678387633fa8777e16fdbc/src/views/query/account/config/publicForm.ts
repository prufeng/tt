import {FormItemInfo} from "riking-ui";
import {publicAccountColumns} from "@/views/query/account/config/publicColumns";

/**请求页面  展开表   查询人公共部分  表单项 */
export const personColumns: FormItemInfo[] = [
    {
        prop: 'qqrxm',
        label: '请求人姓名',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人姓名不可超过20'},{required: true, message: '请求人姓名不能为空'}],
    },
    {
        prop: 'qqrzjlx',
        label: '请求人证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            multiple: false,
        },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{required: true, message: '请求人证件类型不能为空'}],
    },
    {
        prop: 'qqrzjhm',
        label: '请求人证件号码',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:30,message:'请求人证件号码不可超过30'},{required: true, message: '请求人证件号码不能为空'}],
    },
    {
        prop: 'qqrdwmc',
        label: '请求人单位名称',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:100,message:'请求人单位名称不可超过100'},{required: true, message: '请求人单位名称不能为空'}],
    },
    {
        prop: 'qqrsjh',
        label: '请求人手机号',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:30,message:'请求人手机号不可超过30'},{required: true, message: '请求人手机号不能为空'}],
    },
    {
        prop: 'xcrxm',
        label: '协查人姓名',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'协查人姓名不可超过20'},{required: true, message: '协查人姓名不能为空'}],
    },
    {
        prop: 'xcrzjlx',
        label: '协查人证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            multiple: false,
        },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{required: true, message: '协查人证件类型不能为空'}],
    },
    {
        prop: 'xcrzjhm',
        label: '协查人证件号码',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'协查人证件号码不可超过20'},{required: true, message: '协查人证件号码不能为空'}],
    },
]

/**请求页面  展开表   查询人2公共部分  表单项 */
export const person2Columns: FormItemInfo[] = [
    {
        prop: 'qqrxm',
        label: '请求人姓名',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'请求人姓名不可超过20'},{required: true, message: '请求人姓名不能为空'}],
    },
    {
        prop: 'qqrdwmc',
        label: '请求人单位名称',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:100,message:'请求人单位名称不可超过100'},{required: true, message: '请求人单位名称不能为空'}],
    },
    {
        prop: 'qqrsjh',
        label: '请求人手机号',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:30,message:'请求人手机号不可超过30'},{required: true, message: '请求人手机号不能为空'}],
    },
    {
        prop: 'xcrxm',
        label: '案件承办人1姓名',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'协查人2姓名不可超过20'},{required: true, message: '协查人2姓名不能为空'}],
    },
    {
        prop: 'xcrzjlx',
        label: '案件承办人1证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            multiple: false,
        },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{required: true, message: '协查人2证件类型不能为空'}],
    },
    {
        prop: 'xcrzjhm',
        label: '案件承办人1证件号码',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'协查人2证件号码不可超过20'},{required: true, message: '协查人2证件号码不能为空'}],
    },
    {
        prop: 'xcrbxm',
        label: '案件承办人2姓名',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'协查人2姓名不可超过20'},{required: true, message: '协查人2姓名不能为空'}],
    },
    {
        prop: 'xcrbzjlx',
        label: '案件承办人2证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            multiple: false,
        },
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{required: true, message: '协查人2证件类型不能为空'}],
    },
    {
        prop: 'xcrbzjhm',
        label: '案件承办人2证件号码',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'person', title: '查询人'},
        },
        rules: [{max:20,message:'协查人2证件号码不可超过20'},{required: true, message: '协查人2证件号码不能为空'}],
    },
]

/**请求页面  展开表   基础信息公共部分  表单项 */
export const basicFormItems: FormItemInfo[] = [
    {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{max:30,message:'请求单标识长度不可超过30'},{required: true, message: '请求单标识不能为空'}],
    },
    {
        prop: 'qqcslx',
        label: '请求措施类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'qqcslx',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '请求措施类型不能为空'}],
    },
    {
        prop: 'sqjgdm',
        label: '申请机构',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'sqjgdm',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '申请机构不能为空'}],
    },
    {
        prop: 'ajlx',
        label: '案件类型',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '案件类型不能为空'}],
    },
    {
        prop: 'jjcd',
        label: '紧急程度',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'jjcd',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '紧急程度不能为空'}],
    },
    {
        prop: 'beiz',
        label: '备注',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
    },
    {
        prop: 'fssj',
        label: '发送时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '发送时间不能为空'},
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'}],
    },
]

/**请求页面  展开表   主体信息公共部分  账户信息查询  账户信息与交易明细查询 金融理财查询  表单项 */
export const publicAccountFormItems: FormItemInfo[] = [
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '任务流水号长度不可超过35'}, {required: true, message: '任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'cxzh',
        label: '查询账卡号',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'zzhm',
        label: '证照号码',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'ztmc',
        label: '主体名称',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{required: true, message: '分类代码必填'}]
    },

    {
        prop: 'mxsdlx',
        label: '明细时段类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'mxsdlx',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'mxqssj',
        label: '明细起始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'mxjzsj',
        label: '明细截至时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
]

/**请求页面  展开表   主体信息公共部分  交易明细查询  表单项 */
export const publicTransactionFormItems: FormItemInfo[] = [
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '任务流水号长度不可超过35'}, {required: true, message: '任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'cxzh',
        label: '查询账卡号',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{required: true, message: '分类代码必填'}]
        // rules: [{ required: true, message: '请选择证照类型', trigger: 'change' }],
    },
    {
        prop: 'mxsdlx',
        label: '明细时段类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'mxsdlx',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'mxqssj',
        label: '明细起始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'mxjzsj',
        label: '明细截至时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
]

/**请求页面  展开表   主体信息公共部分  动态查询  表单项 */
export const publicDynamicFormItems: FormItemInfo[] = [
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '任务流水号长度不可超过35'}, {required: true, message: '任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'yrwlsh',
        label: '原任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '原任务流水号长度不可超过35'}, {required: true, message: '原任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'zh',
        label: '账卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 50, message: '账卡号长度不可超过50'},{required: true, message: '账卡号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{required: true, message: '分类代码必填'}]
        // rules: [{ required: true, message: '请选择证照类型', trigger: 'change' }],
    },
    {
        prop: 'zxsjqj',
        label: '执行时间区间',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'zxsjqj',
            multiple: false,
        },
        rules: [{required: true, message: '执行时间区间不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'kssj',
        label: '开始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'jssj',
        label: '结束时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
]

/**请求页面  展开表   主体信息公共部分  冻结/解冻/续冻 表单项 */
export const publicFreezeFormItems: FormItemInfo[] = [
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '任务流水号长度不可超过35'}, {required: true, message: '任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'yrwlsh',
        label: '原任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '原任务流水号长度不可超过35'}, {required: true, message: '原任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'djzhhz',
        label: '冻结账户户主',
        labelWidth: 150,
        rules: [{max: 100, message: '冻结账户户主长度不可超过100'},{required: true, message: '冻结账户户主不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'zzlxdm',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            multiple: false,
        },
        rules: [{required: true, message: '证件类型不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'zzhm',
        label: '证件号码',
        labelWidth: 150,
        rules: [{max: 30, message: '证件号码长度不可超过30'},{required: true, message: '证件号码不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'zh',
        label: '冻结账卡号',
        labelWidth: 150,
        rules: [{max: 50, message: '冻结账卡号长度不可超过50'},{required: true, message: '冻结账卡号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'zhxh',
        label: '账户序号',
        labelWidth: 150,
        rules: [{max: 50, message: '账户序号长度不可超过50'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{required: true, message: '分类代码必填'}]
        // rules: [{ required: true, message: '请选择证照类型', trigger: 'change' }],
    },
    {
        prop: 'djfs',
        label: '冻结方式',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'djfs',
            multiple: false,
        },
        rules: [{required: true, message: '冻结方式不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'je',
        label: '金额',
        labelWidth: 150,
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'bz',
        label: '币种',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'currency',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'kssj',
        label: '开始时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'jssj',
        label: '结束时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'date', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [],
    },
]

/**请求页面  展开表   主体信息公共部分  紧急止付/解除止付 表单项 */
export const publicPaymentFormItems: FormItemInfo[] = [
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '任务流水号长度不可超过35'}, {required: true, message: '任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'yrwlsh',
        label: '原任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '原任务流水号长度不可超过35'}, {required: true, message: '原任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'zh',
        label: '账卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 30, message: '账卡号长度不可超过30'}, {required: true, message: '账卡号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        }
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{required: true, message: '分类代码必填'}]
        // rules: [{ required: true, message: '请选择证照类型', trigger: 'change' }],
    },
]

/**请求页面  展开表   主体信息公共部分  调阅凭证图像  表单项 */
export const publicCertificateFormItems: FormItemInfo[] = [
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{max: 35, message: '任务流水号长度不可超过35'}, {required: true, message: '任务流水号不能为空'}],
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'cxzh',
        label: '查询账卡号',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        rules: [{required: true, message: '分类代码必填'}]
        // rules: [{ required: true, message: '请选择证照类型', trigger: 'change' }],
    },
    {
        prop: 'cxzl',
        label: '查询种类',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'cxzl',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
    {
        prop: 'jylsh',
        label: '交易流水号',
        labelWidth: 150,
        inputType: 'input',
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
    },
]