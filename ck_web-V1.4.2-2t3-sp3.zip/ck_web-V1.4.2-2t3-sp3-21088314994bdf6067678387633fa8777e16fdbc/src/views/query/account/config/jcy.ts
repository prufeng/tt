/**
 * 检察院 请求页面 列字段与表单项配置
 */
import {TableColumnInfo} from "riking-ui";
import {
    publicAccountColumns, publicCertificateColumns,
    publicDynamicColumns, publicFreezeColumns, publicPaymentColumns,
    publicTransactionColumns
} from "@/views/query/account/config/publicColumns";
import {
    basicFormItems, person2Columns,
    publicAccountFormItems, publicCertificateFormItems,
    publicDynamicFormItems, publicFreezeFormItems, publicPaymentFormItems,
    publicTransactionFormItems
} from "@/views/query/account/config/publicForm";

/**
 * 检察院 请求页面 列字段
 */
export const AccountColumns: TableColumnInfo[] = [
    ...publicAccountColumns.slice(0, 3), // 插入之前的项
    {prop: 'zzlxdm', label: '证照类型', width: 150, dictFormatKey: 'license', sortable: true}, // 要插入的项
    ...publicAccountColumns.slice(3), // 插入之后的项
];

export const TransactionColumns: TableColumnInfo[] = [
    ...publicTransactionColumns
];

export const DynamicColumns: TableColumnInfo[] = [
    ...publicDynamicColumns
];

export const FreezeColumns: TableColumnInfo[] = [
    ...publicFreezeColumns
];

export const PaymentColumns: TableColumnInfo[] = [
    ...publicPaymentColumns
];

export const CertificateColumns: TableColumnInfo[] = [
    ...publicCertificateColumns
];

/**
 * 检察院 请求页面 表单项
 */
export const AccountFormItems: TableColumnInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicAccountFormItems.slice(0, 2),
    {
        prop: 'zzlxdm',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            multiple: false,
        },
        extra: {
            collapse: {name: 'body', title: '主体信息'},
        },
        // rules: [{ required: true, message: '请选择证照类型', trigger: 'change' }],
    },
    ...publicAccountFormItems.slice(2),
    ...person2Columns,
];

export const TransactionFormItems: TableColumnInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicTransactionFormItems,
    ...person2Columns,
];

export const DynamicFormItems: TableColumnInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicDynamicFormItems,
    ...person2Columns,
];

export const FreezeFormItems: TableColumnInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicFreezeFormItems,
    ...person2Columns,
];

export const PaymentFormItems: TableColumnInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicPaymentFormItems,
    ...person2Columns,
];

export const CertificateFormItems: TableColumnInfo[] = [
    ...basicFormItems.slice(0, 3),
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
            multiple: false,
        },
        extra: {
            collapse: {name: 'basic', title: '基础信息'},
        },
        rules: [{required: true, message: '查控主体类别不能为空'}],
    },
    ...basicFormItems.slice(3),
    ...publicCertificateFormItems,
    ...person2Columns,
];