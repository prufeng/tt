

const reportCodeMap = new Map()
reportCodeMap.set('fkCustomer', 'account')
reportCodeMap.set('fkAccountAndTransaction', 'accountAndTransaction')
reportCodeMap.set('fkDynamicReceipt', 'dynamic')
reportCodeMap.set('fkDynamic', 'dynamic')
reportCodeMap.set('fkFreeze', 'freeze')
reportCodeMap.set('fkPayment', 'payment')
reportCodeMap.set('fkTransaction', 'transaction')
reportCodeMap.set('fkCertificateImage', 'certificate')
reportCodeMap.set('fkFinancialAccount', 'financial')

export default {
    reportCodeMap
}

