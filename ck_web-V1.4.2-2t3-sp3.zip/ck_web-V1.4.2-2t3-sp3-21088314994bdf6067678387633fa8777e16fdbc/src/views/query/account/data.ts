import {ButtonInfo, FormItemInfo, Pagination, TableColumnInfo} from "riking-ui";
import {ElMessage} from "element-plus";

export const buttons: ButtonInfo[] = [
    {
        key: 'import',
        label: '导入',
        tag: 'button',
        type: 'primary',
        icon: 'icon_add',
        handler: () => ElMessage.warning('导入'),
    },
    {
      key: 'export',
      label: '导出',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: () => ElMessage.warning('导出'),
    },
    // {
    //     key: 'BATCH_DELETE',
    //     label: '批量删除',
    //     tag: 'button',
    //     type: 'danger',
    //     icon: 'icon_delete',
    //     handler: () => ElMessage.warning('批量删除'),
    // },
]

export const pagination: Pagination = {
    currentPage: 1,
    pageSize: 50,
    pageSizes: [10, 30, 50, 100],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}
export const treePagination: Pagination = {
    currentPage: 1,
    pageSize: 8,
    pageSizes: [8, 16, 24, 32],
    total: 0,
    layout: 'total, sizes, prev, pager, next, jumper',
    pagerCount: 5,
}
// export const genActButtons: (row: any) => ButtonInfo[] = (row: any) => [
//     {key: 'VIEW', label: '查看', tag: 'button', type: 'primary', handler: () => ElMessage.warning(row.id)},
//     // {key: 'EDIT', label: '编辑', tag: 'button', type: 'primary', handler: () => ElMessage.warning(row.id)},
//     // {key: 'DELETE', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗', handler: () => ElMessage.warning(row.id),},
// ]

// 字典
// export const dictData =  {
//   "status": [
//     {
//       "label": "未完成",
//       "value": "0",
//       "type": "status"
//     },
//     {
//       "label": "已完成",
//       "value": "1",
//       "type": "status"
//     },
//   ],
// }