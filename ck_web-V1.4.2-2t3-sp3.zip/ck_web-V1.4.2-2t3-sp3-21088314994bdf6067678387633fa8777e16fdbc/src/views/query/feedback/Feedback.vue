<template>
  <rk-index-layout>
    <!--    <rk-search-form ref="searchFormRef" v-model="searchForm" :loading="loading" @keyup.enter="search"
                        :form-items="searchItem" @search="search" :label-width="50">
          <el-input/>
        </rk-search-form>-->
    <rk-dynamic-search-form
      v-if="delaySearchFormRender"
      v-model="searchForm"
      :form-items="recordSearchFormItems"
      :fields="advancedQueryItems"
      @search="search"
      :advanced="advanced"
    >
      <template #onlyQuerySucceeded>
        <el-checkbox :checked="dictData.matching != undefined ? true : false" />
      </template>
    </rk-dynamic-search-form>

    <rk-page-table
      :loading="loading"
      :columns="columns"
      :data="data"
      :pagination="page"
      @refresh="search"
      @page-change="pageChange"
      @selection-change="handleSelectionChange"
    >
      <template #operations>
        <div style="display: flex; flex-direction: row">
          <rk-button-group :buttons="Buttons" :route-meta="$route.meta" :max="9" />
          <div style="margin: 0 4px"></div>
          <UpAndDown :imp="imp" :exp="exp" />
        </div>
      </template>
      <template #status="{ row }">
        <el-popover v-if="row.status === '6'" placement="bottom" title="审核不通过原因" :width="250" trigger="hover">
          <p class="tipck">操作: 审核不通过</p>
          <p class="tipck">操作人: {{ row.approveBy }}</p>
          <p class="tipck">操作时间: {{ row.approveTime }}</p>
          <p class="tipck">备注: {{ row.approveDesc }}</p>
          <template #reference>
            <el-button link :type="getTagColor(row.status)">
              {{ dictFormatter(row.status, dictData.dataStatus) }}
            </el-button>
          </template>
        </el-popover>
        <el-popover
          v-else-if="row.status === '0' && row.resetBy !== null && row.resetBy !== ''"
          placement="bottom"
          title="重置原因"
          :width="250"
          trigger="hover"
        >
          <p class="tipck">操作: 重置</p>
          <p class="tipck">操作人: {{ row.resetBy }}</p>
          <p class="tipck">操作时间: {{ row.resetTime }}</p>
          <p class="tipck">备注: {{ row.resetDesc }}</p>
          <template #reference>
            <el-button link :type="getTagColor(row.status)">
              {{ dictFormatter(row.status, dictData.dataStatus) }}
            </el-button>
          </template>
        </el-popover>
        <el-button v-else link :type="getTagColor(row.status)">
          {{ dictFormatter(row.status, dictData.dataStatus) }}
        </el-button>
      </template>

      <template #deleteState="{ row }">
        <el-popover
          v-if="row.deleteState === '4'"
          placement="bottom"
          title="删除审核不通过原因"
          :width="250"
          trigger="hover"
        >
          <p class="tipck">操作: 删除审核不通过</p>
          <p class="tipck">操作人: {{ row.approveBy }}</p>
          <p class="tipck">操作时间: {{ row.approveTime }}</p>
          <p class="tipck">备注: {{ row.deleteComments }}</p>
          <template #reference>
            <el-button link :type="getDelTagColor(row.deleteState)">{{
              dictFormatter(row.deleteState, dictData.deleteStatusList)
            }}</el-button>
          </template>
        </el-popover>
        <el-button v-else link :type="getDelTagColor(row.deleteState)">{{
          dictFormatter(row.deleteState, dictData.deleteStatusList)
        }}</el-button>
      </template>

      <template #actions="{ row }">
        <rk-button-group :buttons="genActButtons(row)" :route-meta="[]" :max="2" link />
      </template>
    </rk-page-table>
  </rk-index-layout>
  <!-- 弹出层 -->
  <el-dialog
    v-model="dialogData.visible"
    :title="dialogData.title"
    class="rk-dialog-default"
    @closed="
      () => {
        clearForm()
      }
    "
    :close-on-click-modal="false"
  >
    <!-- 引用请求页面数据项 -->
    <ShowCx :fkReportCode="reportCode" :visible="dialogData.visible" :qqdbs="qqdbs" :rwlsh="rwlsh"></ShowCx>
    <!-- 弹出层头信息 -->
    <!--    <rk-detail-form ref="dialogHeadFormRef" v-model="form" :form-items="parentsFormItems" disabled="true">-->

    <!--    </rk-detail-form>-->
    <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
      <!-- 标签页-主信息 -->
      <el-tab-pane key="1" :label="formItems[0].name" name="1">
        <div style="display: flex; flex-direction: row">
          <el-space wrap :size="10">
            <rk-button-group
              :buttons="
                dialogData.title === getTitleName() + '编辑' || dialogData.title === getTitleName() + '新增'
                  ? parentsButtons()
                  : []
              "
              :route-meta="$route.meta"
              :max="9"
            ></rk-button-group>
            <el-text class="mx-1" size="small">状态 :</el-text>
            <el-tag size="large">{{ status }}</el-tag>
          </el-space>
        </div>
        <br />
        <rk-detail-form
          ref="dialogFormRef"
          v-model="form"
          :form-items="formItems[0].items"
          :disabled="dialogData.formDisabled"
        >
        </rk-detail-form>
      </el-tab-pane>
      <!-- 标签页-从表信息 -->
      <el-tab-pane
        v-for="(subTable, index) in subTables"
        :key="'sub' + index"
        :label="subTable.name"
        :name="'sub' + index"
      >
        <rk-page-table
          :loading="subLoading"
          :columns="subTable.columns"
          :data="subData"
          :pagination="subPage"
          @page-change="subPageChange"
          @selection-change="subHandleSelectionChange"
          @refresh="handleClick(undefined)"
        >
          <template #operations>
            <div style="display: flex; flex-direction: row">
              <rk-button-group
                v-if="dialogData.title === getTitleName() + '编辑'"
                :buttons="subButtons(subTable.listName, subTable.items)"
                :route-meta="$route.meta"
                :max="9"
              ></rk-button-group>
              <!-- 417report入口-->
              <el-upload ref="upload417ReportRef" :show-file-list="false" :http-request="IUpload417ReportFile">
                <el-button ref="upload417ReportButton" id="upload417ReportButton" type="primary" style="display: none">
                  导入417report
                </el-button>
              </el-upload>
            </div>
          </template>
          <template #status="{ row }">
            <el-popover
              v-if="row.status === '6'"
              placement="bottom"
              title="审核不通过原因"
              :width="250"
              trigger="hover"
            >
              <p class="tipck">操作: 审核不通过</p>
              <p class="tipck">操作人: {{ row.approveBy }}</p>
              <p class="tipck">操作时间: {{ row.approveTime }}</p>
              <p class="tipck">备注: {{ row.approveDesc }}</p>
              <template #reference>
                <el-button link :type="getTagColor(row.status)">
                  {{ dictFormatter(row.status, dictData.dataStatus) }}
                </el-button>
              </template>
            </el-popover>
            <el-popover
              v-else-if="row.status === '0' && row.resetBy !== null && row.resetBy !== ''"
              placement="bottom"
              title="重置原因"
              :width="250"
              trigger="hover"
            >
              <p class="tipck">操作: 重置</p>
              <p class="tipck">操作人: {{ row.resetBy }}</p>
              <p class="tipck">操作时间: {{ row.resetTime }}</p>
              <p class="tipck">备注: {{ row.resetDesc }}</p>
              <template #reference>
                <el-button link :type="getTagColor(row.status)">
                  {{ dictFormatter(row.status, dictData.dataStatus) }}
                </el-button>
              </template>
            </el-popover>
            <el-button v-else link :type="getTagColor(row.status)">
              {{ dictFormatter(row.status, dictData.dataStatus) }}
            </el-button>
          </template>

          <template #deleteState="{ row }">
            <el-popover
              v-if="row.deleteState === '4'"
              placement="bottom"
              title="删除审核不通过原因"
              :width="250"
              trigger="hover"
            >
              <p class="tipck">操作: 删除审核不通过</p>
              <p class="tipck">操作人: {{ row.approveBy }}</p>
              <p class="tipck">操作时间: {{ row.approveTime }}</p>
              <p class="tipck">备注: {{ row.deleteComments }}</p>
              <template #reference>
                <el-button link :type="getDelTagColor(row.deleteState)">{{
                  dictFormatter(row.deleteState, dictData.deleteStatusList)
                }}</el-button>
              </template>
            </el-popover>
            <el-button v-else link :type="getDelTagColor(row.deleteState)">{{
              dictFormatter(row.deleteState, dictData.deleteStatusList)
            }}</el-button>
          </template>

          <template #actions="{ row }">
            <rk-button-group
              :buttons="
                dialogData.title === getTitleName() + '编辑'
                  ? subGenActButtons(row, subTable.listName, subTable.items)
                  : subGenActButtons2(row, subTable.listName, subTable.items)
              "
              :route-meta="$route.meta"
              :max="2"
              link
            />
          </template>
        </rk-page-table>
      </el-tab-pane>
    </el-tabs>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="close"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <el-dialog
    v-model="subDialogData.visible"
    :title="subDialogData.title"
    class="rk-dialog-default"
    @closed="subClosed"
    :close-on-click-modal="false"
  >
    <rk-detail-form
      ref="subDialogFormRef"
      v-model="subForm"
      :form-items="subFormItems"
      :disabled="subDialogData.formDisabled"
    >
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button
          type="primary"
          v-if="subDialogData.title.includes('编辑') || subDialogData.title.includes('新增')"
          @click="save1(null, subReportCode)"
          >保存</el-button
        >
        <el-button @click="subClose"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 主表审核弹窗 -->
  <el-dialog v-model="auditDialog" title="审核" width="30%" draggable :append-to-body="true">
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="audit(ids)">审核通过</el-button>
        <el-button
          type="danger"
          @click="
            () => {
              msgDialog = true
              msg = ''
            }
          "
        >
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 子表审核弹窗 -->
  <el-dialog v-model="subAuditDialog" title="审核" width="30%" draggable :append-to-body="true">
    <span>是否审核通过?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="subAudit(subIds, listName)">审核通过</el-button>
        <el-button
          type="danger"
          @click="
            () => {
              subMsgDialog = true
              msg = ''
            }
          "
        >
          审核不通过
        </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 审核不通过原因输入弹窗 -->
  <el-dialog v-model="msgDialog" title="不通过原因" width="30%" draggable :append-to-body="true">
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="auditNotPass(ids)">提交</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 选择凭证图像类型弹窗 -->
  <el-dialog
    v-model="selectDialogData.visible"
    :title="selectDialogData.title"
    class="rk-dialog-default"
    @closed="selectClosed"
    :close-on-click-modal="false"
  >
    <rk-detail-form
      ref="selectDialogFormRef"
      v-model="selectForm"
      :form-items="certificateImageSelectItems"
      :disabled="selectDialogData.formDisabled"
    >
    </rk-detail-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="imageTypeSave">确定</el-button>
        <el-button @click="selectClose"> 取消 </el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 子表审核不通过原因输入弹窗 -->
  <el-dialog v-model="subMsgDialog" title="不通过原因" width="30%" draggable :append-to-body="true">
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="subAuditNotPass(subIds, listName)">提交</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 主表删除审核弹窗 -->
  <el-dialog v-model="auditDelDialog" title="删除审核" width="30%" draggable :append-to-body="true">
    <!-- <span>是否删除审核通过,审核不通过请输入原因?</span>-->
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入删除审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="delAudit(ids, '1')">审核通过</el-button>
        <el-button type="danger" @click="delAudit(ids, '2')">审核不通过</el-button>
        <el-button
          type="default"
          @click="
            () => {
              auditDelDialog = false
            }
          "
          >取消</el-button
        >
      </span>
    </template>
  </el-dialog>
  <!-- 子表删除审核弹窗 -->
  <el-dialog v-model="auditDelDialogSub" title="删除审核" width="30%" draggable :append-to-body="true">
    <!-- <span>是否删除审核通过,审核不通过请输入原因?</span>-->
    <el-form>
      <el-form-item>
        <el-input v-model="msg" type="textarea" placeholder="请输入删除审核不通过原因" clearable></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="delAuditSub(subIds, '1', listName)">审核通过</el-button>
        <el-button type="danger" @click="delAuditSub(subIds, '2', listName)">审核不通过</el-button>
        <el-button
          type="default"
          @click="
            () => {
              auditDelDialogSub = false
            }
          "
          >取消</el-button
        >
      </span>
    </template>
  </el-dialog>

  <template>
    <div>
      <el-upload
        ref="uploadRef"
        :on-error="
          () => {
            ElMessage.error('上传失败')
          }
        "
        :show-file-list="false"
        :http-request="IUploadFile"
      >
        >
        <el-button ref="uploadButton" id="uploadButton" type="primary">上传文件</el-button>
      </el-upload>
    </div>
  </template>
  <!-- 批量提交/审核结果弹窗 -->
  <el-dialog
    v-model="submitAllVisible"
    title="提示"
    :close-on-click-modal="false"
    :destroy-on-close="true"
    :append-to-body="true"
  >
    <el-collapse v-model="activeNames">
      <el-collapse-item name="1">
        <template #title>
          <div class="message-text">
            {{ submitOrAudit }} 成功 <span style="margin: 0 5px; color: #67c23a">{{ successNum }}</span> 条数据, 失败
            <span style="margin: 0 5px; color: #f56c6c">{{ failNum }}</span> 条数据
          </div>
        </template>
        <div style="box-sizing: border-box" v-html="returnMassage"></div>
      </el-collapse-item>
    </el-collapse>
  </el-dialog>
  <div class="img-viewer-box">
    <el-image-viewer
      v-if="showImageViewer"
      :url-list="urlList"
      @close="
        () => {
          showImageViewer = false
        }
      "
    />
  </div>
</template>

<script setup lang="ts">
//主表所需代码
import { onMounted, ref, watch } from 'vue'
import { ElDialog, ElButton, ElMessage, Action } from 'element-plus'
import {
  RkPageTable,
  RkButtonGroup,
  RkSearchForm,
  RkDetailForm,
  Pagination,
  ButtonInfo,
  RkFormInstance,
  useDialogForm,
  dictFormatter,
  RkDynamicSearchForm,
} from 'riking-ui'
import DialogForm from 'riking-ui/dist/hooks/useDialogForm'
import { useDict } from 'riking-layout'
import { pagination, subPagination } from '@/views/query/feedback/data'
import { certificateImageSelectItems } from '@/views/query/feedback/config/nsa'
import {
  derivedPageElements,
  derivedPageParentsElements,
  isExpPathArray,
  isExpSubSystemArray,
  recordSearchFormItems,
} from '@/views/query/feedback/page'
import {
  list,
  exportExcel,
  saveData,
  submitBatch,
  auditBatch,
  delBatch,
  resetBatch,
  listSub,
  subSaveData,
  subSubmitBatch,
  subResetBatch,
  subAuditBatch,
  subDelBatch,
  auditNotPassBatch,
  subAuditNotPassBatch,
  subUpdateData,
  updateData,
  listBusinessLine,
  checkFileExist,
  previewUploadFile,
  upload,
  importExcel,
  recallBatch,
  subRecallBatch,
  auditAllBatch,
  submitAllBatch,
  auditNotPassAllBatch,
  checkExcelData,
  delAuditNotPass,
  delBatchAudit,
  subDelBatchAudit,
  subDelBatchAuditNotPass,
  delAllBatch,
  auditDelAllBatch,
  auditDelNotPassAllBatch,
} from '@/views/query/feedback/api'
import UpAndDown, { expLoading, impLoading } from '@/components/UpAndDown.vue'
import { getRequestClassificationCode, getSubSystem } from '@/utils/subSystem'
import { checkSpecialCharacters, specialChecks } from '@/utils/utils'
import { listFldm, listOne } from '@/views/query/account/api'
import useRouteParamsStore from '@/store/routeParamsStore'
import ShowCx from '@/views/query/feedback/ShowCx.vue'
import { setRequiredRule } from '@/views/system/sum'

useDict([], [], {
  ...dictData,
  branchCode: async () => {
    const res = await dictsStore.loadDict()
    return res.data.branchCode
  },
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data
  },
  fldm: async () => {
    const res = await listFldm(null)
    return res.data
  },
  sqjgdm: async () => {
    return dictData['sqjgdm' + '.' + getSubSystem()]
  },
})
const activeNames = ref(['1'])
const reportCode = ref('') // 报文编号
const activeName = ref('1')
const loading = ref(false)
const subLoading = ref(false)
const data = ref<any[]>([])
const subData = ref<any[]>([])
const page = ref<Pagination>(pagination)
const subPage = ref<Pagination>(subPagination)
const searchFormRef = ref<RkFormInstance>()
const showImageViewer = ref(false) //组件是否显示
const isSubImpLoading = ref(false)
const urlList = ref([]) //图片List
const businessLineUser = ref()
const searchForm = ref({ businessLine: '' })

async function getBusinessLine() {
  try {
    const res = await listBusinessLine()
    const data1 = res.data
    businessLineUser.value = res.data

    if (data1.length === 0) {
      ElMessage.error({ message: '用户未配置业务线,无法查询数据', grouping: true, showClose: true, duration: 0 })
      searchForm.value.businessLine = ''
    } else {
      searchForm.value.businessLine = data1[0].value
    }
  } catch (error) {
    console.error('Error fetching business line:', error)
  } finally {
    setRouteParams()
    await search()
  }
}

const visible = ref(false)
const rwlsh = ref('')
const id = ref('')
const khbh = ref('')
const cxnr = ref('')
const branchCode = ref('')
const qqdbs = ref('')
let listName = ''
const {
  dialogData,
  open,
  close,
  closed,
  form,
  nameRef: dialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('dialogFormRef', { type: [] })

const {
  dialogData: subDialogData,
  open: subOpen,
  close: subClose,
  closed: subClosed,
  form: subForm,
  nameRef: subDialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('subDialogFormRef', { type: [] })

const {
  dialogData: selectDialogData,
  open: selectOpen,
  close: selectClose,
  closed: selectClosed,
  form: selectForm,
  nameRef: selectDialogFormRef,
}: DialogForm<RkFormInstance, any> = useDialogForm('selectDialogFormRef', { type: [] })

let status = ref('')
let columns: any[] = [],
  subTables: any[] = [],
  advancedQueryItems: any[] = [],
  parentsFormItems: any[] = []
let requestClassificationCode = ref()

const addForm = ref({ type: [] })
const formItems = ref([])
const subFormItems = ref([])

const path = useRoute().path
reportCode.value = getRequestClassificationCode()
requestClassificationCode.value = getRequestClassificationCode()
let pageElements = derivedPageElements(requestClassificationCode.value, null)
let parentsElements = derivedPageParentsElements(requestClassificationCode.value)
parentsFormItems =
  parentsElements?.cxParentsFormItems.length == 0
    ? parentsElements?.kzParentsFormItems
    : parentsElements?.cxParentsFormItems
columns = pageElements.columns
formItems.value = pageElements.formItems
subTables = pageElements.subTables
advancedQueryItems = pageElements.searchItems

// 渲染后更新新advance为true, 高级查询不会展开，可能是封装的组件没监听，做法是延迟高级查询表单的渲染，在确定advance值后再渲染
const delaySearchFormRender = ref(true)
const advanced = ref(false)
const store = useRouteParamsStore()

/**
 * 代办汇总跳转到反馈页面
 */
const setRouteParams = () => {
  const routeParams = store.getParams()

  if (routeParams != undefined && Object.keys(routeParams).length > 0) {
    const filters = [
      { key: 1, field: 'create_time', operator: 'ge', value: routeParams['searchTime'][0] },
      { key: 2, field: 'create_time', operator: 'le', value: routeParams['searchTime'][1] },
    ]

    if (routeParams['status'] == undefined) {
      filters.shift()
    }

    const params = {
      filters,
      businessLine: routeParams['businessLine'],
      branchCodeList: routeParams['branchCode'],
      status: routeParams['status'],
    }
    searchForm.value = params
  }
  // store.setParams({});
}

onMounted(() => {
  page.value = {...pagination}
  delaySearchFormRender.value = false
  const params = store.getParams()
  if (Object.keys(params).length) {
    if (params.status != undefined) {
      searchForm.value = {
        businessLine: '',
        filters: [
          { key: 1, field: '', operator: '', value: '' },
          { key: 2, field: '', operator: '', value: '' },
        ],
      }
    } else {
      searchForm.value = {
        businessLine: '',
        filters: [
          { key: 1, field: '', operator: '', value: '' },
          { key: 2, field: '', operator: '', value: '' },
        ],
      }
    }
  }

  nextTick(() => {
    refresh()
    nextTick(() => {
      setRouteParams()
      store.setParams({})
      getBusinessLine()
    })
  })

  if (dictData.matching != undefined) {
    // @ts-ignore
    searchForm.value.onlyQuerySucceeded = true
  }
})

watch(
  () => store.params,
  (newVal) => {
    if (Object.keys(newVal).length) {
      advanced.value = false
      delaySearchFormRender.value = false

      if (newVal.status != undefined) {
        searchForm.value = {
          businessLine: '',
          filters: [
            { key: 1, field: '', operator: '', value: '' },
            { key: 2, field: '', operator: '', value: '' },
          ],
        }
      } else {
        searchForm.value = {
          businessLine: '',
          filters: [
            { key: 1, field: '', operator: '', value: '' },
            { key: 2, field: '', operator: '', value: '' },
          ],
        }
      }

      nextTick(() => {
        refresh()
        nextTick(() => {
          setRouteParams()
          search()
        })
      })
    }
  },
)

const refresh = () => {
  const routeParams = store.getParams()
  if (routeParams != undefined && Object.keys(routeParams).length > 0) {
    advanced.value = true
    delaySearchFormRender.value = true
  } else {
    delaySearchFormRender.value = true
  }
}

const getTagColor = (status: string) => {
  if (status == '6') {
    return 'danger'
  } else {
    return 'primary'
  }
}

const getDelTagColor = (status: string) => {
  if (status == '4') {
    return 'danger'
  } else {
    return 'primary'
  }
}

const search = async () => {
  loading.value = true
  try {
    let value = searchForm.value
    const newObject = { ...searchForm.value }
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null
        console.log('转化了空串')
      }
    }
    if (value.createTime != undefined) {
      newObject.endTime = formatDate(new Date(value.createTime[1]))
      newObject.createTime = formatDate(new Date(value.createTime[0]))
    }

    let result = await list(reportCode.value, newObject, page.value.currentPage, page.value.pageSize)
    let { current, total, records } = result.data
    data.value = records
    page.value.currentPage = current
    page.value.total = total
  } finally {
    loading.value = false
  }
}

function formatDate(date: Date) {
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  const seconds = date.getSeconds().toString().padStart(2, '0')

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
}

const pageChange = (p: Pagination) => {
  page.value = p
  search()
}

const subPageChange = (p: Pagination) => {
  subPage.value = p
  handleClick(undefined)
}

let ids: string
const handleSelectionChange = async (val: any) => {
  ids = val.map((item: any) => item.id).join(',')
}
let subIds: string
const subHandleSelectionChange = async (val: any) => {
  subIds = val.map((item: any) => item.id).join(',')
}

const save = async () => {
  const valid = await dialogFormRef.value?.asyncValidate()
  const data = toRaw(form.value)
  const specialChecksReturn = specialChecks(data, getSubSystem(), reportCode.value)
  if (specialChecksReturn.clear) {
    await dialogFormRef.value?.clearValidate()
  }
  // 返回值 true是允许保存 , false是不允许保存
  if (!specialChecksReturn.result) {
    ElMessage.error({ message: specialChecksReturn.msg, grouping: true, showClose: true, duration: 0 })
    return
  }
  //校验是否存在特殊字符
  if (checkSpecialCharacters(data)) {
    await dialogFormRef.value?.asyncValidate()
    ElMessage.error({ message: '存在特殊字符', grouping: true, showClose: true, duration: 0 })
    return
  }
  //校验必填项(仅当特殊校验通过时才进行)
  if (!valid && specialChecksReturn.continueToVerify) {
    await dialogFormRef.value?.asyncValidate()
    ElMessage.error({ message: '存在必填项未填', grouping: true, showClose: true, duration: 0 })
    return
  }
  // TOTD SPF-ADD-20240517 公安更新-添加 start
  let result = true,
    msg = '',
    msgArr = [],
    errorMsg = ''
  // 动态查询反馈
  // if (getSubSystem() == 'ga' && reportCode.value == 'fkDynamic') {
  //   let jycz = data.jycz; // 交易操作类型
  //   errorMsg = '若交易操作类型为反馈转账/汇款/ATM等网银转账业务时，name不能为空！';
  //   // 动态查询反馈表t_ga_fk_dynamic：（若交易类型反馈转账/汇款/ATM等网银转账业务时，此数据项不能为空。）
  //   if (jycz.includes('转账') || jycz.includes('汇款') || jycz.includes('ATM') || jycz.includes('网银转账')) {
  //     if (data.jydfzkh == null || data.jydfzkh == '') { // 交易对方账卡号
  //       result = false;
  //       msg = errorMsg.replace('name', '交易对方账卡号');
  //       msgArr.push(msg);
  //     }
  //     // 交易对手是否为本行账户暂无法判断
  //     // 若交易操作类型反馈转账/汇款/ATM等网银转账业务，对手信息为本行账户时，此数据项不能为空。
  //     if (data.jydfzkhlx == null || data.jydfzkhlx == '') { // 交易对方账卡号类型
  //       result = false;
  //       msg = errorMsg.replace('name', '交易对方账卡号类型');
  //       msgArr.push(msg);
  //     }
  //     if (data.dfzhmc == null || data.dfzhmc == '') { // 对方账户名称
  //       result = false;
  //       msg = errorMsg.replace('name', '对方账户名称');
  //       msgArr.push(msg);
  //     }
  //     // 交易对手是否为本行账户暂无法判断
  //     // 若交易操作类型反馈转账/汇款/ATM等网银转账业务，对手信息为本行账户时，此数据项不能为空。
  //     if (data.dfzhbz == null || data.dfzhbz == '') { // 对方账户币种
  //       result = false;
  //       msg = errorMsg.replace('name', '对方账户币种');
  //       msgArr.push(msg);
  //     }
  //   }
  //   if (!result) {
  //     // ElMessage.warning(msgArr.join('\n'));
  //     ElMessageBox.alert(
  //         `<div style="max-height: 500px; overflow-y: auto;">${msgArr.join('<br/>')}</div>`,
  //         '校验结果',
  //         {
  //           customClass: 'customMessageBox',
  //           dangerouslyUseHTMLString: true,
  //         }
  //     );
  //     return;
  //   }
  // }
  // 冻结/续冻/解冻反馈
  // if (getSubSystem() == 'ga' && reportCode.value == 'fkFreeze') {
  //   let zxjg = data.zxjg; // 执行结果
  //   if (zxjg != null && zxjg == '1') {
  //     if (data.wndjyy == null || data.wndjyy == '') { // 未能冻结原因
  //       result = false;
  //       msg = '执行结果为1-执行失败时，未能冻结原因不能为空！';
  //       msgArr.push(msg);
  //     }
  //   }
  //   // 目前无法确定数据是否为在线冻结
  //   // 有在线冻结情况时，此数据项不能为空。
  //   errorMsg = '有在线冻结情况时，name不能为空！';
  //   let zxdj = null;
  //   if (zxdj != null && zxdj != '') {
  //     if (data.djjg == null || data.djjg == '') { // 冻结机关名称
  //       result = false;
  //       msg = errorMsg.replace('name', '冻结机关');
  //       msgArr.push(msg);
  //     }
  //     if ((data.djje == null || data.djje == '') && data.djje != 0) { // 在先冻结金额
  //       result = false;
  //       msg = errorMsg.replace('name', '在先冻结金额');
  //       msgArr.push(msg);
  //     }
  //     if (data.djjzrq == null || data.djjzrq == '') { // 在先冻结到期日
  //       result = false;
  //       msg = errorMsg.replace('name', '在先冻结到期日');
  //       msgArr.push(msg);
  //     }
  //   }
  //
  //   if (!result) {
  //     // ElMessage.warning(msgArr.join('\n'));
  //     ElMessageBox.alert(
  //         `<div style="max-height: 500px; overflow-y: auto;">${msgArr.join('<br/>')}</div>`,
  //         '校验结果',
  //         {
  //           customClass: 'customMessageBox',
  //           dangerouslyUseHTMLString: true,
  //         }
  //     );
  //     return;
  //   }
  // }
  // // 紧急止付\解除止付
  // if (getSubSystem() == 'ga' && reportCode.value == 'fkPayment') {
  //   let zxjg = data.zxjg; // 执行结果
  //   if (zxjg != null && zxjg == '1') {
  //     if (data.sbyy == null || data.sbyy == '') { // 失败原因
  //       ElMessage.warning('执行结果为1-执行失败时，失败原因不能为空！');
  //       return;
  //     }
  //   }
  //   if (zxjg != null && zxjg == '0') {
  //     if (data.zxqssj == null || data.zxqssj == '') { // 执行起始时间
  //       ElMessage.warning('执行结果为0-执行成功时，执行起始时间不能为空！');
  //       return;
  //     }
  //   }
  // }
  // TOTD SPF-ADD-20240517 公安更新-添加 end
  data.status = '1'
  delete data.type
  await updateData(reportCode.value, data)
  await search()
  ElMessage.success('保存成功')
  status.value = status.value = dictFormatter('1', dictData.dataStatus)
  if (dialogData.title === getTitleName() + '新增') {
    close()
  }
}

watch(form.value, (newValue, oldValue) => {
  if (newValue) {
    // form.value.wdjje = form.value.sqdjxe - form.value.sdje;
    // if (form.value.zxjg == '1') { // 执行失败
    //   form.value.sdje = 0; // 执行冻结金额 设置为0
    // }
    if (getSubSystem() == 'jcy' && reportCode.value == 'fkFreeze') {
      setRequiredRule(['sdje', 'wdjje'], newValue.djfs == '02', formItems.value[0].items)
      if (newValue.djfs == '01') {
        // 冻结方式为限额内冻结  wdjje计算
        form.value.wdjje = form.value.sqdjxe - form.value.sdje
      } else if (newValue.djfs == '02') {
        // 只收不付
        form.value.wdjje = 0
      }
    }

    // dialogFormRef.value?.refresh();
    // form.value.refresh();
    // dialogFormRef.value.refresh();
  }
})

/**
 *   这里监听主表单 控制反馈主表单条件非空 调整传参
 */
watch(
  () => form.value,
  (newForm, oldForm) => {
    // 未启用部门编码，编辑页面隐藏
    if (dictData.departmentCodeRequired == undefined) {
      formItems.value[0].items = formItems.value[0].items.filter((item) => 'departmentCode' != item.prop)
    }

    formItems.value = [...formItems.value]
  },
  { deep: true },
)

/**
 *   这里监听子表单 控制反馈子表单条件非空
 */
watch(
  () => subForm.value,
  (newForm, oldForm) => {
    // 未启用部门编码，编辑页面隐藏
    if (dictData.departmentCodeRequired == undefined) {
      subFormItems.value = subFormItems.value.filter((item) => 'departmentCode' != item.prop)
    }

    subFormItems.value = [...subFormItems.value]
  },
  { deep: true },
)

const submit = async (ids: string) => {
  try {
    await submitBatch({}, reportCode.value, ids)
    status.value = status.value = dictFormatter('2', dictData.dataStatus)
    console.log('待审核')
    ElMessage.success('提交成功')
    close()
  } finally {
    await search()
  }
}

const submitAndSave = async (data: any, ids: string) => {
  try {
    const valid = await dialogFormRef.value?.asyncValidate()
    const data = toRaw(form.value)
    const specialChecksReturn = specialChecks(data, getSubSystem(), reportCode.value)
    if (specialChecksReturn.clear) {
      await dialogFormRef.value?.clearValidate()
    }
    // 返回值 true是允许保存 , false是不允许保存
    if (!specialChecksReturn.result) {
      ElMessage.error({ message: specialChecksReturn.msg, grouping: true, showClose: true, duration: 0 })
      return
    }
    //校验是否存在特殊字符
    if (checkSpecialCharacters(data)) {
      await dialogFormRef.value?.asyncValidate()
      ElMessage.error({ message: '存在特殊字符', grouping: true, showClose: true, duration: 0 })
      return
    }
    //校验必填项(仅当特殊校验通过时才进行)
    if (!valid && specialChecksReturn.continueToVerify) {
      await dialogFormRef.value?.asyncValidate()
      ElMessage.error({ message: '存在必填项未填', grouping: true, showClose: true, duration: 0 })
      return
    }
    await submitBatch(data, reportCode.value, ids)
    status.value = status.value = dictFormatter('2', dictData.dataStatus)
    console.log('待审核')
    ElMessage.success('提交成功')
    close()
  } finally {
    await search()
  }
}

const auditDialog = ref(false)
const audit = async (ids: any) => {
  try {
    await auditBatch(reportCode.value, ids)
    status.value = status.value = dictFormatter('3', dictData.dataStatus)
    ElMessage.success('审核成功')
    close()
  } finally {
    auditDialog.value = false
    await search()
  }
}
const auditNotPass = async (ids: any) => {
  try {
    await auditNotPassBatch(reportCode.value, ids, msg.value)
    status.value = status.value = dictFormatter('6', dictData.dataStatus)
    ElMessage.success('审核不通过成功')
    msgDialog.value = false
    auditDialog.value = false
    close()
    await search()
  } finally {
    auditDialog.value = false
    msgDialog.value = false
    await search()
  }
}

const reset = async (ids: string) => {
  ElMessageBox.prompt('重置原因', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    inputType: 'textarea',
  })
    .then(async ({ value }) => {
      try {
        await resetBatch(reportCode.value, ids, value)
        status.value = status.value = dictFormatter('0', dictData.dataStatus)
        ElMessage.success('重置成功')
        close()
      } finally {
        await search()
      }
    })
    .catch(() => {
      return
    })
}

const recall = async (ids: string) => {
  try {
    await recallBatch(reportCode.value, ids)
    status.value = status.value = dictFormatter('0', dictData.dataStatus)
    ElMessage.success('撤回成功')
    close()
  } finally {
    await search()
  }
}

const del = async (ids: string) => {
  ElMessageBox.confirm('您确定删除所选中的待提交或待补录的数据吗?', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        await delBatch(reportCode.value, ids)
        ElMessage.success('删除成功')
      } finally {
        await search()
      }
    })
    .catch(() => {
      return
    })
}

const auditDelDialog = ref(false)
const delAudit = async (ids: string, type: string) => {
  if ((msg.value == null || msg.value == '') && type == '2') {
    ElMessage.warning('删除审核不通过原因必填！')
    return
  }
  try {
    let rs
    if (type == '1') {
      rs = await delBatchAudit(reportCode.value, ids)
    } else {
      rs = await delAuditNotPass(reportCode.value, ids, msg.value)
    }
    ElMessage.success(rs.data)
  } finally {
    await search()
    auditDelDialog.value = false
  }
}

const auditDelDialogSub = ref(false)
const delAuditSub = async (ids: string, type: string, name: string) => {
  if ((msg.value == null || msg.value == '') && type == '2') {
    ElMessage.warning('删除审核不通过原因必填！')
    return
  }
  try {
    let rs
    if (type == '1') {
      rs = await subDelBatchAudit(reportCode.value, ids, name)
    } else {
      rs = await subDelBatchAuditNotPass(reportCode.value, ids, msg.value, name)
    }
    ElMessage.success(rs.data)
  } finally {
    await handleClick(undefined)
    await search()
    auditDelDialogSub.value = false
  }
}

const subSubmit = async (ids: string, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      await subSubmitAll(name)
      return
    }
    await subSubmitBatch(reportCode.value, ids, name)
    await handleClick(undefined)
    ElMessage.success('提交成功')
  } finally {
    await handleClick(undefined)
  }
}

const subAuditDialog = ref(false)
const msgDialog = ref(false)
const subMsgDialog = ref(false)
const msg = ref('')
const subAudit = async (ids: any, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      subAuditAll(name)
      return
    }
    await subAuditBatch(reportCode.value, ids, name)
    ElMessage.success('审核成功')
  } finally {
    subAuditDialog.value = false
    await handleClick(undefined)
  }
}
const subAuditNotPass = async (ids: any, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    await subAuditNotPassBatch(reportCode.value, ids, name, msg.value)
    ElMessage.success('审核不通过成功')
  } finally {
    subMsgDialog.value = false
    subAuditDialog.value = false
    await handleClick(undefined)
  }
}

const subReset = async (ids: string, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    ElMessageBox.prompt('重置原因', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      inputType: 'textarea',
    })
      .then(async ({ value }) => {
        await subResetBatch(reportCode.value, ids, name, value)
        await handleClick(undefined)
        ElMessage.success('重置成功')
      })
      .catch(() => {
        return
      })
  } finally {
    await handleClick(undefined)
  }
}

const subRecall = async (ids: string, name: string) => {
  try {
    if (ids == undefined || ids.length == 0) {
      ElMessage.warning('请先选择数据')
      return
    }
    await subRecallBatch(reportCode.value, ids, name)
    await handleClick(undefined)
    ElMessage.success('撤回成功')
  } finally {
    await handleClick(undefined)
  }
}

const subDel = async (ids: string, name: string) => {
  // if (ids == undefined || ids.length == 0) {
  //   ElMessage.warning('请先选择数据')
  //   return
  // }
  if (ids == undefined || ids.length == 0) {
    subDelAll(name)
    return
  }
  ElMessageBox.confirm('您确定删除所选中的待提交或待补录的数据吗?', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      try {
        await subDelBatch(reportCode.value, ids, name)
        await handleClick(undefined)
        ElMessage.success('删除成功')
      } finally {
        await handleClick(undefined)
      }
    })
    .catch(() => {
      return
    })
}

const imp = async (data = {}) => {
  impLoading.value = true
  try {
    var name = data.name
    if (name == null) {
      name = data[0].name
    }
    console.log(name)
    if (!name.toLowerCase().endsWith('.xlsx') && !name.toLowerCase().endsWith('.xls')) {
      ElMessage.error({ message: '仅可上传Excel文件', grouping: true, showClose: true, duration: 0 })
      return
    }
    var needBeOverridden = await checkExcelData(reportCode.value, data)
    if (needBeOverridden.data) {
      ElMessageBox.confirm('检测到上传文件中的数据已存在,是否覆盖?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(async () => {
          impLoading.value = true
          try {
            const rs = await importExcel(reportCode.value, data, 'null', 'null', 'null', 'null', false)
            // ElMessage.success(rs.data);
            await ElMessageBox.alert(`<div style="max-height: 500px; overflow-y: auto;">${rs.data}</div>`, '导入结果', {
              customClass: 'customMessageBox',
              dangerouslyUseHTMLString: true,
            })
            await search()
          } finally {
            impLoading.value = false
          }
        })
        .catch(() => {
          // ElMessage.warning("取消导入");
          impLoading.value = false
          return
        })
    } else {
      const rs = await importExcel(reportCode.value, data, 'null', 'null', 'null', 'null', false)
      // ElMessage.success(rs.data);
      await ElMessageBox.alert(`<div style="max-height: 500px; overflow-y: auto;">${rs.data}</div>`, '导入结果', {
        customClass: 'customMessageBox',
        dangerouslyUseHTMLString: true,
      })
      await search()
    }
  } finally {
    impLoading.value = false
  }
}

const IUpload417ReportFile = async (data = {}, dd: any) => {
  try {
    isSubImpLoading.value = true
    var name = data.file.name
    if (name == null) {
      name = data[0].name
    }
    console.log(name)
    if (!name.toLowerCase().endsWith('.xlsx') && !name.toLowerCase().endsWith('.xls')) {
      ElMessage.error({ message: '仅可上传Excel文件', grouping: true, showClose: true, duration: 0 })
      return
    }
    const rs = await importExcel(
      reportCode.value,
      data,
      qqdbs.value,
      rwlsh.value,
      businessLineUser.value[0].value,
      khbh.value,
      true,
    )
    // ElMessage.success(rs.data);
    await ElMessageBox.alert(`<div style="max-height: 500px; overflow-y: auto;">${rs.data}</div>`, '导入结果', {
      customClass: 'customMessageBox',
      dangerouslyUseHTMLString: true,
    })
    await search()
  } finally {
    isSubImpLoading.value = false
    await fkSubSearch()
  }
}

const exp = async () => {
  expLoading.value = true
  isExpPathArray.value.push(path)
  isExpSubSystemArray.value.push(getSubSystem())
  try {
    if (ids == undefined || ids.length == 0) {
      ids = ''
    }
    let value = searchForm.value
    const newObject = { ...searchForm.value }
    for (const key in newObject) {
      if (newObject[key] === '') {
        newObject[key] = null
        console.log('转化了空串')
      }
    }
    if (value.createTime != undefined) {
      newObject.endTime = formatDate(new Date(value.createTime[1]))
      newObject.createTime = formatDate(new Date(value.createTime[0]))
    }
    await exportExcel(reportCode.value, ids, newObject)
  } finally {
    expLoading.value = false
    // 查找字符串在数组中的索引
    const isExpPathArrayToRemove = isExpPathArray.value.indexOf(path)
    const isExpSubSystemArrayToRemove = isExpSubSystemArray.value.indexOf(getSubSystem())
    // 如果找到了，使用 splice 移除该元素
    if (isExpPathArrayToRemove !== -1) {
      isExpPathArray.value.splice(isExpPathArrayToRemove, 1)
    }
    if (isExpSubSystemArrayToRemove !== -1) {
      isExpSubSystemArray.value.splice(isExpSubSystemArrayToRemove, 1)
    }
  }
}

const parentsButtons: () => ButtonInfo[] = () => {
  const buttons = [
    {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      icon: 'icon_check',
      handler: () => {
        ids = form.value.id
        auditDialog.value = true
      },
    },
    {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      icon: 'icon_recall',
      handler: () => recall(form.value.id),
    },
    // {
    //   key: 'reset',
    //   label: '重置',
    //   tag: 'button',
    //   type: 'primary',
    //   icon: 'icon_reset',
    //   handler: () => reset(form.value.id),
    // },
  ]
  if (status.value == '待提交' || status.value == '待补录' || status.value == '待补录(审核未通过)') {
    buttons.splice(0, 0, {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => submitAndSave(toRaw(form.value), form.value.id),
    })
    buttons.splice(4, 0, {
      key: 'save',
      label: '保存',
      tag: 'button',
      type: 'primary',
      icon: 'icon_update',
      handler: () => save(),
    })
  }
  return buttons
}
const parentsButtons2: ButtonInfo[] = [
  {
    key: 'submit',
    label: '提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => submit(form.value.id),
  },
  {
    key: 'audit',
    label: '审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => {
      ids = form.value.id
      auditDialog.value = true
    },
  },
  {
    key: 'recall',
    label: '撤回',
    tag: 'button',
    type: 'primary',
    icon: 'icon_recall',
    handler: () => recall(form.value.id),
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => reset(form.value.id),
  },
]
const dictDataList = [
  { label: '1', value: '待提交' },
  { label: '2', value: '待审核' },
  { label: '3', value: '已审核' },
  {
    label: '4',
    value: '已生成',
  },
]
const genActButtons: (row: any) => ButtonInfo[] = (row: any) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: () => {
        // let pageElements = derivedPageElements(requestClassificationCode.value, null);
        activeName.value = '1'
        if (
          (getSubSystem() == 'jcy' || getSubSystem() == 'gjw' || getSubSystem() == 'zyjw' || getSubSystem() == 'nsa') &&
          (row.fldm == 'SS05' || row.fldm == 'SS06' || row.fldm == 'SS32' || row.fldm == 'SS33')
        ) {
          subTables = pageElements.subTables2
        } else {
          subTables = pageElements.subTables
        }
        if (row.fldm == 'SS05' || row.fldm == 'SS06' || row.fldm == 'SS32' || row.fldm == 'SS33') {
          formItems.value = pageElements.formItems2
        } else {
          formItems.value = pageElements.formItems
        }
        rwlsh.value = row.rwlsh
        id.value = row.id
        khbh.value = row.khbh
        cxnr.value = row.cxnr
        branchCode.value = row.branchCode
        qqdbs.value = row.qqdbs
        status.value = dictFormatter(row.status, dictData.dataStatus)
        open(row, true, getTitleName() + '查看')
      },
    },
  ]
  if ((row.status <= 2 || row.status == 6) && (row.deleteState == '1' || row.deleteState == '4')) {
    buttons.splice(1, 0, {
      key: 'edit',
      label: '编辑',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        // let pageElements = derivedPageElements(requestClassificationCode.value, null);
        activeName.value = '1'
        if (
          (getSubSystem() == 'jcy' || getSubSystem() == 'gjw') &&
          (row.fldm == 'SS05' || row.fldm == 'SS06' || row.fldm == 'SS32' || row.fldm == 'SS33')
        ) {
          subTables = pageElements.subTables2
        } else {
          subTables = pageElements.subTables
        }
        if (row.fldm == 'SS05' || row.fldm == 'SS06' || row.fldm == 'SS32' || row.fldm == 'SS33') {
          formItems.value = pageElements.formItems2
        } else {
          formItems.value = pageElements.formItems
        }
        rwlsh.value = row.rwlsh
        id.value = row.id
        khbh.value = row.khbh
        cxnr.value = row.cxnr
        branchCode.value = row.branchCode
        qqdbs.value = row.qqdbs
        status.value = dictFormatter(row.status, dictData.dataStatus)
        if (row.status > 2 && row.status != 6) {
          open(row, true, getTitleName())
        } else {
          let disabled = false
          if (row.status == 2) {
            disabled = true
          }
          open(row, disabled, getTitleName() + '编辑')
        }
      },
    })
  }
  if ('fkCertificateImage' == getRequestClassificationCode()) {
    buttons.splice(2, 0, {
      key: 'upload',
      label: '上传凭证图像',
      tag: 'button',
      type: 'primary',
      handler: () => {
        if (row.status != 1 && row.status != 0 && row.status != 6) {
          ElMessage.error({
            message: '仅在待提交/待补录状态可上传凭证图像',
            grouping: true,
            showClose: true,
            duration: 0,
          })
          return
        }
        if (getSubSystem() == 'nsa') {
          selectOpen(null, false, '选择图像类型')
        } else {
          var elementById = document.getElementById('uploadButton')
          elementById.click()
        }
        rwlsh.value = row.rwlsh
        id.value = row.id
        qqdbs.value = row.qqdbs
      },
    })
    buttons.splice(3, 0, {
      key: 'preview',
      label: '查看已上传凭证图像',
      tag: 'button',
      type: 'primary',
      handler: async () => {
        rwlsh.value = row.rwlsh
        id.value = row.id
        var rsPromise = await previewUploadFile(id.value)
        // 将base64字符串转换为Uint8Array对象
        var split = rsPromise.data.split('-|-')
        const pdfData = atob(split[0])
        const pdfArray = new Uint8Array(pdfData.length)
        for (let i = 0; i < pdfData.length; i++) {
          pdfArray[i] = pdfData.charCodeAt(i)
        }
        // 创建Blob对象
        let pdfBlob
        if (split[1].toLowerCase() == 'pdf') {
          pdfBlob = new Blob([pdfArray], { type: 'application/pdf' })
          // 将Blob对象转换为URL
          const pdfUrl = URL.createObjectURL(pdfBlob)
          // 将URL作为iframe的src属性值
          // let pdfWindow = window.open("", '预览');
          let pdfWindow = window.open('')
          pdfWindow.document.write("<iframe width='100%' height='100%' src='" + pdfUrl + "'></iframe>")
        } else if (split[1].toLowerCase() == 'jpg') {
          pdfBlob = new Blob([pdfArray], { type: 'image/jpeg' })
          // 将Blob对象转换为URL
          const pdfUrl = URL.createObjectURL(pdfBlob)
          // 将URL作为iframe的src属性值
          showImageViewer.value = true
          urlList.value = []
          urlList.value = [...urlList.value, pdfUrl]
        } else {
          ElMessage.error({
            message: '后端返回的类型参数有误:' + split[1].toLowerCase(),
            grouping: true,
            showClose: true,
            duration: 0,
          })
          return
        }
      },
    })
  }
  return buttons
}
let imageType = ref('')
const imageTypeSave = () => {
  if (selectForm.value.imageType == undefined || selectForm.value.imageType == '') {
    return ElMessage.error({ message: '图像类型不能为空', grouping: true, showClose: true, duration: 0 })
  }
  imageType.value = selectForm.value.imageType
  var elementById = document.getElementById('uploadButton')
  elementById.click()
  selectClosed()
}
const IUploadFile = async (data = {}) => {
  if (!data.file.name.toLowerCase().endsWith('.pdf') && !data.file.name.toLowerCase().endsWith('.jpg')) {
    ElMessage.error({ message: '仅可上传PDF/JPG文件', grouping: true, showClose: true, duration: 0 })
    return
  }
  var isNotExist = await checkFileExist(id.value)
  console.log(isNotExist.data)
  if (!isNotExist.data) {
    ElMessageBox.confirm('检测到该数据已经上传过凭证图像,是否覆盖?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    })
      .then(async () => {
        const rsPromise = await upload(qqdbs.value, rwlsh.value, id.value, data, imageType.value)
        ElMessage.success(rsPromise.data)
        search()
      })
      .catch(() => {
        ElMessage.warning('取消上传')
        return
      })
  } else {
    const rsPromise = await upload(qqdbs.value, rwlsh.value, id.value, data, imageType.value)
    ElMessage.success(rsPromise.data)
    search()
  }
}
//子表所需代码
const save1 = async (data: any, name: string) => {
  let sysCode = getSubSystem()
  const valid = await subDialogFormRef.value?.asyncValidate()
  if (!valid) {
    return
  }
  data = toRaw(subForm.value)
  data.status = '1'
  data.deleted = '0'
  data.rwlsh = rwlsh.value
  if (khbh.value != '' && khbh.value != undefined) {
    data.khbh = khbh.value
  }
  if (cxnr.value != '' && cxnr.value != undefined) {
    data.cxnr = cxnr.value
  }
  if (branchCode.value != '' && branchCode.value != undefined) {
    data.branchCode = branchCode.value
  }
  // TOTD SPF-ADD-20240517 公安更新-添加 start
  let result = true,
    msg = '',
    msgArr = [],
    errorMsg = ''
  // 账户信息
  if (sysCode == 'ga' && name == 'fkAccount') {
    let kh = data.kh,
      zh = data.zh // 卡号、账号
    errorMsg = '卡号或者账号有反馈数据时，name不能为空！'
    if ((kh != null && kh != '') || (zh != null && zh != '')) {
      if (data.zhlb == null || data.zhlb == '') {
        // 账户类别
        result = false
        msg = errorMsg.replace('name', '账户类别')
        msgArr.push(msg)
      }
      if (data.zhzt == null || data.zhzt == '') {
        // 账户状态
        result = false
        msg = errorMsg.replace('name', '账户状态')
        msgArr.push(msg)
      }
      if (data.khwd == null || data.khwd == '') {
        // 开户网点
        result = false
        msg = errorMsg.replace('name', '开户网点')
        msgArr.push(msg)
      }
      if (data.khwddm == null || data.khwddm == '') {
        // 开户网点代码
        result = false
        msg = errorMsg.replace('name', '开户网点代码')
        msgArr.push(msg)
      }
      if (data.khrq == null || data.khrq == '') {
        // 开户登记日期
        result = false
        msg = errorMsg.replace('name', '开户日期')
        msgArr.push(msg)
      }
      if ((data.zhye == null || data.zhye == '') && data.zhye != 0) {
        // 账户余额
        result = false
        msg = errorMsg.replace('name', '账户余额')
        msgArr.push(msg)
      }
      if ((data.kyye == null || data.kyye == '') && data.kyye != 0) {
        // 可用余额
        result = false
        msg = errorMsg.replace('name', '可用余额')
        msgArr.push(msg)
      }
    }
    // 账户状态为销户时，此数据项不能为空。
    if (data.zhzt != null && data.zhzt.includes('销户')) {
      if (data.xhrq == null || data.xhrq == '') {
        // 销户日期
        result = false
        msg = '账户状态为销户时，销户日期不能为空！'
        msgArr.push(msg)
      }
      if (data.xhwd == null || data.xhwd == '') {
        // 销户网点
        result = false
        msg = '账户状态为销户时，销户网点不能为空！'
        msgArr.push(msg)
      }
    }
    // 币种有反馈数据且不为人民币时，此数据项不能为空！
    if (data.bz != null && data.bz != '' && data.bz != 'CNY') {
      if (data.chbz == null || data.chbz == '') {
        result = false
        msg = '币种有反馈数据且不为人民币时，钞汇标志不能为空！'
        msgArr.push(msg)
      }
    }
    if (!result) {
      // ElMessage.warning(msgArr.join('\n'));
      ElMessageBox.alert(
        `<div style="max-height: 500px; overflow-y: auto;">${msgArr.join('<br/>')}</div>`,
        '校验结果',
        {
          customClass: 'customMessageBox',
          dangerouslyUseHTMLString: true,
        },
      )
      return
    }
  }
  // 交易明细
  if (sysCode == 'ga' && name == 'fkTransaction') {
    let jylx = data.jylx // 交易类型
    errorMsg = '若交易类型反馈转账/汇款/ATM等网银转账业务时，name不能为空！'
    // 交易明细表：（若交易类型反馈转账/汇款/ATM等网银转账业务时，此数据项不能为空。）
    if (jylx.includes('转账') || jylx.includes('汇款') || jylx.includes('ATM') || jylx.includes('网银转账')) {
      if (data.jydfxm == null || data.jydfxm == '') {
        // 交易对方名称
        result = false
        msg = errorMsg.replace('name', '交易对方名称')
        msgArr.push(msg)
      }
      if (data.jydfzkh == null || data.jydfzkh == '') {
        // 交易对方账卡号
        result = false
        msg = errorMsg.replace('name', '交易对方账卡号')
        msgArr.push(msg)
      }
      // 交易对手是否为本行账户暂无法判断
      // 若交易类型反馈转账/汇款/ATM等网银转账业务，对手信息为本行账户时，此数据项不能为空。
      if (data.jydfzkhlx == null || data.jydfzkhlx == '') {
        // 交易对方帐卡号类型
        result = false
        msg = errorMsg.replace('name', '交易对方帐卡号类型')
        msgArr.push(msg)
      }
      // 若交易类型反馈转账/汇款/ATM等网银转账业务，对手信息为本行账户时，此数据项不能为空。
      if (data.jydfzjhm == null || data.jydfzjhm == '') {
        // 交易对方证件号码
        result = false
        msg = errorMsg.replace('name', '交易对方证件号码')
        msgArr.push(msg)
      }
      // 若交易类型反馈转账/汇款/ATM等网银转账业务，对手信息为本行账户时，此数据项不能为空。
      if ((data.jydsye == null || data.jydsye == '') && data.jydsye != 0) {
        // 交易对手余额
        result = false
        msg = errorMsg.replace('name', '交易对手余额')
        msgArr.push(msg)
      }

      if (data.jydfzhkhh == null || data.jydfzhkhh == '') {
        // 交易对方账号开户行
        result = false
        msg = errorMsg.replace('name', '交易对方账号开户行')
        msgArr.push(msg)
      }
      if (data.ip == null || data.ip == '') {
        // IP地址
        result = false
        msg = errorMsg.replace('name', 'IP地址')
        msgArr.push(msg)
      }
      if (data.mac == null || data.mac == '') {
        // MAC地址
        result = false
        msg = errorMsg.replace('name', 'MAC地址')
        msgArr.push(msg)
      }
    }
    // 交易柜员编号(若柜面交易，此数据项不能为空。) 是否为柜面交易暂时无法判断
    if (jylx.includes('柜面')) {
      if (data.jygyh == null || data.jygyh == '') {
        // 交易柜员编号
        result = false
        msg = '若交易类型为柜面交易，交易柜员编号不能为空！'
        msgArr.push(msg)
      }
    }

    if (!result) {
      // ElMessage.warning(msgArr.join('\n'));
      ElMessageBox.alert(
        `<div style="max-height: 500px; overflow-y: auto;">${msgArr.join('<br/>')}</div>`,
        '校验结果',
        {
          customClass: 'customMessageBox',
          dangerouslyUseHTMLString: true,
        },
      )
      return
    }
  }
  // 冻结/续冻/解冻反馈 明细
  if (sysCode == 'ga' && name == 'fkFreezeDetail') {
    let zxjg = data.zxjg // 执行结果
    if (zxjg != null && zxjg == '1') {
      if (data.zxjgyy == null || data.zxjgyy == '') {
        // 执行失败原因
        ElMessage.warning('执行结果为1-执行失败时，执行失败原因不能为空！')
        return
      }
    }
    // 币种有反馈数据且不为人民币时，此数据项不能为空！
    if (data.bz != null && data.bz != '' && data.bz != 'CNY') {
      if (data.chbz == null || data.chbz == '') {
        ElMessage.warning('币种有反馈数据且不为人民币时，钞汇标志不能为空！')
        return
      }
    }
  }
  // 紧急止付/解除止付明细
  if (sysCode == 'ga' && name == 'fkPaymentDetail') {
    let zxjg = data.zxjg // 执行结果
    if (zxjg != null && zxjg == '1') {
      if (data.zxjgyy == null || data.zxjgyy == '') {
        // 执行失败原因
        ElMessage.warning('执行结果为1-执行失败时，执行失败原因不能为空！')
        return
      }
    }
    // 币种有反馈数据且不为人民币时，此数据项不能为空！
    if (data.bz != null && data.bz != '' && data.bz != 'CNY') {
      if (data.chbz == null || data.chbz == '') {
        ElMessage.warning('币种有反馈数据且不为人民币时，钞汇标志不能为空！')
        return
      }
    }
  }
  // 账户信息-关联子账户
  if (sysCode == 'ga' && name == 'fkSubAccount') {
    // 币种有反馈数据且不为人民币时，此数据项不能为空！
    if (data.bz != null && data.bz != '' && data.bz != 'CNY') {
      if (data.chbz == null || data.chbz == '') {
        ElMessage.warning('币种有反馈数据且不为人民币时，钞汇标志不能为空！')
        return
      }
    }
  }
  // TOTD SPF-ADD-20240517 公安更新-添加 end
  data.qqdbs = qqdbs.value
  delete data.type
  let rs = await subUpdateData(reportCode.value, data, name)
  subClose()
  subClosed()
  ElMessage.success('保存成功')
  handleClick(undefined)
}

const subButtons: (name: string, items: any) => ButtonInfo[] = (name: string, items: any) => {
  const buttons = [
    {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      icon: 'icon_submit',
      handler: () => subSubmit(subIds, name),
    },
    {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      icon: 'icon_check',
      handler: () => {
        listName = name
        if (subIds == null || subIds.length == 0) {
          subAuditAll(name)
          return
        }
        subAuditDialog.value = true
      },
    },
    {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      icon: 'icon_recall',
      handler: () => subRecall(subIds, name),
    },
    {
      key: 'reset',
      label: '重置',
      tag: 'button',
      type: 'primary',
      icon: 'icon_reset',
      handler: () => subReset(subIds, name),
    },
    // {
    //   key: 'del',
    //   label: '批量删除',
    //   tag: 'button',
    //   type: 'danger',
    //   icon: 'icon_delete',
    //   handler: () => subDel(subIds, name),
    // },
    {
      key: 'delete',
      label: '删除',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      handler: () => subDel(subIds, name),
    },
    {
      key: 'delverify',
      label: '删除审核',
      tag: 'button',
      type: 'danger',
      icon: 'icon_delete',
      handler: () => {
        listName = name
        msg.value = null
        if (subIds == undefined || subIds.length == 0) {
          // ElMessage.warning('请先选择数据')
          subAuditDelAll(name)
          return
        }
        auditDelDialogSub.value = true
      },
    },
  ]
  if (status.value == '待提交' || status.value == '待补录' || status.value == '待补录(审核未通过)') {
    buttons.splice(0, 0, {
      key: 'save',
      label: '新增',
      tag: 'button',
      type: 'primary',
      icon: 'icon_add',
      handler: () => {
        listName = name
        subFormItems.value = items
        subOpen({}, false, getSubTitleName(name) + '新增')
      },
    })
  }
  if (
    getSubSystem() === 'jcy' &&
    getRequestClassificationCode() === 'fkAccountAndTransaction' &&
    subReportCode.value === 'fkTransaction' &&
    dialogData.title === getTitleName() + '编辑'
  ) {
    buttons.push({
      key: 'imp417report',
      label: '导入417report',
      tag: 'button',
      type: 'primary',
      loading: isSubImpLoading.value,
      icon: 'icon_upload',
      handler: () => {
        var elementById = document.getElementById('upload417ReportButton')
        elementById.click()
      },
    })
  }
  return buttons
}
const getTitleName = () => {
  switch (getRequestClassificationCode()) {
    case 'fkCustomer':
      return '账户信息查询反馈'
    case 'fkTransaction':
      return '交易明细查询反馈'
    case 'fkAccountAndTransaction':
      return '账户信息和交易明细综合查询反馈'
    case 'fkDynamicReceipt':
      return '动态查询执行回执'
    case 'fkDynamic':
      return '动态查询反馈'
    case 'fkFreeze':
      return '冻结/续冻/解冻反馈'
    case 'fkPayment':
      return '紧急止付/解除止付反馈'
    case 'fkCertificateImage':
      return '调阅凭证图像反馈'
    case 'fkFinancialAccount':
      return '金融理财账户信息反馈'
  }
}

const getSubTitleName = (name: string) => {
  switch (name) {
    case 'fkAccount':
      return '账户信息'
    case 'fkMeasure':
      return '强制措施'
    case 'fkPriority':
      return '共有权/优先权'
    case 'fkSubAccount':
      return '关联子账户'
    case 'fkTransaction':
      return '交易明细'
    case 'fkDynamicReceipt':
      return '动态查询请求回执'
    case 'fkFreezeDetail':
      return '冻结/续冻/解冻明细'
    case 'fkPaymentDetail':
      return '紧急止付/解除止付明细'
    case 'fkCertificateImageDetail':
      return '调阅凭证图像明细'
    case 'fkFinancialDetail':
      return '金融理财信息明细'
    case 'gaFkFinancial':
      return '金融资产信息'
    case 'gaFkFinancialMeasure':
      return '金融资产强制措施'
  }
}
const subGenActButtons2: (row: any, name: string, items: any) => ButtonInfo[] = (
  row: any,
  name: string,
  items: any,
) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: () => {
        subFormItems.value = items
        console.log(row)
        subOpen(row, true, getSubTitleName(name) + '查看')
      },
    },
  ]
  return buttons
}
const subGenActButtons: (row: any, name: string, items: any) => ButtonInfo[] = (row: any, name: string, items: any) => {
  const buttons = [
    {
      key: 'view',
      label: '查看',
      tag: 'button',
      type: 'primary',
      handler: () => {
        subFormItems.value = items
        console.log(row)
        subOpen(row, true, getSubTitleName(name) + '查看')
      },
    },
  ]
  /*if (row.status < 2 || row.status == 6) {
    buttons.splice(1, 0,
        {
          key: 'delete', label: '删除', tag: 'popconfirm', type: 'danger', title: '确定删除吗',
          handler: () => subDel(row.id, name)
        });
  }*/
  if (row.status == 3) {
    buttons.splice(1, 0, {
      key: 'reset',
      label: '重置',
      tag: 'button',
      type: 'primary',
      handler: () => subReset(row.id, name),
    })
  }
  if (row.status == 2) {
    buttons.splice(1, 0, {
      key: 'recall',
      label: '撤回',
      tag: 'button',
      type: 'primary',
      handler: () => subRecall(row.id, name),
    })
  }
  if (row.status == 2) {
    buttons.splice(1, 0, {
      key: 'audit',
      label: '审核',
      tag: 'button',
      type: 'primary',
      handler: () => {
        subIds = row.id
        listName = name
        subAuditDialog.value = true
      },
    })
  }
  if (row.status == 1 && (row.deleteState == '1' || row.deleteState == '4')) {
    buttons.splice(1, 0, {
      key: 'submit',
      label: '提交',
      tag: 'button',
      type: 'primary',
      handler: () => subSubmit(row.id, name),
    })
  }

  if ((row.status < 2 || row.status == 6) && (row.deleteState == '1' || row.deleteState == '4')) {
    buttons.splice(1, 0, {
      key: 'edit',
      label: '编辑',
      tag: 'button',
      type: 'primary',
      handler: () => {
        console.log(row)
        subFormItems.value = items
        if (row.status > 2 && row.status != 6) {
          subOpen(row, true, getSubTitleName(name))
        } else {
          subOpen(row, false, getSubTitleName(name) + '编辑')
        }
      },
    })
  }
  return buttons
}

const fkSubSearch = async () => {
  let result = await listSub(
    subReportCode.value,
    searchForm.value,
    subPage.value.currentPage,
    subPage.value.pageSize,
    rwlsh.value,
    khbh.value,
    branchCode.value,
  )
  subSearch(result)
}
const subSearch = (result: any) => {
  console.log(result)
  let { current, total, records } = result.data
  subData.value = records
  subPage.value.currentPage = current
  subPage.value.total = total
  console.log('出发了子表查询')
}

let tabName = ''
const subReportCode = ref('')
const handleClick = async (tab: any) => {
  console.log(rwlsh)
  subLoading.value = true
  try {
    if (tab == undefined) {
      console.log('分页查询')
      console.log(tabName)
      switch (tabName) {
        case '账户信息':
          subReportCode.value = 'fkAccount'
          await fkSubSearch()
          break
        case '强制措施':
          subReportCode.value = 'fkMeasure'
          await fkSubSearch()
          break
        case '共有权/优先权':
          subReportCode.value = 'fkPriority'
          await fkSubSearch()
          break
        case '关联子账户':
          subReportCode.value = 'fkSubAccount'
          await fkSubSearch()
          break
        case '交易明细':
          subReportCode.value = 'fkTransaction'
          await fkSubSearch()
          break
        case '动态查询请求回执':
          subReportCode.value = 'fkDynamicReceipt'
          await fkSubSearch()
          break
        case '冻结/续冻/解冻明细':
          subReportCode.value = 'fkFreezeDetail'
          await fkSubSearch()
          break
        case '紧急止付/解除止付明细':
          subReportCode.value = 'fkPaymentDetail'
          await fkSubSearch()
          break
        case '调阅凭证图像明细':
          subReportCode.value = 'fkCertificateImageDetail'
          await fkSubSearch()
          break
        case '金融理财信息明细':
          subReportCode.value = 'fkFinancialDetail'
          await fkSubSearch()
          break
        case '金融资产信息':
          subReportCode.value = 'gaFkFinancial'
          await fkSubSearch()
          break
        case '金融资产强制措施':
          subReportCode.value = 'gaFkFinancialMeasure'
          await fkSubSearch()
          break
      }
    } else {
      subPage.value.currentPage = 1
      tabName = tab.props.label
      switch (tab.props.label) {
        case '账户信息':
          subReportCode.value = 'fkAccount'
          await fkSubSearch()
          break
        case '强制措施':
          subReportCode.value = 'fkMeasure'
          await fkSubSearch()
          break
        case '共有权/优先权':
          subReportCode.value = 'fkPriority'
          await fkSubSearch()
          break
        case '关联子账户':
          subReportCode.value = 'fkSubAccount'
          await fkSubSearch()
          break
        case '交易明细':
          subReportCode.value = 'fkTransaction'
          await fkSubSearch()
          break
        case '动态查询请求回执':
          subReportCode.value = 'fkDynamicReceipt'
          await fkSubSearch()
          break
        case '冻结/续冻/解冻明细':
          subReportCode.value = 'fkFreezeDetail'
          await fkSubSearch()
          break
        case '紧急止付/解除止付明细':
          subReportCode.value = 'fkPaymentDetail'
          await fkSubSearch()
          break
        case '调阅凭证图像明细':
          subReportCode.value = 'fkCertificateImageDetail'
          await fkSubSearch()
          break
        case '金融理财信息明细':
          subReportCode.value = 'fkFinancialDetail'
          await fkSubSearch()
          break
        case '金融资产信息':
          subReportCode.value = 'gaFkFinancial'
          await fkSubSearch()
          break
        case '金融资产强制措施':
          subReportCode.value = 'gaFkFinancialMeasure'
          await fkSubSearch()
          break
      }
    }
  } finally {
    subLoading.value = false
  }
}

//主表按钮组件
const Buttons: ButtonInfo[] = [
  {
    key: 'submit',
    label: '提交',
    tag: 'button',
    type: 'primary',
    icon: 'icon_submit',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        submitAll()
        return
      }
      submit(ids)
    },
  },
  {
    key: 'audit',
    label: '审核',
    tag: 'button',
    type: 'primary',
    icon: 'icon_check',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        auditAll()
        return
      }
      auditDialog.value = true
    },
  },
  {
    key: 'recall',
    label: '撤回',
    tag: 'button',
    type: 'primary',
    icon: 'icon_recall',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
      }
      recall(ids)
    },
  },
  {
    key: 'reset',
    label: '重置',
    tag: 'button',
    type: 'primary',
    icon: 'icon_reset',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        ElMessage.warning('请先选择数据')
        return
      }
      reset(ids)
    },
  },
  {
    key: 'delete',
    label: '删除',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => {
      if (ids == undefined || ids.length == 0) {
        // ElMessage.warning('请先选择数据')
        delAll()
        return
      }
      del(ids)
    },
  },
  {
    key: 'delverify',
    label: '删除审核',
    tag: 'button',
    type: 'danger',
    icon: 'icon_delete',
    handler: () => {
      msg.value = null
      if (ids == undefined || ids.length == 0) {
        // ElMessage.warning('请先选择数据')
        auditDelAll()
        return
      }
      auditDelDialog.value = true
    },
  },
]

const submitAllVisible = ref(false)
const successNum = ref(0)
const failNum = ref(0)
const returnMassage = ref('')
const submitOrAudit = ref('')
const submitAll = async () => {
  ElMessageBox.confirm('是否批量提交所有待提交/待补录数据?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      loading.value = true
      const newObject = { ...searchForm.value }
      for (const key in newObject) {
        if (newObject[key] === '') {
          newObject[key] = null
          console.log('转化了空串')
        }
      }
      var rs = await submitAllBatch(reportCode.value, newObject, null, null, false)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '提交'
      submitAllVisible.value = true
      search()
      loading.value = false
    })
    .catch(() => {
      loading.value = false
      return
    })
}
const auditAll = async () => {
  ElMessageBox.confirm('是否批量审核所有待审核数据?', '警告', {
    confirmButtonText: '审核通过',
    cancelButtonText: '审核不通过',
    type: 'warning',
    distinguishCancelAndClose: true,
    confirmButtonClass: 'auditButton',
    cancelButtonClass: 'auditNotPassButton',
  })
    .then(async () => {
      loading.value = true
      const newObject = { ...searchForm.value }
      for (const key in newObject) {
        if (newObject[key] === '') {
          newObject[key] = null
          console.log('转化了空串')
        }
      }
      var rs = await auditAllBatch(reportCode.value, newObject, null, null, false)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '审核'
      submitAllVisible.value = true
      search()
      loading.value = false
    })
    .catch((action: Action) => {
      if (action === 'cancel') {
        ElMessageBox.prompt('审核不通过理由', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputType: 'textarea',
        })
          .then(async ({ value }) => {
            const newObject = { ...searchForm.value }
            for (const key in newObject) {
              if (newObject[key] === '') {
                newObject[key] = null
                console.log('转化了空串')
              }
            }
            var rs = await auditNotPassAllBatch(reportCode.value, newObject, null, null, false, value)
            successNum.value = rs.data.successNum
            failNum.value = rs.data.failNum
            returnMassage.value = rs.data.returnMassage
            submitOrAudit.value = '审核不通过'
            submitAllVisible.value = true
            search()
            loading.value = false
          })
          .catch(() => {
            loading.value = false
            return
          })
      }
    })
}
const subSubmitAll = async (name: string) => {
  ElMessageBox.confirm('是否批量提交所有待提交/待补录数据?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      loading.value = true
      var rs = await submitAllBatch(name, {}, rwlsh.value, khbh.value, true)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitAllVisible.value = true
      submitOrAudit.value = '提交'
      await handleClick(undefined)
      loading.value = false
    })
    .catch(() => {
      loading.value = false
      return
    })
}
const subAuditAll = async (name: string) => {
  ElMessageBox.confirm('是否批量审核所有待审核数据?', '警告', {
    confirmButtonText: '审核通过',
    cancelButtonText: '审核不通过',
    type: 'warning',
    distinguishCancelAndClose: true,
    confirmButtonClass: 'auditButton',
    cancelButtonClass: 'auditNotPassButton',
  })
    .then(async () => {
      loading.value = true
      var rs = await auditAllBatch(name, {}, rwlsh.value, khbh.value, true)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitAllVisible.value = true
      submitOrAudit.value = '审核'
      await handleClick(undefined)
      loading.value = false
    })
    .catch((action: Action) => {
      if (action === 'cancel') {
        ElMessageBox.prompt('审核不通过理由', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputType: 'textarea',
        })
          .then(async ({ value }) => {
            var rs = await auditNotPassAllBatch(name, {}, rwlsh.value, khbh.value, true, value)
            successNum.value = rs.data.successNum
            failNum.value = rs.data.failNum
            returnMassage.value = rs.data.returnMassage
            submitAllVisible.value = true
            submitOrAudit.value = '审核不通过'
            await handleClick(undefined)
            loading.value = false
          })
          .catch(() => {
            loading.value = false
            return
          })
      }
    })
}

const delAll = async () => {
  ElMessageBox.confirm('是否批量删除所有待补录/待提交数据?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      loading.value = true
      const newObject = { ...searchForm.value }
      for (const key in newObject) {
        if (newObject[key] === '') {
          newObject[key] = null
        }
      }
      var rs = await delAllBatch(reportCode.value, newObject, null, null, false)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '删除'
      submitAllVisible.value = true
      search()
      loading.value = false
    })
    .catch(() => {
      loading.value = false
      return
    })
}
const auditDelAll = async () => {
  ElMessageBox.confirm('是否批量删除审核所有删除待审核数据?', '警告', {
    confirmButtonText: '审核通过',
    cancelButtonText: '审核不通过',
    type: 'warning',
    distinguishCancelAndClose: true,
    confirmButtonClass: 'auditButton',
    cancelButtonClass: 'auditNotPassButton',
  })
    .then(async () => {
      loading.value = true
      const newObject = { ...searchForm.value }
      for (const key in newObject) {
        if (newObject[key] === '') {
          newObject[key] = null
        }
      }
      var rs = await auditDelAllBatch(reportCode.value, newObject, null, null, false)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitOrAudit.value = '删除审核'
      submitAllVisible.value = true
      search()
      loading.value = false
    })
    .catch((action: Action) => {
      if (action === 'cancel') {
        ElMessageBox.prompt('删除审核不通过理由', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputType: 'textarea',
        })
          .then(async ({ value }) => {
            if (value == null || value == '') {
              ElMessage.warning('删除审核不通过原因必填！')
              return
            }
            const newObject = { ...searchForm.value }
            for (const key in newObject) {
              if (newObject[key] === '') {
                newObject[key] = null
              }
            }
            var rs = await auditDelNotPassAllBatch(reportCode.value, newObject, null, null, false, value)
            successNum.value = rs.data.successNum
            failNum.value = rs.data.failNum
            returnMassage.value = rs.data.returnMassage
            submitOrAudit.value = '删除审核不通过'
            submitAllVisible.value = true
            search()
            loading.value = false
          })
          .catch(() => {
            loading.value = false
            return
          })
      }
    })
}
const subDelAll = async (name: string) => {
  ElMessageBox.confirm('是否批量删除所有待补录/待提交数据?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(async () => {
      loading.value = true
      var rs = await delAllBatch(name, {}, rwlsh.value, khbh.value, true)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitAllVisible.value = true
      submitOrAudit.value = '删除'
      await handleClick(undefined)
      loading.value = false
    })
    .catch(() => {
      loading.value = false
      return
    })
}
const subAuditDelAll = async (name: string) => {
  ElMessageBox.confirm('是否批量删除审核所有删除待审核数据?', '警告', {
    confirmButtonText: '审核通过',
    cancelButtonText: '审核不通过',
    type: 'warning',
    distinguishCancelAndClose: true,
    confirmButtonClass: 'auditButton',
    cancelButtonClass: 'auditNotPassButton',
  })
    .then(async () => {
      loading.value = true
      var rs = await auditDelAllBatch(name, {}, rwlsh.value, khbh.value, true)
      successNum.value = rs.data.successNum
      failNum.value = rs.data.failNum
      returnMassage.value = rs.data.returnMassage
      submitAllVisible.value = true
      submitOrAudit.value = '删除审核'
      await handleClick(undefined)
      loading.value = false
    })
    .catch((action: Action) => {
      if (action === 'cancel') {
        ElMessageBox.prompt('删除审核不通过理由', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputType: 'textarea',
        })
          .then(async ({ value }) => {
            if (value == null || value == '') {
              ElMessage.warning('删除审核不通过原因必填！')
              return
            }
            var rs = await auditDelNotPassAllBatch(name, {}, rwlsh.value, khbh.value, true, value)
            successNum.value = rs.data.successNum
            failNum.value = rs.data.failNum
            returnMassage.value = rs.data.returnMassage
            submitAllVisible.value = true
            submitOrAudit.value = '删除审核不通过'
            await handleClick(undefined)
            loading.value = false
          })
          .catch(() => {
            loading.value = false
            return
          })
      }
    })
}

function clearForm() {
  activeName.value = null
  dialogFormRef.value?.clearValidate()
  subDialogFormRef.value?.clearValidate()
}
</script>

<script lang="ts">
import useDictsStore from '@/store/dictStore'
// TODO 启动时加载，不在页面里调用   子系统设置
const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<style>
.auditNotPassButton {
  background: #f56c6cff;
  border-color: #f56c6cff;
  color: #fff;
}

.customMessageBox {
  width: 1000px;
}

.auditNotPassButton:hover {
  background: #e08282; /* 鼠标悬停时的背景色 */
  border-color: #e08282; /* 鼠标悬停时的边框颜色 */
  color: #fff; /* 鼠标悬停时的文字颜色 */
}

/*.auditButton{*/
/*  background: var(--el-color-success);*/
/*  border-color: var(--el-color-success);*/
/*  color: #fff;*/
/*}*/
</style>
