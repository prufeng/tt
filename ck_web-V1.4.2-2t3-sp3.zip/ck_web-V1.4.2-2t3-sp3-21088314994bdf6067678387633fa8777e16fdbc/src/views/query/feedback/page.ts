import { getSubSystem } from "@/utils/subSystem";
import { FormItemInfo, TableColumnInfo } from "riking-ui";

declare interface PageElements {
    formItems: TableColumnInfo[],
    formItems2: TableColumnInfo[],
    columns: FormItemInfo[],
    subTables: TableColumnInfo[],
    subTables2: TableColumnInfo[],
    searchItems: FormItemInfo[],
}

declare interface PageParentsElements{
    cxParentsFormItems: FormItemInfo[],
    kzParentsFormItems: FormItemInfo[],
}
import * as jcy from './config/jcy';
import * as nsa from './config/nsa';
import * as zyjw from './config/zyjw';
import * as gjw from './config/gjw';
export const derivedPageElements = (key: string, djfs: string) => {
    const elements: PageElements = { formItems: [],formItems2: [], columns: [], subTables: [],subTables2: [], searchItems: [] };
    const subSystem = getSubSystem();
    const page ={'jcy':jcy, 'nsa':nsa, 'zyjw':zyjw, 'gjw':gjw}
    switch (key) {
        case 'fkCustomer':
            elements.columns = page[subSystem].customerParentsColumns;
            elements.formItems = [{ name: "客户信息", items: page[subSystem].fkCustomerFormItems }];
            elements.formItems2 = [{ name: "客户信息", items: page[subSystem].fkCustomerFormItems2 }];
            elements.subTables = [
                { name: "账户信息", items: page[subSystem].fkAccountFormItems, columns: page[subSystem].fkAccountColumns, listName: "fkAccount" },
                { name: "强制措施", items: page[subSystem].fkMeasureFormItems, columns: page[subSystem].fkMeasureColumns, listName: "fkMeasure" },
                { name: "共有权/优先权", items: page[subSystem].fkPriorityFormItems, columns: page[subSystem].fkPriorityColumns, listName: "fkPriority" },
                { name: "关联子账户", items: page[subSystem].fkSubAccountFormItems, columns: page[subSystem].fkSubAccountColumns, listName: "fkSubAccount" },
            ]
            elements.subTables2 = [
                { name: "账户信息", items: page[subSystem].fkAccountFormItems2, columns: page[subSystem].fkAccountColumns2, listName: "fkAccount" },
            ]
            elements.searchItems = [...page[subSystem].fkCustomerFormItems2
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems]
            break;
        case 'fkTransaction':
            elements.columns = page[subSystem].transactionParentsColumns;
            elements.formItems = [{ name: "交易明细", items: page[subSystem].fkTransactionFormItems }];
            elements.formItems2 = [{ name: "交易明细", items: page[subSystem].fkTransactionFormItems }];
            elements.subTables = [];
            elements.searchItems = [...page[subSystem].fkTransactionFormItems
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems];
            break;
        case 'fkAccountAndTransaction':
            elements.columns = page[subSystem].customerParentsColumns;
            elements.formItems = [{ name: "客户信息", items: page[subSystem].fkCustomerFormItems }];
            elements.formItems2 = [{ name: "客户信息", items: page[subSystem].fkCustomerFormItems2 }];
            elements.subTables = [
                { name: "账户信息", items: page[subSystem].fkAccountFormItems, columns: page[subSystem].fkAccountColumns, listName: "fkAccount" },
                { name: "强制措施", items: page[subSystem].fkMeasureFormItems, columns: page[subSystem].fkMeasureColumns, listName: "fkMeasure" },
                { name: "共有权/优先权", items: page[subSystem].fkPriorityFormItems, columns: page[subSystem].fkPriorityColumns, listName: "fkPriority" },
                { name: "关联子账户", items: page[subSystem].fkSubAccountFormItems, columns: page[subSystem].fkSubAccountColumns, listName: "fkSubAccount" },
                { name: "交易明细", items: page[subSystem].fkTransactionFormItems, columns: page[subSystem].fkTransactionColumns, listName: "fkTransaction" },
            ];
            elements.subTables2 = [
                { name: "账户信息", items: page[subSystem].fkAccountFormItems2, columns: page[subSystem].fkAccountColumns2, listName: "fkAccount" },
                { name: "交易明细", items: page[subSystem].fkTransactionFormItems, columns: page[subSystem].fkTransactionColumns, listName: "fkTransaction" }
            ];
            elements.searchItems = [...page[subSystem].fkCustomerFormItems
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems];
            break;
        case 'fkDynamicReceipt':
            elements.columns = page[subSystem].zhParentsColumns;
            elements.formItems = [{ name: "动态查询执行回执", items: page[subSystem].fkDynamicReceiptFormItems }];
            elements.subTables = [];
            elements.searchItems = [...page[subSystem].fkDynamicReceiptFormItems
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems];
            break;
        case 'fkDynamic':
            elements.columns = page[subSystem].zhParentsColumns;
            elements.formItems = [{ name: "动态查询", items: page[subSystem].fkDynamicFormItems }];
            elements.subTables = [];
            elements.searchItems = [...page[subSystem].fkDynamicFormItems
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems];
            break;
        case 'fkFreeze':
            elements.columns = page[subSystem].zhParentsColumns;
            var fkFreezeFormItemList = page[subSystem].fkFreezeFormItems;
            // if ((subSystem == 'jcy') && djfs == '02') {
            //     fkFreezeFormItemList.forEach((item: any) => {
            //         if (item.label == '执行冻结金额' || item.label == '未冻结金额') {
            //             item.inputType.disabled = true;
            //         }
            //     });
            // } else {
            //     fkFreezeFormItemList.forEach((item: any) => {
            //         if (item.label == '执行冻结金额' || item.label == '未冻结金额') {
            //             item.inputType.disabled = false;
            //         }
            //     });
            // }
            elements.formItems = [{ name: "冻结/续冻/解冻", items: fkFreezeFormItemList}];
            elements.subTables = subSystem=='jcy'? [{
                name: "冻结/续冻/解冻明细",
                items: page[subSystem].fkFreezeDetailFormItems,
                columns: page[subSystem].fkFreezeDetailColumns,
                listName: "fkFreezeDetail"
            }] : [];
            elements.searchItems = [...page[subSystem].fkFreezeFormItems
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems];
            break;
        case 'fkPayment':
            elements.columns = page[subSystem].paymentParentsColumns;
            elements.formItems = [{ name: "紧急止付/解除止付", items: page[subSystem].fkPaymentFormItems }];
            elements.subTables = [];
            elements.searchItems = [...page[subSystem].fkPaymentFormItems
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems];
            break;
        case 'fkCertificateImage':
            elements.columns = page[subSystem].certificateImageParentsColumns;
            elements.formItems = [{ name: "调阅凭证图像", items: page[subSystem].fkCertificateFormItems }];
            elements.subTables = [];
            elements.searchItems =[... page[subSystem].fkCertificateFormItems
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems];
            break;
        case 'fkFinancialAccount':
            elements.columns = page[subSystem].financialParentsColumns;
            elements.formItems = [{ name: "金融理财账户信息", items: page[subSystem].fkFinancialFormItems}];
            elements.formItems2 = [{ name: "金融理财账户信息", items: page[subSystem].fkFinancialFormItems}];
            elements.subTables = [{
                name: "金融理财信息明细",
                items: page[subSystem].fkFinancialDetailFormItems,
                columns: page[subSystem].fkFinancialDetailColumns,
                listName: "fkFinancialDetail"
            }];
            elements.subTables2 = [{
                name: "金融理财信息明细",
                items: page[subSystem].fkFinancialDetailFormItems,
                columns: page[subSystem].fkFinancialDetailColumns,
                listName: "fkFinancialDetail"
            }];
            elements.searchItems = [...page[subSystem].fkFinancialFormItems
               .filter(item => item.label !== '业务操作机构'&&item.label !== '部门编码')
                .map(item => {
                return {
                    value: item.prop,
                    label: item.label,
                    inputType:item.inputType=='input'?'input': {
                        ...item.inputType,
                        disabled:false
                    },
                    labelWidth: item.labelWidth,
                };
            }),...publicAdvancedQueryItems];
            break;
    }
    return elements;
}
export const derivedPageParentsElements = (key: string) => {
    const parentsElements: PageParentsElements = { cxParentsFormItems: [], kzParentsFormItems: [] };
    switch (key) {
        case 'fkCustomer':
            parentsElements.cxParentsFormItems = cxParentsFormItems;
            break;
        case 'fkTransaction':
            parentsElements.cxParentsFormItems = cxParentsFormItems;
            break;
        case 'fkAccountAndTransaction':
            parentsElements.cxParentsFormItems = cxParentsFormItems;
            break;
        case 'fkDynamicReceipt':
            parentsElements.kzParentsFormItems = kzParentsFormItems;
            break;
        case 'fkDynamic':
            parentsElements.kzParentsFormItems = kzParentsFormItems;
            break;
        case 'fkFreeze':
            parentsElements.kzParentsFormItems = kzParentsFormItems;
            break;
        case 'fkPayment':
            parentsElements.kzParentsFormItems = kzParentsFormItems;
            break;
        case 'fkCertificateImage':
            parentsElements.cxParentsFormItems = cxParentsFormItems;
            break;
        case 'fkFinancialAccount':
            parentsElements.cxParentsFormItems = cxParentsFormItems;
            break;
    }
    return parentsElements;
}

export const cxParentsFormItems: FormItemInfo[] = [
    {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
        },

    },
    {
        prop: 'sqjgdm',
        label: '申请机构',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'sqjgdm',
        },
    },
    {
        prop: 'mbjgdm',
        label: '目标机构代码',
        labelWidth: 100,
        inputType: "input",
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
    },
]
export const kzParentsFormItems: FormItemInfo[] = [
    {
        prop: 'qqdbs',
        label: '请求单标识',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        labelWidth: 100,
        inputType: 'input',
    },
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'ckztlb',
        },

    },
    {
        prop: 'sqjgdm',
        label: '申请机构',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'sqjgdm',
        },
    },
    {
        prop: 'mbjgdm',
        label: '目标机构代码',
        labelWidth: 100,
        inputType: "input",
    },
    {
        prop: 'fldm',
        label: '分类代码',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'fldm',
            multiple: false,
        },
    },
    {
        prop: 'qqcslx',
        label: '措施类型',
        labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'qqcslx',
            multiple: false,
        },
    },
    {
        prop: 'yrwlsh',
        label: '原任务流水号',
        labelWidth: 100,
        inputType: "input",
    },
]
export const recordSearchFormItems: FormItemInfo[] = [
    {prop: 'qqdbs', label: '请求单标识', labelWidth: 80, inputType: 'input'},
    {prop: 'rwlsh', label: '任务流水号', labelWidth: 80, inputType: 'input'},
    {
        prop: 'branchCodeList',
        label: '业务操作机构',
        labelWidth: 80,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 50,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
    {
        prop: 'status',
        label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
        },
        labelWidth: 80
    },
    {
        prop: 'onlyQuerySucceeded',
        label: '匹配成功',
        labelWidth: 50,
        inputType: {tag:'checkbox'},
        // inputType: {tag:'checkbox',   checked:"checked"},
    }

]

const publicAdvancedQueryItems = [
    {value: 'fldm', label: '分类代码', width: 140, sortable: true, inputType: {tag: 'select', options: 'fldm',}},
    {value: 'rwlsh', label: '任务流水号', labelWidth: 80, inputType: 'input'},
    {value: 'department_code', label: '部门编码', labelWidth: 80, inputType: 'input'},
    // {
    //     value: 'status',
    //     label: '状态',
    //     inputType: {
    //         tag: 'select',
    //         options: 'dataStatus',
    //     },
    //     labelWidth: 80
    // },
    {value: 'deleteState', label: '删除状态', inputType: {tag: 'select', options: 'deleteStatusList'}, labelWidth: 100},
    {value: 'create_by', label: '创建人', labelWidth: 80, inputType: 'input'},
    {value: 'create_time', label: '数据日期', labelWidth: 80, inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD", valueFormat: 'YYYY-MM-DD'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]},
    {value: 'update_by', label: '修改人', labelWidth: 80, inputType: 'input'},
    {value: 'update_time', label: '修改时间', labelWidth: 80, inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]},
    {value: 'submit_by', label: '提交人', labelWidth: 80, inputType: 'input'},
    {value: 'submit_time', label: '提交时间', labelWidth: 80, inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]},
    {value: 'approve_by', label: '审核人', labelWidth: 80, inputType: 'input'},
    {value: 'approve_time', label: '审核时间', labelWidth: 80, inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ]},
]
export  const isExpPathArray=ref<any[]>([])
export  const isExpSubSystemArray=ref<any[]>([])
