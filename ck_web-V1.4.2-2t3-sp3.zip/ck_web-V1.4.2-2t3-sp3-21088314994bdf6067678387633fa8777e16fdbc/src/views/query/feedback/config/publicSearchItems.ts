import {FormItemInfo} from "riking-ui";

/**
 *  反馈页面 搜索栏项目
 */
//搜索栏所需的公共字段 下面引用
export const searchItems: FormItemInfo[] = [
    {
        prop: 'status',
        label: '状态',
        inputType: {
            tag: 'select',
            options: 'dataStatus',
        },
        labelWidth: 100
    },
    {
        prop: 'qqdbs',
        label: '请求单标识',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'rwlsh',
        label: '任务流水号',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'ckztlb',
        label: '查控主体类别',
        inputType: {
            tag: 'select',
            options: 'ckztlb',
        },
        labelWidth: 100
    },
    {
        prop: 'sqjgdm',
        label: '申请机构',
        inputType: {
            tag: 'select',
            options: 'sqjgdm',
        },
        labelWidth: 100
    },
    {
        prop: 'branchCode', label: '业务操作机构', labelWidth: 100,
        inputType: {
            tag: 'tree-select',
            options: 'branchCode',
            multiple: true,
            showCheckbox: true,
            checkStrictly: true,
        }
    },
    {
        prop: 'businessLine', label: '业务线', labelWidth: 100,
        inputType: {
            tag: 'select',
            options: 'businessLine',
        }
    },
];

// 账户信息页面  账户信息与交易明细页面
export const publicCustomerSearchItems: FormItemInfo[] = [
    {
        prop: 'khmc',
        label: '客户名称',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'zzhm',
        label: '证照号码',
        inputType: 'input',
        labelWidth: 100
    },
    // ...searchItems
];
// 交易明细页面
export const publicTransactionSearchItems: FormItemInfo[] = [
    {
        prop: 'cxzh',
        label: '账号',
        inputType: 'input',
        labelWidth: 100
    }, {
        prop: 'cxkh',
        label: '卡号',
        inputType: 'input',
        labelWidth: 100
    },
    // ...searchItems
];
//动态查询回执 动态查询 冻结页面
export const publicZhSearchItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        inputType: 'input',
        labelWidth: 100
    },
    {
        prop: 'kh',
        label: '卡号',
        inputType: 'input',
        labelWidth: 100
    },
    // ...searchItems
];
//止付页面
export const publicPaymentSearchItems: FormItemInfo[] = [
    {
        prop: 'zh',
        label: '账号',
        inputType: 'input',
        labelWidth: 100
    },
    // ...searchItems
];
//调阅凭证页面
export const publicCertificateImageSearchItems: FormItemInfo[] = [
    {
        prop: 'cxzh',
        label: '查询账号',
        inputType: 'input',
        labelWidth: 100
    },
    // ...searchItems
];
//金融理财页面
export const publicFinancialSearchItems: FormItemInfo[] = [
    {
        prop: 'cxkh',
        label: '查询卡号',
        inputType: 'input',
        labelWidth: 100
    },
    // ...searchItems
];