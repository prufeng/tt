/**
 * 中央军委 反馈页面 列字段与表单项配置
 */
import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {
    publicCertificateImageParentsColumns,
    publicCustomerParentsColumns,
    publicFinancialParentsColumns,
    publicFkAccountColumns, publicFkFinancialDetailColumns,
    publicFkFreezeDetailColumns,
    publicFkMeasureColumns,
    publicFkPaymentDetailColumns,
    publicFkPriorityColumns,
    publicFkSubAccountColumns,
    publicFkTransactionColumns,
    publicPaymentParentsColumns,
    publicTransactionParentsColumns,
    publicZhParentsColumns
} from "@/views/query/feedback/config/publicColumns";
import {
    publicCertificateImageSearchItems,
    publicCustomerSearchItems, publicFinancialSearchItems, publicPaymentSearchItems,
    publicTransactionSearchItems, publicZhSearchItems,
    searchItems
} from "@/views/query/feedback/config/publicSearchItems";
import {
    publicFkAccountFormItems, publicFkCertificateFormItems, publicFkCustomerFormItems, publicFkCustomerFormItems2,
    publicFkDynamicFormItems, publicFkDynamicReceiptFormItems,
    publicFkFinancialDetailFormItems,
    publicFkFinancialFormItems,
    publicFkFreezeDetailFormItems, publicFkFreezeFormItems,
    publicFkMeasureFormItems,
    publicFkPaymentDetailFormItems,
    publicFkPaymentFormItems,
    publicFkPriorityFormItems,
    publicFkSubAccountFormItems,
    publicFkTransactionFormItems, publicNsaFkCertificateFormItems
} from "@/views/query/feedback/config/publicForm";


/**
 * 中央军委 反馈页面 列字段
 */

/*
 * 中央军委 反馈页面 列字段  主表部分
 */

// 账户信息页面  账户信息与交易明细页面
export const customerParentsColumns: TableColumnInfo[] = [
    ...publicCustomerParentsColumns
];
// 交易明细页面
export const transactionParentsColumns: TableColumnInfo[] = [
    ...publicTransactionParentsColumns
];
//动态查询回执 动态查询 冻结页面
export const zhParentsColumns: TableColumnInfo[] = [
    ...publicZhParentsColumns
];
//止付页面
export const paymentParentsColumns: TableColumnInfo[] = [
    ...publicPaymentParentsColumns
];
//调阅凭证页面
export const certificateImageParentsColumns: TableColumnInfo[] = [
    ...publicCertificateImageParentsColumns.slice(0,1),
    { prop: 'cxzh', label: '查询账号', width: 170 ,sortable: true},
    ...publicCertificateImageParentsColumns.slice(1),
];
//金融理财页面
export const financialParentsColumns: TableColumnInfo[] = [
    ...publicFinancialParentsColumns
];

/*
 * 中央军委 反馈页面 列字段  子表部分
 */
//账户信息 子表
export const fkAccountColumns: TableColumnInfo[] = [
    ...publicFkAccountColumns
]
export const fkAccountColumns2: TableColumnInfo[] = [
    ...publicFkAccountColumns.slice(0,9),
    ...publicFkAccountColumns.slice(10),
]
//强制措施信息 子表
export const fkMeasureColumns: TableColumnInfo[] = [
    ...publicFkMeasureColumns
]
//共享权\优先权信息 子表
export const fkPriorityColumns: TableColumnInfo[] = [
    ...publicFkPriorityColumns
]
//关联子账户 子表
export const fkSubAccountColumns: TableColumnInfo[] = [
    ...publicFkSubAccountColumns
]
//交易明细 子表
export const fkTransactionColumns: TableColumnInfo[] = [
    ...publicFkTransactionColumns
]
//冻结明细 子表
export const fkFreezeDetailColumns: TableColumnInfo[] = [
    ...publicFkFreezeDetailColumns
]
//止付明细 子表
export const fkPaymentDetailColumns: TableColumnInfo[] = [
    ...publicFkPaymentDetailColumns
]
//金融理财明细 子表
export const fkFinancialDetailColumns: TableColumnInfo[] = [
    ...publicFkFinancialDetailColumns
]

/**
 * 中央军委 反馈页面 表单项
 */

/**反馈页面 Form配置 主表部分 */
// 账户信息页面  账户信息与交易明细页面
export const fkCustomerFormItems: FormItemInfo[] = [
    ...publicFkCustomerFormItems.slice(0,1),
    {
        prop: 'zzlxdm',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            disabled:true
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '证件类型必填' }]
    },
    ...publicFkCustomerFormItems.slice(1,15),
    {
        prop: 'zddz',
        label: '账单地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 100, message: '账单地址最大长度为100' }],
    },
    ...publicFkCustomerFormItems.slice(15),
    {
        prop: 'tyshxydm',
        label: '统一社会信用码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 18, message: '统一社会信用码最大长度为18' }],
    },
]
// 账户信息页面  账户信息与交易明细页面2
export const fkCustomerFormItems2: FormItemInfo[] = [
    ...publicFkCustomerFormItems2.slice(0,1),
    {
        prop: 'zzlxdm',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '证件类型必填' }]
    },
    ...publicFkCustomerFormItems2.slice(1,15),
    {
        prop: 'zddz',
        label: '账单地址',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 100, message: '账单地址最大长度为100' }],
    },
    ...publicFkCustomerFormItems2.slice(15),
    {
        prop: 'tyshxydm',
        label: '统一社会信用码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 18, message: '统一社会信用码最大长度为18' }],
    },
]
// 交易明细页面
export const fkTransactionFormItems: FormItemInfo[] = [
    ...publicFkTransactionFormItems.slice(0,11),
    {
        prop: 'jydfzh',
        label: '交易对方账号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 50, message: '交易对方账号最大长度为50' }],
    },
    {
        prop: 'jydfkh',
        label: '交易对方卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 50, message: '交易对方卡号最大长度为50' }],
    },
    {
        prop: 'jyfmc',
        label: '交易方_名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '交易方_名称必填' },{ max: 100, message: '交易方_名称最大长度为100' }],
    },
    {
        prop: 'jyfzjhm',
        label: '交易方_证件号码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '交易方_证件号码必填' },{ max: 30, message: '交易方_证件号码最大长度为30' }],
    },
    {
        prop: 'jyfzjlxdm',
        label: '交易方_证件类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '交易方_证件类型必填' },{ max: 10, message: '交易方_证件类型代码最大长度为10' }],
    },
    ...publicFkTransactionFormItems.slice(11)
]
//动态查询执行回执
export const fkDynamicReceiptFormItems: FormItemInfo[] = [
    ...publicFkDynamicReceiptFormItems
]
//动态查询
export const fkDynamicFormItems: FormItemInfo[] = [
    ...publicFkDynamicFormItems
]
//冻结解冻续冻
export const fkFreezeFormItems: FormItemInfo[] = [
    ...publicFkFreezeFormItems
]
//紧急止付\解除止付
export const fkPaymentFormItems: FormItemInfo[] = [
    ...publicFkPaymentFormItems
]
//调阅凭证图像
export const fkCertificateFormItems: FormItemInfo[] = [
    ...publicFkCertificateFormItems.slice(0,6),
    {
        prop: 'pztxlx',
        label: '凭证图像类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'pztxlx',
            disabled: false
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '凭证图像类型必填' }, { max: 6, message: '凭证图像类型最大长度为6' }],
    },
    ...publicFkCertificateFormItems.slice(7),
]
//金融理财
export const fkFinancialFormItems: FormItemInfo[] = [
    ...publicFkFinancialFormItems.slice(0,5),
    {
        prop: 'zhmc',
        label: '账户名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 60, message: '账户名称最大长度为60'}],
    },
    {
        prop: 'sfqywy',
        label: '是否签约网银',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 1, message: '是否签约网银最大长度为1'}],
    },
    {
        prop: 'sfqysjyh',
        label: '是否签约手机银行',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 1, message: '是否签约手机银行最大长度为1'}],
    },
    ...publicFkFinancialFormItems.slice(5)
]


/**反馈页面 Form配置 子表部分 */
//账户信息 子表
export const fkAccountFormItems: FormItemInfo[] = [
    ...publicFkAccountFormItems.slice(0,1),
    {
        prop: 'zhmc',
        label: '账户名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 60, message: '账户名称最大长度为60'}],
    },
    {
        prop: 'sfqywy',
        label: '是否签约网银',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 1, message: '是否签约网银最大长度为1'}],
    },
    {
        prop: 'sfqysjyh',
        label: '是否签约手机银行',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 1, message: '是否签约手机银行最大长度为1'}],
    },
    {
        prop: 'zhdlip',
        label: '最后登录IP',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 30, message: '最后登录IP最大长度为30' }],
    },
    {
        prop: 'zhdlsj',
        label: '最后登录时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    ...publicFkAccountFormItems.slice(1),
]
export const fkAccountFormItems2: FormItemInfo[] = [
    ...publicFkAccountFormItems.slice(0,1),
    {
        prop: 'zhmc',
        label: '账户名称',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 60, message: '账户名称最大长度为60'}],
    },
    {
        prop: 'sfqywy',
        label: '是否签约网银',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 1, message: '是否签约网银最大长度为1'}],
    },
    {
        prop: 'sfqysjyh',
        label: '是否签约手机银行',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 1, message: '是否签约手机银行最大长度为1'}],
    },
    {
        prop: 'zhdlip',
        label: '最后登录IP',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 30, message: '最后登录IP最大长度为30' }],
    },
    {
        prop: 'zhdlsj',
        label: '最后登录时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    ...publicFkAccountFormItems.slice(1,14),
    ...publicFkAccountFormItems.slice(15),
]
//强制措施信息 子表
export const fkMeasureFormItems: FormItemInfo[] = [
    ...publicFkMeasureFormItems
]
//共享权\优先权信息 子表
export const fkPriorityFormItems: FormItemInfo[] = [
    ...publicFkPriorityFormItems
]
//关联子账户 子表
export const fkSubAccountFormItems: FormItemInfo[] = [
    ...publicFkSubAccountFormItems
]
//交易明细 子表
//交易明细 子表和主表共用一个表单项


//冻结明细 子表
export const fkFreezeDetailFormItems: FormItemInfo[] = [
    ...publicFkFreezeDetailFormItems
]
//止付明细 子表
export const fkPaymentDetailFormItems: FormItemInfo[] = [
    ...publicFkPaymentDetailFormItems
]
//金融理财明细 子表
export const fkFinancialDetailFormItems: FormItemInfo[] = [
    ...publicFkFinancialDetailFormItems
]





/**
 * 中央军委 反馈页面 条件查询搜索框
 */

// 账户信息页面  账户信息与交易明细页面
export const customerSearchItems: FormItemInfo[] = [
    ...publicCustomerSearchItems
];
// 交易明细页面
export const transactionSearchItems: FormItemInfo[] = [
    ...publicTransactionSearchItems
];
//动态查询回执 动态查询 冻结页面
export const zhSearchItems: FormItemInfo[] = [
    ...publicZhSearchItems
];
//止付页面
export const paymentSearchItems: FormItemInfo[] = [
    ...publicPaymentSearchItems
];
//调阅凭证页面
export const certificateImageSearchItems: FormItemInfo[] = [
    ...publicCertificateImageSearchItems
];
//金融理财页面
export const financialSearchItems: FormItemInfo[] = [
    ...publicFinancialSearchItems
];