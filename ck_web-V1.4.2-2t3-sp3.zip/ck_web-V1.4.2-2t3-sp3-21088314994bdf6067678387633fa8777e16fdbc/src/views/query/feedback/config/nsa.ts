/**
 * 国安 反馈页面 列字段与表单项配置
 */
import {FormItemInfo, TableColumnInfo} from "riking-ui";
import {
    publicCertificateImageParentsColumns,
    publicCustomerParentsColumns,
    publicFinancialParentsColumns,
    publicFkAccountColumns, publicFkFinancialDetailColumns,
    publicFkFreezeDetailColumns,
    publicFkMeasureColumns,
    publicFkPaymentDetailColumns,
    publicFkPriorityColumns,
    publicFkSubAccountColumns,
    publicFkTransactionColumns,
    publicPaymentParentsColumns,
    publicTransactionParentsColumns,
    publicZhParentsColumns
} from "@/views/query/feedback/config/publicColumns";
import {
    publicCertificateImageSearchItems,
    publicCustomerSearchItems, publicFinancialSearchItems, publicPaymentSearchItems,
    publicTransactionSearchItems, publicZhSearchItems,
    searchItems
} from "@/views/query/feedback/config/publicSearchItems";
import {
    publicFkAccountFormItems, publicFkCertificateFormItems, publicFkCustomerFormItems, publicFkCustomerFormItems2,
    publicFkDynamicFormItems, publicFkDynamicReceiptFormItems,
    publicFkFinancialDetailFormItems,
    publicFkFinancialFormItems,
    publicFkFreezeDetailFormItems, publicFkFreezeFormItems,
    publicFkMeasureFormItems,
    publicFkPaymentDetailFormItems,
    publicFkPaymentFormItems,
    publicFkPriorityFormItems,
    publicFkSubAccountFormItems,
    publicFkTransactionFormItems, publicNsaFkCertificateFormItems
} from "@/views/query/feedback/config/publicForm";


/**
 * 国安 反馈页面 列字段
 */

/*
 * 国安 反馈页面 列字段  主表部分
 */

// 账户信息页面  账户信息与交易明细页面
export const customerParentsColumns: TableColumnInfo[] = [
    ...publicCustomerParentsColumns
];
// 交易明细页面
export const transactionParentsColumns: TableColumnInfo[] = [
    ...publicTransactionParentsColumns
];
//动态查询回执 动态查询 冻结页面
export const zhParentsColumns: TableColumnInfo[] = [
    ...publicZhParentsColumns
];
//止付页面
export const paymentParentsColumns: TableColumnInfo[] = [
    ...publicPaymentParentsColumns
];
//调阅凭证页面
export const certificateImageParentsColumns: TableColumnInfo[] = [
    ...publicCertificateImageParentsColumns.slice(0, 1),
    {prop: 'zh', label: '查询账号', width: 170, sortable: true},
    ...publicCertificateImageParentsColumns.slice(1)
];
//金融理财页面
export const financialParentsColumns: TableColumnInfo[] = [
    ...publicFinancialParentsColumns
];

/*
 * 国安 反馈页面 列字段  子表部分
 */
//账户信息 子表
export const fkAccountColumns: TableColumnInfo[] = [
    ...publicFkAccountColumns
]
export const fkAccountColumns2: TableColumnInfo[] = [
    ...publicFkAccountColumns.slice(0,9),
    ...publicFkAccountColumns.slice(10),
]
//强制措施信息 子表
export const fkMeasureColumns: TableColumnInfo[] = [
    ...publicFkMeasureColumns
]
//共享权\优先权信息 子表
export const fkPriorityColumns: TableColumnInfo[] = [
    ...publicFkPriorityColumns
]
//关联子账户 子表
export const fkSubAccountColumns: TableColumnInfo[] = [
    ...publicFkSubAccountColumns
]
//交易明细 子表
export const fkTransactionColumns: TableColumnInfo[] = [
    ...publicFkTransactionColumns
]
//冻结明细 子表
export const fkFreezeDetailColumns: TableColumnInfo[] = [
    ...publicFkFreezeDetailColumns
]
//止付明细 子表
export const fkPaymentDetailColumns: TableColumnInfo[] = [
    ...publicFkPaymentDetailColumns
]
//金融理财明细 子表
export const fkFinancialDetailColumns: TableColumnInfo[] = [
    ...publicFkFinancialDetailColumns
]

/**
 * 国安 反馈页面 表单项
 */

/**反馈页面 Form配置 主表部分 */
// 账户信息页面  账户信息与交易明细页面
export const fkCustomerFormItems: FormItemInfo[] = [
    ...publicFkCustomerFormItems.slice(0,1),
    {
        prop: 'zzlx',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
            disabled:true
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '证件类型必填' }]
    },
    ...publicFkCustomerFormItems.slice(1),
    {
        prop: 'dbrlxdh',
        label: '代办人联系电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 30, message: '代办人联系电话最大长度为30' }]
    },
    {
        prop: 'wyzhm',
        label: '网银账户名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 200, message: '网银账户名最大长度为200' }]
    },
    {
        prop: 'wyblrq',
        label: '网银办理日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'wykhwd',
        label: '网银开户网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 100, message: '网银开户网点最大长度为100' }]
    },
    {
        prop: 'wykhwddm',
        label: '网银开户网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 20, message: '网银开户网点代码最大长度为20' }]
    },
    {
        prop: 'wykhwdszd',
        label: '网银开户网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 300, message: '网银开户网点所在地最大长度为300' }]
    },
    {
        prop: 'sjyhzhm',
        label: '手机银行账户名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 200, message: '手机银行账户名最大长度为200' }]
    },
    {
        prop: 'sjyhblrq',
        label: '手机银行办理日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'sjyhkhwd',
        label: '手机银行开户网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 100, message: '手机银行开户网点最大长度为100' }]
    },
    {
        prop: 'sjyhkhwddm',
        label: '手机银行开户网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 20, message: '手机银行开户网点代码最大长度为20' }]
    },
    {
        prop: 'sjyhkhwdszd',
        label: '手机银行开户网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 300, message: '手机银行开户网点所在地最大长度为300' }]
    },
]
// 账户信息页面  账户信息与交易明细页面2
export const fkCustomerFormItems2: FormItemInfo[] = [
    ...publicFkCustomerFormItems2.slice(0,1),
    {
        prop: 'zzlx',
        label: '证照类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'license',
        },
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ required: true, message: '证件类型必填' }]
    },
    ...publicFkCustomerFormItems2.slice(1),
    {
        prop: 'dbrlxdh',
        label: '代办人联系电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 30, message: '代办人联系电话最大长度为30' }]
    },
    {
        prop: 'wyzhm',
        label: '网银账户名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 200, message: '网银账户名最大长度为200' }]
    },
    {
        prop: 'wyblrq',
        label: '网银办理日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'wykhwd',
        label: '网银开户网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 100, message: '网银开户网点最大长度为100' }]
    },
    {
        prop: 'wykhwddm',
        label: '网银开户网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 20, message: '网银开户网点代码最大长度为20' }]
    },
    {
        prop: 'wykhwdszd',
        label: '网银开户网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 300, message: '网银开户网点所在地最大长度为300' }]
    },
    {
        prop: 'sjyhzhm',
        label: '手机银行账户名',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 200, message: '手机银行账户名最大长度为200' }]
    },
    {
        prop: 'sjyhblrq',
        label: '手机银行办理日期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'sjyhkhwd',
        label: '手机银行开户网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 100, message: '手机银行开户网点最大长度为100' }]
    },
    {
        prop: 'sjyhkhwddm',
        label: '手机银行开户网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 20, message: '手机银行开户网点代码最大长度为20' }]
    },
    {
        prop: 'sjyhkhwdszd',
        label: '手机银行开户网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 300, message: '手机银行开户网点所在地最大长度为300' }]
    },
]
// 交易明细页面
export const fkTransactionFormItems: FormItemInfo[] = [
    ...publicFkTransactionFormItems.slice(0,11),
    {
        prop: 'jydfzh',
        label: '交易对方账号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 50, message: '交易对方账号最大长度为50' }],
    },
    {
        prop: 'jydfkh',
        label: '交易对方卡号',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{ max: 50, message: '交易对方卡号最大长度为50' }],
    },
    ...publicFkTransactionFormItems.slice(11)
]
//动态查询执行回执
export const fkDynamicReceiptFormItems: FormItemInfo[] = [
    ...publicFkDynamicReceiptFormItems
]
//动态查询
export const fkDynamicFormItems: FormItemInfo[] = [
    ...publicFkDynamicFormItems
]
//冻结解冻续冻
export const fkFreezeFormItems: FormItemInfo[] = [
    ...publicFkFreezeFormItems
]
//紧急止付\解除止付
export const fkPaymentFormItems: FormItemInfo[] = [
    ...publicFkPaymentFormItems
]
//调阅凭证图像
export const fkCertificateFormItems: FormItemInfo[] = [
    ...publicNsaFkCertificateFormItems
]
//金融理财
export const fkFinancialFormItems: FormItemInfo[] = [
    ...publicFkFinancialFormItems
]


/**反馈页面 Form配置 子表部分 */
//账户信息 子表
export const fkAccountFormItems: FormItemInfo[] = [
    ...publicFkAccountFormItems,
    {
        prop: 'khwdszd',
        label: '开户网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 300, message: '开户网点所在地最大长度为300'}],
    },
    {
        prop: 'xhwddm',
        label: '销户网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '销户网点代码最大长度为20'}],
    },
    {
        prop: 'xhwdszd',
        label: '销户网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 300, message: '销户网点所在地最大长度为300'}],
    },
    {
        prop: 'yxq',
        label: '有效期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        // rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 8, message: '有效期最大长度为8'}],
    },
    {
        prop: 'dwdh',
        label: '银行卡签约电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '银行卡签约电话最大长度为20'}],
    },
    {
        prop: 'syblrq',
        label: '银行卡签约时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'qywd',
        label: '银行卡签约网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 100, message: '银行卡签约网点最大长度为100'}],
    },
    {
        prop: 'syzzrq',
        label: '银行卡终止签约时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'zhdj',
        label: '账号等级',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '账号等级最大长度为20'}],
    },
    {
        prop: 'zhlx',
        label: '账号类型',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '账号类型最大长度为20'}],
    },
    {
        prop: 'zcwblx',
        label: '支持外币类型',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 200, message: '支持外币类型最大长度为200'}],
    },
    {
        prop: 'bksj',
        label: '补卡时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'bkwd',
        label: '补卡网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 100, message: '补卡网点最大长度为100'}],
    },
    {
        prop: 'bkwddm',
        label: '补卡网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '补卡网点代码最大长度为20'}],
    },
    {
        prop: 'bkwdszd',
        label: '补卡网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 300, message: '补卡网点所在地最大长度为300'}],
    },
]
export const fkAccountFormItems2: FormItemInfo[] = [
    ...publicFkAccountFormItems.slice(0,14),
    ...publicFkAccountFormItems.slice(15),
    {
        prop: 'khwdszd',
        label: '开户网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 300, message: '开户网点所在地最大长度为300'}],
    },
    {
        prop: 'xhwddm',
        label: '销户网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '销户网点代码最大长度为20'}],
    },
    {
        prop: 'xhwdszd',
        label: '销户网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 300, message: '销户网点所在地最大长度为300'}],
    },
    {
        prop: 'yxq',
        label: '有效期',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
        // rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 8, message: '有效期最大长度为8'}],
    },
    {
        prop: 'dwdh',
        label: '银行卡签约电话',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '银行卡签约电话最大长度为20'}],
    },
    {
        prop: 'syblrq',
        label: '银行卡签约时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'qywd',
        label: '银行卡签约网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 100, message: '银行卡签约网点最大长度为100'}],
    },
    {
        prop: 'syzzrq',
        label: '银行卡终止签约时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'zhdj',
        label: '账号等级',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '账号等级最大长度为20'}],
    },
    {
        prop: 'zhlx',
        label: '账号类型',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '账号类型最大长度为20'}],
    },
    {
        prop: 'zcwblx',
        label: '支持外币类型',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 200, message: '支持外币类型最大长度为200'}],
    },
    {
        prop: 'bksj',
        label: '补卡时间',
        labelWidth: 150,
        inputType: {tag: 'date-input', type: 'datetime', format: "YYYY-MM-DD HH:mm:ss", valueFormat: 'YYYY-MM-DD HH:mm:ss'},
        rules: [
            {pattern: '^((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29))\\s+([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$', message: '格式应为年-月-日 时:分:秒'},
        ],
    },
    {
        prop: 'bkwd',
        label: '补卡网点',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 100, message: '补卡网点最大长度为100'}],
    },
    {
        prop: 'bkwddm',
        label: '补卡网点代码',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 20, message: '补卡网点代码最大长度为20'}],
    },
    {
        prop: 'bkwdszd',
        label: '补卡网点所在地',
        labelWidth: 150,
        inputType: 'input',
        rules: [{pattern:'^[^<>&]*$',message: '存在特殊字符'},{max: 300, message: '补卡网点所在地最大长度为300'}],
    },
]
//强制措施信息 子表
export const fkMeasureFormItems: FormItemInfo[] = [
    ...publicFkMeasureFormItems
]
//共享权\优先权信息 子表
export const fkPriorityFormItems: FormItemInfo[] = [
    ...publicFkPriorityFormItems
]
//关联子账户 子表
export const fkSubAccountFormItems: FormItemInfo[] = [
    ...publicFkSubAccountFormItems
]
//交易明细 子表
//交易明细 子表和主表共用一个表单项


//冻结明细 子表
export const fkFreezeDetailFormItems: FormItemInfo[] = [
    ...publicFkFreezeDetailFormItems
]
//止付明细 子表
export const fkPaymentDetailFormItems: FormItemInfo[] = [
    ...publicFkPaymentDetailFormItems
]
//金融理财明细 子表
export const fkFinancialDetailFormItems: FormItemInfo[] = [
    ...publicFkFinancialDetailFormItems
]





/**
 * 国安 反馈页面 条件查询搜索框
 */

// 账户信息页面  账户信息与交易明细页面
export const customerSearchItems: FormItemInfo[] = [
    ...publicCustomerSearchItems
];
// 交易明细页面
export const transactionSearchItems: FormItemInfo[] = [
    ...publicTransactionSearchItems
];
//动态查询回执 动态查询 冻结页面
export const zhSearchItems: FormItemInfo[] = [
    ...publicZhSearchItems
];
//止付页面
export const paymentSearchItems: FormItemInfo[] = [
    ...publicPaymentSearchItems
];
//调阅凭证页面
export const certificateImageSearchItems: FormItemInfo[] = [
    ...publicCertificateImageSearchItems
];
//凭证图像选择类型
export const certificateImageSelectItems: FormItemInfo[] = [
    {
        prop: 'imageType',
        label: '图像类型',
        labelWidth: 150,
        inputType: {
            tag: 'select',
            options: 'imageType',
        },
        rules: [{ required: true, message: '图像类型必填' }]
    },
];
//金融理财页面
export const financialSearchItems: FormItemInfo[] = [
    ...publicFinancialSearchItems
];