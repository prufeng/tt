import { FormItemInfo } from "riking-ui";

export const searchFormItems: FormItemInfo[] = [
    {
        prop: 'createTime', label: '查控日期', labelWidth: 50,
        inputType: { tag: 'date-picker', type: 'daterange', rangeSeparator: "-" },
    },
    {
      prop: 'createTime', label: '机构', labelWidth: 50,
      inputType: {
        tag: 'select',
        options: 'ckztlb',
        multiple: true,
    },
  },
]