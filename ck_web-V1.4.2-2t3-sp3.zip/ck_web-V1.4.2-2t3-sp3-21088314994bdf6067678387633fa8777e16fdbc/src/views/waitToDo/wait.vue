<template>
  <div class="app-container">
    <rk-search-form
      ref="searchFormRef"
      v-model="searchForm"
      @keyup.enter="search"
      :form-items="getQueryFormItems()"
      @search="search"
      :label-width="50"
    />
    <!--    <rk-dynamic-search-form v-model="searchForm" :form-items="searchFormItems" :fields="[]"-->
    <!--                            @search="search"></rk-dynamic-search-form>-->

    <template v-if="!showJytFormItems()">
      <el-row :gutter="50" style="margin: 0 0; row-gap: 100px; color: #ffffff">
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 16px; padding-left: 0px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">待补录</p>
              <p class="card-content">{{ waitSupplyNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./请求单.png" alt="请求单图片" />
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 8px; padding-left: 0px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">待提交</p>
              <p class="card-content">{{ waitSubmitNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./已提交.png" alt="已提交" />
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 8px; padding-left: 8px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">待审核</p>
              <p class="card-content">{{ waitAuditNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./待审核.png" alt="待审核" />
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 8px; padding-left: 8px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">已审核</p>
              <p class="card-content">{{ auditNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./已审核.png" alt="已审核" />
            </div>
          </div>
        </el-col>
        <el-col
          :xs="24"
          :sm="12"
          :md="8"
          :lg="4"
          style="padding-right: 0px; padding-left: 8px"
          v-if="getSubSystem() != 'taf'"
        >
          <div class="card">
            <div class="text-content">
              <p class="card-title">已生成</p>
              <p class="card-content">{{ createNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./已生成.png" alt="已生成" />
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 0; padding-left: 16px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">已上报</p>
              <p class="card-content">{{ uploadNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./已上报.png" alt="已上报" />
            </div>
          </div>
        </el-col>
      </el-row>
    </template>

    <template v-if="showJytFormItems()">
      <el-row :gutter="50" style="margin: 0 0; row-gap: 100px; color: #ffffff; justify-content: center">
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 16px; padding-left: 0px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">待匹配</p>
              <p class="card-content">{{ waitQueryNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./请求单.png" alt="请求单图片" />
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 8px; padding-left: 0px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">未匹配到</p>
              <p class="card-content">{{ notMatchedNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./已提交.png" alt="已提交" />
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 8px; padding-left: 8px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">待处理</p>
              <p class="card-content">{{ pendingNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./待审核.png" alt="待审核" />
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="4" style="padding-right: 8px; padding-left: 8px">
          <div class="card">
            <div class="text-content">
              <p class="card-title">已处理</p>
              <p class="card-content">{{ processedNum }}</p>
            </div>
            <div class="image-content">
              <img class="card-image" src="./已审核.png" alt="已审核" />
            </div>
          </div>
        </el-col>
      </el-row>
    </template>

    <div style="display: flex; align-items: center">
      <img class="card-image2" src="./待办明细.png" alt="待办明细" />
      <el-text size="large" class="divider-title">待办明细</el-text>
      <el-divider class="divider" />
    </div>

    <rk-page-table :data="data" :columns="getTableItems()" :loading="loading" @refresh="search" hidden-table-tools>
      <template v-for="item in getScopedSlotsArr()" #[item.scopedSlots]="{ row }" :key="item[prop]">
        <!--        <el-text @onclick="goModule(row)" :class="{no_zero: row[item.prop] > 0}">{{row[item.prop]}}</el-text>-->
        <a
          href="javascript:;"
          :onclick="() => goModule(row, item.status)"
          :class="{ no_zero: row[item.prop] > 0 }"
          style="text-decoration: none"
          >{{ row[item.prop] }}</a
        >
      </template>
      <template #actions="{ row }">
        <rk-button-group :buttons="getDetailButtons(row)" :route-meta="['view']" link />
      </template>
    </rk-page-table>

    <!--冻结到期提醒-->
    <template v-if="showControlNotification()">
      <div style="display: flex; align-items: center">
        <img class="card-image2" src="./待办明细.png" alt="冻结到期提醒" />
        <el-text size="large" class="divider-title">冻结到期提醒</el-text>
        <el-divider class="divider" />
      </div>

      <rk-page-table
        :data="maturityData"
        :columns="subSystem == 'taf' ? maturityColumns : subSystem == 'zgfy' ? maturityColumns_zgfy : maturityColumns_5"
        :loading="loading"
        @refresh="search"
        hidden-table-tools
      >
        <!--<template v-for="item in scopedSlotsArr" #[item.scopedSlots]="{ row }" :key="item[prop]" >-->
        <!--  &lt;!&ndash;<el-text :class="{no_zero: row[item.prop] > 0}">{{row[item.prop]}}</el-text>&ndash;&gt;-->
        <!--</template>-->
      </rk-page-table>
    </template>

    <CjReminder ref="cjReminderRef" v-if="showCJReminder" :query="query"/>
  </div>
</template>

<script lang="ts">
import useDictsStore from '@/store/dictStore'

const dictsStore = useDictsStore()
const dictData = await dictsStore.getDict
</script>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage, ElDivider, ElRow, ElCol, ElText } from 'element-plus'
import { RkPageTable, RkButtonGroup, RkSearchForm, ButtonInfo, RkFormInstance } from 'riking-ui'
import { useDict } from 'riking-layout'
import {
  statisticTotal,
  statisticDetail,
  maturity,
  statisticDetailTaf,
  statisticTotalTaf,
  maturityTaf, statisticZgfy,
} from '@/views/waitToDo/api'
import { getSubSystem } from '@/utils/subSystem'
import moment from 'moment'
import useChangeTab from '@/hooks/useChangeTab'
import { listBusinessLine } from '@/views/query/feedback/api'
import useRouteParamsStore from '@/store/routeParamsStore'
import CjReminder from "@/views/waitToDo/CjReminder.vue";

interface ISearch {
  searchTime: [] | any
  branchCode: []
  businessLine: string
  subSystem: string | undefined
}

const subSystem = getSubSystem()

const defaultDateRangeValue = [moment().add(-9, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')] // 默认日期范围
const defaultDateRangeValueByZhangHua = [
  moment().add(-9999, 'days').format('YYYY-MM-DD'),
  moment().format('YYYY-MM-DD'),
]
const defaultSystemValue = getSubSystem() === 'ybjh' ? undefined : getSubSystem() // 默认选择系统

async function getBusinessLine() {
  try {
    const res = await listBusinessLine()
    const data1 = res.data
    console.log('执行获取业务线')
    if (data1.length === 0) {
      if (getSubSystem() !== 'ybjh' && getSubSystem() !== 'jyt' && getSubSystem() !== 'yjm') {
        ElMessage({
          message: '用户未配置业务线,无法查询数据',
          grouping: true,
          type: 'error',
        })
      }
      searchForm.value.businessLine = ''
    } else {
      searchForm.value.businessLine = data1[0].value
    }
  } catch (error) {
    console.error('Error fetching business line:', error)
  } finally {
    search()
  }
}

let searchForm = ref<ISearch>({
  searchTime: defaultDateRangeValue,
  branchCode: [],
  subSystem: defaultSystemValue,
  businessLine: '',
})

const searchFormRef = ref<RkFormInstance>()

const subModuleName = ref('') // 新增请求单
// const newAddNum = ref(0)     // 新增请求单
const waitSupplyNum = ref(0) // 待补录
const waitSubmitNum = ref(0) // 待提交
const waitAuditNum = ref(0) // 待审核
const auditNum = ref(0) // 已审核
const createNum = ref(0) // 已生成
const uploadNum = ref(0) // 以上报

const waitQueryNum = ref(0) // 待匹配
const notMatchedNum = ref(0) // 未匹配到
const pendingNum = ref(0) // 待处理
const processedNum = ref(0) // 已处理

const data = ref<any[]>([])
const maturityData = ref<any[]>([])
const loading = ref(false) // 加载状态

const showCJReminder = ref(false)
const cjReminderRef = ref()

const { show, handleTabClick, setwaremake } = useChangeTab()

useDict([], [], {
  ...dictData,
  branchCode: async () => {
    const res = await dictsStore.loadDict()
    return res.data.branchCode
  },
  businessLine: async () => {
    const res = await listBusinessLine()
    return res.data
  },
}) // 往页面加载数据集

onMounted(() => {
  getBusinessLine()
})

const search = async () => {
  const value = searchForm.value
  /*if (Object.keys(value).length === 0) {
    ElMessage.error("请选择日期条件！");
    return;
  }*/

  const params: any = {}
  params.businessLine = value.businessLine
  params.branchCodeList = value.branchCode

  const searchTime = value.searchTime
  if (searchTime) {
    params.start = searchTime[0]
    params.end = searchTime[1]
  }
  if (value?.subSystem != 'ybjh' && value?.subSystem) {
    // 下拉框选择
    params.subSystem = value?.subSystem
  }

  if ('ybjh' === getSubSystem()) {
    params.page = 'ybjh'
  }

  if ('ybjh' != getSubSystem()) {
    let maturities
    let postponement
    if ('taf' === getSubSystem()) {
      maturities = await maturityTaf(params)
    } else {
      maturities = await maturity(params)
    }
    maturityData.value = maturities.data
  }

  loading.value = true

  let totalData
  let detailData
  let zgfyData;

  // taf系统的代办首页数据从单独的接口访问
  if (params.page != 'ybjh' && params.subSystem === 'taf') {
    totalData = await statisticTotalTaf(params)
    detailData = await statisticDetailTaf(params)
  } else if (params.page != 'ybjh' && params.subSystem === 'zgfy') {
    zgfyData = await statisticZgfy(params);
    totalData = {data: zgfyData.data.total};
    detailData = {data: zgfyData.data.detail};
  } else {
    totalData = await statisticTotal(params)
    detailData = await statisticDetail(params)
  }

  loading.value = false
  data.value = detailData.data
  if (totalData?.data) {
    // newAddNum.value = totalData.data?.newAddNum;
    waitSupplyNum.value = totalData.data?.waitSupplyNum
    waitSubmitNum.value = totalData.data.waitSubmitNum
    waitAuditNum.value = totalData.data.waitAuditNum
    auditNum.value = totalData.data.auditNum
    createNum.value = totalData.data.createNum
    uploadNum.value = totalData.data.uploadNum

    waitQueryNum.value = totalData.data.waitQueryNum
    notMatchedNum.value = totalData.data.notMatchedNum
    pendingNum.value = totalData.data.pendingNum
    processedNum.value = totalData.data.processedNum
  }

  // 惩戒到期提醒
  await cjSearch(params)
}

const cjSearch = (params) => {
  if (dictData.showCJReminder == undefined) {
    return;
  }
  showCJReminder.value = true;
  nextTick(() => {
    cjReminderRef.value.search(params);
  })
}

const router = useRouter()

/**
 * 反馈状态：五和一4-已生成，5-已上报； taf 4-上报成功
 * 列的配置中的status是按五合一的配置的，如果是taf系统，需要把5转成4
 */
const goModule = (row, status) => {
  if ('taf' == defaultSystemValue && status == '5') {
    status = '4'
  }

  let url = ''
  if (defaultSystemValue) {
    if (row?.['routeUrl'] && row?.['superRouteUrl']) {
      url = row?.['superRouteUrl'] + row?.['routeUrl']
      const routeParamsStore = useRouteParamsStore()
      routeParamsStore.setParams({ status, ...toRaw(searchForm.value) })
      router.push(url)
    } else {
      ElMessage.warning('缺少路径的数据')
    }
  }
}

const getDetailButtons: (row: Record<string, any>) => ButtonInfo[] = (row: any) => [
  {
    key: 'view',
    label: '查看明细',
    tag: 'button',
    type: 'primary',
    handler: async () => {
      // ElMessage.success('show detail')
      if (defaultSystemValue) {
        if (row?.['routeUrl'] && row?.['superRouteUrl']) {
          const routeParamsStore = useRouteParamsStore()
          routeParamsStore.setParams({ ...toRaw(searchForm.value) })
          router.push(row?.['superRouteUrl'] + row?.['routeUrl'])
        } else {
          ElMessage.warning('缺少路径的数据')
        }
      } else {
        if (row?.['subSystem'] && row?.['subSystemName']) {
          handleTabClick({ value: row['subSystem'], label: row['subSystemName'] }, true)
          // await nextTick()
          // document.querySelector('#subSystemList .active')?.click?.()
        } else {
          ElMessage.warning('缺少系统的数据')
        }
      }
    },
  },
]

const scopedSlotsArr = [
  { prop: 'waitSupplyNum', scopedSlots: 'waitSupplyNum', status: '0' },
  { prop: 'waitSubmitNum', scopedSlots: 'waitSubmitNum', status: '1' },
  { prop: 'waitAuditNum', scopedSlots: 'waitAuditNum', status: '2' },
  { prop: 'auditNum', scopedSlots: 'auditNum', status: '3' },
  { prop: 'createNum', scopedSlots: 'createNum', status: '4' },
  { prop: 'uploadNum', scopedSlots: 'uploadNum', status: '5' },
  { prop: 'subModuleName', scopedSlots: 'subModuleName' },
]

let columns = [
  { prop: 'subModuleName', label: '子模块', labelWidth: 150, sortable: true },
  // {prop: 'newAddNum', label: '新增请求单', labelWidth: 150, sortable: true, scopedSlots: "newAddNum"},
  { prop: 'waitSupplyNum', label: '待补录', labelWidth: 150, sortable: true, scopedSlots: 'waitSupplyNum' },
  { prop: 'waitSubmitNum', label: '待提交', labelWidth: 150, sortable: true, scopedSlots: 'waitSubmitNum' },
  { prop: 'waitAuditNum', label: '待审核', labelWidth: 150, sortable: true, scopedSlots: 'waitAuditNum' },
  { prop: 'auditNum', label: '已审核', labelWidth: 150, sortable: true, scopedSlots: 'auditNum' },
  { prop: 'createNum', label: '已生成', labelWidth: 150, sortable: true, scopedSlots: 'createNum' },
  { prop: 'uploadNum', label: '已上报', labelWidth: 150, sortable: true, scopedSlots: 'uploadNum' },
  { key: 'actions', label: '操作', labelWidth: 150, fixed: 'right', scopedSlots: 'actions' },
]

const maturityColumns = [
  { prop: 'no', label: 'No', labelWidth: 10, sortable: false },
  { prop: 'qqdbs', label: subSystem == 'taf' ? '业务申请编号' : '请求单标识', labelWidth: 150, sortable: true },
  { prop: 'zh', label: '开户账号', labelWidth: 150, sortable: true },
  { prop: 'controlDateStart', label: '申请控制开始时间', labelWidth: 150, sortable: true },
  { prop: 'controlDateEnd', label: '申请控制结束时间', labelWidth: 150, sortable: true },
  { prop: 'rest', label: '申请控制剩余时间', labelWidth: 150, sortable: true },
  { prop: 'businessDate', label: '业务时间', labelWidth: 150, sortable: true },
]

const maturityColumns_zgfy = [
  { prop: 'no', label: 'No', labelWidth: 10, sortable: false },
  { prop: 'qqdbs', label: '请求单标识', labelWidth: 150, sortable: true },
  { prop: 'rwlsh', label: '控制请求单号', minWidth: 150, sortable: true },
  { prop: 'zh', label: '开户账号', labelWidth: 150, sortable: true },
  { prop: 'controlDateStart', label: '申请控制开始时间', labelWidth: 150, sortable: true },
  { prop: 'controlDateEnd', label: '申请控制结束时间', labelWidth: 150, sortable: true },
  { prop: 'rest', label: '申请控制剩余时间', labelWidth: 150, sortable: true },
  { prop: 'businessDate', label: '业务时间', labelWidth: 150, sortable: true },
]

const maturityColumns_5 = [
  { prop: 'no', label: 'No', labelWidth: 10, sortable: false },
  { prop: 'qqdbs', label: '请求单标识', labelWidth: 150, sortable: true },
  { prop: 'rwlsh', label: '任务流水号', minWidth: 150, sortable: true },
  { prop: 'zh', label: '开户账号', labelWidth: 150, sortable: true },
  { prop: 'controlDateStart', label: '申请控制开始时间', labelWidth: 150, sortable: true },
  { prop: 'controlDateEnd', label: '申请控制结束时间', labelWidth: 150, sortable: true },
  { prop: 'rest', label: '申请控制剩余时间', labelWidth: 150, sortable: true },
  { prop: 'businessDate', label: '业务时间', labelWidth: 150, sortable: true },
]

if (defaultSystemValue) {
  columns.unshift({ prop: 'reportName', label: '功能', labelWidth: 150, sortable: true })
  if (getSubSystem() === 'taf') {
    columns = columns.filter((item) => item.prop != 'createNum')
  }
} else {
  columns.shift({
    prop: 'subModuleName',
    label: '子模块',
    labelWidth: 150,
    sortable: true,
    scopedSlots: 'subModuleName',
  })
  columns.unshift({ prop: 'subSystemName', label: '系统', labelWidth: 150, sortable: true })
}

const searchFormItems = [
  {
    prop: 'searchTime',
    label: '查控日期',
    labelWidth: 80,
    inputType: {
      tag: 'date-picker',
      type: 'daterange',
      style: 'width: 220px',
      rangeSeparator: '-',
      format: 'YYYY-MM-DD',
      valueFormat: 'YYYY-MM-DD',
    },
    rules: [{ required: true, message: '查控日期不能为空' }],
  },
  {
    prop: 'branchCode',
    label: '机构',
    labelWidth: 40,
    inputType: {
      tag: 'tree-select',
      options: 'branchCode',
      multiple: true,
      showCheckbox: true,
      checkStrictly: true,
      collapseTags: true,
      maxCollapseTags: 1,
    },
  },
  {
    prop: 'businessLine',
    label: '业务线',
    labelWidth: 40,
    inputType: {
      tag: 'select',
      options: 'businessLine',
    },
  },
  {
    prop: 'subSystem',
    label: '系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
      disabled: defaultSystemValue ? true : false,
    },
  },
]

const showControlNotification = () => {
  if (subSystem === 'ybjh' || subSystem === 'szmz' || subSystem === 'jyt') {
    return false
  }
  return true
}

const queryFormItems = [
  {
    prop: 'searchTime',
    label: '数据日期',
    labelWidth: 80,
    inputType: {
      tag: 'date-picker',
      type: 'daterange',
      style: 'width: 220px',
      rangeSeparator: '-',
      format: 'YYYY-MM-DD',
      valueFormat: 'YYYY-MM-DD',
    },
    rules: [{ required: true, message: '数据日期不能为空' }],
  },
  {
    prop: 'subSystem',
    label: '系统',
    inputType: {
      tag: 'select',
      options: 'systemCode',
      disabled: defaultSystemValue ? true : false,
    },
  },
]

const tableItems = [
  { prop: 'subModuleName', label: '子模块', labelWidth: 150, sortable: true, scopedSlots: 'subModuleName' },
  { prop: 'waitQueryNum', label: '待匹配', labelWidth: 150, sortable: true, scopedSlots: 'waitQueryNum' },
  { prop: 'notMatchedNum', label: '未匹配到', labelWidth: 150, sortable: true, scopedSlots: 'notMatchedNum' },
  { prop: 'pendingNum', label: '待处理', labelWidth: 150, sortable: true, scopedSlots: 'pendingNum' },
  { prop: 'processedNum', label: '已处理', labelWidth: 150, sortable: true, scopedSlots: 'processedNum' },
  { key: 'actions', label: '操作', labelWidth: 150, fixed: 'right', scopedSlots: 'actions' },
]

const jytScopedSlotsArr = [
  { prop: 'waitQueryNum', scopedSlots: 'waitQueryNum' },
  { prop: 'notMatchedNum', scopedSlots: 'notMatchedNum' },
  { prop: 'pendingNum', scopedSlots: 'pendingNum' },
  { prop: 'processedNum', scopedSlots: 'processedNum' },
  { prop: 'subModuleName', scopedSlots: 'subModuleName' },
]

const getQueryFormItems = () => {
  if (subSystem === 'jyt') {
    return queryFormItems
  } else {
    if (subSystem === 'ybjh') {
      return [...searchFormItems.slice(0, 2), ...searchFormItems.slice(3)]
    }
    return searchFormItems
  }
}
const getTableItems = () => {
  if (subSystem === 'jyt') {
    return tableItems
  } else {
    return columns
  }
}

const getScopedSlotsArr = () => {
  if (subSystem === 'jyt') {
    return jytScopedSlotsArr
  } else {
    return scopedSlotsArr
  }
}
const showJytFormItems = () => {
  if (subSystem === 'jyt') {
    return true
  }
}
</script>

<style scoped>
.card {
  /*background-color: #409eff;*/
  background-color: white;
  border-radius: 0.5rem;
  color: black;
  padding: 10px 15px;
  box-shadow: 0 0 0.25rem 0 rgba(0, 0, 0, 0.2);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card:hover {
  background-color: white;
}

.no_zero {
  color: #5c51e3;
  font-weight: bold;
  font-size: 14px;
}

.card-title {
  text-align: left;
  font-size: 14px;
  color: #333333;
  margin-top: 0;
  margin-bottom: 0;
}

.card-content {
  text-align: left;
  font-weight: bold;
  font-size: 24px;
  color: #5c51e3;
  margin-top: 8px;
  margin-bottom: 0;
}

.card-image {
  width: 42px; /* 设置图片宽度为 42 像素 */
  height: 42px; /* 设置图片高度为 42 像素 */
}

.card-image2 {
  width: 14px; /* 设置图片宽度为 42 像素 */
  height: 14px; /* 设置图片高度为 42 像素 */
}

.divider-title {
  flex-grow: 0;
  flex-shrink: 0;
  flex-basis: auto;
  font-weight: bold;
  font-size: 14px;
  color: #5c51e3;
  font-weight: bold;
}

.divider {
  flex: 1;
  margin-left: 0.5rem;
}
</style>
