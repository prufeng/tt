import {RS} from 'riking-ui'

export function statisticTotal(data: {}): Promise<RS> {
    return service({
        url: `/todo/statisticTotal`,
        method: 'POST',
        data,
    })
}

export function statisticDetail(data: {}): Promise<RS> {
    return service({
        url: `/todo/statisticDetail`,
        method: 'POST',
        data,
    })
}

export function statisticZgfy(data: {}): Promise<RS> {
    return service({
        url: `/todo/statisticZgfy`,
        method: 'POST',
        data,
    })
}

export function maturity(data: {}): Promise<RS> {
    return service({
        url: `/todo/maturity`,
        method: 'POST',
        data,
    })
}

// 以下为taf专用, 一期的可以沿用原有的统计，
export function maturityTaf(data: {}): Promise<RS> {
    return service({
        url: `/taf/maturity`,
        method: 'POST',
        data,
    })
}

// 惩戒到期提醒
export function maturityCJ(data: {}): Promise<RS> {
    return service({
        url: `/taf/maturityCJ`,
        method: 'POST',
        data,
    })
}

// 以下为taf专用, 一期的可以沿用原有的统计，
export function zhangHuaMaturityTaf(): Promise<RS> {
    return service({
        url: `/ControlLedger/maturity`,
        method: 'POST',
    })
}




export function statisticTotalTaf(data: {}): Promise<RS> {
    return service({
        url: `/taf/statisticTotal`,
        method: 'POST',
        data,
    })
}

export function statisticDetailTaf(data: {}): Promise<RS> {
    return service({
        url: `/taf/statisticDetail`,
        method: 'POST',
        data,
    })
}
