<!--惩戒到期提醒-->
<template style="margin-top: 50px">
  <div style="display: flex; align-items: center">
    <img class="card-image2" src="./待办明细.png" alt="惩戒到期提醒" />
    <el-text size="large" class="divider-title">惩戒到期提醒</el-text>
    <el-divider class="divider" />
  </div>

  <rk-page-table
      :data="data"
      :columns="columns"
      :loading="loading"
      hidden-table-tools>

  </rk-page-table>
</template>


<script setup lang="ts">
import {ref} from "vue";
import {ElDivider, ElText} from "element-plus";
import {RkPageTable} from "riking-ui";
import {maturityCJ} from "@/views/waitToDo/api";

const data = ref<any[]>([])
const loading = ref(false) // 加载状态

const props = defineProps([""])
const emits = defineEmits(['update']);


onMounted(async () => {

})

const search = async (params: {}) => {
  loading.value = true;
  const result = await maturityCJ(params);
  data.value = result.data;
  loading.value = false;
}

defineExpose({search})

const columns = [
  { prop: 'no', label: 'No', labelWidth: 10, sortable: false },
  { prop: 'applicationID', label: '业务申请编号', labelWidth: 150, sortable: true },
  { prop: 'dobjectId', label: '惩戒对象唯一标识', labelWidth: 150, sortable: true },
  { prop: 'dobjectName', label: '惩戒对象名称', labelWidth: 150, sortable: true },
  { prop: 'startDate', label: '惩戒开始时间', labelWidth: 150, sortable: true },
  { prop: 'endDate', label: '惩戒结束时间', labelWidth: 150, sortable: true },
  { prop: 'rest', label: '惩戒到期剩余时间', labelWidth: 150, sortable: true },
  { prop: 'businessDate', label: '业务时间', labelWidth: 150, sortable: true },
]

</script>



<style scoped>
.divider-title {
  flex-grow: 0;
  flex-shrink: 0;
  flex-basis: auto;
  font-weight: bold;
  font-size: 14px;
  color: #5c51e3;
  font-weight: bold;
}


.divider {
  flex: 1;
  margin-left: 0.5rem;
}
</style>