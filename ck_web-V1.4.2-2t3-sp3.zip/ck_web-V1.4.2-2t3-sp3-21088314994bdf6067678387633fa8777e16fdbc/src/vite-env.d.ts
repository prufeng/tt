/// <reference types="vite/client" />

declare module '*.vue' {
  import type { DefineComponent } from 'vue'
  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/ban-types
  const component: DefineComponent<{}, {}, any>
  export default component
}

declare module 'element-plus/dist/locale/zh-cn.mjs'
declare module 'element-plus/dist/locale/en.mjs'

interface ImportMetaEnv {
  // axios 访问 后端接口 需要代理的 URL 前缀,   vite.config.server.proxy
  readonly VITE_CONFIG_SERVER_PROXY_URL_PREFIX: string
  // 被代理的 后端服务地址， vite.config.server.proxy
  readonly VITE_CONFIG_SERVER_PROXY_TARGET: string
  // vite 配置 公共基础路径， 以及 vue-router 的路由前缀， vite.config.base => import.meta.env.BASE_URL
  readonly VITE_CONFIG_BASE: string
  // vite 配置 打包后的 输出路径（相对于 项目根目录), vite.config.build.outDir
  readonly VITE_CONFIG_BUILD_OUT_DIR: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
