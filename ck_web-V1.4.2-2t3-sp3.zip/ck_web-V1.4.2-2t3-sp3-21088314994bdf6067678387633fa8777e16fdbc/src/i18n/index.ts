import { createI18n } from 'vue-i18n'
import { getLang, setLang } from 'riking-layout'
// import en from '../locales/en.json'
// import zh from '../locales/zh.json'

const localPathPrefix = '../locales/'
// import i18n resources
// https://vitejs.dev/guide/features.html#glob-import
const messages = Object.fromEntries(
  Object.entries(import.meta.glob('../locales/*.json', { eager: true })).map(
    ([key, value]) => {
      //   const yaml = key.endsWith('.json')
      return [key.slice(localPathPrefix.length, -5), (value as any).default]
    },
  ),
)

const locale = (() => {
  !getLang() ? setLang('zh_CN') : null
  return getLang()
})()

// https://github.com/intlify/vite-plugin-vue-i18n
const i18n = createI18n({
  // 使用 Composition API 模式，则需要将其设置为false
  legacy: true,
  // 全局注入 $t 函数
  globalInjection: true,
  fallbackLocale: 'zh_CN', //没有英文的时候默认中文语言
  locale,
  messages,
})

export default i18n
