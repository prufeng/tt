import {defineStore} from "pinia";
import {loadDict} from "@/apis/dictApi";
import {RS} from "riking-ui";

export interface IDict {
    dict: {}
}

export default defineStore({
    id: 'dictStore',
    state: () => {
        return {
            dict: {}
        }
    },

    getters: {
        getDict: async (state) => {
            if(Object.keys(state.dict).length === 0) {
                const res = await loadDict();
                console.log('100')
                return res.data;
            }else {
                console.log('200')
                return state.dict;
            }
        }
    },

    actions: {
        loadDict() {
            return new Promise<RS>(async (resolve, reject) => {
                try {
                    const res = await loadDict();
                    // this.$patch({dict: res.data})
                    this.dict = res.data
                    resolve(res);
                    return res;
                } catch (error) {
                    reject(error);
                }
            })
        }

        // async loadDict() {
        //     const result = await loadDict();
        //     this.$patch({dict: result.data})
        //     return result.data;
        // }
    }
})