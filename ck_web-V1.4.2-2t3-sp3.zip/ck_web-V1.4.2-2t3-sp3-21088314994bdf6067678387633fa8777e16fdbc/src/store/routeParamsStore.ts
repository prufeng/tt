

export interface RouteParamsState {
    params: {}
}

export default  defineStore({
    id: 'routeParamsStore',
    state: () => {
        return {
            params: {}
        }
    },
    actions: {
        setParams(params: {}) {
            this.params = params;
        },

        getParams() {
            return this.params;
        }
    }

})