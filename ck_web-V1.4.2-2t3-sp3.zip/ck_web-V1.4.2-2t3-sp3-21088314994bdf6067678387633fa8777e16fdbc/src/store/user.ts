/* eslint-disable @typescript-eslint/no-unused-vars */
import {RouteRecordRaw} from 'vue-router'
import {setToken, getToken, removeToken, setRefreshToken, removeRefreshToken} from '@/utils/token'
import {login, logout, getUserResources, getCurrentBizData, loadUserSystems, accessToken} from '@/apis/oauth'
import {encrypt} from '@/utils/encrypt'
// import { conn, close } from '@/utils/sse'

import router, {rootRoute, notFoundRoute, treeData, buildAsyncRoutes, asyncRoutes, resetRouter} from '@/router'
import {
    getModId,
    getSubSystem, getSubSystemList,
    getSubSystemName,
    getCookieSubSystemName,
    getCookieSubSystem,
    setSubSystem,
    setSubSystemList,
    setSubSystemName
} from "@/utils/subSystem";

export interface UserState {
    username: string
    avatar: string
    repoBranchCode: string
    lineCode: string
    routes: RouteRecordRaw[]
    subSystem?: string
    removeRouteFns: Array<() => void>
    sseSource?: EventSource
    historyTabs: any
    showLayout: boolean
}

const sseEvents: any[] = []

function findMenuByModId(data:any, targetModId) {
    let path=null;
    for (let item of data) {
        if (path){
            break
        }
        if (item.children && item.children.length > 0) {
            for (let c of item.children){
                if (c.meta.menuCode.split('_')[0]==targetModId){
                    path= c.path
                    break
                }else {
                    findMenuByModId(c.meta.menuCode.split('_')[0], targetModId,c);
                }
            }

        }
    }
    return path
}

export default defineStore({
    id: 'user', // id必填，且需要唯一
    state: () => {
        const user: UserState = {
            username: '',
            avatar: '',
            repoBranchCode: '',
            lineCode: '',
            routes: [],
            removeRouteFns: [],
            sseSource: undefined,
            subSystem: getSubSystem(),
            historyTabs: {},
            showLayout: true
        }

        return user
    },
    actions: {
        updateShowLayout(showLayout: boolean) {
            this.showLayout = showLayout;
        },
        updateUsername(username: string) {
            this.username = username
        },
        updateRepoBranchCode(repoBranchCode: string) {
            this.repoBranchCode = repoBranchCode
        },
        updateBusinessLineCode(lineCode: string) {
            this.lineCode = lineCode
        },
        loadRepoBranchCode() {
            return new Promise<string>(async (resolve, reject) => {
                try {
                    const res = await getCurrentBizData({disableLogoutConfirm: 'true'})
                    this.repoBranchCode = res.data?.repoBranchCode
                    resolve(this.repoBranchCode)
                } catch (error) {
                    reject(error)
                }
            })
        },
        loadBusinessLineCode() {
            return new Promise<string>(async (resolve, reject) => {
                try {
                    const res = await getCurrentBizData({disableLogoutConfirm: 'true'})
                    this.lineCode = res.data?.lineCode
                    resolve(this.lineCode)
                } catch (error) {
                    reject(error)
                }
            })
        },
        sseConnect() {
            // this.sseSource = conn(this.username)
            sseEvents.forEach((e) => {
                this.sseSource?.addEventListener(e.event, e.listener, e.options)
            })
            sseEvents.length = 0
        },
        addSseEvent(event: string, listener: (this: EventSource, event: MessageEvent) => any) {
            if (this.sseSource) {
                this.sseSource?.addEventListener(event, listener)
            }
            sseEvents.push({event, listener})
        },
        removeSseEvent(event: string, listener: (this: EventSource, event: MessageEvent) => any) {
            if (this.sseSource) {
                this.sseSource?.removeEventListener(event, listener)
            }
            const index = sseEvents.findIndex((e) => e.event == event && e.listener == listener)
            if (index >= 0) sseEvents.splice(index, 1)
        },
        // 切换系统重新加载菜单
        async changeSubSystem(subSystem?: string) {
            this.subSystem = subSystem
            await this.loadUserResources()
        },
        // 缓存切换系统前tabs路由信息
        setPreSubSystemRoute(key: string, tabs: any, path: string) {
            this.historyTabs[key] = {tabs, path};
        },
        // 切系统重置路由相关参数
        resetSubSystem() {
            resetRouter(this.removeRouteFns)
            this.routes = []
            this.removeRouteFns = []
        },
        resetUserData() {
            // close(this.username, this.sseSource)
            this.resetSubSystem()
            this.username = ''
            this.avatar = ''
            this.repoBranchCode = ''
            this.lineCode = ''
            this.sseSource = undefined
            this.historyTabs = {} // 重置tabs历史记录
        },
        accessToken(thirdPartyToken: any) {
            removeToken()
            removeRefreshToken()
            this.resetUserData()
            setToken(thirdPartyToken)

            // return new Promise<any>(async (resolve, reject) => {
            //     try {
            //         removeToken()
            //         removeRefreshToken()
            //         this.resetUserData()
            //         const res = await accessToken({r2token: thirdPartyToken})
            //         setToken(res.data.accessToken)
            //         setRefreshToken(res.data.refreshToken)
            //         resolve(res)
            //     } catch (error) {
            //         reject(error)
            //     }
            // })
        },
        login(data: any) {
            return new Promise<any>(async (resolve, reject) => {
                try {
                    const res = await login({
                        password: data.password,
                        username: data.username,
                        tenantCode: data.tenant,
                        verificationCode: '111111',
                    }, {subSystem: data.subSystem})
                    //res.data = JSON.parse(res['_data'])
                    // const res = { data: { token: '11111' } }
                    setToken(res.data.accessToken)
                    setRefreshToken(res.data.refreshToken)
                    this.resetUserData()
                    resolve(res)
                } catch (error) {
                    reject(error)
                }
            })
        },
        loadUserSystems() {
            return new Promise<any>(async (resolve, reject) => {
                try {
                    const res = await loadUserSystems()
                    //this.subSystem = res.data[res.data.length - 1].value
                    //setSubSystem(this.subSystem || '')
                     //setSubSystemName(res.data[res.data.length - 1].label)
                     //如果SubSystem没值，赋默认值最后一个，如果有值则不赋值
                     if(!getSubSystem()&&!getCookieSubSystem()){
                         setSubSystem(res.data[res.data.length - 1].value || '');
                         this.subSystem = res.data[res.data.length - 1].value|| '';
                         setSubSystemName(res.data[res.data.length - 1].label || '');
                     }

                    setSubSystemList(JSON.stringify(res.data))
                    resolve(res)
                } catch (error) {
                    reject(error)
                }
            })
        },
        loadUserResources() {
            return new Promise<RouteRecordRaw[]>(async (resolve, reject) => {
                try {
                    let subSystem = getSubSystem();
                    //wyh 浏览器打开新的标签页，由于subSystem没值而退出登录
                    if((!subSystem||subSystem=="null")&&!!getSubSystemList()){
                        subSystem=getCookieSubSystem();
                        setSubSystem(subSystem);
                        setSubSystemName(getCookieSubSystemName());
                        this.subSystem=subSystem;
                    }
                    const res = await getUserResources({disableLogoutConfirm: 'true'}, {subSystem})
                    //todo
                    this.username = res.data.username
                    this.avatar = res.data.avatar
                    this.sseConnect()
                    let accessedRoutes = asyncRoutes
                    // if (import.meta.env.PROD) {
                    accessedRoutes = buildAsyncRoutes(treeData(res.data.menuList))
                    // }
                    accessedRoutes = [
                        {
                            ...rootRoute,
                            // redirect: accessedRoutes[0].redirect,
                            redirect: !!findMenuByModId(accessedRoutes,getModId())?findMenuByModId(accessedRoutes,getModId()):accessedRoutes[0].redirect,
                            children: [...accessedRoutes],
                        },
                        notFoundRoute,
                    ]
                    console.log(accessedRoutes)
                    this.routes = accessedRoutes
                    console.log("result.....", res);
                    // 删除动态路由
                    this.removeRouteFns = accessedRoutes.map((item) =>
                        // 添加动态路由
                        router.addRoute(item),
                    )
                    console.log(router.getRoutes())
                    resolve(accessedRoutes)
                } catch (error) {
                    removeToken()
                    reject(error)
                }
            })
        },
        logout() {
            return new Promise<void>(async (resolve, reject) => {
                try {
                    await logout({disableLogoutConfirm: 'true'})
                    this.resetUserData()
                    resolve()
                } catch (error) {
                    reject(error)
                } finally {
                    removeToken()
                    removeRefreshToken()
                }
            })
        },
    },
})
