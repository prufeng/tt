export {}

declare global {
  interface Window {
    g: any
    eventCenterForAppNameVite: any
  }
}
