import {RS} from "riking-ui";
import service from "@/utils/request";

export function loadDict(): Promise<RS> {
    return service({
        url: '/dict/getDictList',
        method: 'POST',
    })
}