import { RS } from 'riking-ui'
import service from '../utils/request'
import { AxiosRequestHeaders } from 'axios'

export interface TokenInfo {
  accessToken: string
  refreshToken: string
  token: string
}

export function accessToken(data: any): Promise<RS<TokenInfo>> {
  return service({
    url: '/r2oauth/accessToken',
    method: 'POST',
    data,
  })
}

export function login(data: any, params={}): Promise<RS<TokenInfo>> {
  return service({
    url: '/oauth/login',
    method: 'POST',
    data,
    params,
    headers: {
      'Content-Type': 'application/json',
    },
  })
}

export function logout(headers: AxiosRequestHeaders) {
  return service({
    url: '/oauth/logout',
    method: 'POST',
    headers,
  })
}

export function loadUserSystems(headers: AxiosRequestHeaders) {
  return service({
    url: '/oauth/getUserSubSysList',
    method: 'POST',
    headers,
  })
}

export function getUserResources(headers: AxiosRequestHeaders, params={}) {
  return service({
    url: '/oauth/getUserResources',
    method: 'POST',
    params,
    headers,
  })
}

export function findAllTenantList(data = {}) {
  return service({
    url: '/oauth/selectTenantList',
    method: 'post',
    data,
  })
}

export function getCurrentBizData(headers: AxiosRequestHeaders): Promise<RS<any>> {
  return service({
    url: '/oauth/rkSysBizData/getCurrentBizData',
    method: 'POST',
    headers,
  })
}
