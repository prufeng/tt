import service from '../utils/request'

export function getUserInfo() {
  return service({ url: '/oauth/getUserInfo', method: 'GET' })
}

export function updateUserInfo(data: any) {
  return service({ url: '/oauth/updateUserInfo', method: 'POST', data })
}

export function updateUserPass(data: any) {
  return service({ url: '/oauth/userModifyPwd', method: 'POST', data })
}

export function findUserBranchDict() {
  return service({ url: '/oauth/findUserBindRepoBranchBySubSys', method: 'POST' })
}

export function findUserBizLineDict() {
  return service({ url: '/oauth/findUserBindBusLineList', method: 'POST' })
}
