#############################################################
#This script converts alerts from Bridger4 to Bridger5  using the Data Bridge API
#Multi-threading version
#############################################################

<#
Section 0: Initializing the script
#>

cls

#start timer to show total elapsed time after script is finished

$totalelapsedtimer = [System.Diagnostics.Stopwatch]::StartNew()
$now = Get-Date

#############################################################
#set folder path where script and config file are stored, where log will be written
$folderpath = $PSScriptRoot

#############################################################
#initialize variables needed to connect to data bridge successfully, set default values 

$user = ''
$password = ''

#default dates
$today = Get-Date
$date_created_from = '2001-01-01'     				#records search to start with records with this date or newer
$date_created_to = $today.ToString("yyyy-MM-dd")    #records search to end with records with this date or older

$server_name = ''
$customer_ID = ''
$user_ID = ''

$all_divisions = 'false'               				#'true' to retrieve alerts from all divisions, false (default value) requires division IDs to be specified as an array
$division_ids= ''

$save_results = 'false'								#'true' to save converted results, 'false' to just test
$last_record = 0									#0 for first time run, will be set in .config file if different start record is desired
$alert_state = ''	
$order_by = 'ID'

$page_size = 50										#number of records to return per page


############################################
# read config data file for variable values
if ($folderpath.endsWith('\') -eq $false)
{
	$folderpath += '\'
}
$configfile = $folderpath + "DataBridgeConvert.config"

$file_exists = Test-Path -Path $configfile

if ($file_exists -eq $false)
{
	#if there is an error log the error message and terminate the script
	$logstring = "Config file does not exist in expected folder: $configfile `n`nPlease put the folder in the specified location and run the DataBridgeConvert.ps1 script again.`n"
	$logstring
		
	break script	
}

<#
Section 0 end
#>

<#
Section 1: Loading the values
#>

$configdata = Get-Content $configfile

foreach ($oneline in $configdata)
{
	if ($oneline.indexOf(':') -gt -1)
	{
        $keydata = $oneline.Replace("'", '').Replace('"', '').Split(':')
		
		$onekey = $keydata[0].trim().ToLower()		
        $onedata = $keydata[1].trim()

        if ($onekey -eq 'server name')
        {
            $server_name = $onedata
			if (($server_name -eq 'http') -or ($server_name -eq 'https'))
			{
				$server_name += ':' + $keydata[2]
			}
        }
        elseif  ($onekey -eq 'user')
        {
            $user = $onedata
        }
        elseif  ($onekey -eq 'password')
        {
            $password = $onedata
        }
        elseif  ($onekey -eq 'date created from')
        {
			if ($onedata -ne '')
			{
				$date_created_from = $onedata
			}
        }
        elseif  ($onekey -eq 'date created to')
        {
			if ($onedata -ne '')
			{
				$date_created_to = $onedata
			}
        }
        elseif  ($onekey -eq 'customer id')
        {
            $customer_ID = $onedata
        }
        elseif  ($onekey -eq 'user id')
        {
            $user_ID = $onedata
        }
        elseif  ($onekey -eq 'all divisions')
        {
            if ($onedata -ne '')
			{
				$all_divisions = $onedata.ToLower()
			}
        }
        elseif  ($onekey -eq 'division ids')
        {			
            $division_ids = $onedata.Replace(' ', '').Replace('[', '').Replace(']', '')
			$division_ids = '[' + $division_ids + ']'
        }
        elseif  ($onekey -eq 'save results')
        {
			if ($onedata -ne '')
			{
				$save_results = $onedata.ToLower()
			}
        }
        elseif  ($onekey -eq 'last record')
        {
			if ($onedata -ne '')
			{
				$last_record = $onedata
			}
        }
        elseif  ($onekey -eq 'alert state')
        {
			if ($onedata -ne '')
			{
				$alert_state = $onedata.Substring(0,1).ToUpper() + $onedata.Substring(1).ToLower()
			}
        }
        elseif  ($onekey -eq 'test')
        {
			if ($onedata -ne '')
			{
				$test = $onedata.ToLower()
			}
        }
        elseif  ($onekey -eq 'order by')
        {
			if ($onedata -ne '')
			{
				$order_by = $onedata
			}
        }
        elseif  ($onekey -eq 'batch size')
        {
			if ($onedata -ne '')
			{
				$page_size = $onedata
			}
        }
	}
} 

<#
Section 1 end
#>

<#
Section 2: Start logging
#>

#####################################
#log file path and name
$log_start_time = (Get-Date -Format "MM-dd-yyyy-HH-mm-ss")
$logfile = $folderpath + "DataBridge" + $server_name.replace('https://', '').Replace('http://', '') + '-' + $log_start_time + ".log"
$summarylogfile = $folderpath + "DataBridge" + $server_name.replace('https://', '').Replace('http://', '')  + '-' + $log_start_time + "summary.log"

#####################################
#display start time and begin log file
$startlog = "########################################################`r`n#  Data Bridge Log for Data Conversion on Bridger5 server $server_name`r`n########################################################`r`n`r`nStart Time: $now`r`n"

Write-Host $startlog
$startlog | Out-File -Filepath $logfile -Append

<#
Section 2 end
#>

<#
Section 3: Verify variable values
#>

#####################################
#validate data from config file

if ($server_name -eq '')
{
	$logstring = "Valid server name must be provided in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script
}

if ($user -eq '')
{
	$logstring = "Account user name must be provided in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if ($password -eq '')
{
	$logstring = "Account password must be provided in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if ($customer_ID -eq '')
{
	$logstring = "Valid customer ID must be provided in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if (($all_divisions -eq 'false') -and ($division_ids -eq ''))
{
	$logstring = "If All Divisions is 'false', then you must provide at least one Division ID in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script
}

if ($alert_state -ne "")
{
	if (($alert_state.toLower() -ne 'open') -and ($alert_state.toLower() -ne 'closed') -and ($alert_state.toLower() -ne 'unassigned'))
	{
		$logstring = "Invalid Alert State in DataBridgeConvert.config file: $alert_state.  Valid values are 'Open', 'Closed', and 'Unassigned'.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
		$logstring
		$logstring | Out-File -Filepath $logfile -Append
		
		break script
	}
}

if (($customer_ID -match "^[\d]+$") -eq $false)
{
	$logstring = "Invalid Customer ID in DataBridgeConvert.config file: $customer_ID.  Must be a number.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if (($save_results -ne $true) -and ($save_results -ne $false))
{
	$logstring = "Invalid Save Results State in DataBridgeConvert.config file: $save_results.  Must be either 'true' or 'false'.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script		
}

if ($user_ID -ne "")
{
	if (($user_ID -match "^[\d]+$") -eq $false)
	{
		$logstring = "Invalid User ID in DataBridgeConvert.config file: $user_ID.  Must be a number.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
		$logstring
		$logstring | Out-File -Filepath $logfile -Append
		
		break script
	}
}

if (($page_size -match "^[\d]+$") -eq $false)
{
	$logstring = "Invalid Page Size in DataBridgeConvert.config file: $page_size.  Must be a number.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if (($last_record -match "^[\d]+$") -eq $false)
{
	$logstring = "Invalid Last Record in DataBridgeConvert.config file: $last_record.  Must be a number.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

<#
Section 3 end
#>

<#
Section 4: Connection setup
#>

if ($server_name.endsWith('/') -eq $false)
{
	$server_name += '/'
}
$url_base = $server_name + 'LN.Web.Api'

$req = [system.Net.WebRequest]::Create($url_base)
$req.UseDefaultCredentials = $true
try
{
    $res = $req.GetResponse()
}
catch [System.Net.WebException]
{
    $res = $_.Exception.Response
}

$statuscode = [int]$res.StatusCode

if ($statuscode -ne 200)
{
	$logstring = "LN.Web.Api does not exist on the specified server.`r`nCheck the spelling of the server name and verify that it is the correct server.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

#####################################
#set header values, including super user name and password
$header = @{
    "Content-Type" = "application/json";
    "Authorization" = "Basic " + [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($user +":"+$password))

    }

$address = @{
			"Type" = "None";
			"Instance" = "0"
			}

<#
Section 4 end
#>

<#
Section 5: Multi-threading script
#>

#Set up multi-threading
$convert_script = 
{
    param($url,
        $body, 
		$header,
        $logfile,
		$summarylogfile,
        $countdone,
        $page_size
		)
    
	$results = @()
	
    try 
	{
	
		$results = Invoke-RestMethod -Method Post -Uri $url -Body $body -Headers $header
		
        $logstring = ""
		
        foreach ($oneresult in $results)
        {
            $countdone++
			
			if ($oneresult.Id -eq 0)
			{
				$onelog = "Error creating new record from Bridger4 record #" + $oneresult.LegacyResultId + "`r`nBridger5 reported Division: " + $oneresult.DivisionID + "`r`nCheck individual record Bridger4 record number for possible discrepancy with Bridger5 database limits.`r`n`r`n-----------------------------------------------------------------------------------`r`n"
			}
			else
			{
				$onelog = "Record #" + ($countdone + 1) + " converted`r`nBridger4 record #" + $oneresult.LegacyResultId + ", Bridger5 record #" + $oneresult.Id + ", created by " + $oneresult.CreatedBy + "`r`nCreated on " + $oneresult.DateCreated + "`r`nDivision: " + $oneresult.DivisionID + ".`r`n-----------------------------------------------------------------------------------`r`n"
			}
            $logstring += $onelog
        }

        #show data about records processed on screen and write to log	
		if ($logstring.length -gt 0)
		{
			$logstring.trim() | Out-File $logfile -Append
		}
    } 
	catch 
	{
		#if there is an error, log the error message, the ID of the last alert successfully processed, and terminate the script
		$logstring = "Error with record #" + ($countdone + 1)
        $logstring += ". Error: " + $Error[0].Exception.Message
		if (($Error[0].Exception.Message.IndexOf('(50') -eq -1) -and ($Error[0].Exception.Message.IndexOf('SSL/TLS') -eq -1))
		{
			$logstring += "`r`nLast Record Processed Successfully Bridger4 ID#" + $oneresult[0].LegacyResultId
		}
		else
		{
			$logstring += "`r`n"
		}
		$logstring += "`r`n-----------------------------------------------------------------------------------`r`n"
		$logstring
		$logstring | Out-File $logfile -Append
	}

}

<#
Section 5 End
#>

<#
Section 6: Setting up multi-threading
#>

$MaxRunspaces = 10

$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxRunspaces)
$RunspacePool.Open()
$Jobs = New-Object System.Collections.ArrayList

#End set up multi-threading
######################################################################

<#
Section 6 end
#>

<#
Section 7: Getting alert IDs from the file and setting up the body text for the REST call
#>

#####################################
#URL to convert alerts
    
$url_endpoint = '/v1/archiveaearch/convertarchiveresults'
$url = $url_base + $url_endpoint	

$page_number = 0

#if a last record has been specified due to the script being interrupted, 
# processing can be restarted where the previous processing was terminated
# Order By value MUST be the same as in interrupted processing run for records to be retrieved in the same sequence
# this has not been tested as of 8-12-22
if ($last_record -ne 0)
{
	$page_number = [Math]::Floor([int]$last_record / $page_size)
}

$date_created_from = '"DateCreatedFrom": "'+ $date_created_from + '"'
$date_created_to = '"DateCreatedTo": "' + $date_created_to + '"'
$customer_ID = '"CustomerId": "' + $customer_ID + '"'

if ($user_ID -ne "")
{
	$user_ID = '"UserId": "' + $user_ID + '"'
}

$address_info = '"Address": {"Type": "' + $address.Type + '", "Instance": "' + $address.Instance + '"}'

$divstring = '"AllDivisions":"' + $all_divisions + '"'

if ($all_divisions -eq 'false')
{
	$divstring += ', "DivisionIds":' + $division_ids
}

if ($alert_state -ne '')
{
	$alert_state = '"AlertState": "' + $alert_state + '"'
}

$save_results = '"SaveResults": "' + $save_results + '"'
$order_by = '"OrderBy": "' + $order_by + '"'
$this_page_size = '"PageSize": "' + $page_size + '"'

$countdone = 0

$this_body = '{' + $date_created_from + ', ' + $date_created_to + ', ' + $customer_ID + ', ' + $divstring + ', ' + $address_info + ', ' + $save_results + ', ' + $order_by + ', ' + $this_page_size + ', "PageNumber": "##PageNumber##"'
	
if ($user_ID -ne "")
{	
	$this_body += ', ' + $user_ID
}
	
if ($alert_state -ne '')
{
	$this_body += ', ' + $alert_state
}

$this_body += '}'

<#
Section 7 end
#>

<#
Section 8: Looping through alerts, creating threads, sending data to the thread to make the REST call
#>
	
#go through the alerts one by one and use the data bridge to move them to Bridger5
do
{
	$results = @()
    	
    $body = $this_body.replace('##PageNumber##', $page_number)

    #####################################
    #Do first set in main thread, if records are returned process more sets
	try
	{
		Write-Host Checking for records
		$results = Invoke-RestMethod -Method Post -Uri $url -Body $body -Headers $header	
		$displaystring = "Processing alerts " + ($countdone + 1) + " to " + ($countdone + $page_size) + " at " + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss") + "`r`n"
        $displaystring

        $logstring = ""
		
        foreach ($oneresult in $results)
        {
            $countdone++
            $onelog = "Record #" + $countdone + " converted`r`nBridger4 record #" + $oneresult.LegacyResultId + ", Bridger5 record #" + $oneresult.Id + ", created by " + $oneresult.CreatedBy + "`nCreated on " + $oneresult.DateCreated + "`r`nDivision: " + $oneresult.DivisionID + "`r`n-----------------------------------------------------------------------------------`r`n"
            $logstring += $onelog
        }

        #show data about records processed on screen and write to log	
		if ($logstring.length -gt 0)
		{
			$logstring.trim() | Out-File $logfile -Append
		}

		$page_number++
		$countdone += $page_size
	}
	catch
	{
		#if there is an error, log the error message, the ID of the last alert successfully processed, and terminate the script
		$logstring = "Error with record #" + ($countdone + 1)
		$logstring += ". Error: " + $Error[0].Exception.Message
		if (($Error[0].Exception.Message.IndexOf('(50') -eq -1) -and ($Error[0].Exception.Message.IndexOf('SSL/TLS') -eq -1))
		{
			$logstring += "`r`nLast Record Processed Successfully Bridger4 ID#" + $results[0].LegacyResultId + " `r`n"
		}
		$logstring
		$logstring | Out-File $logfile -Append			
	}
	
	Write-Host Processing $MaxRunspaces sets of records

	if ($results.count -gt 0)
	{
		for ($batchcount = 0; $batchcount -lt $MaxRunspaces; $batchcount++)
		{	
			$body = $this_body.replace('##PageNumber##', $page_number)
	
			$PowerShell = [powershell]::Create()
			$PowerShell.RunspacePool = $RunspacePool
			$PowerShell.AddScript($convert_script).AddArgument($url).AddArgument($body).AddArgument($header).AddArgument($logfile).AddArgument($summarylogfile).AddArgument($countdone).AddArgument($page_size) | Out-Null
			   
			$JobObj = New-Object -TypeName PSObject -Property @{
				Runspace = $PowerShell.BeginInvoke()
				PowerShell = $PowerShell  
			}

			$Jobs.Add($JobObj) | Out-Null
			$Jobs[0].PowerShell.EndInvoke($Jobs[0].Runspace) | Out-Null			

            $displaystring = "Processing alerts " + ($countdone + 1) + " to " + ($countdone + $page_size) + " at " + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss") + "`r`n"
            $displaystring

			$page_number++
			$countdone += $page_size
		
		}
	}

}
while ($results.count -gt 0)

<#
Section 8 end
#>

<#
Section 9: Monitoring thread completion
#>

#####################################
# display progress of batches of alerts processed
while ($Jobs.Runspace.IsCompleted -contains $false) 
{

    $jobs_to_complete = ($Jobs.Runspace.IsCompleted | group | where {$_.Name -eq $false}).count
    
    Write-Host $jobs_to_complete sets of $page_size alert conversions left to complete
	Start-Sleep -Milliseconds 10000
}

#####################################
# count number of results in log file for display of records processed
$logfilecontents = Get-Content $logfile

$countresults = ($logfilecontents.count - 6) / 5

<#
Section 9 end
#>

<#
Section 10: Error summary for log file and screen output
#>

#####################################
# write errors listed in log file at bottom of file

$errorcount = 0

$logerror = ""

$logfilecontents = Get-Content $logfile

for ($linecount = 0; $linecount -lt $logfilecontents.count; $linecount++)
{
	
	if ($logfilecontents[$linecount].indexOf('Error') -gt -1)
	{
		
		$logerror += $logfilecontents[$linecount] + ': ' + $logfilecontents[$linecount + 1] + "`r`n----------"
		$errorcount++
		
	}
	
	if ($logfilecontents[$linecount].indexOf('#0') -gt -1)
	{
		
		$logerror += $logfilecontents[$linecount] + ': ' + $logfilecontents[$linecount + 1] + "`r`n----------"
		$errorcount++
		
	}
	
}

$logerror = "`r`n" + $errorcount + " errors:`r`n----------" + $logerror

$logerror
$logerror | Out-File -Filepath $logfile -Append

<#
Section 10 end
#>

<#
Section 11: Epilogue
#>

#####################################
# display and log time statistics from successful conversion process

$now = Get-Date

$totalelapsedtimer.Stop()

$hours = $totalelapsedtimer.Elapsed.Hours
$minutes = $totalelapsedtimer.Elapsed.Minutes
$seconds = $totalelapsedtimer.Elapsed.Seconds
$milliseconds = $totalelapsedtimer.Elapsed.Milliseconds

$endlog = "`r`nTotal Alerts processed: $countresults`r`nEnd Time: $now`nTotal Elapsed Time: : $hours hours, $minutes minutes, $seconds." + $milliseconds + " seconds`r`n`r`n`r`n"
Write-Host $endlog
$endlog | Out-File -Filepath $logfile -Append

<#
Section 11 end
#>

