#############################################################
#This script converts specific alert records based on the Legacy Result ID  using the Data Bridge API
#Multi-threading version
#############################################################

<#
Section 0: Initializing the script
#>

cls

#start timer to show total elapsed time after script is finished

$totalelapsedtimer = [System.Diagnostics.Stopwatch]::StartNew()
$now = Get-Date

#############################################################
#set folder path where script and config file are stored, where log will be written
$folderpath = $PSScriptRoot

#initialize variables needed to connect to data bridge successfully, set default values 

$user = ''
$password = ''

#default dates
$today = Get-Date
$date_created_from = '2001-01-01'     				#records search to start with records with this date or newer
$date_created_to = $today.ToString("yyyy-MM-dd")    #records search to end with records with this date or older

$server_name = ''
$customer_ID = ''
$user_ID = ''

$all_divisions = 'false'               				#'true' to retrieve alerts from all divisions, false (default value) requires division IDs to be specified as an array
$division_ids= ''

$save_results = 'false'								#'true' to save converted results, 'false' to just test
$last_record = 0									#0 for first time run, will be set in .config file if different start record is desired
$alert_state = ''	
$order_by = 'ID'
$alert_id_file = ''

$batch_size = 25									#number of LegacyResultIDs to process per thread

############################################
# read config data file for variable values
if ($folderpath.endsWith('\') -eq $false)
{
	$folderpath += '\'
}
$configfile = $folderpath + "DataBridgeConvert.config"

$file_exists = Test-Path -Path $configfile

if ($file_exists -eq $false)
{
	#if there is an error log the error message and terminate the script
	$logstring = "Config file does not exist in expected folder: $configfile `n`nPlease put the folder in the specified location and run the DataBridgeConvert.ps1 script again.`n"
	$logstring
		
	break script	
}

<#
Section 0 end
#>

<#
Section 1: Loading the values
#>

$configdata = Get-Content $configfile

foreach ($oneline in $configdata)
{
	if ($oneline.indexOf(':') -gt -1)
	{
        $keydata = $oneline.Replace("'", '').Replace('"', '').Split(':')
		
		$onekey = $keydata[0].trim().ToLower()		
        $onedata = $keydata[1].trim()

        if ($onekey -eq 'server name')
        {
            $server_name = $onedata
			if (($server_name -eq 'http') -or ($server_name -eq 'https'))
			{
				$server_name += ':' + $keydata[2]
			}
        }
        elseif  ($onekey -eq 'user')
        {
            $user = $onedata
        }
        elseif  ($onekey -eq 'password')
        {
            $password = $onedata
        }
        elseif  ($onekey -eq 'date created from')
        {
			if ($onedata -ne '')
			{
				$date_created_from = $onedata
			}
        }
        elseif  ($onekey -eq 'date created to')
        {
			if ($onedata -ne '')
			{
				$date_created_to = $onedata
			}
        }
        elseif  ($onekey -eq 'customer id')
        {
            $customer_ID = $onedata.ToLower()
        }
        elseif  ($onekey -eq 'user id')
        {
            $user_ID = $onedata.ToLower()
        }
        elseif  ($onekey -eq 'all divisions')
        {
            if ($onedata -ne '')
			{
				$all_divisions = $onedata.ToLower()
			}
        }
        elseif  ($onekey -eq 'division ids')
        {			
            $division_ids = $onedata.Replace(' ', '').Replace('[', '').Replace(']', '')
			$division_ids = '[' + $division_ids + ']'
        }
        elseif  ($onekey -eq 'save results')
        {
			if ($onedata -ne '')
			{
				$save_results = $onedata.ToLower()
			}
        }
        elseif  ($onekey -eq 'last record')
        {
			if ($onedata -ne '')
			{
				$last_record = $onedata
			}
        }
        elseif  ($onekey -eq 'alert state')
        {
			if ($onedata -ne '')
			{
				$alert_state = $onedata.Substring(0,1).ToUpper() + $onedata.Substring(1).ToLower()
			}
        }
        elseif  ($onekey -eq 'test')
        {
			if ($onedata -ne '')
			{
				$test = $onedata.ToLower()
			}
        }
        elseif  ($onekey -eq 'order by')
        {
			if ($onedata -ne '')
			{
				$order_by = $onedata
			}
        }
		elseif ($onekey -eq 'id file')
		{
			$alert_id_file = $onedata.ToLower()
		}
        elseif  ($onekey -eq 'batch size')
        {
			if ($onedata -ne '')
			{
				$batch_size = $onedata
			}
        }

	}
} 

<#
Section 1 end
#>

<#
Section 2: Start logging
#>

#####################################
#log file path and name
$log_start_time = (Get-Date -Format "MM-dd-yyyy-HH-mm-ss")
$logfile = $folderpath + "DataBridge" + $server_name.replace('https://', '').Replace('http://', '') + '-' + $log_start_time + ".log"

#####################################
#display start time and begin log file
$startlog = "########################################################`r`n#  Data Bridge Log for Data Conversion on Bridger5 server $server_name`r`n########################################################`r`n`r`nStart Time: $now`r`n"

Write-Host $startlog
$startlog | Out-File -Filepath $logfile -Append

<#
Section 2 end
#>

<#
Section 3: Verify variable values
#>

#####################################
#validate data from config file

if ($server_name -eq '')
{
	$logstring = "Valid server name must be provided in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script
}

if ($user -eq '')
{
	$logstring = "Account user name must be provided in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if ($password -eq '')
{
	$logstring = "Account password must be provided in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if ($customer_ID -eq '')
{
	$logstring = "Valid customer ID must be provided in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if (($all_divisions -eq $false) -and ($division_ids -eq ''))
{
	$logstring = "If All Divisions is 'false', then you must provide at least one Division ID in DataBridgeConvert.config file`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script
}

if ($alert_state -ne "")
{
	if (($alert_state.toLower() -ne 'open') -and ($alert_state.toLower() -ne 'closed') -and ($alert_state.toLower() -ne 'unassigned'))
	{
		$logstring = "Invalid Alert State in DataBridgeConvert.config file: $alert_state.  Valid values are 'Open', 'Closed', and 'Unassigned'.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
		$logstring
		$logstring | Out-File -Filepath $logfile -Append
		
		break script
	}
}

if (($customer_ID -match "^[\d]+$") -eq $false)
{
	$logstring = "Invalid Customer ID in DataBridgeConvert.config file: $customer_ID.  Must be a number.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if (($save_results -ne $true) -and ($save_results -ne $false))
{
	$logstring = "Invalid Save Results State in DataBridgeConvert.config file: $save_results.  Must be either 'true' or 'false'.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script		
}

if ($user_ID -ne "")
{
	if (($user_ID -match "^[\d]+$") -eq $false)
	{
		$logstring = "Invalid User ID in DataBridgeConvert.config file: $user_ID.  Must be a number.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
		$logstring
		$logstring | Out-File -Filepath $logfile -Append
		
		break script
	}
}

if (($batch_size -match "^[\d]+$") -eq $false)
{
	$logstring = "Invalid Page Size in DataBridgeConvert.config file: $batch_size.  Must be a number.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

if (($last_record -match "^[\d]+$") -eq $false)
{
	$logstring = "Invalid Last Record in DataBridgeConvert.config file: $last_record.  Must be a number.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

$alert_id_file = $folderpath + $alert_id_file

$file_exists = Test-Path -Path $alert_id_file
if ($file_exists -eq $false)
{
	$logstring = "Alert ID File missing in DataBridgeConvert folder.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script
}

<#
Section 3 end
#>

<#
Section 4: Connection setup
#>

if ($server_name.endsWith('/') -eq $false)
{
	$server_name += '/'
}
$url_base = $server_name + 'LN.Web.Api'

$req = [system.Net.WebRequest]::Create($url_base)
$req.UseDefaultCredentials = $true
try
{
    $res = $req.GetResponse()
}
catch [System.Net.WebException]
{
    $res = $_.Exception.Response
}

$statuscode = [int]$res.StatusCode

if ($statuscode -ne 200)
{
	$logstring = "LN.Web.Api does not exist on the specified server.`r`nCheck the spelling of the server name and verify that it is the correct server.`r`nUnable to continue.  Data Bridge Conversion will now terminate.`r`n`r`n`r`n"
	$logstring
	$logstring | Out-File -Filepath $logfile -Append
		
	break script	
}

#####################################
#set header values, including super user name and password
$header = @{
    "Content-Type" = "application/json";
    "Authorization" = "Basic " + [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($user +":"+$password))

    }

$address = @{
			"Type" = "None";
			"Instance" = "0"
			}

#set up values to be passed to API for count and for converting records

$divstring = '"AllDivisions":"' + $all_divisions + '"'

$customer_ID = '"CustomerId": "' + $customer_ID + '"'

if ($user_ID -ne "")
{
	$user_ID = '"UserId": "' + $user_ID + '"'
}

$address_info = '"Address": {"Type": "' + $address.Type + '", "Instance": "' + $address.Instance + '"}'

<#
Section 4 end
#>

<#
Section 5: Multi-threading script
#>

#Set up multi-threading
$convert_script = 
{
    param($url,
        $one_body, 
		$header,
        $logfile,		
        $countdone,
        $alert_ids
		)
    
    $logstring = ''
	foreach ($one_id in $alert_ids)
	{		
		$results = @()
		if ($one_id.ToString() -match "^[\d]+$")
		{
            try 
		    {
			    $body = $one_body.replace('##LegacyResultID##', $one_id)
			    $oneresult = Invoke-RestMethod -Method Post -Uri $url -Body $body -Headers $header
				
				if ($oneresult.count -gt 0) 
				{
					if ($oneresult.Id -eq 0)
					{
						$onelog = "Error creating new record from Bridger4 record #" + $oneresult.LegacyResultId + "`r`nBridger5 reported Division: " + $oneresult.DivisionID + "`r`nCheck individual record Bridger4 record number for possible discrepancy with Bridger5 database limits.`r`n`r`n-----------------------------------------------------------------------------------`r`n"
					}
					else
					{
						$onelog = "XG4 ID sent to API: " + $one_id + " Record #" + ($countdone + 1) + " converted`r`nBridger4 record #" + $oneresult.LegacyResultId + ", Bridger5 record #" + $oneresult.Id + ", created by " + $oneresult.CreatedBy + "`r`nCreated on " + $oneresult.DateCreated + "`r`nDivision: " + $oneresult.DivisionID + ".`r`n-----------------------------------------------------------------------------------`r`n"
					}
				}
				else
				{
					$onelog = "Error in processing record for Bridger4 #" + $one_id + ".  Complete record not found in Bridger4 database or no response from server.`r`nThis error is most likely part of a failed search that included this XG4 alert ID.`r`nYou may find the results using the run_id from the XG4 XXX_results table and reference that in the XG4 XXX_runs table.`r`nXG4 error messages can be found in the XG4 XXX_watch_list_results table.  Continuing with next Bridger4 ID.`r`n-----------------------------------------------------------------------------------`r`n"
				}
			    $logstring += $onelog
                $countdone++			

		    } 
		    catch 
		    {
			    #if there is an error, log the error message, the ID of the last alert successfully processed, and terminate the script
			    $onelog = "Error with record #" + $one_id
                $onelog += ". Error: " + $Error[0].Exception.Message
				if (($Error[0].Exception.Message.IndexOf('(50') -eq -1) -and ($Error[0].Exception.Message.IndexOf('SSL/TLS') -eq -1))
				{
					$onelog += "`r`nLast Record Processed Successfully Bridger4 ID#" + $oneresult[0].LegacyResultId
				}
				else
				{
					$onelog += "`r`n"
				}
				$onelog += "`r`n-----------------------------------------------------------------------------------`r`n"	
				$logstring += $onelog
				$countdone++
		    	
		    }
	    }
		else
		{
			$onelog = "Error in processing record for Bridger4 #" + $one_id + ".`r`nInvalid alert record number: " + $one_id + ".`r`nContinuing with next Bridger4 ID.`r`n-----------------------------------------------------------------------------------`r`n"
		
			$logstring += $onelog
            $countdone++
		}
    }

	#show data about records processed on screen and write to log	    
	
	$logstring.trim() | Out-File $logfile -Append
		
}

<#
Section 5 End
#>

<#
Section 6: Setting up multi-threading
#>

$MaxRunspaces = 10
$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxRunspaces)
$RunspacePool.Open()
$Jobs = New-Object System.Collections.ArrayList

#End set up multi-threading
######################################################################

<#
Section 6 end
#>

<#
Section 7: Getting alert IDs from the file and setting up the body text for the REST call
#>

#####################################
#URL to convert alerts
$url_endpoint = '/v1/archiveaearch/convertarchiveresults'
$url = $url_base + $url_endpoint	

#####################################
#load the list of specific Bridger4 IDs

Write-Host Loading Alert IDs

$filecontents = Get-Content $alert_id_file -Raw

$alert_ids = $filecontents -Split "`r`n"

#####################################
#get the quantity of specific IDs listed
$max_count = $alert_ids.count

Write-Host Alert IDs Loaded: $max_count

$save_results = '"SaveResults": "' + $save_results + '"'

$countdone = 0
$page_number = 0

#create body to be passed to API
$body = '{' + $customer_ID	
	
if ($user_ID -ne "")
{	
	$body += ', ' + $user_ID
}
	
$body += ', ' + $address_info + ', ' + $save_results + ', "PageSize": "1", "PageNumber": "0", "LegacyResultID": "##LegacyResultID##", ' + $divstring + '}'

<#
Section 7 end
#>

<#
Section 8: Looping through alerts, creating threads, sending data to the thread to make the REST call
#>

#go through the alerts one by one and use the data bridge to move them to Bridger5
do
{

	#process batches of individual alert IDs per thread
	$alert_ids_batch = @()

    Write-Host Selecting alert IDs to process
	
    $last_id = $countdone + ($batch_size - 1)
    if ($last_id -ge $max_count)
	{
		$last_id = $max_count - 1
	}

    $alert_ids_batch = $alert_ids[$countdone..$last_id]
	
    #####################################
    #Do the conversion
	#run sets of the maximum number of threads

	$PowerShell = [powershell]::Create()
	$PowerShell.RunspacePool = $RunspacePool
	$PowerShell.AddScript($convert_script).AddArgument($url).AddArgument($body).AddArgument($header).AddArgument($logfile).AddArgument($countdone).AddArgument($alert_ids_batch) | Out-Null
		
	$JobObj = New-Object -TypeName PSObject -Property @{
		Runspace = $PowerShell.BeginInvoke()
		PowerShell = $PowerShell  
	}

	$Jobs.Add($JobObj) | Out-Null
	$Jobs[0].PowerShell.EndInvoke($Jobs[0].Runspace) | Out-Null
    $displaystring = "Processing alerts " + ($countdone + 1) + " to " + ($countdone + $alert_ids_batch.count) + " at " + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss") + "`r`n"
    $displaystring
		
	$countdone += $alert_ids_batch.count

}
while ($countdone -lt $max_count)

<#
Section 8 end
#>

<#
Section 9: Monitoring thread completion
#>

#####################################
# display progress of batches of alerts processed
while ($Jobs.Runspace.IsCompleted -contains $false) 
{
    
    $jobs_to_complete = ($Jobs.Runspace.IsCompleted | group | where {$_.Name -eq $false}).count
    
    Write-Host $jobs_to_complete sets of $batch_size alert conversions left to complete
	Start-Sleep -Milliseconds 10000
}

<#
Section 9 end
#>

<#
Section 10: Error summary for log file and screen output
#>

#####################################
# write errors listed in log file at bottom of file

$errorcount = 0

$logerror = ""

$logfilecontents = Get-Content $logfile

for ($linecount = 0; $linecount -lt $logfilecontents.count; $linecount++)
{
	
	if ($logfilecontents[$linecount].indexOf('Error') -gt -1)
	{
		
		$logerror += $logfilecontents[$linecount] + ': ' + $logfilecontents[$linecount + 1] + "`r`n----------"
		$errorcount++
		
	}
	
	if ($logfilecontents[$linecount].indexOf('#0') -gt -1)
	{
		
		$logerror += $logfilecontents[$linecount] + ': ' + $logfilecontents[$linecount + 1] + "`r`n----------"
		$errorcount++
		
	}
	
}

$logerror = "`r`n" + $errorcount + " errors:`r`n----------" + $logerror

$logerror
$logerror | Out-File -Filepath $logfile -Append

<#
Section 10 end
#>

<#
Section 11: Epilogue
#>

#####################################
# display and log time statistics from successful conversion process

$now = Get-Date

$totalelapsedtimer.Stop()

$hours = $totalelapsedtimer.Elapsed.Hours
$minutes = $totalelapsedtimer.Elapsed.Minutes
$seconds = $totalelapsedtimer.Elapsed.Seconds
$milliseconds = $totalelapsedtimer.Elapsed.Milliseconds

$endlog = "`r`n$countdone alerts processed.`r`nEnd Time: $now`r`nTotal Elapsed Time: : $hours hours, $minutes minutes, $seconds." + $milliseconds + " seconds`r`n`r`n`r`n"
$endlog
$endlog | Out-File -Filepath $logfile -Append

<#
Section 11 end
#>
